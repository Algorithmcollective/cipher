# Texas CUBI – Training & Attorney General Inquiry Response Kit (MASTER)

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Training Outline & AG Inquiry / Enforcement Response Kit (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This document helps {{ORG_NAME}}:

- Train key teams on CUBI basics and internal biometric procedures.  
- Prepare a **grab‑and‑go package** if the Texas Attorney General (AG) or another regulator asks about biometric practices.[web:37][web:82][web:84][web:88][web:90][web:117][web:127]

---

## 2. CUBI Basics – Training Summary

Key points for short training sessions:

- CUBI covers **capture or use of biometric identifiers for a commercial purpose** in Texas (e.g., fingerprint time clocks, facial recognition for access, voiceprints for authentication).[web:82][web:90][web:100][web:118]  
- Biometric identifiers include retina/iris scans, fingerprints, voiceprints, hand geometry, and face geometry.[web:82][web:100][web:118]  
- Core duties:  
  - Get **informed notice and consent** before capture.  
  - **No sale or lease** of biometric identifiers; only limited disclosures.  
  - Maintain **reasonable security** at least as strong as for other confidential personal data.  
  - **Destroy** identifiers within a reasonable time, and no later than one year after the business purpose expires.[web:82][web:100][web:102][web:105][web:107][web:109][web:127]  
- Enforcement:  
  - Only the Texas AG can enforce CUBI (no private lawsuits).  
  - Penalties up to **25,000 dollars per violation**, and recent Meta/Google settlements show penalties can quickly reach the billions when many scans are involved.[web:37][web:40][web:82][web:84][web:88][web:90][web:103][web:104][web:126][web:127]

---

## 3. Training Outline (Internal)

### 3.1 Audience

- HR and Payroll.  
- IT / Security / Facilities.  
- Site managers / supervisors at locations using biometric systems.

### 3.2 Session Topics (60–90 minutes)

1. **What counts as a biometric identifier under CUBI** and where {{ORG_NAME}} uses it.  
2. **Our Biometric Data Policy & Retention Schedule** – key rules, including no sale and destruction timelines.  
3. **Notice & consent procedures** – new‑hire enrollment, re‑papering existing staff, handling questions.  
4. **Vendor responsibilities** – who our biometric vendors are, what their contracts say, and when to involve Legal/Compliance.  
5. **Incident and complaint handling** – what to do if:  
   - A device misbehaves (e.g., reveals data).  
   - An employee complains about biometric use.  
   - You receive anything from the Texas AG or a lawyer.[web:82][web:100][web:102][web:105][web:107][web:117][web:127]

### 3.3 Training Materials

- Slide deck summarizing CUBI and internal policies.  
- Copies/links to: Biometric Policy, notice, consent forms, and signage.  
- Short FAQ for supervisors (e.g., “Can I require employees to use the time clock?”).

> {{TRAINING_MATERIALS_NOTES}}

---

## 4. AG Inquiry / Enforcement Response Kit – Contents

If {{ORG_NAME}} receives:

- A letter, CID, subpoena, or informal inquiry from the Texas AG about biometrics,  
- Or a serious media/investor question about biometric practices,

the response team should immediately compile and review the following.[web:37][web:82][web:84][web:88][web:90][web:117][web:127]

### 4.1 Core Documents

- Latest **Biometric Systems Inventory** (Deliverable 1).  
- **Biometric Data Policy & Retention Schedule** (Deliverable 2).  
- **Notice & consent templates and executed samples** (Deliverable 3).  
- Any **vendor contracts / addenda** with biometric providers (Deliverable 4).  
- Any **training records** for relevant teams (attendance logs, materials).[web:82][web:100][web:105][web:107][web:117]

### 4.2 Evidence of Compliance in Practice

- Logs or records showing biometric template deletion in line with the retention schedule.  
- Screenshots/photos of biometric signage at time clocks and access points.  
- Sample audit of current enrollees vs. active employees (to show de‑provisioning).  
- Any internal audits or assessments addressing biometric controls.[web:82][web:100][web:105][web:107][web:117][web:127]

> {{EVIDENCE_SOURCES_NOTES}}

---

## 5. Response Playbook – High Level

### 5.1 Initial Triage

When an AG inquiry is received:

1. Immediately notify: {{LEGAL_CONTACT}}, {{PRIVACY_CONTACT}}, {{SECURITY_CONTACT}}.  
2. Preserve all relevant records (legal hold), including vendor communications.  
3. Avoid informal responses; centralize all communications through Legal.[web:37][web:82][web:84][web:88][web:90][web:117][web:127]

### 5.2 Fact Gathering

With Legal:

- Confirm **which systems and time periods** the inquiry covers.  
- Identify **how many individuals and scans** are potentially in scope (to understand exposure).  
- Assess **historic gaps** (e.g., period before CUBI‑aligned consent forms) and any remedial steps already taken.[web:37][web:82][web:84][web:88][web:90][web:126][web:127]

### 5.3 Remediation and Commitments

If issues are identified (e.g., incomplete consent or retention):

- Quickly implement fixes – update forms, accelerate deletion of old templates, tighten vendor contracts.  
- Document remediation with dates, screenshots, redlines, and deployment notes.  
- Prepare a concise narrative explaining what happened, what has changed, and how future compliance will be monitored.[web:84][web:88][web:90][web:117][web:126][web:127]

> {{REMEDIATION_PLAYBOOK_NOTES}}

### 5.4 Messaging and Governance

- Coordinate any employee communications (e.g., FAQ or town‑hall) with HR and Comms.  
- Brief executive leadership and, if applicable, the board or risk committee.  
- Decide who will speak externally (if at all) about the inquiry or any eventual settlement.[web:37][web:83][web:84][web:88][web:117]

---

## 6. Metrics and Continuous Improvement

Track:

- Number of biometric systems, Texas enrollees, and vendor relationships.  
- Completion of annual biometric training for HR/IT/security.  
- Timeliness of deletion after termination/access removal.  
- Any complaints, near‑misses, or incidents involving biometric systems.

Use these metrics to refine policy, training, and vendor oversight.[web:82][web:100][web:105][web:107][web:117][web:127]

> {{METRICS_PLAN_SUMMARY}}

---

## 7. Review and Updates

- Review this training and response kit at least annually or after any AG interaction or major biometric incident.  
- Align updates with changes in CUBI enforcement trends and related Texas privacy laws.

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
