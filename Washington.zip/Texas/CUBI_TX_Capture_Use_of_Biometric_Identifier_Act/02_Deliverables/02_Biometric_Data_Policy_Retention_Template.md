# Texas CUBI – Biometric Data Policy & Retention Schedule (MASTER)

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Biometric Data Policy & Retention Schedule (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This Biometric Data Policy explains how {{ORG_NAME}}:

- Captures, uses, stores, and destroys **biometric identifiers** in Texas.  
- Complies with CUBI requirements regarding notice/consent, no sale/disclosure, security, and retention/destruction.[web:82][web:90][web:100][web:101][web:105][web:107]

This policy applies to biometric identifiers collected in Texas or relating to individuals in Texas.

---

## 2. Scope and Definitions

### 2.1 Biometric Identifiers

For this policy, **biometric identifier** means:

- Retina or iris scan.  
- Fingerprint.  
- Voiceprint.  
- Record of hand or face geometry.

These terms are interpreted consistent with CUBI.[web:82][web:100][web:101][web:105]

### 2.2 Covered Individuals and Systems

This policy applies to:

- {{COVERED_INDIVIDUALS}} (e.g., employees, contractors, etc.).  
- Systems and vendors listed in the Biometric Systems Inventory (Deliverable 1).

---

## 3. Purposes for Biometric Use

{{ORG_NAME}} will only collect and use biometric identifiers for limited, job‑related or security‑related purposes, such as:

- Timekeeping and attendance tracking.  
- Facility or system access control.  
- Other specific, documented purposes approved by {{APPROVAL_ROLE}}.

Biometric identifiers will not be used for general surveillance, marketing, or other incompatible purposes.[web:82][web:100][web:105][web:107][web:117]

> {{PURPOSES_DESCRIPTION}}

---

## 4. Notice and Consent

Before collecting biometric identifiers, {{ORG_NAME}} will:

- Provide a written or electronic **notice** describing:  
  - The type of biometric identifier to be collected.  
  - The purpose(s) of collection and use.  
  - How long the identifier will be stored and when it will be destroyed.  
- Obtain the individual’s **consent** (e.g., signed form or electronic acknowledgment) as required by law and internal policy.[web:82][web:100][web:101][web:102][web:105]

Biometric identifiers will not be collected from an individual in Texas without such notice and consent, except in limited emergency or legally required situations as advised by counsel.

> {{NOTICE_CONSENT_PRACTICE_SUMMARY}}

---

## 5. No Sale / Limited Disclosure

### 5.1 No Sale or Lease

{{ORG_NAME}} will **not sell, lease, or otherwise profit from** biometric identifiers.[web:82][web:100][web:105][web:107]

### 5.2 Limited Disclosure

{{ORG_NAME}} will not disclose biometric identifiers to third parties, except:

- To **service providers** that operate biometric systems on {{ORG_NAME}}’s behalf under written contracts that:  
  - Prohibit sale or unrelated use of biometric identifiers.  
  - Require appropriate security and destruction consistent with this policy.  
- When required by law, subpoena, or court order.  
- With the individual’s consent, where permitted.

> {{DISCLOSURE_PRACTICE_SUMMARY}}

---

## 6. Security of Biometric Identifiers

{{ORG_NAME}} will store, transmit, and protect biometric identifiers using **reasonable care**, and **at least as protective** as for other forms of highly sensitive personal information.[web:82][web:100][web:101][web:105][web:107][web:117]

Controls may include:

- Encryption at rest and in transit for biometric templates.  
- Role‑based access controls, with access limited to those who need it.  
- Logging and periodic review of administrator access and configuration changes.  
- Secure onboarding and offboarding procedures for users with system access.

> {{SECURITY_MEASURES_SUMMARY}}

---

## 7. Retention and Destruction Schedule

### 7.1 General Retention Rule

{{ORG_NAME}} will retain biometric identifiers **only for as long as needed** to fulfill the purpose for which they were collected and will destroy them:

- Within a **reasonable time** after the initial purpose for collecting the biometric identifier has been satisfied, and  
- In all cases, **no later than one year after the date the purpose for collecting the biometric identifier expires**, such as one year after:  
  - Employment or contractual relationship ends, or  
  - The individual’s access to a secured facility/system is permanently revoked.[web:82][web:100][web:102][web:105][web:107][web:109]

### 7.2 System-Specific Retention

Example structure (customize):

| System ID | System / Use | Retention Trigger | Destruction Deadline |
|----------|--------------|-------------------|----------------------|
| B‑01 | {{SYSTEM_1_NAME}} | Termination of employment or change in role removing need for biometric access | Within 30 days of trigger; in no case later than 1 year after separation/change. |
| B‑02 | {{SYSTEM_2_NAME}} | End of access to secure area or removal from pilot | Within 30 days of trigger; in no case later than 1 year after access ends. |

> {{SYSTEM_SPECIFIC_RETENTION_NOTES}}

### 7.3 Destruction Methods

When biometric identifiers are destroyed, {{ORG_NAME}} and its vendors will use methods appropriate for the medium, such as:

- Secure deletion of electronic templates so they cannot be reconstructed.  
- Physical destruction of any hardware or media used solely to store biometric identifiers, where applicable.

Destruction events should be logged with date, system, and responsible party.[web:82][web:100][web:105][web:107][web:109]

> {{DESTRUCTION_METHODS_SUMMARY}}

---

## 8. Roles and Responsibilities

- **Policy Owner:** {{POLICY_OWNER_ROLE}} (e.g., Compliance or HR).  
- **System Owners:** Responsible for ensuring biometric systems follow this policy.  
- **Vendors:** Must comply with contractual biometric data requirements and this policy, where applicable.  
- **Employees:** Must follow procedures for enrollment, use, and reporting issues.

> {{ROLES_RESPONSIBILITIES_DETAIL}}

---

## 9. Training and Awareness

{{ORG_NAME}} will provide training, as appropriate, to HR, IT, security, and other relevant staff on:

- CUBI basics and the importance of biometric data protection.  
- This policy’s requirements, including notice/consent and retention/destruction.  
- How to report issues or suspected violations.

> {{TRAINING_PLAN_SUMMARY}}[web:82][web:100][web:105][web:107][web:117]

---

## 10. Policy Review

This policy will be:

- Reviewed at least **annually**, and  
- Updated as needed to reflect changes in law, technology, or {{ORG_NAME}}’s use of biometrics.

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
