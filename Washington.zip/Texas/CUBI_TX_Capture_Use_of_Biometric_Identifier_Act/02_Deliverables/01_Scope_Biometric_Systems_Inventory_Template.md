# Texas CUBI – Scope & Biometric Systems Inventory Memo (MASTER)

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Scope & Biometric Systems Inventory (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of This Memo

This memo helps {{ORG_NAME}}:

- Determine whether it is capturing or using **biometric identifiers** in Texas in ways that fall under CUBI.  
- Identify biometric systems, vendors, and locations in Texas.  
- Highlight key compliance gaps and enforcement risks so {{ORG_NAME}} can prioritize a CUBI program (policy, notice/consent, retention, vendor controls).[web:82][web:100][web:105][web:107]

It is not legal advice and should be reviewed by qualified counsel before being relied upon.

---

## 2. Overview of CUBI (Plain Language)

CUBI applies to **persons who capture a biometric identifier of an individual for a commercial purpose**, including employers and service providers operating in Texas.[web:82][web:90][web:100]

- **Biometric identifier** (for this memo) includes:  
  - Retina or iris scan.  
  - Fingerprint.  
  - Voiceprint.  
  - Record of hand or face geometry (e.g., some facial recognition, palm/hand geometry readers).[web:82][web:100][web:101][web:105]

Key requirements summarized:

- Provide **notice and obtain consent** before capturing biometric identifiers.  
- Do **not sell, lease, or otherwise disclose** biometric identifiers except in narrow circumstances.  
- Use **reasonable care** to store biometric identifiers, in a manner at least as protective as other confidential personal information.  
- **Destroy** biometric identifiers within a reasonable time, but no later than one year after the purpose of collection expires (e.g., after employment or account closure for many uses).[web:82][web:100][web:102][web:105][web:107][web:109]

Enforcement:

- Texas Attorney General has exclusive enforcement authority.  
- Civil penalty up to **25,000 dollars per violation**, and recent settlements against major tech companies (high nine‑ and ten‑figure amounts) show that Texas is an aggressive biometric enforcer.[web:40][web:82][web:84][web:85][web:88][web:90][web:103][web:104][web:108][web:114]

---

## 3. Organizational Context

### 3.1 Presence in Texas

- Does {{ORG_NAME}} operate facilities in Texas (offices, plants, warehouses, stores, clinics, etc.)?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Does {{ORG_NAME}} have employees or contractors physically working in Texas?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Does {{ORG_NAME}} provide services in Texas that involve customer or visitor identification or authentication?  
  - ☐ Yes  ☐ No  ☐ Unclear  

If any answer is “Yes” or “Unclear,” CUBI may apply.[web:82][web:100][web:102]

### 3.2 Known or Suspected Biometric Uses

Check any that apply in Texas:

- ☐ Fingerprint or palm time clocks for employees.  
- ☐ Fingerprint or palm readers for door or facility access.  
- ☐ Facial recognition for building access or employee check‑in.  
- ☐ Voiceprint authentication (e.g., in call centers).  
- ☐ Customer‑facing kiosks using face or fingerprint recognition.  
- ☐ AI/analytics using face geometry for surveillance, loss prevention, or customer experience.  
- ☐ Other biometric tools: {{OTHER_BIOMETRIC_USES}}[web:82][web:90][web:100][web:101][web:105][web:107]

Brief overview of current understanding:

> {{BIOMETRIC_USE_OVERVIEW}}

---

## 4. Biometric Systems Inventory

List each system or vendor that may involve biometric identifiers in Texas.

| ID | System / Product | Biometric Type | Use Case | Location(s) | Vendor / Owner |
|----|------------------|----------------|----------|-------------|----------------|
| B‑01 | {{SYSTEM_1_NAME}} | {{SYSTEM_1_TYPE}} | {{SYSTEM_1_USE}} | {{SYSTEM_1_LOCATIONS}} | {{SYSTEM_1_VENDOR}} |
| B‑02 | {{SYSTEM_2_NAME}} | {{SYSTEM_2_TYPE}} | {{SYSTEM_2_USE}} | {{SYSTEM_2_LOCATIONS}} | {{SYSTEM_2_VENDOR}} |
| B‑03 | {{SYSTEM_3_NAME}} | {{SYSTEM_3_TYPE}} | {{SYSTEM_3_USE}} | {{SYSTEM_3_LOCATIONS}} | {{SYSTEM_3_VENDOR}} |

---

## 5. CUBI Applicability by System

For each system, indicate whether it likely falls under CUBI’s definition of **biometric identifier** and involves capture or use for a commercial purpose in Texas.

| ID | System / Product | Biometric Identifier? (Y/N/Unclear) | In Texas? (Y/N) | Notes |
|----|------------------|--------------------------------------|-----------------|-------|
| B‑01 | {{SYSTEM_1_NAME}} | {{SYSTEM_1_CUBI_SCOPE}} | {{SYSTEM_1_TX}} | {{SYSTEM_1_NOTES}} |
| B‑02 | {{SYSTEM_2_NAME}} | {{SYSTEM_2_CUBI_SCOPE}} | {{SYSTEM_2_TX}} | {{SYSTEM_2_NOTES}} |
| B‑03 | {{SYSTEM_3_NAME}} | {{SYSTEM_3_CUBI_SCOPE}} | {{SYSTEM_3_TX}} | {{SYSTEM_3_NOTES}} |

Notes should include any factors that might take a system out of scope (e.g., purely non‑identifying analytics) or bring it in (e.g., templates linked to identifiable individuals).[web:82][web:100][web:101][web:105][web:107][web:117]

---

## 6. Current Controls Snapshot

For each CUBI‑relevant system, quickly assess whether the following are in place:

### 6.1 Notice and Consent

- Do individuals receive **clear notice** that a biometric identifier is being captured?  
- Do they provide **consent** (written or electronic) before capture or storage?

Summarize by system:

- B‑01: {{NOTICE_CONSENT_STATUS_1}}  
- B‑02: {{NOTICE_CONSENT_STATUS_2}}  
- B‑03: {{NOTICE_CONSENT_STATUS_3}}[web:82][web:100][web:101][web:102][web:105]

### 6.2 No Sale / Disclosure

- Does {{ORG_NAME}} ever sell, lease, or otherwise disclose biometric identifiers to third parties (beyond service providers needed to operate the system)?  
  - ☐ Yes  ☐ No  ☐ Unclear  

If there is any sharing, describe how it fits within the limited exceptions (e.g., with consent, as required by law, etc.).[web:82][web:100][web:105][web:107][web:117]

> {{SALE_DISCLOSURE_STATUS}}

### 6.3 Security

- Are biometric identifiers protected at least as strongly as other confidential personal information?  
  - Encryption, access controls, segregation, logging.[web:82][web:100][web:105][web:107][web:117]

Summarize key protections:

> {{SECURITY_CONTROLS_SUMMARY}}

### 6.4 Retention and Destruction

- Is there a **written retention and destruction policy** specific to biometric identifiers?  
- Are identifiers destroyed within a reasonable time, and no later than one year after the purpose of collection expires (e.g., termination, end of program, closure of account)?[web:82][web:100][web:102][web:105][web:107][web:109]

Summarize:

> {{RETENTION_DESTRUCTION_STATUS}}

---

## 7. Enforcement and Risk Snapshot

Briefly assess:

- Whether {{ORG_NAME}} operates in sectors or uses technologies that have drawn CUBI enforcement interest (e.g., large‑scale facial recognition, AI‑based analytics, employer biometrics).[web:40][web:82][web:84][web:85][web:88][web:90][web:103][web:104][web:108][web:114]  
- Volume of Texas individuals enrolled in biometric systems.  
- Whether there is any historical use of biometric systems without clear notice/consent or retention rules.

Narrative:

> {{ENFORCEMENT_RISK_SUMMARY}}

---

## 8. Recommended Next Steps (High Level)

Based on this initial scope and inventory:

1. Confirm CUBI applicability and any nuances with counsel.  
2. Draft and adopt a **Biometric Data Policy & Retention Schedule** for CUBI (Deliverable 2).  
3. Implement or update **notice and consent** forms and postings for CUBI‑covered systems (Deliverable 3).  
4. Review and strengthen **vendor contracts and security** for biometric providers (Deliverable 4).  
5. Prepare a short **training and AG‑response kit** for HR/IT/facilities (Deliverable 5).

Owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} |
| {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} |

---

**End of Template**
