# Texas CUBI – Biometric Notice & Consent Package (MASTER)

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Biometric Notice, Consent Forms & Signage (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## PART A – EMPLOYEE BIOMETRIC NOTICE (TEMPLATE)

**Title:** Notice of Collection and Use of Biometric Identifiers (Texas)

{{ORG_NAME}} uses certain technologies that collect **biometric identifiers** of employees who work in Texas. Biometric identifiers may include fingerprints, or records of hand or face geometry, used to identify you.[web:82][web:100][web:102]

We currently use biometric identifiers for the following purposes:

- Timekeeping and attendance (e.g., fingerprint time clocks).  
- Facility or secure‑area access control (e.g., hand or facial‑recognition readers).  
- Any other approved uses listed in {{ORG_BIOMETRIC_POLICY_REFERENCE}}.

We collect and use your biometric identifier solely to verify your identity for these limited, work‑related purposes.[web:82][web:100][web:105]

We will:

- Not sell, lease, or otherwise profit from your biometric identifier.  
- Not disclose your biometric identifier to third parties except to service providers operating these systems for us, as required by law, or with your consent.  
- Protect your biometric identifier using reasonable safeguards at least as strong as those used for other confidential personal information.  
- Destroy your biometric identifier within a reasonable time after the original purpose for collection has been satisfied, and in all cases no later than one year after that purpose expires (for example, after your employment or access need ends), consistent with our Biometric Data Policy & Retention Schedule.[web:82][web:100][web:102][web:105][web:107][web:109]

If you have questions about this notice or our biometric practices, contact {{BIOMETRIC_CONTACT_NAME}}, {{ROLE}}, at {{EMAIL}} / {{PHONE}}.

---

## PART B – EMPLOYEE BIOMETRIC CONSENT FORM (TEMPLATE)

**Title:** Employee Consent to Collection and Use of Biometric Identifiers (Texas)

I, {{EMPLOYEE_NAME}}, acknowledge and agree to the following:

1. I have received and read (or had the opportunity to read) {{ORG_NAME}}’s **Biometric Data Policy & Retention Schedule** and the **Notice of Collection and Use of Biometric Identifiers (Texas)**.[web:82][web:100][web:105][web:120][web:125]

2. I understand that {{ORG_NAME}} and its designated service providers may collect, capture, store, and use my biometric identifier(s), which may include (check all that apply):

   - ☐ Fingerprint  
   - ☐ Hand geometry  
   - ☐ Face geometry  
   - ☐ Other (describe): ______________________

   for the limited purposes of:

   - ☐ Timekeeping and attendance  
   - ☐ Facility or secure‑area access control  
   - ☐ Other (describe): ______________________

3. I understand that {{ORG_NAME}} will **not sell, lease, or otherwise profit from** my biometric identifier, and will not disclose it to third parties except to service providers operating the systems on {{ORG_NAME}}’s behalf, as required by law, or with my consent.[web:82][web:100][web:105][web:107]

4. I understand that {{ORG_NAME}} will retain my biometric identifier only for as long as needed for these purposes and will destroy it within a reasonable time after the purpose has been satisfied and, in all cases, no later than one year after that purpose expires, consistent with the Biometric Data Policy & Retention Schedule.[web:82][web:100][web:102][web:105][web:107][web:109]

5. I understand that I may ask questions about this consent or {{ORG_NAME}}’s biometric practices at any time by contacting {{BIOMETRIC_CONTACT_NAME}} at {{EMAIL}} / {{PHONE}}.

By signing below, I **consent** to {{ORG_NAME}} and its service providers collecting, capturing, storing, and using my biometric identifier(s) as described above and in the Biometric Data Policy & Retention Schedule.

Employee Name: _______________________________  

Employee ID (if applicable): ____________________  

Signature: ____________________________________  

Date: ________________________________________

---

## PART C – OPTIONAL CUSTOMER / VISITOR NOTICE (TEMPLATE)

Use this if you ever deploy customer‑ or visitor‑facing biometric systems (e.g., access kiosks).

**Title:** Notice of Biometric Identifier Collection (Texas Customers/Visitors)

{{ORG_NAME}} uses certain technologies at this location that may collect **biometric identifiers** (such as fingerprint or face‑geometry data) to verify your identity for {{PURPOSES}}.[web:82][web:100][web:119][web:123]

If you choose to use these features, we may collect and use your biometric identifier for:

- {{CUSTOMER_BIOMETRIC_PURPOSES}} (e.g., secure facility access, membership verification).

We will:

- Not sell, lease, or otherwise profit from your biometric identifier.  
- Not disclose it to third parties except to service providers operating these systems for us, as required by law, or with your consent.  
- Protect your biometric identifier and destroy it within a reasonable time after the purpose has been satisfied, and in all cases no later than one year after that purpose expires, consistent with our Biometric Data Policy & Retention Schedule.[web:82][web:100][web:105][web:107][web:109]

If you do not wish to provide a biometric identifier, please speak with a representative to request an alternative process (if available).

Contact for questions: {{BIOMETRIC_CONTACT_NAME}} – {{EMAIL}} / {{PHONE}}.

---

## PART D – SIGNAGE / POSTING TEXT (TEMPLATE)

Place near time clocks, access readers, or kiosks where biometrics are captured.

**Sign Text (Short):**

> **Biometric Notice – Texas**  
> This device collects biometric identifiers (such as fingerprints or face geometry) for timekeeping and/or access control. By using this device, you acknowledge that collection and use are subject to {{ORG_NAME}}’s Biometric Data Policy & Retention Schedule and applicable law.  
> Questions? Contact {{BIOMETRIC_CONTACT_NAME}} at {{EMAIL}} / {{PHONE}}.[web:82][web:100][web:102][web:105]

(Optionally add QR code or URL linking to full notice/policy.)

---

**End of Template**
