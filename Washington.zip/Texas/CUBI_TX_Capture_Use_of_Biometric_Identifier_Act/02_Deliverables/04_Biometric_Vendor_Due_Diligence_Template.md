# Texas CUBI – Biometric Vendor Due Diligence & Contract Controls (MASTER)

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100][web:90]  
**Document Type:** Vendor Due Diligence Questionnaire & Contract Control Checklist (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This template helps {{ORG_NAME}}:

- Evaluate biometric technology vendors (time clocks, access control, AI/vision tools) used in Texas.  
- Embed **CUBI‑aligned requirements** into contracts: notice/consent support, no sale/lease, security, and retention/destruction.[web:82][web:90][web:100][web:105][web:117][web:138]

---

## 2. Biometric Vendor Due Diligence Questionnaire (Template)

Use this for any vendor that will **capture, store, or process biometric identifiers** (e.g., fingerprint templates, face geometry, voiceprints) for {{ORG_NAME}}.

### 2.1 Vendor and Service Overview

- Vendor legal name: {{VENDOR_NAME}}  
- Product/service name: {{PRODUCT_NAME}}  
- Primary contact: {{CONTACT_NAME}}, {{CONTACT_EMAIL}}, {{CONTACT_PHONE}}  
- Description of service (include Texas locations/users):  
  > {{SERVICE_DESCRIPTION}}[web:82][web:100][web:131][web:135]

### 2.2 Biometric Data and Use

- What biometric identifiers does the product capture/process?  
  - ☐ Fingerprint  
  - ☐ Hand geometry  
  - ☐ Face geometry / facial recognition  
  - ☐ Voiceprint  
  - ☐ Other: ____________________

- For what purposes is biometric data used (e.g., timekeeping, access control, authentication)?  
  > {{BIOMETRIC_PURPOSES}}

- Does the product use biometric data **for any secondary purposes** (e.g., training unrelated AI models, analytics beyond the contracted services)?  
  - ☐ Yes  ☐ No  
  If yes, describe and explain how this aligns with contract terms:  
  > {{SECONDARY_USE_DESCRIPTION}}[web:82][web:100][web:105][web:117][web:132]

### 2.3 Storage, Location, and Retention

- Where is biometric data stored (regions, data centers, cloud provider)?  
  > {{STORAGE_LOCATIONS}}  

- How long is biometric data retained by default?  
  > {{DEFAULT_RETENTION}}

- Can {{ORG_NAME}} configure or instruct shorter retention and deletion upon events (e.g., termination, access removal)?  
  - ☐ Yes  ☐ No  
  Details:  
  > {{RETENTION_CONTROL_DETAILS}}[web:82][web:100][web:102][web:105][web:107][web:131]

### 2.4 Security Controls

- Do you encrypt biometric templates/data at rest and in transit?  
  - ☐ Yes  ☐ No  

- What access controls protect biometric data (roles, MFA, logging, periodic reviews)?  
  > {{ACCESS_CONTROLS_SUMMARY}}

- Do you have any relevant certifications or audits (e.g., SOC 2, ISO 27001)?  
  - ☐ SOC 2  ☐ ISO 27001  ☐ Other: __________  ☐ None

- Have you had any material security incidents or regulatory investigations related to biometric data in the last 5 years?  
  - ☐ Yes  ☐ No  
  If yes, provide a brief description:  
  > {{INCIDENT_HISTORY}}[web:82][web:100][web:105][web:117][web:131][web:135][web:137]

### 2.5 Compliance and Contract Commitments

- Will you agree by contract to:  
  - Not **sell, lease, or otherwise profit from** biometric identifiers? ☐ Yes  ☐ No  
  - Use biometric identifiers only to provide services to {{ORG_NAME}} and not for unrelated purposes? ☐ Yes  ☐ No  
  - Comply with applicable biometric privacy laws (including CUBI) and {{ORG_NAME}}’s Biometric Data Policy? ☐ Yes  ☐ No  
  - Destroy biometric data upon {{ORG_NAME}}’s instruction and within specified timelines? ☐ Yes  ☐ No  
  - Notify {{ORG_NAME}} promptly of any security incident or regulatory inquiry involving {{ORG_NAME}}’s biometric data? ☐ Yes  ☐ No[web:82][web:90][web:100][web:124][web:131][web:132][web:136][web:138]

Provide additional compliance information, including any public biometric policy:  
> {{COMPLIANCE_NOTES}}

---

## 3. Biometric Vendor Contract Control Checklist

Use this checklist when drafting or reviewing contracts with biometric vendors.

### 3.1 Data Scope and Purpose

- Contract clearly defines **biometric identifiers** and other personal data processed.  
- Contract limits vendor processing to **specified purposes** (e.g., timekeeping, access control) and prohibits unrelated use (e.g., training general AI models).[web:82][web:100][web:105][web:117][web:132][web:138]

### 3.2 No Sale / Restricted Disclosure

- Express prohibition on vendor **selling, leasing, or profiting from** biometric identifiers.  
- Restrictions on disclosure to third parties except:  
  - Sub‑processors bound to equivalent obligations, or  
  - As required by law (with notice to {{ORG_NAME}} where permitted).[web:82][web:90][web:100][web:124][web:131][web:132][web:138]

### 3.3 Security Obligations

- Minimum security standards for biometric data (e.g., encryption, MFA, access logging, least‑privilege access).  
- Requirement to maintain relevant certifications or equivalent security posture (e.g., SOC 2).  
- Obligation to notify {{ORG_NAME}} promptly of any security incident impacting biometric data and to cooperate in investigation and remediation.[web:82][web:100][web:105][web:117][web:131][web:138]

### 3.4 Retention and Destruction

- Vendor must support {{ORG_NAME}}’s **retention schedule** and destroy biometric identifiers:  
  - Upon {{ORG_NAME}}’s instruction (e.g., employee termination), and  
  - Upon contract termination, within a defined period.  
- Vendor must provide **written confirmation** of destruction (e.g., certificate or log).[web:82][web:100][web:102][web:105][web:107][web:109][web:131][web:138]

### 3.5 Audit and Oversight

- {{ORG_NAME}} has a right to receive security/privacy documentation (e.g., SOC 2, policies) and, where appropriate, to audit or have a third party assess vendor compliance.  
- Vendor must cooperate with {{ORG_NAME}} in responding to regulatory inquiries (e.g., Texas AG) about biometric practices.[web:82][web:100][web:117][web:131][web:136][web:138]

### 3.6 Indemnification / Liability

- Vendor indemnifies {{ORG_NAME}} for breaches of biometric obligations (e.g., sale, misuse, failure to secure or delete biometric data) to an appropriate extent, considering risk.  
- Consider caps that reflect potential CUBI exposure (high per‑violation penalties).[web:82][web:84][web:88][web:100][web:117][web:126][web:138]

> {{CONTRACT_NOTES}}

---

## 4. Internal Responsibilities

- **Vendor Owner (Business/IT):** Completes due diligence questionnaire and ensures ongoing alignment with service needs.  
- **Security/Privacy/Legal:** Reviews questionnaire and contract terms for CUBI alignment.  
- **Compliance:** Keeps records of questionnaires, contracts, and periodic reviews in a central repository.

> {{INTERNAL_PROCESS_SUMMARY}}

---

**End of Template**
