# Texas CUBI – Scope & Biometric Systems Inventory Memo – LoneStar Distribution LLC

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Scope & Biometric Systems Inventory (Example)  
**Organization:** LoneStar Distribution LLC  
**Date:** January 31, 2026  
**Prepared By:** Rachel Kim, Compliance Manager  

---

## 1. Purpose of This Memo

This memo identifies biometric systems used by LoneStar Distribution LLC (“LoneStar”) in Texas, evaluates whether they are covered by CUBI, and highlights key compliance risks and actions for a CUBI program. LoneStar operates warehouses and distribution centers in Texas and uses biometric time clocks and access control at several sites.[web:82][web:90][web:100][web:101][web:105]

---

## 2. Overview of CUBI (Plain Language)

CUBI regulates the **capture of biometric identifiers for a commercial purpose** in Texas.[web:82][web:100]

For LoneStar:

- **Biometric identifiers** include employee fingerprints used for timekeeping, plus hand or face geometry if used for building access.  
- CUBI requires LoneStar to:  
  - Provide notice and obtain consent before capturing biometric identifiers.  
  - Not sell or improperly disclose biometric identifiers.  
  - Use reasonable care and security protections.  
  - Destroy biometric identifiers within a reasonable time, no later than one year after the purpose of capture expires (e.g., after employment ends or the system is decommissioned).[web:82][web:100][web:102][web:105][web:107][web:109]

The Texas Attorney General can seek penalties up to 25,000 dollars per violation, and recent high‑profile settlements with major tech companies (Meta and Google) show the state is actively enforcing CUBI and related laws.[web:40][web:82][web:84][web:85][web:88][web:90][web:103][web:104][web:108][web:114]

---

## 3. Organizational Context

### 3.1 Presence in Texas

- LoneStar operates three warehouses in Texas (Dallas, Houston, San Antonio).  
- Approximately 450 hourly employees and 50 salaried employees are based in Texas.  
- LoneStar does not offer customer‑facing biometric services; biometrics are used internally for workforce management and facility security.

### 3.2 Known or Suspected Biometric Uses

Current uses in Texas:

- Fingerprint time clocks for hourly employees to clock in/out.  
- Badge‑plus‑PIN access for most external doors (no biometrics).  
- Pilot of a facial-recognition‑based access system for one restricted area in the Dallas warehouse, managed by a security vendor.

Biometric uses checklist:

- ☒ Fingerprint time clocks for employees.  
- ☐ Fingerprint door access (not currently used).  
- ☒ Facial recognition for access (restricted area pilot).  
- ☐ Voiceprint authentication.  
- ☐ Customer‑facing biometric kiosks.  
- ☐ AI camera analytics for customer‑facing environments (not used; warehouses only).[web:82][web:90][web:100][web:101][web:105][web:107]

Overview:

> LoneStar’s primary CUBI exposure is employee fingerprint timekeeping, plus a smaller exposure from the facial‑recognition access pilot.

---

## 4. Biometric Systems Inventory

| ID | System / Product | Biometric Type | Use Case | Location(s) | Vendor / Owner |
|----|------------------|----------------|----------|-------------|----------------|
| B‑01 | TimeTrack Fingerprint Time Clocks | Fingerprint templates | Hourly employee timekeeping (clock in/out). | All three Texas warehouses. | TimeTrack Systems Inc. |
| B‑02 | SecureGate FR Access | Face geometry templates | Secure access to high‑value goods cage (pilot). | Dallas warehouse only. | SecureGate Technologies |

---

## 5. CUBI Applicability by System

| ID | System / Product | Biometric Identifier? | In Texas? | Notes |
|----|------------------|-----------------------|----------|-------|
| B‑01 | TimeTrack Fingerprint Time Clocks | Yes – fingerprints are biometric identifiers under CUBI. | Yes – all three TX warehouses. | Employees enroll via fingerprint scan; templates stored by vendor in cloud; used for daily timekeeping. |
| B‑02 | SecureGate FR Access | Likely yes – face geometry used for access. | Yes – Dallas pilot. | Employees enroll face templates for access to secure cage; vendor stores and matches templates. |

Conclusion:

> Both B‑01 and B‑02 are CUBI‑covered systems because they capture and use biometric identifiers of individuals in Texas for commercial, employment‑related purposes.[web:82][web:100][web:101][web:105][web:107]

---

## 6. Current Controls Snapshot

### 6.1 Notice and Consent

- **B‑01 (TimeTrack):**  
  - New‑hire packets include a generic “time clock acknowledgment” form but do not explicitly mention fingerprints, biometric identifiers, retention, or destruction.  
  - Existing wall signage near time clocks notes that “employees must use fingerprint scanners” but does not provide full CUBI‑style notice.

- **B‑02 (SecureGate FR):**  
  - Pilot participants signed an internal security form referencing “photo images and facial recognition for access,” but the form does not clearly explain how long templates are kept or that CUBI applies.

Status:

> Notice and consent are **incomplete/non‑specific** for both systems and should be updated with clear biometric language, purposes, and retention/disposal statements.[web:82][web:100][web:101][web:102][web:105]

### 6.2 No Sale / Disclosure

- LoneStar does not sell or lease biometric identifiers.  
- Vendors (TimeTrack, SecureGate) have access as service providers. Their contracts reference “no sale” in general terms but do not specifically mention CUBI or biometric identifiers.

Status:

> Practice is aligned (no sale/profit), but contracts should be tightened to clearly prohibit biometric data sale or unrelated use and to limit disclosures to permitted exceptions.[web:82][web:100][web:105][web:107][web:117]

### 6.3 Security

- Biometric templates are stored by TimeTrack and SecureGate in their own cloud environments.  
- LoneStar’s vendor security questionnaires require SOC 2 or similar assurance and encryption at rest/in transit.  
- Internally, access to timeclock and access‑control admin portals is restricted to HR and facilities/security managers.

Status:

> Security practices appear reasonable but are documented at the vendor level; LoneStar should confirm that biometric data is treated at least as securely as other confidential personal information and that admin access is tightly controlled.[web:82][web:100][web:101][web:105][web:107][web:117]

### 6.4 Retention and Destruction

- LoneStar has no standalone biometric retention policy.  
- TimeTrack retains fingerprint templates for active employees indefinitely; HR requests deletion on an ad hoc basis after termination.  
- SecureGate’s default is to keep templates until manually removed; pilot data has not yet been purged.

Status:

> There is **no formal CUBI‑aligned retention/destruction schedule**. LoneStar should adopt a policy to destroy biometric identifiers within a reasonable time, and no later than one year after the employment or access purpose ends, and ensure vendors follow it.[web:82][web:100][web:102][web:105][web:107][web:109]

---

## 7. Enforcement and Risk Snapshot

Factors increasing LoneStar’s CUBI risk:

- Use of fingerprint time clocks across multiple Texas sites (hundreds of employees).  
- Historical collection of biometric identifiers without clear, explicit biometric notice and consent forms.  
- Lack of a written biometric retention/destruction policy and consistent deletion workflows.  
- Texas AG’s demonstrated willingness to pursue large CUBI settlements against companies using facial recognition and other biometric technologies.[web:40][web:82][web:84][web:85][web:88][web:90][web:103][web:104][web:108][web:114]

Summary:

> LoneStar has **moderate to high CUBI exposure** due to long‑running fingerprint time clocks and a facial‑recognition pilot. Addressing notice/consent, retention, vendor contracts, and training should be treated as priority compliance work.

---

## 8. Recommended Next Steps (High Level)

1. Confirm CUBI applicability with counsel and align LoneStar’s risk appetite.  
2. Draft and adopt a **Biometric Data Policy & Retention Schedule** for all CUBI‑covered systems, including vendor responsibilities (Deliverable 2).  
3. Implement CUBI‑aligned **notice and consent forms** for employees (and any future customer/visitor uses) and replace legacy time‑clock acknowledgments (Deliverable 3).  
4. Update contracts with TimeTrack and SecureGate to include specific biometric data provisions (no sale/profit, limited disclosure, security, destruction, and audit cooperation) (Deliverable 4).  
5. Develop a short **training module** for HR, facilities, and managers and an **AG inquiry response kit** that compiles this memo, policies, consents, and deletion logs (Deliverable 5).

Owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| Draft Biometric Data Policy & Retention Schedule | Compliance + HR | March 31, 2026 |
| Implement new employee biometric notice/consent forms | HR | April 30, 2026 |
| Update TimeTrack & SecureGate contracts for CUBI | Legal | June 30, 2026 |

---

**End of Example**
