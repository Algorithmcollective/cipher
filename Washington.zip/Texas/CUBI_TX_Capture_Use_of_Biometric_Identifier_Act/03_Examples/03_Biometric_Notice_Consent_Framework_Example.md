# Texas CUBI – Biometric Notice & Consent Package – LoneStar Distribution LLC

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Biometric Notice, Consent Forms & Signage (Example)  
**Organization:** LoneStar Distribution LLC  
**Date:** January 31, 2026  
**Prepared By:** Rachel Kim, Compliance Manager  

---

## PART A – EMPLOYEE BIOMETRIC NOTICE (EXAMPLE)

**Notice of Collection and Use of Biometric Identifiers (Texas)**

LoneStar Distribution LLC (“LoneStar”) uses certain technologies that collect **biometric identifiers** of employees who work in Texas. For LoneStar, biometric identifiers currently include fingerprints and face‑geometry templates used to identify you.[web:82][web:100][web:102]

We use your biometric identifier for:

- **Timekeeping and attendance:** Fingerprint time clocks at our Dallas, Houston, and San Antonio warehouses.  
- **Secure‑area access control (pilot):** Facial‑recognition access to the high‑value goods cage in our Dallas warehouse.

We collect and use your biometric identifier solely to verify your identity for these work‑related purposes, and not for general surveillance or marketing.[web:82][web:100][web:105]

LoneStar will:

- Not sell, lease, or otherwise profit from your biometric identifier.  
- Not disclose your biometric identifier to third parties except:  
  - To TimeTrack Systems Inc. and SecureGate Technologies, which operate these systems for LoneStar under written contracts.  
  - As required by law, warrant, or court order.  
  - With your written consent, where permitted.[web:82][web:100][web:105][web:107][web:117]

We protect biometric identifiers using reasonable safeguards, including encryption and role‑based access to vendor portals, and we treat them at least as securely as other highly sensitive personal information.

We will retain your biometric identifier only as long as needed for timekeeping or access control and will ensure that it is destroyed within a reasonable time after that need ends and, in all cases, **no later than one year after** the purpose for collection has expired (for example, after your employment ends or your secure‑area access is removed), consistent with our Biometric Data Policy & Retention Schedule.[web:82][web:100][web:102][web:105][web:107][web:109]

If you have questions about this notice or LoneStar’s biometric practices, contact:

- Rachel Kim, Compliance Manager  
- Email: privacy@lonestardistribution.com  
- Phone: (555) 555‑0123

---

## PART B – EMPLOYEE BIOMETRIC CONSENT FORM (EXAMPLE)

**Employee Consent to Collection and Use of Biometric Identifiers (Texas)**

I, __________________________________ (“Employee”), acknowledge and agree as follows:

1. I have received and had the opportunity to review LoneStar’s **Biometric Data Policy & Retention Schedule** and the **Notice of Collection and Use of Biometric Identifiers (Texas)**.[web:82][web:100][web:105][web:120][web:125]

2. I understand that LoneStar and its service providers (TimeTrack Systems Inc. and SecureGate Technologies) may collect, capture, store, and use my biometric identifier(s), which may include:

   - ☒ Fingerprint  
   - ☒ Face geometry (for certain roles in Dallas)  
   - ☐ Other: __________________________________

   for the following limited purposes:

   - ☒ Timekeeping and attendance (fingerprint time clocks).  
   - ☒ Facility access control to the high‑value goods cage (facial‑recognition pilot, if my role requires it).  
   - ☐ Other: __________________________________

3. I understand that LoneStar will **not sell, lease, or otherwise profit from** my biometric identifier and will not disclose it to third parties except to the above service providers operating these systems on LoneStar’s behalf, as required by law, or with my consent.[web:82][web:100][web:105][web:107]

4. I understand that LoneStar will retain my biometric identifier only for as long as needed for the above purposes and will destroy it within a reasonable time after the purpose has been satisfied and, in all cases, no later than one year after that purpose expires, as described in LoneStar’s Biometric Data Policy & Retention Schedule.[web:82][web:100][web:102][web:105][web:107][web:109]

5. I understand that I may direct questions about this consent or LoneStar’s biometric practices to the Compliance Manager at privacy@lonestardistribution.com.

By signing below, I voluntarily **consent** to LoneStar and its service providers collecting, capturing, storing, and using my biometric identifier(s) as described above and in LoneStar’s Biometric Data Policy & Retention Schedule.

Employee Name: __________________________________________  

Employee ID (if applicable): _______________________________  

Employee Signature: ______________________________________  

Date: ____________________________________________________

---

## PART C – CUSTOMER / VISITOR NOTICE (EXAMPLE – NOT CURRENTLY USED)

LoneStar does not currently use customer‑ or visitor‑facing biometric systems in Texas. If that changes (for example, secure‑area kiosks for vendors), LoneStar will adapt the customer notice template to:

- Identify the biometric identifier collected.  
- Explain the purpose (e.g., secure facility access).  
- Offer a non‑biometric alternative if feasible.[web:82][web:100][web:119][web:123]

---

## PART D – SIGNAGE / POSTING TEXT (EXAMPLE)

**Sign to Post Near Fingerprint Time Clocks**

> **Biometric Notice – Texas Employees**  
> This time clock uses biometric identifiers (fingerprints) to record time worked. LoneStar Distribution LLC collects and uses your fingerprint for timekeeping only, consistent with its Biometric Data Policy & Retention Schedule and Texas law. If you have questions, contact Privacy & Compliance at privacy@lonestardistribution.com or (555) 555‑0123.[web:82][web:100][web:102][web:105]

**Sign to Post Near SecureGate Facial-Recognition Reader (Dallas)**

> **Biometric Notice – Restricted Access (Texas)**  
> This reader uses facial‑recognition technology to control access to the high‑value goods cage. By using this system, you acknowledge that LoneStar Distribution LLC collects and uses your face‑geometry template for access control, in line with its Biometric Data Policy & Retention Schedule and Texas law. For questions, contact Privacy & Compliance at privacy@lonestardistribution.com.[web:82][web:90][web:100][web:102][web:105]

---

**End of Example**
