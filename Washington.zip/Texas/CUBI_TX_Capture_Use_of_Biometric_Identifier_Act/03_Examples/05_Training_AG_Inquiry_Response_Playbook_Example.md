# Texas CUBI – Training & AG Inquiry Response Kit – LoneStar Distribution LLC

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Training Outline & AG Inquiry / Enforcement Response Kit (Example)  
**Organization:** LoneStar Distribution LLC  
**Date:** January 31, 2026  
**Prepared By:** Rachel Kim, Compliance Manager  

---

## 1. Purpose

This document outlines LoneStar Distribution LLC’s (“LoneStar”) internal training on CUBI and its playbook for responding if the Texas Attorney General inquires about LoneStar’s biometric practices. This complements LoneStar’s Biometric Systems Inventory, Biometric Data Policy & Retention Schedule, and Notice/Consent package.[web:82][web:90][web:100][web:105][web:107][web:117][web:127]

---

## 2. CUBI Basics – Training Summary

LoneStar emphasizes the following to HR, Payroll, Facilities, Security, and site managers:

- CUBI applies because LoneStar captures fingerprint and face‑geometry identifiers of employees in Texas for timekeeping and access control – both “commercial purposes.”[web:82][web:90][web:100][web:118]  
- Biometric identifiers include fingerprints and face geometry (the two modalities LoneStar uses), and, under CUBI, violations can trigger civil penalties up to 25,000 dollars **per violation**.[web:37][web:82][web:84][web:88][web:90][web:118][web:127]  
- Texas has pursued high‑profile CUBI cases against Meta and Google, with settlements exceeding 1 billion dollars, signaling an aggressive enforcement posture.[web:40][web:82][web:84][web:88][web:103][web:104][web:114][web:126][web:127]  
- LoneStar’s program centers on:  
  - Informed notice and signed consent before enrollment.  
  - No sale or unrelated disclosure of biometric identifiers.  
  - Vendor security and contractual controls.  
  - Prompt destruction after employment/access ends, and in all cases within one year of the purpose expiring.

---

## 3. Training Outline (Internal)

### 3.1 Audience

- HR and Payroll staff at Texas locations.  
- Facilities/Security and IT staff who administer TimeTrack and SecureGate.  
- Warehouse/site managers at Dallas, Houston, and San Antonio.

### 3.2 Session Topics

1. **What CUBI is and why it matters** (15 minutes) – overview, penalties, and recent Meta/Google cases.  
2. **LoneStar’s biometric systems** (15 minutes) – TimeTrack fingerprint clocks and SecureGate facial access; where they are deployed and who uses them.  
3. **Policy & retention** (15 minutes) – review of LoneStar’s Biometric Data Policy, with emphasis on no sale, vendor responsibilities, and one‑year maximum retention after employment/access ends.  
4. **Notice & consent workflows** (10–15 minutes) – how HR ensures new hires sign the biometric consent, and how existing staff are re‑papered.  
5. **Offboarding & deletion** (10–15 minutes) – the importance of promptly removing terminated employees and documenting template deletion.  
6. **What to do if something goes wrong** (10 minutes) – reporting issues, complaints, or any communication from the Texas AG.[web:82][web:100][web:102][web:105][web:107][web:117][web:127]

### 3.3 Training Materials

- 15‑slide deck covering the above topics.  
- Copies of biometric notice and consent forms.  
- Short FAQ (“Can employees refuse?”, “What if the device fails?”, “Who can I contact?”).

Attendance is tracked in the HR system.

---

## 4. AG Inquiry / Enforcement Response Kit – Contents

If LoneStar receives a letter or civil investigative demand from the Texas AG about biometrics, the response team will assemble:

### 4.1 Core Documents

- Latest **Biometric Systems Inventory Memo** (TX_CUBI_01_...).  
- **Biometric Data Policy & Retention Schedule** (TX_CUBI_02_...).  
- **Notice & Consent package** (TX_CUBI_03_...) and sample executed employee consents from each Texas site.  
- Vendor contracts or addenda with TimeTrack Systems Inc. and SecureGate Technologies, showing biometric‑specific clauses.  
- Records of annual CUBI/biometric training (rosters, materials).[web:82][web:100][web:105][web:107][web:117][web:127]

### 4.2 Evidence of Implementation

- Deletion logs or screenshots from TimeTrack and SecureGate confirming removal of former employees’ templates, aligned with the retention schedule.  
- Photos of biometric signage at time‑clock locations and the SecureGate reader.  
- A recent internal sample check showing that former Texas employees are no longer enrolled in biometric systems.

---

## 5. Response Playbook – LoneStar

### 5.1 Initial Triage

Upon receipt of any Texas AG inquiry mentioning biometrics:

1. Site manager or recipient immediately forwards the communication to:  
   - General Counsel (or external counsel),  
   - Compliance Manager (Rachel Kim), and  
   - Director of Security.[web:37][web:82][web:84][web:88][web:90][web:117][web:127]  

2. Legal places a **hold** on deletion of any potentially relevant records and instructs vendors to retain relevant logs and configurations.  
3. All external communications with the AG or media go through Legal and designated spokespersons; employees are instructed not to respond individually.

### 5.2 Fact Gathering

Legal and Compliance, with HR and Facilities:

- Identify which systems and sites the inquiry appears to concern (e.g., only fingerprints, or also facial recognition).  
- Estimate how many employees and biometric templates are involved and over what time period.  
- Determine whether any historical gaps existed (e.g., period before the new consent forms and retention policy) and whether remediation already occurred.[web:37][web:82][web:84][web:88][web:90][web:126][web:127]

### 5.3 Remediation and Commitments

If LoneStar finds issues (for example, some legacy employees enrolled without signed biometric consent, or templates retained longer than one year):

- Immediately stop any non‑compliant practice.  
- Correct records (e.g., obtain consents, accelerate deletion of old templates, lock down access).  
- Update vendor instructions and contract terms if needed.  
- Document all fixes (dates, screenshots, updated forms) in a “CUBI Remediation” folder.[web:84][web:88][web:90][web:117][web:126][web:127]

Legal will prepare a written description of these remedial steps to support any potential negotiation or settlement.

### 5.4 Messaging and Governance

- HR and Compliance may issue an internal update to managers explaining that LoneStar is addressing biometric compliance and reiterating expectations.  
- Executive leadership is briefed on potential exposure (number of scans, duration, mitigation steps, and timing).  
- Any external statements (if needed) are coordinated by Legal and Communications to avoid inconsistent messaging.[web:37][web:83][web:84][web:88][web:117]

---

## 6. Metrics and Continuous Improvement

LoneStar will track:

- Number of employees enrolled in biometric systems by site.  
- Timeliness of biometric deletion after termination/access removal (e.g., % deleted within 30 days).  
- Completion rates for annual biometric training.  
- Any biometric‑related complaints or incidents and their resolution.

These metrics will be presented to the Risk Committee at least annually and used to adjust policies, training, and vendor oversight.[web:82][web:100][web:105][web:107][web:117][web:127]

---

## 7. Review and Updates

This kit is reviewed annually by Compliance and Legal, or after any significant AG interaction, biometric incident, or change in law or vendor stack.

Version history:

- Version 1.0 – January 31, 2026 – Initial CUBI training and AG‑response kit adopted for Texas operations.

---

**End of Example**
