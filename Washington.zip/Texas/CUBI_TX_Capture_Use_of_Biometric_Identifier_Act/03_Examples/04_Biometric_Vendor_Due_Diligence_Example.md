# Texas CUBI – Biometric Vendor Due Diligence & Contract Controls – LoneStar Distribution LLC

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100][web:90]  
**Document Type:** Vendor Due Diligence Questionnaire & Contract Control Checklist (Example)  
**Organization:** LoneStar Distribution LLC  
**Date:** January 31, 2026  
**Prepared By:** Rachel Kim, Compliance Manager  

---

## 1. Purpose

This document shows how LoneStar Distribution LLC (“LoneStar”) evaluates and contracts with its biometric vendors—TimeTrack Systems Inc. (fingerprint time clocks) and SecureGate Technologies (facial‑recognition access)—to align with CUBI requirements.[web:82][web:90][web:100][web:105][web:117][web:138]

---

## 2. Biometric Vendor Due Diligence – TimeTrack Systems Inc.

### 2.1 Vendor and Service Overview

- Vendor: TimeTrack Systems Inc.  
- Product: TimeTrack Fingerprint Timekeeping.  
- Description: Cloud‑hosted timekeeping service using fingerprint scanners at LoneStar’s Texas warehouses to authenticate employees clocking in and out.

### 2.2 Biometric Data and Use

- Biometric identifiers: Fingerprint templates (mathematical representations, not raw images).  
- Purpose: Employee identity verification for timekeeping and attendance.  
- Secondary uses: TimeTrack confirms it **does not** use LoneStar fingerprint templates for unrelated analytics or AI model training.[web:82][web:100][web:105][web:117][web:132]

### 2.3 Storage, Location, and Retention

- Storage: Encrypted at rest in a US‑based cloud region; no transfers outside the US.  
- Default retention: Templates remain active until LoneStar flags the employee as terminated or removed.  
- Retention control: Contract addendum now requires TimeTrack to delete templates:  
  - Within 30 days of LoneStar marking the employee inactive, and  
  - In all cases no later than one year after the employee’s separation, consistent with LoneStar’s Biometric Data Policy.[web:82][web:100][web:102][web:105][web:107][web:131]

### 2.4 Security Controls

- Encryption: TLS in transit, AES‑256 at rest.  
- Access: Role‑based admin access, enforced MFA, logging of admin actions.  
- Certifications: SOC 2 Type II report available under NDA.  
- Incidents: Vendor reports no material biometric‑related incidents or regulatory investigations in the past five years.[web:82][web:100][web:105][web:117][web:131][web:135][web:137]

### 2.5 Compliance and Contract Commitments

TimeTrack agrees by contract to:

- Not sell, lease, or otherwise profit from LoneStar’s biometric identifiers.  
- Use biometric data only to provide timekeeping services to LoneStar.  
- Comply with applicable biometric privacy laws, including CUBI, and LoneStar’s Biometric Data Policy and retention/destruction requirements.  
- Delete biometric templates upon LoneStar’s instruction or contract termination and confirm deletion in writing.  
- Notify LoneStar promptly of any security incident or government inquiry involving LoneStar’s biometric data.[web:82][web:90][web:100][web:124][web:131][web:132][web:136][web:138]

---

## 3. Biometric Vendor Due Diligence – SecureGate Technologies

### 3.1 Vendor and Service Overview

- Vendor: SecureGate Technologies.  
- Product: SecureGate FR Access.  
- Description: Facial‑recognition access control system for LoneStar’s Dallas high‑value goods cage.

### 3.2 Biometric Data and Use

- Biometric identifiers: Face‑geometry templates derived from enrollment images.  
- Purpose: Verify authorized employees for cage access; no other use.  
- Secondary uses: Contract states templates are not used to train generalized facial‑recognition models and are not shared with other clients.[web:82][web:100][web:105][web:117][web:132]

### 3.3 Storage, Location, and Retention

- Storage: On SecureGate’s US‑based cloud with encryption.  
- Retention: Templates remain until LoneStar marks users as removed or pilot ends.  
- Retention control: Addendum requires SecureGate to:  
  - Delete templates within 30 days after LoneStar removes access or ends the pilot, and  
  - In all cases no later than one year after access ends.[web:82][web:100][web:102][web:105][web:107][web:131]

### 3.4 Security Controls

- Encryption of templates and communications.  
- Role‑based admin access with MFA.  
- Annual penetration tests; summary reports available on request.  
- No known biometric‑specific regulatory inquiries to date.[web:82][web:100][web:105][web:117][web:131][web:135]

### 3.5 Compliance and Contract Commitments

SecureGate contract includes:

- Explicit ban on sale, lease, or profit from LoneStar biometric identifiers.  
- Limitation of processing to access‑control services for LoneStar.  
- Obligation to comply with CUBI and LoneStar’s retention and destruction rules.  
- Security obligations (encryption, MFA, logging, incident notice).  
- Cooperation with LoneStar in responding to any Texas AG inquiries about the system.[web:82][web:90][web:100][web:124][web:131][web:132][web:136][web:138]

---

## 4. Contract Control Checklist – LoneStar Status

LoneStar applies the following controls for both TimeTrack and SecureGate:

- **Data scope & purpose:** Biometric identifiers (fingerprints, face geometry) defined; use limited to timekeeping and access control.  
- **No sale / restricted disclosure:** Contracts prohibit sale/lease; disclosure limited to sub‑processors under equivalent obligations or legal requirements.  
- **Security:** Minimum controls (encryption, MFA, logging) are spelled out; vendors must provide documentation (e.g., SOC 2).  
- **Retention & destruction:** Contracts reference LoneStar’s Biometric Data Policy; vendors must delete within specific timeframes and confirm in writing.  
- **Audit & oversight:** LoneStar can request security documentation and conduct targeted assessments; vendors must support responses to regulatory inquiries.  
- **Indemnification:** Vendors indemnify LoneStar for breaches of biometric obligations, subject to negotiated caps that reflect the potential per‑scan risk under CUBI.[web:82][web:84][web:88][web:100][web:117][web:131][web:136][web:138][web:126][web:127]

---

## 5. Internal Responsibilities

- HR and Facilities own operational relationships with TimeTrack and SecureGate and ensure enrollment/removal processes are followed.  
- Compliance and Legal review due‑diligence responses and contract terms before onboarding and at renewal.  
- Security reviews vendor security reports and tracks any incidents.

All questionnaires, contracts, and review notes are stored in LoneStar’s “Texas Biometric Compliance – Vendors” SharePoint folder.

---

**End of Example**
