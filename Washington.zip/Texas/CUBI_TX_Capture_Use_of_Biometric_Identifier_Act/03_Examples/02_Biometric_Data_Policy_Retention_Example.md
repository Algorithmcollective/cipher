# Texas CUBI – Biometric Data Policy & Retention Schedule – LoneStar Distribution LLC

**Law:** Texas Capture or Use of Biometric Identifier Act (CUBI), Tex. Bus. & Com. Code § 503.001.[web:82][web:100]  
**Document Type:** Biometric Data Policy & Retention Schedule (Example)  
**Organization:** LoneStar Distribution LLC  
**Date:** January 31, 2026  
**Prepared By:** Rachel Kim, Compliance Manager  

---

## 1. Purpose

This Biometric Data Policy explains how LoneStar Distribution LLC (“LoneStar”) collects, uses, stores, and destroys biometric identifiers of employees in Texas in accordance with CUBI. LoneStar’s current biometric uses in Texas are limited to fingerprint time clocks and a small facial‑recognition access pilot in its Dallas warehouse.[web:82][web:90][web:100][web:101][web:105][web:107]

---

## 2. Scope and Definitions

### 2.1 Biometric Identifiers

For this policy, **biometric identifier** means:

- Fingerprint.  
- Record of face geometry (for the SecureGate access pilot).

LoneStar does not use retina/iris scans or voiceprints at this time.[web:82][web:100][web:101][web:105]

### 2.2 Covered Individuals and Systems

Covered individuals:

- Hourly and salaried employees in Texas who use biometric time clocks or are enrolled in facial‑recognition access.

Covered systems:

- TimeTrack fingerprint time clocks (B‑01).  
- SecureGate facial‑recognition access control for the high‑value goods cage in Dallas (B‑02).

---

## 3. Purposes for Biometric Use

LoneStar uses biometric identifiers solely for:

- **Timekeeping and attendance** – to ensure accurate, efficient, and accountable clock‑in/clock‑out records for hourly employees.  
- **Facility access control** – to manage secure access to a restricted area containing high‑value goods in the Dallas warehouse.

LoneStar does **not** use employee biometric identifiers for general surveillance, marketing, or unrelated analytics.[web:82][web:100][web:105][web:107][web:117]

---

## 4. Notice and Consent

Before enrolling an employee in a biometric system, LoneStar will:

- Provide a written notice explaining:  
  - That the employee’s fingerprint or face geometry template will be captured.  
  - The specific purpose (timekeeping or secure cage access).  
  - How long the data will be stored and when it will be destroyed.  
- Obtain a signed consent form (paper or electronic) from the employee.[web:82][web:100][web:101][web:102][web:105]

New CUBI‑aligned forms will replace legacy time‑clock acknowledgments. Enrollments without such notice/consent will be phased out by re‑papering existing employees under the updated forms.

---

## 5. No Sale / Limited Disclosure

- LoneStar does **not** sell, lease, or otherwise profit from biometric identifiers.  
- TimeTrack Systems Inc. and SecureGate Technologies access biometric templates only as service providers under written contracts.  
- LoneStar will not disclose biometric identifiers to third parties except:  
  - To these service providers under contracts that prohibit sale and unrelated use,  
  - As required by law, warrant, or court order, or  
  - With the employee’s written consent where permitted.[web:82][web:100][web:105][web:107][web:117]

---

## 6. Security of Biometric Identifiers

LoneStar requires that biometric identifiers be stored and protected at least as strongly as other highly sensitive personal information.

Current controls:

- Vendors (TimeTrack and SecureGate) store templates in encrypted form, with SOC 2‑type assurances.  
- Access to vendor admin portals is restricted to HR (for timekeeping) and Facilities/Security (for access control) with strong passwords and MFA.  
- LoneStar’s internal access reviews ensure only appropriate staff retain admin rights.

LoneStar will periodically review vendor security reports and confirm that biometric templates are adequately protected.[web:82][web:100][web:101][web:105][web:107][web:117]

---

## 7. Retention and Destruction Schedule

### 7.1 General Rule

LoneStar will keep biometric identifiers **only as long as necessary** for timekeeping and access control, and will destroy them:

- Within a reasonable time after an employee’s need for the biometric system ends (e.g., termination or role change), and  
- In all cases, **no later than one year after** the purpose of the original collection has expired, in line with CUBI and common biometric‑law practices.[web:82][web:100][web:102][web:105][web:107][web:109]

### 7.2 System-Specific Retention

| System ID | System / Use | Retention Trigger | Destruction Deadline |
|----------|--------------|-------------------|----------------------|
| B‑01 | TimeTrack Fingerprint Time Clocks | Employee’s employment ends, or employee’s role no longer uses clocks. | TimeTrack must delete the employee’s fingerprint template within 30 days of HR marking termination/role change in the HRIS/TimeTrack system, and in all cases no later than 1 year after separation/change. |
| B‑02 | SecureGate Facial-Recognition Access | Employee removed from secure‑cage access list or leaves LoneStar. | SecureGate must delete the employee’s face template within 30 days of removal, and in all cases no later than 1 year after access ends. |

LoneStar’s HR and Facilities teams will run quarterly checks to ensure former employees have been removed from both systems.

### 7.3 Destruction Methods

- For TimeTrack and SecureGate, biometric templates will be deleted using vendor‑provided secure deletion functions such that they cannot be reconstructed.  
- Any backup or export files containing biometric identifiers (if ever used) will be securely deleted or destroyed following vendor and LoneStar security procedures.

Deletion events should be logged with employee ID (or pseudonymous identifier), date of deletion, and system.[web:82][web:100][web:105][web:107][web:109]

---

## 8. Roles and Responsibilities

- **Policy Owner:** Compliance Manager, in coordination with HR and Facilities.  
- **HR:** Manages enrollment and removal of employees from TimeTrack; ensures consent forms are signed and retained.  
- **Facilities/Security:** Manages enrollment and removal for SecureGate; ensures only authorized employees are enrolled.  
- **Legal:** Reviews and updates vendor contracts to include biometric‑specific terms and supports responses to any AG inquiries.  
- **Vendors:** Must follow contractual requirements regarding no sale/use, security, and destruction.

---

## 9. Training and Awareness

LoneStar will provide:

- Brief training to HR, Payroll, Facilities, and site managers on this policy and CUBI basics.  
- Instructions for managers on onboarding/offboarding employees in biometric systems and responding to employee questions.  
- Refreshers if systems or legal requirements change.[web:82][web:100][web:105][web:107][web:117]

---

## 10. Policy Review

This policy will be reviewed annually by the Compliance Manager and updated as necessary.

Version history:

- Version 1.0 – January 31, 2026 – Initial CUBI‑aligned biometric data policy adopted for Texas operations.

---

**End of Example**
