# Law Profile

## Law Name
Texas Capture or Use of Biometric Identifier Act (CUBI)

## Citation
Texas Business & Commerce Code § 503.001

## Status
Enacted

## Effective Date
September 1, 2009

## Regulatory Scope

Applies to persons who:

- Capture a biometric identifier of an individual for a commercial purpose

Biometric identifiers include:

- Retina or iris scan
- Fingerprint
- Voiceprint
- Record of hand or face geometry

Applies broadly to commercial entities operating in Texas.

## Core Obligations

A person may not capture a biometric identifier for a commercial purpose unless the person:

1. Informs the individual before capture
2. Receives the individual’s consent
3. Does not sell, lease, or disclose biometric identifiers except under statutory exceptions
4. Uses reasonable care to store, transmit, and protect biometric identifiers
5. Destroys biometric identifiers within a reasonable time (no later than one year after purpose expires)

## Enforcement Authority

Texas Attorney General

## Penalties

Civil penalty up to:

- $25,000 per violation

No private right of action.

Enforcement is AG-driven.

## Private Right of Action
No

## Tier Classification
Tier 2 – Biometric Commercial Regulation

## Revenue Priority
Medium (Lower than BIPA due to no private lawsuits)

## Target Industries

- Employers using biometric time clocks
- Retail facial recognition
- Security systems providers
- AI-based authentication systems
- Financial institutions using biometrics

## Strategic Positioning

Position as:

Texas Biometric Commercial Use Compliance Program.

Primary risk driver:

AG enforcement and civil penalties.

Lower litigation exposure than Illinois BIPA, but still significant regulatory risk.

## Internal Notes

Primary compliance focus areas:

1. Biometric Capture Inventory
2. Notice & Consent Controls
3. Retention & Destruction Timing
4. Vendor Governance
5. Security Safeguards
6. AG Inquiry Response Readiness

Often bundled with:
- Texas TDPSA
- Colorado Biometric
- Illinois BIPA (multi-state employers)