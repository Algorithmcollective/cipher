# Texas CUBI Discovery Script

Purpose: Gather information needed to prepare Texas biometric compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Scope & Applicability

Say:
“I need to identify any biometric technologies used in Texas.”

Ask:

- Facilities or employees in Texas
- Customer services in Texas
- Biometric use cases (time clocks, access, kiosks, voice auth)
- Systems involved
- Vendors involved
- Biometric types collected
- Populations affected

---

## 🧾 Deliverable: Biometric Inventory & Data Flow

For each system ask:

- Capture method
- Storage location
- Access roles
- Transmission path
- Sharing
- Destruction approach
- Applicability to CUBI

---

## 🧾 Deliverable: Biometric Policy & Retention

Ask:

- Policy exists
- Policy owner
- Approved use cases
- Retention schedule
- Destruction trigger
- Destruction methods
- Public policy location

CUBI requires destruction no later than one year after the purpose expires — your policy template centers on that requirement. :contentReference[oaicite:2]{index=2}

---

## 🧾 Deliverable: Notice & Consent Package

Ask:

- Notice provided before capture
- Consent method
- Consent storage
- Employee vs customer notices
- Signage locations
- Alternative process offered

Your notice template emphasizes identity verification purposes and retention disclosure before collection. :contentReference[oaicite:3]{index=3}

---

## 🧾 Deliverable: Vendor Due Diligence

Ask:

- Vendors handling biometrics
- Data uses
- Storage regions
- Retention controls
- Security controls
- Certifications
- Incident history
- Contract commitments (no sale, deletion, cooperation)

Your vendor template explicitly requires contractual prohibition on selling biometric identifiers and support for retention/destruction. :contentReference[oaicite:4]{index=4}

---

## 🧾 Deliverable: Training & AG Inquiry Readiness

Ask:

- Training audiences
- Training frequency
- Materials used
- Evidence storage
- AG response owner
- Incident escalation process
- Metrics tracked

Your response kit centers on quickly assembling policy, inventory, consent records, vendor contracts, and training evidence if the Texas AG asks questions. :contentReference[oaicite:5]{index=5}

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Texas biometric compliance documentation.”