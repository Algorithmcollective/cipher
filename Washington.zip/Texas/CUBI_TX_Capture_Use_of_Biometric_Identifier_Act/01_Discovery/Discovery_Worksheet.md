# Texas CUBI Discovery Worksheet

---

## Scope

Texas Presence:
Biometric Use Cases:
Systems:
Vendors:
Biometric Types:
Populations:

---

## Inventory & Flow

System:
Capture:
Storage:
Access:
Transmission:
Sharing:
Destruction:
CUBI Applicability:

---

## Policy & Retention

Policy Exists:
Owner:
Approved Uses:
Retention:
Destruction Trigger:
Destruction Methods:
Public Location:

---

## Notice & Consent

Notice Provided:
Consent Method:
Consent Storage:
Employee Notices:
Customer Notices:
Signage:
Alternatives:

---

## Vendors

Vendor:
Data Uses:
Storage Regions:
Retention Controls:
Security Controls:
Certifications:
Incident History:
Contract Commitments:

---

## Training & AG Readiness

Training Audiences:
Frequency:
Materials:
Evidence Storage:
AG Response Owner:
Escalation:
Metrics:

---

## TBD

Item:
Owner:
Notes: