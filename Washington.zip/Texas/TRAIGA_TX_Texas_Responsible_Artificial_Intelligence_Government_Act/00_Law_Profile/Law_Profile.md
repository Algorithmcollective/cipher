# Law Profile

## Law Name
Texas Responsible Artificial Intelligence Governance Act (TRAIGA)

## Citation
Texas Responsible Artificial Intelligence Governance Act (2024)

## Status
Enacted

## Effective Date
January 1, 2026

## Regulatory Scope

Applies to developers and deployers of certain artificial intelligence systems operating in Texas, particularly:

- High-impact AI systems
- AI used in government functions
- AI systems affecting legal rights or access to essential services

Includes obligations for both:

- AI Developers
- AI Deployers

## Core Obligations

Covered entities must:

1. Maintain an AI system inventory
2. Implement a formal AI governance program
3. Conduct risk and impact assessments for high-impact systems
4. Perform data testing and monitoring for accuracy, bias, and reliability
5. Provide transparency notices where required
6. Maintain human review and appeals processes
7. Conduct vendor and third-party due diligence
8. Maintain recordkeeping and documentation
9. Submit sandbox applications and reporting where applicable

## Enforcement Authority

Texas Attorney General

## Penalties

Civil enforcement authority under state law.

Specific penalty structure depends on violation type and applicable enforcement provisions.

No private right of action.

## Private Right of Action
No

## Tier Classification
Tier 1 – State AI Governance Law

## Revenue Priority
Very High (Enterprise + Public Sector)

## Target Industries

- AI developers
- Enterprise AI deployers
- Public sector contractors
- Regulated industries using high-impact AI
- Financial services
- Healthcare systems
- Critical infrastructure operators

## Strategic Positioning

Position as:

Texas Enterprise AI Governance & Risk Management Compliance Program.

TRAIGA establishes structured AI governance expectations similar to emerging state AI acts.

Strong bundling candidate with:

- TDPSA (privacy)
- CUBI (biometrics)
- Colorado AI Act (multi-state AI governance)

## Internal Notes

Primary compliance focus areas:

1. AI Inventory & Classification
2. Governance Program Documentation
3. Risk & Impact Assessment
4. Bias Testing & Monitoring
5. Transparency Controls
6. Human Oversight & Appeals
7. Vendor Risk Management
8. Regulatory Sandbox Engagement
9. Documentation & Enforcement Readiness

Key risk driver:
Failure to operationalize AI governance across enterprise systems.