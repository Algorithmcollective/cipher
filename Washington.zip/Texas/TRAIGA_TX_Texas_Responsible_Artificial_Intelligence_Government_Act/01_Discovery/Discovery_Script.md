# Texas TRAIGA Discovery Script

Purpose: Gather information needed to prepare Texas TRAIGA AI governance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: AI System Inventory & Scope Memo

Say:
“I need to understand every AI system your organization develops, uses, or deploys that affects individuals in Texas.”

Ask:

- Texas business presence or users
- AI systems in use (internal and vendor)
- Business areas using AI
- Systems used for hiring, credit, housing, healthcare, education, essential services
- Systems making or supporting consequential decisions
- Vendor-provided AI tools
- Systems deployed in Texas vs. elsewhere
- Human involvement in decisions
- Volume of Texas individuals impacted
- Planned AI deployments

---

## 🧾 Deliverable: AI Governance Program

Say:
“I want to understand how AI is approved, overseen, and monitored inside your organization.”

Ask:

- AI governance committee or officer
- Roles responsible for AI oversight
- AI intake / approval process
- Classification method (high-impact vs low-impact)
- Meeting cadence
- Policy documentation exists
- Executive or board reporting
- Change management process for AI systems

---

## 🧾 Deliverable: AI Risk & Impact Assessment

Say:
“For systems making consequential decisions, I need to assess risk and document controls.”

Ask:

- Consequential decision types
- Inputs (structured, unstructured, sensitive data)
- Outputs (score, rank, decision)
- Advisory vs decisive system
- Individuals affected categories
- Texas volume per year
- Identified risks (accuracy, bias, privacy, legal, reputational)
- Pre-deployment testing performed
- Ongoing monitoring schedule
- Fairness testing performed
- Proxy feature concerns
- Human oversight process
- Appeals available
- Overall internal risk rating

---

## 🧾 Deliverable: Data, Testing & Monitoring Plan

Say:
“I need to document how AI systems are tested before launch and monitored over time.”

Ask:

- Data sources used
- Data quality controls
- Data minimization practices
- Retention alignment
- Pre-deployment testing methods
- Testing documentation retained
- Monitoring frequency by system type
- Metrics tracked (error rate, selection rate, overrides, complaints)
- Alert thresholds
- Monitoring owner
- Incident detection process
- Incident logging practice

---

## 🧾 Deliverable: Transparency & Notice Package

Say:
“I want to understand how individuals are informed about AI use.”

Ask:

- Website AI disclosure exists
- Hiring / portal notice language
- Chatbot disclosure
- FAQ or email explanation
- Internal response script
- Notice logging practice
- Last update date
- Owner responsible for updates

---

## 🧾 Deliverable: Human Review & Appeals Workflow

Say:
“I need to understand how humans review AI-influenced decisions and how appeals are handled.”

Ask:

- Primary human reviewer role
- Escalation reviewer role
- Override documentation process
- Sampling below AI cutoff
- Appeal intake channels
- Appeal tracking system
- Appeal response timelines
- Independent reviewer requirement
- Appeal metrics tracked
- Governance review of appeal trends

---

## 🧾 Deliverable: Vendor & Third-Party Due-Diligence Pack

Say:
“I want to document how AI vendors are evaluated and contractually controlled.”

Ask:

- AI vendors in scope
- Due-diligence questionnaire used
- Vendor testing summaries obtained
- Security certifications
- Data use restrictions in contract
- Model change notification requirement
- Incident notification SLA
- Cooperation for regulatory inquiries
- Vendor risk register maintained
- Last vendor review date

---

## 🧾 Deliverable: Sandbox Application & Reporting (If Applicable)

Say:
“If you are using or planning innovative high-impact AI in Texas, we need to assess sandbox participation.”

Ask:

- Interest in regulatory sandbox
- Innovative AI systems planned
- Licensing uncertainty
- Testing plan summary
- Risk mitigation plan exists
- Reporting owner
- Quarterly reporting process
- Exit criteria defined

---

## 🧾 Deliverable: Recordkeeping & Documentation Index

Say:
“I need to confirm where all AI governance documents are stored and how long they are retained.”

Ask:

- Inventory location
- Governance documents location
- Assessment storage
- Testing reports storage
- Notice evidence storage
- Appeal logs storage
- Vendor files storage
- Incident log location
- Retention periods defined
- Retrieval process owner
- File naming convention

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Texas TRAIGA AI governance documentation.”