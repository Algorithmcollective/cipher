# Texas TRAIGA Discovery Worksheet

---

## AI System Inventory & Scope

Texas Presence:
AI Systems:
Business Areas:
Consequential Systems:
Vendor AI Tools:
Deployed in Texas:
Human Involvement:
Texas Volume:
Planned Deployments:

---

## AI Governance Program

Governance Committee:
AI Governance Officer:
Oversight Roles:
Intake Process:
Classification Method:
Meeting Cadence:
Policy Exists:
Executive Reporting:
Change Management:

---

## AI Risk & Impact Assessment

Consequential Decision Types:
Inputs:
Outputs:
Advisory or Decisive:
Individuals Affected:
Texas Volume Per Year:
Risk Categories:
Pre-Deployment Testing:
Monitoring Schedule:
Fairness Testing:
Proxy Features:
Human Oversight:
Appeals Available:
Overall Risk Rating:

---

## Data, Testing & Monitoring

Data Sources:
Data Quality Controls:
Data Minimization:
Retention Alignment:
Pre-Deployment Methods:
Testing Documentation:
Monitoring Frequency:
Metrics Tracked:
Alert Thresholds:
Monitoring Owner:
Incident Detection:
Incident Logging:

---

## Transparency & Notice

Website Disclosure:
Hiring Notice:
Chatbot Disclosure:
FAQ Language:
Internal Script:
Notice Logging:
Last Update:
Notice Owner:

---

## Human Review & Appeals

Primary Reviewer:
Escalation Reviewer:
Override Logging:
Cutoff Sampling:
Appeal Channels:
Appeal Tracking:
Response Timelines:
Independent Reviewer:
Appeal Metrics:
Governance Review:

---

## Vendor & Third-Party Due Diligence

AI Vendors:
Questionnaire Used:
Testing Summaries:
Security Certifications:
Data Use Restrictions:
Change Notification:
Incident SLA:
Regulatory Cooperation:
Risk Register:
Last Review Date:

---

## Sandbox (If Applicable)

Sandbox Interest:
Innovative Systems:
Licensing Uncertainty:
Testing Plan:
Risk Mitigation:
Reporting Owner:
Quarterly Reporting:
Exit Criteria:

---

## Recordkeeping & Documentation

Inventory Location:
Governance Location:
Assessment Storage:
Testing Storage:
Notice Storage:
Appeal Logs:
Vendor Files:
Incident Log:
Retention Periods:
Retrieval Owner:
Naming Convention:

---

## TBD

Item:
Owner:
Notes: