# Texas TRAIGA – Transparency & Notice Package (MASTER)

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Transparency & Notice Package (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose and Scope

This package provides standard language and internal guidance for:

- Disclosing {{ORG_NAME}}’s use of AI systems where appropriate.  
- Explaining, in plain language, how AI tools affect individuals.  
- Supporting TRAIGA-aligned transparency expectations and general consumer-protection principles, even though most private businesses are not directly bound by TRAIGA’s formal disclosure section (which focuses on government and certain healthcare uses).[web:17][web:36][web:56][web:60]

It is not legal advice and should be reviewed by counsel.

---

## 2. When to Use These Notices

Use or adapt these notices when:

- AI tools materially influence **consequential decisions** about individuals in Texas (employment, credit, housing, healthcare, education, etc.).[web:17][web:33][web:36]  
- Individuals interact directly with AI tools (e.g., chatbots) in a way that could affect their rights or opportunities.  
- You want to align with emerging best practices and avoid “black box” interactions.[web:50][web:52][web:58]

Notices should be:

- Clear and conspicuous.  
- Written in plain language.  
- Free from dark patterns or misleading design.[web:46][web:50][web:58][web:60]

---

## 3. Website / Careers Page Disclosure (Template)

**File:** `TEX_TRAIGA_05_Website_Careers_Notice_Template.md`

Suggested placement: careers or privacy page, near application flow.

> **Use of Automated Tools in Our Process**  
>  
> {{ORG_NAME}} uses software tools, including automated systems, to help review applications and match candidates to open roles. These tools analyze information you provide (such as your résumé, application responses, and job preferences) and may generate scores or recommendations for our recruiting team.  
>  
> Human recruiters remain involved in our hiring decisions. If you have questions about how automated tools are used in our process, you can contact us at {{CONTACT_EMAIL}}.

Fields to customize:

- {{ORG_NAME}}  
- {{CONTACT_EMAIL}}

---

## 4. Application Portal Inline Notice (Template)

**File:** `TEX_TRAIGA_05_Application_Inline_Notice_Template.md`

Suggested placement: just before candidates submit an application.

> **Automated Screening Notice**  
>  
> We may use automated tools to help review and prioritize applications for this role. These tools do not make final hiring decisions on their own, but they may influence which applications our recruiting team reviews first.  
>  
> By submitting your application, you acknowledge that automated tools may be used in this way. If you prefer that your application be reviewed without the use of automated tools where feasible, please contact us at {{CONTACT_EMAIL}}.

---

## 5. Chatbot / Virtual Assistant Disclosure (Template)

**File:** `TEX_TRAIGA_05_Chatbot_Disclosure_Template.md`

For chatbots that interact with candidates/customers.

> **You’re Chatting With an Automated Assistant**  
>  
> This chat is powered by an automated system that uses artificial intelligence to respond to your questions. A member of our team may review and use this conversation as part of our recruiting and support process.  
>  
> If you would like to speak directly with a person, you can request a human agent at any time or contact us at {{CONTACT_EMAIL}}.[web:36][web:52][web:58][web:60]

---

## 6. Email / FAQ Language (Template)

**File:** `TEX_TRAIGA_05_FAQ_AI_Use_Template.md`

Short explanation for FAQs or email responses:

> **How does {{ORG_NAME}} use AI in hiring?**  
>  
> We use software tools, including AI-based systems, to help organize and review applications. These tools may score or rank candidates based on job-related criteria so our team can focus on the most relevant profiles. Our recruiters still review candidates and make final decisions. We regularly review these tools as part of our compliance and risk management program.[web:17][web:33][web:36][web:49]

---

## 7. Internal Script for Responding to Questions (Template)

**File:** `TEX_TRAIGA_05_Internal_Response_Script_Template.md`

For recruiters/HR when a candidate asks about AI use:

**Short script**

> “We use some automated tools to help us manage a high volume of applications. They look at things like your experience, skills, and job fit, and they help us prioritize reviews. They don’t make final hiring decisions on their own. A recruiter is always involved before we move someone forward or close out a role.”

**If asked about fairness/testing**

> “Our compliance and systems teams periodically review how these tools are working, including checking for errors or patterns that could raise fairness concerns. If you believe something in your background wasn’t considered correctly, we can have a human review your application.”

---

## 8. Logging and Evidence

For each place where notices are used, {{ORG_NAME}} should:

- Capture screenshots or PDFs showing the notice in context.  
- Record when the notice was first implemented and last updated.  
- Note any A/B-tested variants and reasoning.

> {{NOTICE_LOGGING_PRACTICE}}

These records support your TRAIGA documentation and broader regulatory expectations around transparency.[web:46][web:49][web:52][web:53]

---

**End of Template**
