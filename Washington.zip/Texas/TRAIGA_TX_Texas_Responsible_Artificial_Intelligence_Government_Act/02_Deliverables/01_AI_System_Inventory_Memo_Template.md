# Texas TRAIGA – AI System Inventory & Scope Memo (MASTER)

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** AI System Inventory & Scope Assessment (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of This Memo

This memo helps {{ORG_NAME}}:

- Identify systems, tools, and services that qualify as “artificial intelligence systems” under Texas TRAIGA.  
- Classify which AI systems are used for **consequential decisions** affecting individuals in Texas (e.g., employment, credit, housing, healthcare, education).  
- Establish a central inventory that will drive later TRAIGA deliverables (risk assessments, testing, notices, and governance).

It is not legal advice and should be reviewed by qualified counsel before being relied upon.[web:17][web:36]

---

## 2. Overview of TRAIGA (Plain Language)

TRAIGA applies to **developers** and **deployers** of covered AI systems that are used in Texas.[web:17][web:34][web:36]

For this memo:

- An **AI system** generally means a machine-based system that, for explicit or implicit objectives, infers from input how to generate outputs such as predictions, recommendations, content, or decisions.[web:17][web:36]  
- A **consequential decision** is a decision that has a material legal or similarly significant effect on an individual, such as hiring, promotion, termination, lending, housing, health coverage, education, or essential services.[web:17][web:33][web:36]

Key concepts this memo supports:

- Keeping a **living inventory** of AI systems in scope.  
- Flagging which systems trigger enhanced TRAIGA obligations (e.g., risk assessments, testing, notices, appeals).

---

## 3. Organizational Context

### 3.1 Presence in Texas

- Does {{ORG_NAME}} have employees or facilities in Texas?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Does {{ORG_NAME}} offer products or services to individuals or businesses in Texas?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Does {{ORG_NAME}} process data about individuals located in Texas, even if operations are elsewhere?  
  - ☐ Yes  ☐ No  ☐ Unclear  

If any answer is “Yes” or “Unclear,” TRAIGA may apply to some AI uses.[web:17][web:36]

### 3.2 Business Areas Using AI

Check all areas where {{ORG_NAME}} currently uses or plans to use AI:

- ☐ Talent acquisition / recruiting / hiring  
- ☐ HR (promotions, performance ratings, terminations)  
- ☐ Credit / lending / underwriting / pricing  
- ☐ Fraud detection / transaction monitoring  
- ☐ Customer service (chatbots, virtual assistants)  
- ☐ Marketing / personalization / ad targeting  
- ☐ Claims handling / eligibility or benefit determinations  
- ☐ Healthcare diagnostics / treatment suggestions  
- ☐ Other high‑impact workflows: {{OTHER_HIGH_IMPACT}}  

Provide a brief overview of how AI is used today:

> {{ORG_OVERVIEW_OF_AI_USE}}

---

## 4. AI System Inventory

List each AI system, service, or model in use. Treat vendor tools (e.g., ATS ranking feature), in‑house models, and embedded AI in SaaS products as separate entries.

| ID | System / Tool Name | Provider (Internal/Vendor) | Main Purpose | Business Area | Deployed in Texas? (Y/N/Planned) |
|----|--------------------|----------------------------|--------------|--------------|----------------------------------|
| AI‑01 | {{SYSTEM_1_NAME}} | {{SYSTEM_1_PROVIDER}} | {{SYSTEM_1_PURPOSE}} | {{SYSTEM_1_AREA}} | {{SYSTEM_1_TX_STATUS}} |
| AI‑02 | {{SYSTEM_2_NAME}} | {{SYSTEM_2_PROVIDER}} | {{SYSTEM_2_PURPOSE}} | {{SYSTEM_2_AREA}} | {{SYSTEM_2_TX_STATUS}} |
| AI‑03 | {{SYSTEM_3_NAME}} | {{SYSTEM_3_PROVIDER}} | {{SYSTEM_3_PURPOSE}} | {{SYSTEM_3_AREA}} | {{SYSTEM_3_TX_STATUS}} |

Add rows as needed.

---

## 5. Consequential Decision Classification

For each AI system, indicate whether it is used to support or make “consequential decisions” about individuals in Texas.[web:17][web:33][web:36]

Use the table below:

| ID | System / Tool Name | Decision Type | Consequential? (Y/N) | Example Decisions | Texas Individuals Affected? (Y/N) |
|----|--------------------|--------------|----------------------|-------------------|-----------------------------------|
| AI‑01 | {{SYSTEM_1_NAME}} | {{DECISION_TYPE_1}} | {{CONSEQUENTIAL_1}} | {{EXAMPLE_DECISIONS_1}} | {{TX_AFFECTED_1}} |
| AI‑02 | {{SYSTEM_2_NAME}} | {{DECISION_TYPE_2}} | {{CONSEQUENTIAL_2}} | {{EXAMPLE_DECISIONS_2}} | {{TX_AFFECTED_2}} |

Decision type examples:

- Hiring / promotion / termination  
- Credit approval / pricing / limit setting  
- Housing approval / denial  
- Health coverage eligibility / prior authorization  
- Education admission / grading / placement  
- Eligibility for essential services or benefits

---

## 6. Input, Output, and Human Involvement

For each consequential system, capture key facts that will be reused for TRAIGA risk assessments and governance.

| ID | Inputs (Data Types) | Outputs (Score / Recommendation / Decision) | Human in the Loop? (How?) |
|----|---------------------|---------------------------------------------|---------------------------|
| AI‑01 | {{INPUTS_1}} | {{OUTPUTS_1}} | {{HUMAN_LOOP_1}} |
| AI‑02 | {{INPUTS_2}} | {{OUTPUTS_2}} | {{HUMAN_LOOP_2}} |

Brief narrative description for each high‑impact system:

- **AI‑01 – {{SYSTEM_1_NAME}}**: {{NARRATIVE_1}}  
- **AI‑02 – {{SYSTEM_2_NAME}}**: {{NARRATIVE_2}}  

---

## 7. Initial TRAIGA Scope Assessment

Summarize which systems appear to be in scope for enhanced TRAIGA obligations (e.g., risk assessments, testing, notices, appeals, documentation), based on current understanding.[web:17][web:33][web:36]

- Systems clearly in scope (high‑impact consequential decisions for Texas individuals):  
  - {{IN_SCOPE_SYSTEMS_LIST}}

- Systems likely out of scope (no consequential decisions, used only for low‑risk internal support):  
  - {{OUT_OF_SCOPE_SYSTEMS_LIST}}

- Open questions / dependencies (need legal or technical confirmation):  
  - {{OPEN_QUESTIONS_LIST}}

High‑level assessment:

- **Current TRAIGA scope level for {{ORG_NAME}}:**  
  - ☐ Low  ☐ Medium  ☐ High  
  - Rationale: {{SCOPE_RATIONALE}}

---

## 8. Recommended Next Steps

Prioritized follow‑ups based on this inventory:

1. Confirm TRAIGA applicability and high‑risk systems with legal counsel.  
2. For each “in‑scope” system, initiate a **TRAIGA AI Risk / Impact Assessment** (Deliverable 02).  
3. Identify systems that may require updated **notices, human review procedures, and appeal mechanisms** under TRAIGA.  
4. Review contracts and documentation for vendor‑provided AI systems that appear in scope.

Responsible owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} |
| {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} |

---

**End of Template**
