# Texas TRAIGA – AI Risk & Impact Assessment (MASTER)

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** AI Risk & Impact Assessment (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of This Assessment

This assessment helps {{ORG_NAME}}:

- Evaluate risks associated with a specific AI system used for consequential decisions affecting individuals in Texas.  
- Document how the system is designed, tested, and governed to comply with TRAIGA expectations.  
- Provide a reusable record for oversight bodies, counsel, and regulators if needed.[web:17][web:33][web:36]

It is not legal advice and should be reviewed by qualified counsel before being relied upon.

---

## 2. System Overview

### 2.1 Basic Information

- **System ID (from inventory):** {{SYSTEM_ID}}  
- **System / Tool Name:** {{SYSTEM_NAME}}  
- **Provider (Internal / Vendor):** {{PROVIDER}}  
- **Business Owner:** {{BUSINESS_OWNER_NAME}}, {{BUSINESS_OWNER_ROLE}}  
- **Technical Owner:** {{TECH_OWNER_NAME}}, {{TECH_OWNER_ROLE}}  

### 2.2 Purpose and Use

- **Primary purpose of the AI system:**  
  > {{SYSTEM_PURPOSE}}

- **Consequential decision(s) supported:** (e.g., hiring, promotion, lending, housing)  
  > {{CONSEQUENTIAL_DECISIONS}}

- **Geographic scope:**  
  - Used for decisions about individuals in Texas? ☐ Yes ☐ No ☐ Planned  
  - Used in other states/countries? {{OTHER_REGIONS}}[web:17][web:33]

---

## 3. Inputs, Outputs, and Decision Flow

### 3.1 Inputs

List the key input data types:

- Structured data (e.g., application fields, credit attributes): {{STRUCTURED_INPUTS}}  
- Unstructured data (e.g., free‑text, CVs, notes): {{UNSTRUCTURED_INPUTS}}  
- Sensitive data (e.g., race, health, biometrics) used or inferred: {{SENSITIVE_INPUTS}}  

### 3.2 Outputs

Describe the outputs:

- Output type (score / rank / label / decision): {{OUTPUT_TYPE}}  
- Output range (e.g., 0–100 score, “Proceed / Review / Reject”): {{OUTPUT_RANGE}}  
- How outputs are presented to human users: {{OUTPUT_PRESENTATION}}  

### 3.3 Role in Decision-Making

- Is the AI system **advisory** (human makes final decision)? ☐ Yes ☐ No  
- Is the AI system **decisive** (auto‑approves/denies without human review)? ☐ Yes ☐ No  
- Brief description of how the AI output influences the final decision:  
  > {{DECISION_FLOW_EXPLANATION}}[web:17][web:36]

---

## 4. Individuals Affected

### 4.1 Categories of Individuals

Check all that apply:

- ☐ Job applicants / candidates  
- ☐ Employees / contractors  
- ☐ Consumers / borrowers / applicants  
- ☐ Patients / plan members  
- ☐ Students / applicants  
- ☐ Other: {{OTHER_INDIVIDUALS}}  

### 4.2 Scale of Use

- Approximate number of individuals impacted per year (Texas only): {{TX_VOLUME_PER_YEAR}}  
- Approximate total individuals impacted per year (all regions): {{TOTAL_VOLUME_PER_YEAR}}  

---

## 5. Risk Identification

### 5.1 Types of Risk Considered

Check each risk category evaluated for this system:

- ☐ Accuracy / reliability risk  
- ☐ Bias / fairness risk  
- ☐ Privacy / security risk  
- ☐ Transparency / explainability risk  
- ☐ Operational / outage risk  
- ☐ Legal / regulatory risk (TRAIGA, TDPSA, discrimination laws, sector laws)  
- ☐ Reputational risk  

### 5.2 Narrative Risk Summary

Provide a brief narrative of key risks identified:

> {{RISK_SUMMARY}}

---

## 6. Testing and Evaluation

### 6.1 Pre-Deployment Testing

- Was the system evaluated before initial deployment? ☐ Yes ☐ No  
- Types of testing performed (check all that apply):  
  - ☐ Accuracy / performance testing  
  - ☐ Bias / disparate impact checks  
  - ☐ Robustness / adversarial testing  
  - ☐ Security / access controls review  

- Summary of pre‑deployment testing approach and findings:  
  > {{PRE_DEPLOYMENT_TESTING_SUMMARY}}[web:17][web:33][web:36]

### 6.2 Ongoing Monitoring

- Is there a defined schedule for ongoing testing/monitoring? ☐ Yes ☐ No  
  - Frequency (e.g., monthly, quarterly, annually): {{MONITORING_FREQUENCY}}  
- Metrics tracked (e.g., selection rates, error rates, overrides, appeals): {{MONITORING_METRICS}}  
- Who reviews monitoring results? {{MONITORING_OWNER}}  

Briefly describe the ongoing monitoring process:

> {{MONITORING_PROCESS_SUMMARY}}[web:17][web:33][web:36]

---

## 7. Bias, Fairness, and Impact on Protected Groups

### 7.1 Data and Features

- Are protected characteristics (race, sex, age, etc.) **explicitly** used as inputs? ☐ Yes ☐ No  
- Are any features strong **proxies** for protected characteristics (e.g., ZIP code, certain schools)? ☐ Yes ☐ No ☐ Unclear  

If “Yes” or “Unclear,” describe:

> {{PROXY_FEATURES_DESCRIPTION}}

### 7.2 Fairness Evaluation

- Tests or analyses performed to evaluate impact on protected groups (e.g., selection rate comparisons):  
  > {{FAIRNESS_TESTS_PERFORMED}}

- Key findings on impact:

> {{FAIRNESS_FINDINGS}}

- Mitigations implemented (e.g., threshold adjustments, feature removal, manual review):  
  > {{FAIRNESS_MITIGATIONS}}[web:17][web:33][web:36]

---

## 8. Human Oversight and Appeals

### 8.1 Human in the Loop

- Who reviews AI outputs before final decisions? {{HUMAN_REVIEW_ROLE}}  
- Under what circumstances must a human override or escalate a decision? {{ESCALATION_CRITERIA}}  

Brief description:

> {{HUMAN_OVERSIGHT_DESCRIPTION}}

### 8.2 Individual Rights and Appeals

- Can affected individuals contest or appeal AI‑influenced decisions? ☐ Yes ☐ No  
- How do they submit an appeal (channel / process)? {{APPEAL_CHANNEL}}  
- Internal process for handling appeals and overrides:  

> {{APPEAL_PROCESS_SUMMARY}}[web:17][web:33][web:36]

---

## 9. Security, Privacy, and Vendors

### 9.1 Security and Data Protection

- Sensitive data handled by the AI system: {{SENSITIVE_DATA_LIST}}  
- Key security controls (encryption, access controls, logging, etc.): {{SECURITY_CONTROLS}}  

### 9.2 Vendors and Contracts

- Is the AI provided by an external vendor? ☐ Yes ☐ No  
  - If Yes, vendor name: {{VENDOR_NAME}}  

Contractual controls in place (check all that apply):

- ☐ Description of AI services and data use limits  
- ☐ Security and incident‑response commitments  
- ☐ Cooperation with testing / audits  
- ☐ Rights to information and documentation needed for TRAIGA compliance  

Briefly describe any gaps or open items:

> {{VENDOR_GAPS}}[web:17][web:24][web:36]

---

## 10. Overall Risk Rating and Mitigation Plan

### 10.1 Overall Risk Rating

- **Current overall risk level for this AI system:**  
  - ☐ Low  ☐ Medium  ☐ High  

Rationale:

> {{OVERALL_RISK_RATIONALE}}

### 10.2 Mitigation Actions

List prioritized mitigation steps:

1. {{MITIGATION_1}}  
2. {{MITIGATION_2}}  
3. {{MITIGATION_3}}  

Owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} |
| {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} |

---

**End of Template**
