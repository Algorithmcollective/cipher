# Texas TRAIGA – AI Governance Program (MASTER)

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** AI Governance Program (Policy + Oversight Charter)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose and Scope

This AI Governance Program sets out how {{ORG_NAME}} designs, approves, deploys, and monitors artificial intelligence (AI) systems used in connection with individuals in Texas.

It is intended to:

- Align {{ORG_NAME}}’s AI practices with TRAIGA’s expectations for developers and deployers of AI systems.  
- Define roles, responsibilities, and decision-making authority for AI governance.  
- Provide a framework for risk assessments, testing, monitoring, notices, and documentation for AI systems used for consequential decisions.[web:17][web:33][web:36]

This document is internal governance guidance and does not replace legal advice.

---

## 2. Definitions (Plain Language)

For purposes of this program:

- **AI system:** A machine-based system that, for explicit or implicit objectives, infers from input data how to generate outputs such as predictions, recommendations, content, or decisions, which can influence or support human decision-making.[web:17][web:36]  
- **Consequential decision:** A decision that has a material legal or similarly significant effect on an individual (e.g., employment, credit, housing, healthcare, education, essential services).[web:17][web:33][web:36]  
- **Developer:** A person or entity that develops or substantially modifies an AI system.  
- **Deployer:** A person or entity that uses or makes available an AI system in the ordinary course of business.

{{ORG_NAME}} may act as a **developer**, **deployer**, or both, depending on the system.

---

## 3. Governance Structure

### 3.1 AI Governance Committee (or Officer)

{{ORG_NAME}} establishes an **AI Governance Committee** (the “Committee”) to oversee AI risk and compliance.

- **Chair:** {{CHAIR_NAME}}, {{CHAIR_ROLE}}  
- **Members:**  
  - {{MEMBER_1_NAME}}, {{MEMBER_1_ROLE}} (e.g., Compliance)  
  - {{MEMBER_2_NAME}}, {{MEMBER_2_ROLE}} (e.g., IT / Data)  
  - {{MEMBER_3_NAME}}, {{MEMBER_3_ROLE}} (e.g., HR / Product)  

If a full committee is not feasible, {{ORG_NAME}} designates an **AI Governance Officer** with similar responsibilities.

### 3.2 Responsibilities

The Committee (or Officer) is responsible for:

- Maintaining the **AI system inventory** and classifying systems under TRAIGA.  
- Approving new AI systems and material changes to existing systems before deployment.  
- Overseeing completion and review of **AI Risk & Impact Assessments** for consequential systems.  
- Approving testing and monitoring plans and reviewing results.  
- Ensuring appropriate transparency, notices, and appeal mechanisms.  
- Coordinating with Legal/Compliance on TRAIGA and other regulatory obligations.[web:17][web:33][web:36]

### 3.3 Meeting Cadence

- Regular meetings: at least **quarterly**.  
- Ad‑hoc meetings: when new high‑impact AI systems are proposed or significant incidents occur.  

Meeting minutes should be documented and retained according to the recordkeeping schedule in Section 9.

---

## 4. AI System Lifecycle and Approval

### 4.1 When This Program Applies

This program applies to:

- Any new AI system proposed for use in connection with individuals in Texas.  
- Any substantial modification to an existing AI system that could change its impact or risk profile.  
- Any retirement or decommissioning of high‑impact AI systems.

### 4.2 Lifecycle Stages

{{ORG_NAME}} manages AI systems through the following stages:

1. **Proposal & Triage** – Business owner submits a brief AI proposal.  
2. **Classification** – System is added to the AI inventory and classified (consequential vs. low‑impact).  
3. **Assessment** – Risk & impact assessment completed for consequential systems.  
4. **Approval** – Committee/Officer reviews and approves or rejects.  
5. **Deployment** – System launched with required controls, notices, and documentation.  
6. **Monitoring & Review** – Ongoing testing, monitoring, and periodic reassessment.[web:17][web:33][web:36]

---

## 5. Roles and Responsibilities

### 5.1 Business Owners

- Propose new AI systems and changes using the standard intake form.  
- Ensure accurate descriptions of use cases, data, and affected individuals.  
- Implement operational controls and training for their teams.

### 5.2 Technical / Data Owners

- Provide technical details on inputs, outputs, architecture, and dependencies.  
- Support testing, monitoring, and incident response.  
- Maintain technical documentation needed for TRAIGA compliance.

### 5.3 Compliance / Legal

- Interpret TRAIGA and related laws for {{ORG_NAME}}.  
- Review and sign off on high‑risk AI assessments.  
- Coordinate responses to regulatory inquiries and complaints.

### 5.4 AI Governance Committee / Officer

- Final approval for consequential AI deployments.  
- Oversight of risk assessments, testing plans, monitoring results, and corrective actions.  
- Periodic report to senior leadership on AI risk posture.

---

## 6. Intake and Classification of AI Systems

### 6.1 Intake Form

Before implementing a new AI system, the business owner must submit an intake form containing:

- System name, provider, and business purpose.  
- Types of decisions supported and whether they may be consequential.  
- Categories of individuals affected, especially in Texas.  
- Overview of input data, outputs, and human involvement.

### 6.2 Classification Criteria

The Committee/Officer classifies each AI system as:

- **High‑impact / Consequential** – Used for decisions with material effects on individuals (e.g., employment, lending).  
- **Moderate‑impact** – Influences but does not determine important decisions.  
- **Low‑impact** – Primarily operational support, no direct or significant effect on individual rights.

High‑impact systems require full TRAIGA‑aligned risk/impact assessments, testing, and oversight.[web:17][web:33][web:36]

---

## 7. Risk Assessment, Testing, and Monitoring

### 7.1 Risk & Impact Assessments

For each high‑impact AI system, {{ORG_NAME}} must complete an **AI Risk & Impact Assessment** before deployment and on a periodic basis.[web:17][web:33][web:36]

- Use the standard TRAIGA assessment template (Deliverable 03).  
- Address accuracy, bias/fairness, privacy/security, transparency, and legal/regulatory risks.  
- Document mitigations and residual risk.

### 7.2 Testing

- Pre‑deployment: evaluate performance and fairness on representative data where feasible.  
- Ongoing: re‑test at defined intervals and after material changes.

Testing requirements and frequency should be specified in a separate **Data, Testing & Monitoring Plan** (Deliverable 04).

### 7.3 Monitoring and Reporting

- Track key metrics (e.g., error rates, selection rates, overrides, appeals).  
- Escalate significant anomalies or incidents to the Committee/Officer.  
- Document monitoring results and actions taken.

---

## 8. Transparency, Human Review, and Appeals

### 8.1 Transparency and Notices

For AI systems used in consequential decisions, {{ORG_NAME}} will:

- Provide clear, plain‑language disclosures where appropriate (e.g., on websites, portals, or forms).  
- Explain that automated tools may be used, the nature of those tools, and how individuals can request more information.[web:17][web:33][web:36]

Details are implemented via the **Transparency & Notice Package** (Deliverable 05).

### 8.2 Human Review of Decisions

- For high‑impact systems, final decisions should not be made solely by AI unless approved by the Committee/Officer.  
- Humans must have sufficient context and authority to override AI outputs.

### 8.3 Appeals and Corrections

- Individuals affected by AI‑influenced consequential decisions should have a channel to request review or correction.  
- The appeals process (timeframes, decision‑makers, documentation) is defined in the **Human Review & Appeals Workflow** (Deliverable 06).

---

## 9. Documentation and Recordkeeping

{{ORG_NAME}} will maintain documentation for:

- AI system inventory and classification.  
- Intake forms and approval decisions.  
- Risk & impact assessments and updates.  
- Testing plans, results, and monitoring reports.  
- Notices, policies, and training materials.  
- Vendor contracts and due‑diligence records.

Retention periods and storage locations are defined in the **Recordkeeping & Documentation Index** (Deliverable 09).[web:17][web:33][web:36]

---

## 10. Training and Awareness

- Relevant staff (e.g., HR, product, risk, IT) must receive periodic training on {{ORG_NAME}}’s AI governance program.  
- Training covers: TRAIGA basics, internal processes, roles, and escalation paths.

Completion of training should be logged and retained.

---

## 11. Review and Updates

This AI Governance Program will be:

- Reviewed at least **annually**, or sooner if:  
  - TRAIGA or other applicable laws change.  
  - {{ORG_NAME}} launches or significantly modifies high‑impact AI.  
- Updates must be approved by the AI Governance Committee/Officer and Legal/Compliance.

---

**End of Template**
