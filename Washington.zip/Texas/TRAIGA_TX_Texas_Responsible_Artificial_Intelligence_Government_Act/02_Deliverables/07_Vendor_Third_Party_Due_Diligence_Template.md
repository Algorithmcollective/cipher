# Texas TRAIGA – Vendor & Third-Party AI Due-Diligence Pack (MASTER)

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Vendor & Third-Party AI Due-Diligence Pack (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This pack helps {{ORG_NAME}}:

- Evaluate AI vendors and other third parties whose systems are used in connection with individuals in Texas.  
- Align third‑party contracts and documentation with TRAIGA‑driven governance expectations (even though organizations are not strictly liable for third‑party misuse, they must show reasonable care).[web:47][web:49][web:64][web:65]  
- Maintain a defensible record of vendor due diligence and contract controls.

---

## 2. When to Use This Pack

Use this pack when:

- Selecting a new AI‑enabled vendor (e.g., ATS with AI ranking, credit model provider, chatbot platform).  
- Renewing, expanding, or materially changing an existing AI vendor relationship.  
- Documenting TRAIGA‑aligned diligence for regulators, clients, or internal audit.[web:47][web:49][web:64]

---

## 3. Vendor AI Due-Diligence Questionnaire (Template)

**File:** `TEX_TRAIGA_07_Vendor_DueDiligence_Questionnaire_Template.md`

Key sections (you can send as a form or spreadsheet):

1. **Vendor and System Identification**  
   - Vendor name and contact.  
   - Name and version of AI system.  
   - High‑level description of purpose and use cases.  
   - Markets and geographies where the system is currently deployed.

2. **AI System Design and Intended Use**  
   - What decisions or recommendations does the system support?  
   - What are the intended users (e.g., recruiters, underwriters) and end‑users (e.g., candidates, borrowers)?  
   - Can the system be configured by the customer (thresholds, filters, features)?[web:49][web:64][web:66]

3. **Data and Model Information (High Level)**  
   - Types of input data (categories, not proprietary training details).  
   - Known use of sensitive or protected characteristics, or proxies.  
   - High‑level information on model type and update cadence.

4. **Testing, Fairness, and Monitoring**  
   - Summary of pre‑deployment testing (accuracy, robustness, fairness).  
   - Ongoing monitoring practices (frequency, metrics, triggers).  
   - Ability to share testing summaries or relevant documentation.[web:49][web:64][web:65]

5. **Security and Privacy**  
   - Certifications and frameworks (e.g., SOC 2, ISO 27001).  
   - Security controls for data at rest/in transit, access control, logging.  
   - Data retention and deletion practices; data residency if relevant.[web:22][web:37][web:39][web:64]

6. **Explainability and Oversight Support**  
   - How can customers understand the main factors influencing outputs?  
   - Tools/logs provided for oversight (e.g., audit logs, configuration history).  
   - Ability to support impact assessments and regulatory inquiries.[web:64][web:67][web:70]

7. **Incident and Complaint Handling**  
   - How the vendor detects, logs, and responds to AI system incidents.  
   - SLA for notifying customers about material issues or model changes.  
   - Process for handling end‑user complaints escalated by customers.[web:47][web:49][web:64]

8. **Compliance and Legal**  
   - How the vendor addresses applicable AI and privacy laws (TRAIGA, TDPSA, etc.).  
   - Whether they have an internal AI governance program.  
   - Contact details for legal/compliance liaison.

---

## 4. AI Vendor Contract Checklist (Template)

**File:** `TEX_TRAIGA_07_Vendor_Contract_Checklist_Template.md`

Key clauses you should look for or add:

1. **Scope and Description of AI Services**  
   - Clear description of AI features and intended use cases.  
   - Ability for {{ORG_NAME}} to configure or disable high‑risk functions.[web:67][web:70]

2. **Data Use and Ownership**  
   - Limits on vendor use of {{ORG_NAME}} data (no unauthorized sale or unrelated training without consent).  
   - Clarification of data ownership and access to logs.

3. **Security and Privacy**  
   - Baseline security obligations (encryption, access controls, incident response).  
   - Alignment with applicable privacy laws (e.g., TDPSA).[web:22][web:37][web:39][web:64][web:70]

4. **Testing, Documentation, and Cooperation**  
   - Vendor commits to reasonable testing and to providing high‑level documentation of system performance and limitations.  
   - Cooperation in providing information needed for {{ORG_NAME}}’s risk assessments, monitoring, and regulatory responses.[web:47][web:49][web:64][web:67][web:70]

5. **Change Management and Notifications**  
   - Advance notice of material changes to AI models, features, or intended use.  
   - Option for {{ORG_NAME}} to pause or opt out of specific changes.

6. **Incident Notification and Remediation**  
   - Timely notification of security incidents, material AI errors, or misuse.  
   - Joint remediation planning where outputs have materially affected individuals.

7. **Indemnity and Limitations (High-Level)**  
   - Consider specific coverage for vendor misconduct or failure to meet contractual AI obligations (subject to negotiation).  
   - Clarify that {{ORG_NAME}} retains responsibility for its own misuse or misconfiguration.

---

## 5. AI Vendor Contract Addendum – Clause Shell (Template)

**File:** `TEX_TRAIGA_07_Vendor_Addendum_Short_Template.md`

This is a short, generic addendum you can adapt with counsel:

> **AI Governance and Cooperation**  
>  
> Vendor will:  
> (a) Provide a high‑level description of the AI System, including its intended use, main input types, and general output behavior, suitable for the Customer’s internal documentation and risk assessments.  
> (b) Implement and maintain reasonable testing and monitoring practices for the AI System, including periodic evaluations of performance and documented known limitations.  
> (c) Upon reasonable request, provide Customer with summaries of testing, monitoring, and any material limitations relevant to Customer’s use cases, to support Customer’s compliance with applicable AI governance laws and frameworks.  
> (d) Provide advance notice of material changes to the AI System that could significantly affect outputs or risk profile for Customer’s use cases, and cooperate in good faith with Customer to mitigate any resulting risks.  
> (e) Promptly notify Customer of any known incidents, malfunctions, or misuse of the AI System that could reasonably be expected to materially affect Customer’s decisions relating to individuals.

> **Data Use and Protection**  
>  
> Vendor will:  
> (a) Use Customer Data only to provide the services and as otherwise expressly permitted in the Agreement.  
> (b) Not sell Customer Data or use it for unrelated purposes without Customer’s prior written consent.  
> (c) Maintain appropriate technical and organizational measures to protect Customer Data, consistent with industry standards and applicable law.

> **Regulatory and Audit Support**  
>  
> Vendor will:  
> (a) Provide reasonable assistance, upon request, in responding to regulatory inquiries or investigations relating to Customer’s use of the AI System, to the extent such inquiries involve Vendor’s systems or operations.  
> (b) Maintain records reasonably necessary to demonstrate its compliance with this Addendum and applicable AI, privacy, and security obligations for the services provided to Customer.[web:47][web:49][web:64][web:67][web:70]

(Exact legal language should be finalized by counsel.)

---

## 6. Vendor Risk Register Entry (Template)

**File:** `TEX_TRAIGA_07_Vendor_Risk_Register_Template.md`

For each key AI vendor:

| Vendor | System | Role (Developer/Provider) | Risk Level | Key Issues | Mitigations | Last Review |
|--------|--------|---------------------------|-----------|-----------|------------|------------|
| {{VENDOR_NAME}} | {{SYSTEM_NAME}} | {{VENDOR_ROLE}} | {{RISK_LEVEL}} | {{KEY_ISSUES}} | {{MITIGATIONS}} | {{LAST_REVIEW_DATE}} |

---

**End of Template**
