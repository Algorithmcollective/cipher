# Texas TRAIGA – Human Review & Appeals Workflow (MASTER)

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Human Review & Appeals Workflow (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This workflow defines how {{ORG_NAME}}:

- Ensures meaningful human involvement in consequential decisions supported by AI systems.  
- Provides individuals with a way to raise concerns and request review or correction.  
- Documents a clear process that can be shown to regulators or clients as part of TRAIGA-aligned governance.[web:17][web:33][web:36][web:50]

---

## 2. Scope

This workflow applies to AI systems that:

- Are classified as **high‑impact / consequential** in the AI inventory; and  
- Affect individuals in Texas (e.g., job applicants, customers, borrowers, patients).[web:17][web:33][web:36]

List the systems covered here (IDs from inventory):

- {{SYSTEM_ID_1}} – {{SYSTEM_NAME_1}}  
- {{SYSTEM_ID_2}} – {{SYSTEM_NAME_2}}  

---

## 3. Human Review of AI Outputs

### 3.1 General Principle

For covered systems, AI outputs are **advisory**, not fully determinative, unless explicitly approved otherwise. Humans with appropriate authority must:

- See enough context to understand the AI output.  
- Be able to override or adjust AI‑influenced decisions.  
- Escalate unclear or high‑risk cases.[web:17][web:33][web:36][web:52]

### 3.2 Standard Workflow (High-Level)

1. AI system evaluates the case (e.g., candidate, application, transaction).  
2. AI generates an output (score, ranking, label, recommendation).  
3. Human reviewer (e.g., recruiter, underwriter) reviews the case and AI output.  
4. Human accepts, modifies, or rejects the AI‑influenced recommendation.  
5. Decision and key reasons (where practical) are logged in the relevant system.

You can adapt the detailed steps per system below.

---

## 4. Roles and Responsibilities

- **Primary reviewer:** {{PRIMARY_ROLE}} (e.g., recruiter, underwriter).  
- **Escalation reviewer:** {{ESCALATION_ROLE}} (e.g., team lead, manager).  
- **Compliance contact:** {{COMPLIANCE_CONTACT}} (for systemic issues).  

RACI (example):

- Responsible: Primary reviewer.  
- Accountable: Escalation reviewer or manager.  
- Consulted: Compliance / Legal.  
- Informed: AI Governance Committee.[web:17][web:33][web:36]

---

## 5. Detailed Human Review Steps

Customize per system; example structure:

1. **Review queue:**  
   - Reviewer logs into {{SYSTEM_NAME}} and views the AI‑ranked queue.  
2. **Case selection:**  
   - Reviewer must consider not only the very top AI‑ranked items but also a sample below the cutoff (e.g., top 50 plus a sample of next 50).  
3. **Information review:**  
   - Reviewer examines underlying file (e.g., résumé, application form, notes).  
4. **Decision:**  
   - Options: Advance, Hold/Needs Review, Do Not Proceed.  
5. **Override:**  
   - If reviewer disagrees with AI output, they record an override and short reason using a structured field, if available.  
6. **Escalation:**  
   - Cases meeting predefined criteria (e.g., complaints, unusual AI scores) are escalated to {{ESCALATION_ROLE}}.

> {{SYSTEM_SPECIFIC_STEPS}}

---

## 6. Appeals and Complaint Intake

### 6.1 How Individuals Can Raise Concerns

Provide at least one easy channel:

- Dedicated email (e.g., ai-review@{{ORG_DOMAIN}}).  
- Web form in the portal.  
- Phone support, with process to log AI-related concerns.

Describe chosen channel(s):

> {{APPEAL_CHANNELS_DESCRIPTION}}

### 6.2 Information Collected

When someone contests or queries an AI‑influenced decision, {{ORG_NAME}} should capture:

- Name and contact details.  
- Reference (application ID, account ID, claim number, etc.).  
- Brief description of the concern.  
- Whether they request a human review.

> {{APPEAL_INTAKE_FIELDS}}[web:17][web:33][web:36][web:50]

---

## 7. Appeals Handling Workflow

### 7.1 Timelines

Define internal targets, for example:

- Acknowledge receipt within {{ACK_TIMEFRAME}} (e.g., 5 business days).  
- Complete review and respond within {{REVIEW_TIMEFRAME}} (e.g., 15–30 business days).

### 7.2 Steps

1. **Log the appeal:**  
   - Logged in {{APPEAL_TRACKING_SYSTEM}} with date, system, and summary.  
2. **Assign reviewer:**  
   - Assigned to {{APPEAL_REVIEWER_ROLE}} (not the same person who made the initial decision, where feasible).  
3. **Collect records:**  
   - Pull the AI output, underlying data, and notes used in the decision.  
4. **Human review:**  
   - Reviewer reassesses the case on its merits, considering but not bound by AI output.  
5. **Decision:**  
   - Options: Uphold, Modify, or Reverse the original outcome.  
6. **Communicate outcome:**  
   - Clear, plain‑language explanation, including contact point for further questions.  
7. **Close and tag:**  
   - Tag appeals that reveal systemic issues and flag for the AI Governance Committee.

> {{APPEAL_WORKFLOW_DETAILS}}[web:17][web:33][web:36][web:52][web:60]

---

## 8. Logging, Metrics, and Feedback Loop

Track, at minimum:

- Number of appeals per quarter per AI system.  
- Outcomes (upheld / modified / reversed).  
- Common themes (e.g., “system misread experience,” “location handling”).  
- Time taken to resolve.

> {{APPEAL_METRICS_SUMMARY}}

Twice per year (or quarterly for high‑impact systems), the AI Governance Committee should review appeal trends and:

- Consider changes to AI configurations or thresholds.  
- Update training for reviewers.  
- Update notices or FAQs if recurring confusion appears.

---

## 9. Review and Updates

This workflow will be:

- Reviewed annually, or sooner if there is a material change to AI systems or legal expectations.  
- Updated with any new channels, timeframes, or escalation paths.

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
