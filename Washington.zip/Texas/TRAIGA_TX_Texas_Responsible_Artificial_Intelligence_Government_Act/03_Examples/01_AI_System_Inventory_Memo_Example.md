# Texas TRAIGA – AI System Inventory & Scope Memo – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** AI System Inventory & Scope Assessment (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose of This Memo

This memo identifies AI systems used by LoneStar Talent Solutions (“LoneStar”) that may be subject to Texas TRAIGA, classifies which systems are used for consequential employment decisions about candidates in Texas, and establishes a central inventory that will feed into TRAIGA risk assessments, notices, and governance work.

This document is internal compliance support, not legal advice, and should be reviewed by counsel before being relied upon.[web:17][web:36]

---

## 2. Overview of TRAIGA (Plain Language)

TRAIGA applies to developers and deployers of AI systems that operate in Texas.[web:17][web:34][web:36]

For LoneStar:

- An AI system is any automated system that infers from input data how to produce outputs like candidate scores, rankings, flags, or recommendations used in hiring.  
- A consequential decision is any decision that materially affects a candidate’s employment opportunity in Texas, including whether a candidate is shortlisted, interviewed, or placed with a client.[web:17][web:33][web:36]

The main purpose of this memo is to:

- Document all AI‑enabled tools used in the recruiting workflow.  
- Flag which tools materially influence employment decisions for Texas candidates.

---

## 3. Organizational Context

### 3.1 Presence in Texas

- LoneStar is headquartered in Dallas, Texas.  
- LoneStar places candidates with staffing clients across Texas (Dallas–Fort Worth, Houston, Austin, San Antonio) and remotely.  
- LoneStar processes data of candidates nationwide, including Texas residents.

Conclusion: TRAIGA clearly applies to LoneStar’s Texas recruiting operations.[web:17][web:36]

### 3.2 Business Areas Using AI

Current AI usage:

- Talent acquisition / recruiting / hiring – résumé screening, candidate matching, and lead scoring.  
- HR (internal) – basic performance analytics for LoneStar’s internal sales staff.  
- Marketing – simple email subject‑line optimization (not tied to individual rights).

For this memo, focus is on AI used in **candidate sourcing and screening** for Texas positions.

---

## 4. AI System Inventory

| ID | System / Tool Name | Provider (Internal/Vendor) | Main Purpose | Business Area | Deployed in Texas? (Y/N/Planned) |
|----|--------------------|----------------------------|--------------|--------------|----------------------------------|
| AI‑01 | TalentRank ATS Scoring | Vendor – TalentRank Inc. | Scores and ranks applicants based on résumé and application data. | Recruiting / screening | Y |
| AI‑02 | MatchPro Candidate Matcher | Vendor – MatchPro Labs | Suggests “best‑fit” candidates from database for open reqs. | Recruiting / sourcing | Y |
| AI‑03 | ChatAssist Recruiter Bot | Vendor – ChatAssist Co. | Answers candidate FAQs and does initial chat screening. | Recruiting / pre‑screen | Y |
| AI‑04 | InsightSales Performance Analytics | Vendor – InsightSales | Analyzes internal sales rep performance. | Internal HR / sales | Y |
| AI‑05 | SmartSend Email Optimizer | Vendor – SmartSend | Optimizes subject lines and send times. | Marketing | Y |

---

## 5. Consequential Decision Classification

| ID | System / Tool Name | Decision Type | Consequential? (Y/N) | Example Decisions | Texas Individuals Affected? (Y/N) |
|----|--------------------|--------------|----------------------|-------------------|-----------------------------------|
| AI‑01 | TalentRank ATS Scoring | Candidate screening / shortlisting | Y | Determines which applicants are surfaced at the top of recruiter queues and which are effectively ignored. | Y |
| AI‑02 | MatchPro Candidate Matcher | Candidate matching / recommendations | Y | Suggests which existing candidates are recommended to clients first. | Y |
| AI‑03 | ChatAssist Recruiter Bot | Pre‑screen / eligibility filter | Y (limited) | Uses rules to determine which candidates proceed to recruiter review. | Y |
| AI‑04 | InsightSales Performance Analytics | Internal performance analytics | N | Used for dashboards only; managers make decisions manually. | Y |
| AI‑05 | SmartSend Email Optimizer | Email optimization | N | Only changes subject lines and send times; no direct effect on individual rights. | Y |

Observations:

- AI‑01, AI‑02, and AI‑03 all influence hiring outcomes for candidates applying for positions in Texas.  
- AI‑04 and AI‑05 are currently treated as low‑risk and non‑consequential for TRAIGA purposes.

---

## 6. Input, Output, and Human Involvement

| ID | Inputs (Data Types) | Outputs (Score / Recommendation / Decision) | Human in the Loop? (How?) |
|----|---------------------|---------------------------------------------|---------------------------|
| AI‑01 | Résumé text, application answers, years of experience, location, skills keywords. | Numeric “fit” score 0–100 and ranked candidate list. | Recruiters can override rankings, but default view uses AI ordering. |
| AI‑02 | Historical placement data, job descriptions, candidate profiles, skills tags. | Ranked list of “recommended” candidates for each job order. | Recruiters can add/remove candidates manually; many start from AI list. |
| AI‑03 | Chat responses, availability, experience level, work authorization answers. | Rule‑based recommendation: “Proceed,” “Needs Review,” or “Not a fit.” | Recruiters review “Needs Review,” but often auto‑advance “Proceed.” |
| AI‑04 | Sales activity logs, revenue generated, tenure, pipeline metrics. | Performance scores and trend dashboards. | Managers interpret dashboards; no automatic decisions. |
| AI‑05 | Email engagement stats (open/click), send history, recipient segments. | Recommended send times and subject‑line variants. | Marketing decides campaigns; no individual‑level rights impact. |

Narrative descriptions:

- **AI‑01 – TalentRank ATS Scoring:** LoneStar uses TalentRank’s scoring feature to automatically rank applicants for high‑volume roles. Recruiters typically work the top 50 candidates first, which can materially affect whether a candidate receives an interview.  
- **AI‑02 – MatchPro Candidate Matcher:** MatchPro recommends candidates already in LoneStar’s database when a new requisition is opened. Recruiters routinely start with the top recommendations, which affects which candidates are submitted to clients.  
- **AI‑03 – ChatAssist Recruiter Bot:** Handles initial screening questions through the careers chatbot. Some “Not a fit” candidates are not reviewed by a human unless they re‑apply through another channel.

---

## 7. Initial TRAIGA Scope Assessment

Systems clearly in scope for enhanced TRAIGA obligations (consequential employment decisions for Texas candidates):

- AI‑01 – TalentRank ATS Scoring (screening / shortlisting).  
- AI‑02 – MatchPro Candidate Matcher (candidate recommendations to clients).  
- AI‑03 – ChatAssist Recruiter Bot (initial eligibility screening).[web:17][web:21][web:33][web:36]

Systems likely out of scope as non‑consequential:

- AI‑04 – InsightSales Performance Analytics (internal dashboards; no automated employment decisions).  
- AI‑05 – SmartSend Email Optimizer (marketing optimization only).

Open questions / dependencies:

- Whether any client‑side AI tools (e.g., clients’ own screening platforms) are used jointly with LoneStar’s systems and how TRAIGA allocates responsibilities.  
- Whether future use of AI‑04 for automated performance‑based bonuses or terminations would bring it into scope.

**Current TRAIGA scope level for LoneStar:**  
- ☒ Medium / High  
- Rationale: Multiple AI systems materially influence candidate screening and selection for Texas roles, but there are no AI systems yet making fully automated final hiring or termination decisions.

---

## 8. Recommended Next Steps

Priority TRAIGA follow‑ups:

1. Launch TRAIGA AI Risk / Impact Assessments for AI‑01, AI‑02, and AI‑03 (Deliverable 02).  
2. Document human‑in‑the‑loop safeguards and escalation rules for all three systems.  
3. Review vendor contracts for TalentRank, MatchPro, and ChatAssist to ensure appropriate AI disclosures, performance commitments, and cooperation with testing/monitoring.  
4. Begin drafting applicant notices and candidate appeal language tied to these tools.

Responsible owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| Complete full TRAIGA scope confirmation with counsel | Compliance + Legal | March 15, 2026 |
| Finish AI‑01 / AI‑02 / AI‑03 risk assessments | Compliance | April 30, 2026 |
| Update vendor contracts for AI recruiting tools | Legal | May 31, 2026 |

---

**End of Example**
