# Texas TRAIGA – AI Governance Program – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** AI Governance Program (Policy + Oversight Charter)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose and Scope

This AI Governance Program describes how LoneStar Talent Solutions (“LoneStar”) manages artificial intelligence systems used in its staffing and recruiting business, particularly for roles in Texas.

It is intended to:

- Align LoneStar’s AI practices with TRAIGA’s expectations for deployers of AI systems used in employment decisions.  
- Define roles and responsibilities for AI oversight across Compliance, Recruiting, IT, and Leadership.  
- Provide a framework for inventory, assessments, testing, monitoring, notices, and appeals for AI used in candidate screening and selection.[web:17][web:21][web:33][web:36]

---

## 2. Definitions (Plain Language)

For LoneStar:

- **AI system:** Any automated system that infers from input data (résumés, applications, chat responses, etc.) how to generate outputs such as scores, rankings, or recommendations that influence recruiting decisions.  
- **Consequential decision:** Any decision that materially affects a candidate’s employment opportunity with a LoneStar client in Texas, including whether a candidate is shortlisted, interviewed, or placed in a role.[web:17][web:33][web:36]  
- LoneStar is primarily a **deployer** of third‑party AI systems embedded in its ATS and recruiting tools.

---

## 3. Governance Structure

### 3.1 AI Governance Committee

LoneStar establishes an **AI Governance Committee** with members from Compliance, Recruiting, Systems & Data, and Legal (external counsel as needed).

- **Chair:** Maria Ortiz, Director of Compliance  
- **Members:**  
  - Jason Reed, VP of Recruiting  
  - Priya Desai, Director of Systems & Data  
  - External Counsel (as invited for specific matters)

### 3.2 Responsibilities

The Committee:

- Maintains the AI system inventory (TalentRank scoring, MatchPro, ChatAssist, and any future tools).  
- Approves new AI‑enabled recruiting tools before they are used for candidate decisions in Texas.  
- Reviews and signs off on AI Risk & Impact Assessments for high‑impact systems.  
- Oversees testing and monitoring results, including fairness checks on candidate selection outcomes.  
- Ensures appropriate candidate disclosures and a functioning appeal process.

### 3.3 Meeting Cadence

- Regular meetings: Quarterly (January, April, July, October).  
- Ad‑hoc meetings:  
  - When a new AI recruiting tool is proposed.  
  - When major updates to AI tools occur (e.g., new model versions).  
  - When significant complaints or anomalies arise (e.g., pattern of candidate complaints).

---

## 4. AI System Lifecycle and Approval

### 4.1 When This Program Applies

This program applies to:

- Any new AI‑driven feature or tool that ranks, filters, or screens candidates.  
- Any significant configuration change (e.g., thresholds, model options) to existing AI tools used for Texas roles.  
- Any retirement of AI tools that have historically influenced Texas candidate decisions.

### 4.2 Lifecycle Stages at LoneStar

1. **Proposal & Triage** – Recruiting or IT identifies a new AI feature (e.g., a new matching algorithm in the ATS) and submits a one‑page intake form.  
2. **Classification** – The Committee classifies the tool as high‑impact, moderate‑impact, or low‑impact based on its influence on candidate outcomes.  
3. **Assessment** – For high‑impact systems (TalentRank scoring, MatchPro, ChatAssist), LoneStar completes a TRAIGA AI Risk & Impact Assessment.  
4. **Approval** – The Committee reviews the assessment and either approves, approves with conditions, or rejects the deployment.  
5. **Deployment** – Systems are rolled out with required controls, notices, and recruiter training.  
6. **Monitoring & Review** – Quarterly reviews of performance, fairness, and complaints.

---

## 5. Roles and Responsibilities

### 5.1 Business Owners (Recruiting)

- Propose use of new ATS/AI features.  
- Ensure frontline recruiters follow documented workflows, including human‑review and appeal steps.  
- Provide feedback on tool performance and candidate experience.

### 5.2 Technical / Data Owners (Systems & Data)

- Configure and manage integrations with TalentRank, MatchPro, and ChatAssist.  
- Support data extraction for fairness and performance analysis.  
- Maintain technical documentation (system diagrams, data flows, logs).

### 5.3 Compliance / Legal

- Interpret TRAIGA and employment law implications for LoneStar’s use of AI in recruiting.  
- Lead AI Risk & Impact Assessments and document conclusions.  
- Coordinate external counsel review when needed and manage responses to inquiries or complaints.

### 5.4 AI Governance Committee

- Approve or deny AI deployments and major changes.  
- Review quarterly monitoring reports and escalations.  
- Report annually to the CEO on AI‑related risks and remediation plans.

---

## 6. Intake and Classification of AI Systems

### 6.1 Intake Form

LoneStar’s intake form for new AI tools asks for:

- Tool name and provider, with contract status.  
- Description of the recruiting use case (sourcing, screening, scheduling, etc.).  
- Whether the tool will be used for Texas candidates.  
- Expected impact on shortlisting or hiring outcomes.

### 6.2 Classification Criteria

The Committee uses the following simplified criteria:

- **High‑impact:** Tool ranks, filters, or recommends candidates in a way that can materially change who is interviewed or hired for Texas roles (e.g., TalentRank scoring).  
- **Moderate‑impact:** Tool supports recruiters but does not directly determine candidate flow (e.g., scheduling assist).  
- **Low‑impact:** Tool is limited to admin support, reporting, or communications (e.g., generic email optimization).

High‑impact systems are the priority for TRAIGA‑aligned assessments and controls.[web:17][web:33][web:36]

---

## 7. Risk Assessment, Testing, and Monitoring

### 7.1 Risk & Impact Assessments

LoneStar completes AI Risk & Impact Assessments for:

- AI‑01 – TalentRank ATS Scoring (candidate ranking).  
- AI‑02 – MatchPro Candidate Matcher (candidate recommendations).  
- AI‑03 – ChatAssist Recruiter Bot (initial screening).

Assessments capture how these tools influence candidate outcomes and what risks exist around bias, accuracy, and transparency.

### 7.2 Testing

- Pre‑deployment: LoneStar now requests and reviews vendor testing summaries before enabling new AI features. For future tools, LoneStar plans small pilots with manual review.  
- Ongoing: Compliance runs quarterly checks on selection and outreach patterns for Texas roles, looking for anomalies or patterns suggesting unfair impact.

### 7.3 Monitoring and Reporting

- Systems & Data generates quarterly reports showing:  
  - Number of candidates processed, contacted, and placed per role.  
  - Use of overrides (recruiters advancing low‑scored candidates).  
  - Any spikes in complaints referencing “automated rejection.”

- The Committee reviews these reports and documents any follow‑up actions.

---

## 8. Transparency, Human Review, and Appeals

### 8.1 Transparency and Notices

LoneStar is implementing updates to:

- Add a short disclosure on its careers site and application portal that automated tools may be used to help screen and match candidates, and that human recruiters remain involved.  
- Include a brief explanation in candidate FAQs about the role of AI‑based tools and how candidates can contact LoneStar with questions.[web:17][web:33][web:36]

### 8.2 Human Review of Decisions

Policies for TalentRank and MatchPro:

- Recruiters must review a mix of top‑scored candidates and a sample of mid‑range candidates for high‑volume requisitions.  
- Fully automated rejection without any recruiter review is not permitted for Texas candidates.

### 8.3 Appeals and Corrections

LoneStar is piloting an **AI decision review** process:

- Candidates can email a dedicated address or use a form to request review if they believe they were unfairly screened out.  
- Compliance and Recruiting jointly review such requests, inspect the ATS records, and determine whether to re‑open the candidate.  
- All appeals and outcomes are logged for future monitoring.

---

## 9. Documentation and Recordkeeping

LoneStar maintains:

- A central AI inventory spreadsheet with system details and classification.  
- Signed meeting minutes for AI Governance Committee sessions.  
- Completed AI Risk & Impact Assessments for AI‑01, AI‑02, and AI‑03.  
- Copies of candidate disclosures, recruiter guidance documents, and appeal procedures.  
- Key email exchanges and contractual clauses with AI vendors regarding configuration and testing.

Retention:

- Core governance documents and assessments: minimum 5 years.  
- Monitoring reports and meeting minutes: minimum 3 years, or longer if tied to ongoing matters.[web:17][web:33][web:36]

---

## 10. Training and Awareness

- New recruiters receive an onboarding module explaining LoneStar’s use of AI tools and their obligations (e.g., not relying blindly on scores, honoring appeals).  
- Annual refresher training highlights any changes to tools, policies, or legal expectations.

Completion is tracked in the HR system.

---

## 11. Review and Updates

- The AI Governance Committee will review this program annually each January.  
- Updates will be made if TRAIGA guidance evolves, if LoneStar deploys new high‑impact AI tools, or if monitoring reveals significant issues.

Any changes are communicated to affected teams and incorporated into training.

---

**End of Example**
