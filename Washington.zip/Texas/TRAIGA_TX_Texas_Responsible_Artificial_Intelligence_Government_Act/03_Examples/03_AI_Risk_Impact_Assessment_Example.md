# Texas TRAIGA – AI Risk & Impact Assessment – AI‑01 TalentRank ATS Scoring

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** AI Risk & Impact Assessment (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose of This Assessment

This assessment evaluates the risks associated with LoneStar’s use of the TalentRank ATS scoring feature (AI‑01) for candidate screening in Texas. It documents how the system is used, what risks it poses, and what controls LoneStar has in place to align with TRAIGA.

This document is internal compliance support, not legal advice, and should be reviewed by counsel before being relied upon.[web:17][web:33][web:36]

---

## 2. System Overview

### 2.1 Basic Information

- **System ID (from inventory):** AI‑01  
- **System / Tool Name:** TalentRank ATS Scoring  
- **Provider (Internal / Vendor):** Vendor – TalentRank Inc.  
- **Business Owner:** Jason Reed, VP of Recruiting  
- **Technical Owner:** Priya Desai, Director of Systems & Data  

### 2.2 Purpose and Use

- **Primary purpose of the AI system:**  
  TalentRank’s scoring feature automatically assigns a “fit score” to applicants and ranks them within each requisition to help recruiters prioritize outreach.

- **Consequential decision(s) supported:**  
  - Shortlisting and screening of candidates for client positions in Texas.  
  - In practice, candidates with low scores are rarely reviewed, which can materially affect whether they are interviewed or placed.[web:17][web:21][web:33]

- **Geographic scope:**  
  - Used for candidates applying to roles with Texas clients: **Yes**  
  - Also used for some out‑of‑state roles nationwide.

---

## 3. Inputs, Outputs, and Decision Flow

### 3.1 Inputs

- Structured data: job title, years of experience, education level, location, skills tags, work authorization status.  
- Unstructured data: résumé text, cover letters, some recruiter notes.  
- Sensitive / proxy data: ZIP code and school history may act as proxies for race or socioeconomic status; age is inferred from graduation year when available (proxy for age).[web:17][web:33]

### 3.2 Outputs

- **Output type:** Numeric “fit score” (0–100) and ranked candidate list per requisition.  
- **Output range:** 0–100; candidates above 70 are tagged as “Top Matches.”  
- **Presentation:** Recruiters see an ordered list in the ATS with the score next to each candidate.

### 3.3 Role in Decision-Making

- The system is **advisory in theory**, but **highly influential in practice**.  
- Recruiters typically contact the top 50 candidates first; candidates below a certain threshold are rarely reviewed unless manually searched.

Decision flow:

- Candidates apply → TalentRank scores and ranks them → Recruiter views top candidates list → Recruiter selects candidates for outreach based primarily on AI ranking → Clients receive submissions from this pool.

---

## 4. Individuals Affected

### 4.1 Categories of Individuals

- Job applicants / candidates: **Yes**  
- Employees / contractors (internal roles): Occasionally, for internal hires.

### 4.2 Scale of Use

- Approximate Texas candidates scored per year: ~18,000.  
- Approximate total candidates scored per year (all regions): ~75,000.

---

## 5. Risk Identification

### 5.1 Types of Risk Considered

- ☒ Accuracy / reliability risk  
- ☒ Bias / fairness risk  
- ☒ Privacy / security risk  
- ☒ Transparency / explainability risk  
- ☒ Legal / regulatory risk  
- ☒ Reputational risk  

### 5.2 Narrative Risk Summary

Key risks:

- If the model is mis‑calibrated, qualified candidates may receive low scores and never be contacted.  
- Features such as ZIP code and school history could produce disparate impact on protected groups.  
- Lack of clear applicant disclosures could create regulatory and reputational exposure under TRAIGA and discrimination laws.

---

## 6. Testing and Evaluation

### 6.1 Pre-Deployment Testing

- LoneStar relied primarily on vendor documentation when enabling TalentRank in 2024. No independent pre‑deployment fairness testing was performed at LoneStar.  
- Vendor claimed “benchmark testing for bias,” but did not provide detailed metrics or underlying datasets.

Pre‑deployment testing summary:

- Accuracy and performance: Reviewed vendor’s high‑level documentation.  
- Bias: Vendor asserted fair performance; no internal validation.  
- Robustness/security: No separate penetration or adversarial testing beyond standard ATS security review.[web:17][web:33][web:36]

### 6.2 Ongoing Monitoring

- Monitoring schedule: Quarterly review, implemented in Q1 2026.  
- Metrics tracked:  
  - Distribution of scores by candidate demographic proxies (using location and job category).  
  - Ratio of candidates contacted vs. total applicants, by requisition and recruiter.  
  - Number of recruiter overrides (low‑scored candidate manually advanced).  

Monitoring owner: Compliance team, with reports to VP of Recruiting.

Process summary:

- Compliance exports quarterly data from the ATS, calculates score distributions and contact rates, and flags outlier requisitions or patterns for detailed review.

---

## 7. Bias, Fairness, and Impact on Protected Groups

### 7.1 Data and Features

- Protected characteristics (race, sex, age) are **not explicitly used** as inputs.  
- ZIP code, school history, and inferred career gaps may act as proxies for protected characteristics.

Proxy features description:

- Candidates from certain ZIP codes and less‑resourced schools appear to receive slightly lower average scores for some clerical roles.

### 7.2 Fairness Evaluation

Fairness tests performed:

- Comparison of score distributions and contact rates across major metro regions in Texas.  
- Manual spot‑checks of candidate profiles with high experience but low scores.

Key findings:

- No extreme disparities detected, but some roles show lower average scores for candidates in certain regions linked with lower income demographics.  
- Recruiters occasionally report “strong candidates with inexplicably low scores.”

Mitigations implemented:

- Introduced recruiter guidance to regularly search beyond the top 50 candidates for high‑volume roles.  
- Compliance and technical teams are working with the vendor to reduce the weight of ZIP code and school prestige in the scoring logic for Texas positions.[web:17][web:33][web:36]

---

## 8. Human Oversight and Appeals

### 8.1 Human in the Loop

- Recruiters remain formally responsible for final screening decisions.  
- New policy (2026): Recruiters must review at least a sample of candidates below the “Top Matches” threshold for high‑volume requisitions to reduce over‑reliance on AI.

Human oversight description:

- Recruiters can override rankings and manually advance any candidate.  
- Compliance periodically reviews override rates; low override use triggers additional training.

### 8.2 Individual Rights and Appeals

- Candidates currently have a generic contact channel (“careers@lonestartalent.com”) for questions or complaints.  
- Formal AI‑specific appeal process is being designed for 2026.

Appeal process summary (planned):

- Add disclosure to application portal noting use of automated tools in screening.  
- Provide a simple web form where candidates can request a human review if they believe they were unfairly screened out.  
- HR/Compliance will log such appeals and require a manual assessment of the candidate’s application within 15 business days.[web:17][web:33][web:36]

---

## 9. Security, Privacy, and Vendors

### 9.1 Security and Data Protection

Sensitive data handled:

- Candidate personal information, work history, contact details, limited demographic info when provided voluntarily.

Security controls:

- ATS and TalentRank hosted in SOC 2–certified environment, with role‑based access control.  
- Data encrypted in transit and at rest; access restricted to recruiting and IT staff.

### 9.2 Vendors and Contracts

- AI provided by external vendor: TalentRank Inc.  

Contractual controls:

- Contract describes services and basic data‑use limits, but does not specifically reference TRAIGA or AI‑specific responsibilities.  
- Security and incident‑response clauses exist; cooperation with testing and audits is high‑level only.

Vendor gaps:

- No requirement to provide detailed bias testing results or explainability documentation.  
- No explicit commitment to cooperate with LoneStar’s TRAIGA risk assessments and ongoing monitoring.

Planned actions:

- Amend contract in 2026 renewal to include AI‑specific obligations (documentation, cooperation, and notification duties regarding material model changes).[web:17][web:24][web:36]

---

## 10. Overall Risk Rating and Mitigation Plan

### 10.1 Overall Risk Rating

**Overall risk level for AI‑01:**

- ☒ Medium / High  

Rationale:

- System materially influences which candidates in Texas are considered for roles.  
- Independent fairness testing has been limited, and proxy features may create disparate impact if not managed.  
- Controls are improving but not yet mature.

### 10.2 Mitigation Actions

Priority mitigation steps:

1. Complete a full independent fairness review for AI‑01 using 2025–2026 Texas candidate data.  
2. Negotiate revised model configuration with TalentRank to reduce reliance on proxy features for protected characteristics.  
3. Implement and document a clear candidate appeal process with human review.  
4. Update vendor contract to include specific AI documentation and cooperation obligations under TRAIGA.

Owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| Independent fairness review for AI‑01 | Compliance + Data | May 31, 2026 |
| Adjust model configuration with vendor | Systems & Data + Vendor | July 31, 2026 |
| Launch candidate AI‑screening appeal process | HR + Compliance | June 30, 2026 |
| Amend TalentRank contract for TRAIGA alignment | Legal | September 30, 2026 |

---

**End of Example**
