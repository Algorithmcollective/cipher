# Texas TRAIGA – Human Review & Appeals Workflow – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Human Review & Appeals Workflow (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose

This workflow describes how LoneStar Talent Solutions (“LoneStar”) ensures human review of AI‑assisted recruiting decisions and provides candidates with a way to raise concerns and request review for Texas roles.

It supports LoneStar’s TRAIGA‑aligned AI governance and complements its AI Governance Program and Data, Testing & Monitoring Plan.[web:17][web:33][web:36][web:49][web:50]

---

## 2. Scope

Applies to AI systems:

- **AI‑01 – TalentRank ATS Scoring** (candidate ranking).  
- **AI‑02 – MatchPro Candidate Matcher** (candidate recommendations).  
- **AI‑03 – ChatAssist Recruiter Bot** (initial screening).

These systems influence which candidates are contacted or advanced for roles with Texas clients.

---

## 3. Human Review of AI Outputs

### 3.1 General Principle

At LoneStar:

- AI tools assist recruiters but do **not** make final hiring or rejection decisions on their own.  
- A recruiter is expected to review candidate information before closing a requisition or designating a candidate as “not moving forward” for Texas roles.[web:17][web:21][web:33][web:36]

### 3.2 Standard Workflow

1. **AI output generated:**  
   - TalentRank scores and ranks candidates.  
   - MatchPro suggests candidates from the database.  
   - ChatAssist labels candidates as “Proceed,” “Needs Review,” or “Not a fit.”

2. **Recruiter review:**  
   - Recruiter logs into the ATS, sees AI‑ranked lists, and opens candidate profiles.  
   - For high‑volume roles, recruiters must review:  
     - The top 50 AI‑ranked candidates, and  
     - At least a sample of candidates outside the top 50 for Texas roles.

3. **Decision:**  
   - Recruiter decides whether to contact, hold, or decline each candidate, based on the candidate’s materials and role requirements.  

4. **Override:**  
   - If a recruiter advances a low‑scored candidate or declines a high‑scored candidate, they select an override reason (e.g., “unique niche experience,” “client‑specific requirement”).

5. **Escalation:**  
   - If a recruiter suspects an AI tool is behaving strangely (e.g., all candidates from a particular city receiving low scores), they escalate to their team lead and Compliance.

---

## 4. Roles and Responsibilities

- **Primary reviewer:** Recruiters (and, where applicable, account managers).  
- **Escalation reviewer:** Recruiting team leads.  
- **Compliance contact:** Maria Ortiz, Director of Compliance.

RACI:

- Responsible: Recruiters.  
- Accountable: Team leads.  
- Consulted: Compliance, Systems & Data, external counsel as needed.  
- Informed: AI Governance Committee.

---

## 5. Detailed Steps per Tool

### 5.1 TalentRank ATS Scoring (AI‑01)

1. Recruiter opens TalentRank view for each requisition.  
2. Reviews candidate details starting from the top of the list.  
3. Ensures that for Texas roles, at least a set of mid‑range candidates (e.g., scores 50–69) are sampled.  
4. Applies decision: Contact, Hold, or Decline.  
5. Records any override reasons using ATS notes.

### 5.2 MatchPro Candidate Matcher (AI‑02)

1. When a new requisition is opened, recruiter runs MatchPro to generate recommended candidates.  
2. Reviews recommended candidates and may also run a manual search.  
3. Ensures that recommendations are not used as the sole source of candidates for Texas roles.  
4. Flags obviously irrelevant recommendations to Systems & Data for configuration review.

### 5.3 ChatAssist Recruiter Bot (AI‑03)

1. ChatAssist conducts initial Q&A with candidates and assigns them a preliminary label.  
2. For Texas roles, candidates labeled “Not a fit” are not auto‑discarded; a subset is reviewed weekly by recruiters.  
3. Any repeated issues (e.g., candidates mis‑labeled due to ambiguous questions) are escalated to Compliance and Systems & Data for script adjustment.

---

## 6. Appeals and Complaint Intake

### 6.1 Channels

LoneStar offers:

- Email: ai-review@lonestartalent.com  
- Web form: “Request a Review” link on the careers FAQ and in some rejection email templates.

Description:

> Candidates who believe they were unfairly screened out or affected by automation can email or submit the form to request a human review for Texas roles.

### 6.2 Information Collected

For each appeal:

- Candidate name and contact information.  
- Role title and requisition ID.  
- Approximate date of application or communication.  
- Short description of the concern (e.g., “automated screening message,” “no human review”).  
- Explicit request for human review, if applicable.[web:17][web:33][web:36][web:50]

---

## 7. Appeals Handling Workflow

### 7.1 Timelines

- Acknowledgment email: within **5 business days**.  
- Substantive response / decision: within **20 business days**, unless more time is needed (in which case LoneStar sends an interim update).

### 7.2 Steps

1. **Log the appeal:**  
   - Intake team logs request in the “AI Appeals” tracker (SharePoint list), assigns ID, and tags the relevant AI system(s).

2. **Assign reviewer:**  
   - A senior recruiter or team lead not directly involved in the original decision is assigned.

3. **Collect records:**  
   - Reviewer pulls the candidate’s application, AI scores/labels, recruiter notes, and any relevant email or chat logs.

4. **Human review:**  
   - Reviewer reassesses the candidate’s qualifications against job requirements *without* relying solely on the prior AI output.  
   - Reviewer can consult Compliance if systemic issues appear.

5. **Decision:**  
   - Uphold (decision stands), Modify (e.g., re-open for consideration), or Reverse (e.g., invite for interview).

6. **Communicate outcome:**  
   - Candidate receives a concise explanation and, if relevant, confirmation that a human has reviewed their case.

7. **Close and tag:**  
   - Appeal outcome is logged. If multiple appeals reveal similar issues, Compliance flags a potential systemic problem for the AI Governance Committee.

---

## 8. Logging, Metrics, and Feedback Loop

LoneStar tracks:

- Number of AI-related appeals per quarter, by AI system and by client segment.  
- Outcome distribution (upheld / modified / reversed).  
- Average time to resolution.  
- Recurrent themes (e.g., location handling, gaps in experience interpretation).

Summary:

> Twice per year, the AI Governance Committee reviews appeal trends. If patterns suggest a recurring AI configuration or communication problem, LoneStar may adjust thresholds, revise scripts, or enhance candidate notices.[web:17][web:33][web:36][web:49][web:52]

---

## 9. Review and Updates

- This workflow will be reviewed each January alongside LoneStar’s AI Governance Program.  
- If LoneStar adds new AI tools (e.g., automated reference checking) or significantly changes existing tools, Compliance will update the workflow accordingly.

Version history:

- Version 1.0 – January 31, 2026 – Initial TRAIGA-aligned workflow adopted.

---

**End of Example**
