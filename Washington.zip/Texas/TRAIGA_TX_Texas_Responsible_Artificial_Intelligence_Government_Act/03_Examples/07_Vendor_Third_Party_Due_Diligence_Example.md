# Texas TRAIGA – Vendor & Third-Party AI Due-Diligence Pack – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Vendor & Third-Party AI Due-Diligence Pack (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose

This example shows how LoneStar Talent Solutions (“LoneStar”) documents due diligence and contract controls for its AI‑enabled recruiting vendors under a TRAIGA-aligned governance approach.

It focuses on:

- TalentRank Inc. (AI‑based ATS scoring).  
- MatchPro Labs (candidate matching).  
- ChatAssist Co. (screening chatbot).[web:17][web:21][web:47][web:49][web:64]

---

## 2. When LoneStar Uses This Pack

LoneStar applies this pack when:

- Evaluating new AI recruiting tools or upgrades proposed by its ATS provider.  
- Renewing or renegotiating vendor contracts where AI features materially impact candidate outcomes in Texas.  
- Preparing for client due‑diligence requests or potential regulatory questions about third‑party AI tools.

---

## 3. Vendor AI Due-Diligence Questionnaire (Example: TalentRank Inc.)

**File:** `TEX_TRAIGA_07_Vendor_DueDiligence_Questionnaire_Example_TalentRank.md`

Key information captured from TalentRank:

1. **Vendor and System Identification**  
   - Vendor: TalentRank Inc.  
   - System: TalentRank ATS Scoring – Version 3.2.  
   - Description: AI‑based scoring and ranking feature embedded in LoneStar’s ATS, used to prioritize applicants for open roles.

2. **AI System Design and Intended Use**  
   - Decision supported: Candidate screening and shortlisting.  
   - Intended users: Recruiters within staffing agencies; end‑users are job applicants.  
   - Customer configuration: LoneStar can adjust some thresholds (e.g., score cutoffs) and enable/disable certain filters.

3. **Data and Model Information**  
   - Inputs: application fields, résumé contents, job description keywords, tenure, location.  
   - Vendor states that protected characteristics (race, sex, religion, disability) are not explicit features.  

4. **Testing, Fairness, and Monitoring**  
   - Vendor provided high‑level summaries of benchmarking and periodic performance checks.  
   - Vendor offers limited documentation on fairness testing but is open to customer‑specific evaluation discussions.

5. **Security and Privacy**  
   - SOC 2 Type II certified.  
   - Data encrypted at rest and in transit; role‑based access control; activity logging.  
   - Retention: Candidate data handled under LoneStar’s ATS retention settings.[web:22][web:37][web:39][web:64]

6. **Explainability and Oversight Support**  
   - Vendor provides high‑level explanation of factors influencing scores (e.g., skills match, experience, location).  
   - Audit logs show when scores were computed and when configurations changed.

7. **Incident and Complaint Handling**  
   - Vendor commits to notifying LoneStar of any major system bugs or misconfigurations affecting scoring behavior.  
   - Escalation path to a named technical account manager.

8. **Compliance and Legal**  
   - Vendor has an internal AI governance committee and monitors developments in state AI laws, including TRAIGA.  
   - Legal contact provided for data protection and AI compliance queries.[web:47][web:49][web:64][web:65]

---

## 4. AI Vendor Contract Checklist (Example Notes)

**File:** `TEX_TRAIGA_07_Vendor_Contract_Checklist_Example_LoneStar.md`

Highlights for LoneStar’s TalentRank contract:

- **Scope and Description:**  
  - Contract and attached SOW describe TalentRank’s scoring as an advisory feature to assist recruiters; LoneStar retains final hiring authority.

- **Data Use and Ownership:**  
  - Data use limited to providing services and product improvement in de‑identified/aggregated form.  
  - No sale of candidate data; LoneStar remains data controller for ATS records.

- **Security and Privacy:**  
  - Explicit SOC 2 requirement, with annual report sharing.  
  - Security incident notice within 72 hours of confirmed incidents.

- **Testing, Documentation, and Cooperation:**  
  - New addendum language requires TalentRank to share high‑level model documentation and summaries of testing efforts, upon request, to support LoneStar’s TRAIGA risk assessments.

- **Change Management and Notifications:**  
  - Vendor must provide 30 days’ notice before material feature or model changes affecting scoring logic.

- **Incident Notification and Remediation:**  
  - For any scoring bug materially affecting candidate rankings over more than 7 days, TalentRank agrees to cooperate in identifying impacted candidates and supporting customer remediation.[web:47][web:49][web:64][web:67][web:70]

---

## 5. AI Vendor Contract Addendum – Short Clause Example

**File:** `TEX_TRAIGA_07_Vendor_Addendum_Short_Example_TalentRank.md`

LoneStar’s short addendum with TalentRank includes:

- An “AI Governance and Cooperation” section requiring TalentRank to provide enough documentation for LoneStar’s internal AI assessments and monitoring.  
- A “Data Use and Protection” section limiting TalentRank’s use of candidate data and reinforcing security obligations.  
- A “Regulatory and Audit Support” clause stating that TalentRank will provide reasonable assistance if LoneStar faces inquiries regarding the AI scoring features used in Texas.[web:47][web:49][web:64][web:67][web:70]

(Exact legal text handled with external counsel.)

---

## 6. Vendor Risk Register Entry (Example)

**File:** `TEX_TRAIGA_07_Vendor_Risk_Register_Example_LoneStar.md`

| Vendor | System | Role | Risk Level | Key Issues | Mitigations | Last Review |
|--------|--------|------|-----------|-----------|------------|------------|
| TalentRank Inc. | TalentRank ATS Scoring | AI scoring provider | Medium / High | Limited transparency into model internals; reliance on vendor fairness testing. | Contract addendum requiring documentation and cooperation; internal quarterly monitoring and overrides tracking. | Jan 31, 2026 |
| MatchPro Labs | MatchPro Candidate Matcher | AI matching provider | Medium | Risk of stale or biased recommendations narrowing candidate pool. | Monitoring of placement sources; periodic retraining and configuration review. | Jan 31, 2026 |
| ChatAssist Co. | ChatAssist Recruiter Bot | AI chatbot provider | Medium | Misclassification risk in initial screening; candidate perception of “robotic” rejection. | Regular transcript reviews; conservative configuration; clear chatbot disclosure and appeals channel. | Jan 31, 2026 |

---

**End of Example**
