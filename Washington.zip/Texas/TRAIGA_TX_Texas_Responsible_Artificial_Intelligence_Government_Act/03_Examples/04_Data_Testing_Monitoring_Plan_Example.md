# Texas TRAIGA – Data, Testing & Monitoring Plan – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Data, Testing & Monitoring Plan (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose of This Plan

This plan explains how LoneStar Talent Solutions (“LoneStar”) manages data, testing, and monitoring for its AI‑enabled recruiting tools used for Texas candidates.

It is intended to:

- Support LoneStar’s TRAIGA compliance strategy and potential reliance on NIST AI RMF‑aligned practices as a safe harbor.  
- Provide a clear, repeatable process for evaluating and monitoring AI systems that influence staffing decisions in Texas.[web:17][web:49][web:50][web:52][web:53]

---

## 2. Systems in Scope

For 2026, LoneStar applies this plan to:

| ID | System / Tool Name | Provider | Decision Type | Consequential? (Y/N) |
|----|--------------------|---------|---------------|----------------------|
| AI‑01 | TalentRank ATS Scoring | TalentRank Inc. | Candidate screening / ranking | Y |
| AI‑02 | MatchPro Candidate Matcher | MatchPro Labs | Candidate matching / recommendations | Y |
| AI‑03 | ChatAssist Recruiter Bot | ChatAssist Co. | Initial candidate pre‑screen | Y |

These three systems materially influence which candidates are contacted and submitted for Texas roles.

---

## 3. Data Management Principles

### 3.1 Data Sources and Quality

- Data sources: LoneStar’s ATS (applications, résumés, job requisitions), recruiter notes, and limited third‑party enrichment (public professional profiles).  
- Data quality controls: mandatory fields on applications, basic validation on email/phone formats, and routine deduplication of candidate profiles.

Summary:

> LoneStar relies mainly on first‑party application data and résumés, with basic quality checks in place. There is no large‑scale external data scraping.

### 3.2 Data Minimization and Retention

- LoneStar does not intentionally feed protected characteristics (race, religion, etc.) into AI tools.  
- Candidate records are generally retained for up to 3 years unless legal requirements or client contracts require longer retention.  
- Data used in aggregate testing and monitoring is stored in controlled reports and dashboards.

Summary:

> LoneStar collects only data necessary for recruiting and retains it according to HR and client policies, while avoiding unnecessary sensitive attributes whenever possible.[web:22][web:37][web:39]

---

## 4. Pre-Deployment Testing

### 4.1 Testing Objectives

For AI‑01, AI‑02, and AI‑03, LoneStar’s objectives are to:

- Confirm that scoring and matching behave as described by vendors.  
- Identify obvious errors (e.g., blank scores, mis‑ordered rankings).  
- Conduct basic fairness checks using available data before full rollout.

### 4.2 Testing Methods

Pre‑deployment and early‑deployment methods:

- **Shadow mode:** When TalentRank scoring was first enabled, recruiters continued their normal shortlist approach for one month while Compliance compared their picks to the AI’s recommended top candidates.  
- **Sample review:** For MatchPro, recruiters reviewed samples of recommended candidates vs. random candidates to evaluate face‑validity.  
- **Manual sanity checks:** For ChatAssist, Recruiting and Compliance reviewed transcripts from the first 200 conversations to confirm that questions and decision outcomes were reasonable.

Pre‑deployment test summary:

> Testing identified some overly strict default filters in ChatAssist (for availability and experience), which were adjusted before broader use. No major functional errors were identified, but structured fairness testing was limited and is now addressed through ongoing monitoring.[web:47][web:49][web:50][web:52][web:55]

---

## 5. Ongoing Monitoring

### 5.1 Monitoring Schedule

- High‑impact systems (AI‑01, AI‑02, AI‑03): Quarterly monitoring.  
- No moderate/low‑impact AI systems currently in scope for Texas recruiting (analytics tools are tracked separately).

### 5.2 Metrics and Alerts

For AI‑01 (TalentRank scoring):

- Score distribution by role and region.  
- Percentage of candidates contacted within each score band (0–49, 50–69, 70–100).  
- Override rate (low‑scored candidates manually advanced).

For AI‑02 (MatchPro):

- Percentage of placements where candidates originated from MatchPro recommendations vs. manual search.  
- Coverage per role (how many candidates receive recommendations).

For AI‑03 (ChatAssist):

- Percentage of candidates classified as “Proceed,” “Needs Review,” and “Not a fit.”  
- Escalation rate from “Not a fit” to “Reviewed by recruiter” following complaints or internal flags.

Alert thresholds (examples):

- If fewer than 5 percent of low‑scored candidates (0–49) are ever reviewed for a high‑volume Texas role over a quarter, Compliance investigates and may adjust recruiter guidance.  
- If complaint volume referencing “automated rejection” exceeds 10 unique reports in a quarter, the Committee reviews the relevant tool configuration.

Monitoring metrics summary:

> Compliance compiles a quarterly monitoring report for the AI Governance Committee with these metrics and any anomalies.[web:49][web:50][web:52][web:53]

### 5.3 Roles and Responsibilities

- Monitoring data extraction: Systems & Data (Priya Desai).  
- Monitoring analysis: Compliance (Maria Ortiz) with support from Data.  
- Escalation: AI Governance Committee, chaired by Maria Ortiz.

---

## 6. Red-Teaming and Adversarial Testing

Given LoneStar’s size and current AI use:

- Formal red‑teaming is reserved for major changes (e.g., a new version of the scoring model or introduction of automated rejection logic).  
- For 2026, LoneStar plans a limited red‑team exercise for ChatAssist, where internal staff try to elicit inconsistent or inappropriate screening outcomes and log results.

Red‑teaming plan:

> In Q3 2026, Compliance and Systems & Data will coordinate a structured exercise for ChatAssist and, if feasible, for MatchPro’s recommended candidate lists, focusing on edge cases and potential discriminatory impacts.[web:49][web:50][web:52][web:55]

---

## 7. Incident Detection and Response

### 7.1 What Counts as an Incident at LoneStar

Examples:

- Discovering that an AI configuration inadvertently excluded a broad group of candidates (e.g., all ZIP codes outside certain metros).  
- Multiple candidates reporting that they were told “automated screening” rejected them, and internal review reveals a configuration error.  
- Vendor‑reported issues affecting the accuracy or fairness of model outputs.

### 7.2 Response Process

LoneStar’s incident response steps:

1. **Log:** The issue is logged in the AI incident register with a brief description.  
2. **Initial triage:** Compliance and Systems & Data assess scope and urgency within 5 business days.  
3. **Containment:** If needed, pause use of the affected feature (e.g., disable a filter or temporarily suspend automation).  
4. **Analysis:** Review data, configurations, and any vendor notices to identify root cause.  
5. **Remediation:** Adjust settings, retrain internal users, or escalate to vendor for model changes.  
6. **Documentation:** Record the incident, root cause, actions taken, and any follow‑up monitoring.

Incident response summary:

> LoneStar will document AI incidents with enough detail to demonstrate good‑faith detection, remediation, and learning, which supports TRAIGA’s emphasis on documented internal testing and review.[web:49][web:50][web:52][web:53]

---

## 8. Documentation and Regulator-Ready Files

LoneStar maintains:

- An AI systems inventory with basic descriptions of purpose and intended use.  
- A file containing high‑level descriptions of data inputs, outputs, and known limitations for AI‑01, AI‑02, and AI‑03.  
- Quarterly monitoring reports and meeting minutes from AI Governance Committee sessions.  
- Summaries of any red‑team or adversarial testing exercises.  
- The AI incident register with logged issues and resolutions.

Location:

> All AI governance documentation is stored in a restricted SharePoint workspace (“AI Governance – LoneStar”), with access limited to Compliance, Systems & Data, and senior leadership.[web:46][web:49][web:52][web:53]

Retention:

- Monitoring reports and incident logs: minimum 5 years, or longer if related to active disputes or investigations.

---

## 9. Review and Updates

- This plan will be reviewed annually by the AI Governance Committee in January, alongside the AI Governance Program.  
- Updates will be made when LoneStar adds new high‑impact AI systems, changes vendor tools materially, or when TRAIGA guidance or enforcement trends shift.

Version history:

- Version 1.0 – January 31, 2026 – Initial TRAIGA‑aligned plan adopted.  

---

**End of Example**
