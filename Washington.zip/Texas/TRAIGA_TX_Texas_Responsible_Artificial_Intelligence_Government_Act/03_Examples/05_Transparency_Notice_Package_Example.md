# Texas TRAIGA – Transparency & Notice Package – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Transparency & Notice Package (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose and Scope

This package shows how LoneStar Talent Solutions (“LoneStar”) explains its use of AI-based recruiting tools to candidates, even though TRAIGA’s formal disclosure obligations focus on government and certain healthcare providers.

The goal is to reduce “black box” perceptions and demonstrate reasonable transparency to candidates affected by AI-assisted screening in Texas.[web:17][web:36][web:50][web:58][web:60]

---

## 2. When LoneStar Uses These Notices

LoneStar uses these notices when:

- AI tools (TalentRank scoring, MatchPro, ChatAssist) influence which candidates are contacted for Texas roles.  
- Candidates interact directly with ChatAssist, the recruiting chatbot.  
- Candidates or clients ask how AI is being used in recruiting.

---

## 3. Website / Careers Page Disclosure (Example)

**File:** `TEX_TRAIGA_05_Website_Careers_Notice_Example_LoneStar.md`

Placement: “How We Hire” section on careers page.

> **Use of Automated Tools in Our Hiring Process**  
>  
> LoneStar Talent Solutions uses software tools, including automated systems, to help review applications and match candidates to open roles with our clients. These tools analyze information you provide (such as your résumé, application responses, and job preferences) and may generate scores or recommendations for our recruiting team.  
>  
> Human recruiters remain involved in our hiring decisions. If you have questions about how automated tools are used in our process, you can contact us at careers@lonestartalent.com.

---

## 4. Application Portal Inline Notice (Example)

**File:** `TEX_TRAIGA_05_Application_Inline_Notice_Example_LoneStar.md`

Placement: Just above the “Submit Application” button in LoneStar’s ATS.

> **Automated Screening Notice**  
>  
> We may use automated tools to help review and prioritize applications for this role. These tools do not make final hiring decisions on their own, but they may influence which applications our recruiting team reviews first.  
>  
> By submitting your application, you acknowledge that automated tools may be used in this way. If you prefer that your application be reviewed without the use of automated tools where feasible, please email us at careers@lonestartalent.com with the subject line “Manual Review Request.”

---

## 5. Chatbot / Virtual Assistant Disclosure (Example)

**File:** `TEX_TRAIGA_05_Chatbot_Disclosure_Example_LoneStar.md`

Placement: First message from ChatAssist on LoneStar’s careers chatbot.

> **You’re Chatting With an Automated Assistant**  
>  
> This chat is powered by an automated assistant that uses artificial intelligence to respond to your questions and help with basic screening for some roles. A member of our team may review this conversation as part of our recruiting process.  
>  
> If you would like to speak directly with a recruiter, type “human” at any time or email us at careers@lonestartalent.com.[web:36][web:52][web:58][web:60]

---

## 6. FAQ Entry on AI Use (Example)

**File:** `TEX_TRAIGA_05_FAQ_AI_Use_Example_LoneStar.md`

FAQ on LoneStar’s site:

> **Do you use AI in your hiring process?**  
>  
> Yes. We use software tools, including AI-based systems, to help organize and review applications, especially for high-volume positions. These tools may score or rank candidates based on job-related criteria like experience, skills, and location so our recruiting team can focus on the most relevant profiles. Our recruiters still review candidates and make final decisions. We periodically review how these tools are working as part of our compliance and risk management program.[web:17][web:33][web:36][web:49]

---

## 7. Internal Response Script for Recruiters (Example)

**File:** `TEX_TRAIGA_05_Internal_Response_Script_Example_LoneStar.md`

Short script in recruiter playbook:

**If a candidate asks “Did a robot reject me?”**

> “We use some automated tools to help manage a large number of applications, but they don’t make final decisions by themselves. They help us organize and prioritize candidates based on job-related information. If you’d like us to take another look at your application, I can make sure a recruiter reviews it manually.”

**If asked about fairness/testing**

> “Our Compliance and Systems teams review how these tools are working, and we can escalate specific concerns. If you feel something about your background wasn’t handled correctly, we can log that and have someone review it.”

---

## 8. Logging and Evidence at LoneStar

LoneStar keeps:

- Screenshots of all AI-related notices in the careers site, application portal, and ChatAssist.  
- A simple change log noting when each notice was added or updated.  
- A folder in the AI Governance SharePoint site labeled “Transparency & Notices” with PDFs and dates.

Summary practice:

> This documentation helps LoneStar demonstrate that it provides clear and conspicuous, plain-language disclosures where AI plays a meaningful role in candidate interactions, consistent with broader transparency trends under TRAIGA and related laws.[web:46][web:49][web:52][web:53][web:58][web:60]

---

**End of Example**
