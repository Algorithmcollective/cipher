# Texas TRAIGA – Recordkeeping & Documentation Index – LoneStar Talent Solutions

**Law:** Texas Responsible Artificial Intelligence Governance Act (TRAIGA)  
**Document Type:** Recordkeeping & Documentation Index (Example)  
**Organization:** LoneStar Talent Solutions, LLC  
**Date:** January 31, 2026  
**Prepared By:** Maria Ortiz, Director of Compliance  

---

## 1. Purpose

This index shows where LoneStar Talent Solutions (“LoneStar”) stores its TRAIGA‑related AI governance documents and how long it keeps them, so the company can respond quickly to client due‑diligence or regulatory questions about AI use in Texas recruiting.[web:17][web:33][web:36][web:49][web:50][web:52][web:53]

---

## 2. Scope

Covers LoneStar’s 2026 TRAIGA documentation for:

- AI inventory and governance.  
- Risk assessments, testing, and monitoring for AI‑01, AI‑02, and AI‑03.  
- Notices, appeals, vendor files, and potential sandbox materials (if used).

---

## 3. Document Categories and Locations

| Category | Document Type | Example Files | System / Location | Owner | Retention Period |
|---------|---------------|--------------|-------------------|-------|------------------|
| Inventory | AI system inventory & scope memos | `TEX_TRAIGA_01_AI_System_Inventory_MEMO_LoneStar.md` | SharePoint → AI Governance → “01 Inventory” | Compliance | 5 years from last update |
| Governance | AI governance program, committee charter, minutes | `TEX_TRAIGA_02_AI_Governance_Program_LoneStar.md`, committee minutes PDFs | SharePoint → AI Governance → “02 Governance & Minutes” | Compliance | 5 years |
| Assessments | AI risk & impact assessments | `TEX_TRAIGA_03_Risk_Impact_Assessment_AI01_LoneStar.md` etc. | SharePoint → AI Governance → “03 Assessments” | Compliance | 5 years after system retirement |
| Testing & Monitoring | Data/testing plan, quarterly monitoring reports | `TEX_TRAIGA_04_Data_Testing_Monitoring_Plan_LoneStar.md`, `Monitoring_Report_Q12026.pdf` | SharePoint → AI Governance → “04 Testing & Monitoring” | Compliance + Systems & Data | 5 years |
| Transparency | Website/app notices, chatbot text, FAQ entries | `TEX_TRAIGA_05_Website_Careers_Notice_Example_LoneStar.md`, screenshots | SharePoint → AI Governance → “05 Transparency & Notices” | Compliance + Marketing | 3 years (or longer if needed) |
| Human Review & Appeals | Workflow doc, appeals tracker | `TEX_TRAIGA_06_Human_Review_Appeals_Workflow_LoneStar.md`, `AI_Appeals_Log.xlsx` | SharePoint → AI Governance → “06 Appeals & Workflows” | Compliance + HR | 5 years; individual appeal records per HR policy |
| Vendors | Due‑diligence questionnaires, contract addenda, risk register | `TEX_TRAIGA_07_Vendor_DueDiligence_Questionnaire_TalentRank.xlsx`, `AI_Vendor_Risk_Register.xlsx` | SharePoint → AI Governance → “07 Vendors & Contracts” (contracts themselves in Legal’s system) | Compliance + Legal | Per vendor/contract policy (min 5 years after termination) |
| Sandbox | Application drafts, risk plans, quarterly reports (if used) | `TEX_TRAIGA_08_Sandbox_Application_Summary_LoneStar.md` | SharePoint → AI Governance → “08 Sandbox (if any)” | Compliance | 5 years after sandbox exit |
| Incidents | AI incident log & related analysis | `AI_Incident_Register.xlsx` | SharePoint → AI Governance → “09 Incidents & Issues” | Compliance | 5 years after resolution |

---

## 4. File Naming Conventions

LoneStar uses:

- Prefix: `TEX_TRAIGA_` for Texas TRAIGA documents.  
- Number: `01`–`09` to match deliverables.  
- Descriptive suffixes, e.g.:  
  - `_Template`, `_Example_LoneStar`, `_Monitoring_Report_QXYYYY`, `_MeetingMinutes_YYYYMMDD`.

Example:

- `TEX_TRAIGA_03_Risk_Impact_Assessment_AI01_LoneStar.md`  
- `TEX_TRAIGA_04_Monitoring_Report_Q12026_LoneStar.pdf`

This makes it easy to identify and retrieve relevant files for internal or external reviews.[web:49][web:52][web:53]

---

## 5. Access Control and Security

- AI Governance SharePoint workspace is restricted to:  
  - Compliance, Systems & Data, HR leadership, and Legal.  
- Appeals logs and incident registers have additional row‑level protections where feasible and are not broadly shared.  
- Vendor contracts remain in Legal’s contract management system, with AI‑specific addenda referenced in the AI Governance library.[web:22][web:37][web:39][web:49]

---

## 6. Retrieval Process for Inquiries

If a large client or regulator asks for AI governance evidence:

1. Request is routed to `compliance@lonestartalent.com`.  
2. Compliance checks this index to identify which categories/files are relevant (e.g., inventory, TRAIGA risk assessment for AI‑01, monitoring reports, and vendor diligence for TalentRank).  
3. Owners (Compliance, Systems & Data, Legal) gather the latest versions.  
4. Compliance and Legal review and assemble a response pack (often as a ZIP or secure folder link).  
5. Response is logged in an internal “AI Information Requests” tracker (date, requester, scope, documents provided).

This process ensures LoneStar can reply efficiently and consistently to external questions about its AI recruiting tools.[web:49][web:50][web:52][web:53]

---

## 7. Review and Maintenance

- LoneStar reviews and updates this index each January as part of its AI Governance Committee cycle.  
- Changes in storage locations, ownership, or retention periods are reflected here and in the corporate record‑retention schedule.

Version history:

- Version 1.0 – January 31, 2026 – Initial TRAIGA recordkeeping index created.

---

**End of Example**
