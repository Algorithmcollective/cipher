# Texas TDPSA Discovery Worksheet

---

## Scope

Texas Presence:
Business Units:
Personal Data Categories:
Sensitive Data:
Systems:
Vendors:
Lifecycle Stages:
High-Volume Areas:
AI Systems:

---

## Privacy Notice & Rights

Notice Exists:
Last Update:
Display Locations:
Rights Offered:
Intake Channels:
Identity Verification:
Owner:
Timelines:
Appeal Process:
Tracking:

---

## Data Protection Assessment

High-Risk Activities:
Profiling:
Sale:
Targeted Advertising:
Sensitive Processing:
Large-Scale Processing:
Children Data:
Assessment Exists:
Mitigations:

---

## Opt-Out & Consent

Opt-Out Methods:
Cookie Controls:
Ad Opt-Out:
Sale Opt-Out:
Global Signal:
Sensitive Consent:
Consent Storage:
Preference Tools:

---

## Security & Incident Response

Security Framework:
Access Controls:
Encryption:
Vendor Security:
IR Plan:
Breach Workflow:
Logging:
Security Owner:

---

## Sensitive Data & Sale Notices

Sensitive Categories:
Notice Provided:
Consent Flow:
Sale Definition:
Third-Party Sharing:
Broker Activity:
Minor Safeguards:

---

## High-Risk / Data Broker

Monetization:
Ad Networks:
Behavioral Advertising:
AI Profiling:
Data Enrichment:
Eligibility Decisions:

---

## AG Defense Readiness

Evidence Repository:
Policy Storage:
Request Logs:
Vendor Contracts:
Assessment Records:
Training Records:
Owner:
Escalation:
Metrics:

---

## TBD

Item:
Owner:
Notes: