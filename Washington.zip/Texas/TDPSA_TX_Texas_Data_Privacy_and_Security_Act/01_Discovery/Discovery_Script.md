# Texas TDPSA Discovery Script

Purpose: Gather information needed to prepare Texas consumer privacy compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Scope & Inventory Memo

Say:
“I need to understand what personal data your organization collects from Texas residents and where it lives.”

Ask:

- Texas customers, employees, or users
- Business units processing personal data
- Categories of personal data collected
- Sensitive data collected (precise location, biometrics, health, minors, etc.)
- Systems storing personal data
- Vendors processing personal data
- Data lifecycle stages (collection → use → sharing → deletion)
- High-volume processing areas
- AI systems using personal data

---

## 🧾 Deliverable: Privacy Notice & Rights Workflow

Say:
“I want to map how consumers are informed and how rights requests are handled.”

Ask:

- Privacy notice exists
- Last update
- Where displayed
- Rights offered (access, delete, correct, portability, opt-out)
- Intake channels
- Identity verification method
- Fulfillment owner
- Response timelines
- Appeal process
- Request tracking

---

## 🧾 Deliverable: Data Protection Assessment

Ask:

- High-risk processing
- Profiling or automated decision making
- Sale of personal data
- Targeted advertising
- Sensitive data processing
- Large-scale processing
- Children data
- Existing assessment
- Risk controls

---

## 🧾 Deliverable: Opt-Out & Consent Implementation

Ask:

- Opt-out methods
- Cookie controls
- Targeted advertising opt-out
- Sale opt-out
- Global privacy signal
- Sensitive consent flow
- Consent storage
- Preference tools

---

## 🧾 Deliverable: Security & Incident Response

Ask:

- Security framework
- Access controls
- Encryption
- Vendor security requirements
- Incident response plan
- Breach workflow
- Logging
- Security owner

---

## 🧾 Deliverable: Sensitive Data & Sale Notices

Ask:

- Sensitive data categories
- Notice provided
- Consent flow
- Sale definition applied
- Third-party sharing
- Broker activity
- Minor safeguards

---

## 🧾 Deliverable: Data Broker / High-Risk Check

Ask:

- Data monetization
- Advertising networks
- Behavioral advertising
- AI profiling impacting consumers
- Data enrichment vendors
- Eligibility decisions

---

## 🧾 Deliverable: AG Inquiry & Enforcement Defense

Ask:

- Evidence repository
- Policy storage
- Request logs
- Vendor contracts
- Assessment records
- Training records
- Responsible owner
- Escalation process
- Metrics

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Texas privacy compliance documentation.”