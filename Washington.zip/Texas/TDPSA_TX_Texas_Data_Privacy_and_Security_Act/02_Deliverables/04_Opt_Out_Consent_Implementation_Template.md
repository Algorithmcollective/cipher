# Texas TDPSA – Opt-Out & Consent Implementation Plan (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Opt-Out & Consent Implementation Plan (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This plan describes how {{ORG_NAME}} will:

- Implement and honor Texas consumers’ **opt-out rights** (sale, targeted advertising, certain profiling).  
- Obtain and manage **consent** for TDPSA **sensitive personal data** where required.  
- Coordinate UI, backend systems, and vendors so choices actually stick.[web:81][web:86][web:91][web:96][web:98]

---

## 2. Scope

Applies to:

- All public‑facing websites, apps, and services that process personal data of Texas consumers.  
- All systems and vendors involved in sale/targeted ads/profiling or sensitive data processing.[web:81][web:86][web:91][web:96]

List in-scope channels:

- Websites: {{WEBSITES}}  
- Apps: {{APPS}}  
- Key vendors (ad/analytics/consent tools): {{VENDORS}}

---

## 3. Rights and Consent Types Covered

### 3.1 Opt-Out Rights (TDPSA)

For Texas consumers:

- Opt-out of sale of personal data.  
- Opt-out of targeted advertising.  
- Opt-out of profiling in furtherance of decisions that produce legal or similarly significant effects (if applicable).[web:81][web:86][web:91][web:96][web:98]

### 3.2 Sensitive Data Consent

Where required, TDPSA expects consent for processing sensitive personal data, such as:

- Precise geolocation.  
- Biometric identifiers.  
- Certain health or children’s data (as applicable).[web:81][web:86][web:91]

---

## 4. Front-End Experience: Where Choices Are Presented

### 4.1 Privacy Choices / “Do Not Sell or Share” Page

- URL: {{OPTOUT_PAGE_URL}}  
- Linked from:  
  - Footer of main site(s).  
  - Privacy notice.  
  - Account settings (if available).

This page should:

- Briefly explain targeted ads, sale, and what opting out does.  
- Provide clear toggles/links to submit opt‑out preferences.[web:81][web:86][web:91][web:96]

### 4.2 Cookie / Tracking Banner

- Tool used: {{COOKIE_TOOL}}  
- Behavior for Texas visitors:  
  - Shows banner with concise explanation.  
  - Provides link to detailed preferences (including targeted ads).[web:95][web:96][web:98]

### 4.3 App Settings (If Mobile Apps)

- Screen name: {{APP_PRIVACY_SETTINGS_SCREEN}}  
- Allows users to:  
  - Toggle location‑based features.  
  - View/adjust ad and analytics preferences (as supported).

---

## 5. Data Flow: From Choice to Enforcement

Describe how a Texas consumer’s choice flows through systems.

### 5.1 Identity and Preference Storage

- Where preferences are stored: {{PREFERENCE_STORE}} (e.g., consent management platform, internal DB).  
- Key fields: user ID / identifier, consent/opt‑out flags, timestamps, source (web/app).[web:81][web:86][web:91][web:96]

### 5.2 Internal Systems

For each major internal system (CRM, marketing tool, data warehouse):

| System | Data Used | How Opt-Out is Applied |
|--------|----------|------------------------|
| {{SYSTEM_1}} | {{DATA_USE_1}} | {{OPTOUT_MECHANISM_1}} |
| {{SYSTEM_2}} | {{DATA_USE_2}} | {{OPTOUT_MECHANISM_2}} |

### 5.3 Vendors and Ad/Analytics Partners

For each vendor:

| Vendor | Role | Opt-Out Implementation |
|--------|------|------------------------|
| {{VENDOR_1}} | {{ROLE_1}} | {{HOW_OPTOUT_1}} |
| {{VENDOR_2}} | {{ROLE_2}} | {{HOW_OPTOUT_2}} |

Note any technical IDs (e.g., suppression lists, signals) used to communicate opt‑outs.[web:81][web:86][web:91][web:96][web:98]

---

## 6. Sensitive Data Consent Flows

### 6.1 Precise Geolocation (Example Structure)

- Trigger: user enables location services in app.  
- UI: OS‑level prompt plus in‑app explanation.  
- Backend: store consent flag and allow revocation in settings.

Template description:

> For {{SENSITIVE_USE_CASE}}, {{ORG_NAME}} will present a clear explanation of what sensitive data is used and why, and will only proceed when users give explicit permission via {{CHANNEL}}. Users can revoke consent at any time via {{REVOCATION_PATH}}.[web:81][web:86][web:91]

Repeat per sensitive-data use case.

---

## 7. Handling Opt-Out Requests

### 7.1 Intake

Opt‑outs can be:

- Submitted via choices page / cookie banner.  
- Included as part of TDPSA rights requests (Deliverable 2).  

All opt‑outs should end up in {{PREFERENCE_STORE}}.[web:81][web:86][web:91][web:96]

### 7.2 Timelines

- Internal goal: apply opt‑outs to internal systems and major vendors within {{OPTOUT_APPLY_TIME}} (e.g., 15 days).  
- Document any exceptions/edge cases.

> {{OPTOUT_TIMELINE_NOTES}}

---

## 8. Testing and Monitoring

Describe how {{ORG_NAME}} will verify:

- That opt‑out toggles work and are persisted.  
- That tagged users are removed from or excluded in ad/analytics tools.  
- That sensitive-data features disable correctly when consent is revoked.[web:81][web:86][web:91][web:96][web:98]

> {{TESTING_MONITORING_PLAN}}

---

## 9. Recordkeeping

Keep:

- Screenshots and copies of UI where choices/consents are collected.  
- Logs of preference changes.  
- Integration documentation showing how vendors honor preferences.

> {{RECORDKEEPING_NOTES}}[web:49][web:81][web:86][web:91][web:96]

---

## 10. Review and Updates

- Review this plan at least annually, or when adding new ad tech, vendors, or sensitive‑data features.  
- Coordinate changes with privacy notice updates and TDPSA rights workflow.

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
