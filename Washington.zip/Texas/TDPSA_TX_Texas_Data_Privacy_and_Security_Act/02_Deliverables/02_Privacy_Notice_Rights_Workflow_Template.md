# Texas TDPSA – Privacy Notice & Rights Workflow (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Public Privacy Notice + Consumer Rights & Appeals Workflow (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## PART A – PUBLIC-FACING PRIVACY NOTICE (TEMPLATE)

> This is a **starter structure** for a TDPSA-aligned privacy notice. {{ORG_NAME}} should adapt it to its actual processing and other laws (e.g., CCPA/CPRA, GDPR) as needed.[web:81][web:86][web:91][web:96][web:98]

### 1. Introduction

{{ORG_NAME}} (“we,” “us,” or “our”) provides {{BRIEF_SERVICES_DESCRIPTION}}. This Privacy Notice explains how we collect, use, and share personal data, and describes your rights under the Texas Data Privacy and Security Act (TDPSA) if you are a Texas consumer.[web:81][web:86][web:91]

### 2. Personal Data We Collect

We may collect the following categories of personal data:

- Identifiers (e.g., name, email address, phone number, account ID).  
- Commercial information (e.g., purchase or subscription details).  
- Internet or device information (e.g., IP address, device IDs, browsing activity on our sites or apps).  
- Geolocation data (e.g., approximate or precise location, if you enable it).  
- Professional or employment information (if relevant to our services).  
- Other information you choose to provide (e.g., messages to support).

If you provide information about others, you are responsible for having any necessary permission.[web:81][web:91][web:96][web:98]

### 3. How We Use Personal Data

We use personal data for purposes such as:

- Providing and improving our services.  
- Creating and managing accounts.  
- Processing transactions and sending service-related communications.  
- Providing customer support.  
- Personalizing content and measuring service performance.  
- Running marketing campaigns and, where applicable, targeted advertising.  
- Protecting against fraud, abuse, or security threats.  
- Complying with legal obligations.

We only use personal data for purposes that are compatible with these descriptions unless we notify you otherwise.[web:81][web:86][web:91][web:96]

### 4. How We Share Personal Data

We may share personal data with:

- Service providers who process data on our behalf (e.g., hosting, analytics, customer support).  
- Business customers (if we provide B2B services and they are controllers of certain data).  
- Affiliates, in compliance with applicable laws.  
- Authorities or other parties when required by law or to protect rights and safety.  
- Other third parties with your direction or consent.[web:81][web:86][web:91]

We do **not** sell your personal data in the traditional sense (e.g., selling lists of emails), but certain data practices may be considered a “sale” or “targeted advertising” under TDPSA, as explained below.[web:81][web:86][web:91][web:96][web:98]

### 5. Targeted Advertising and “Sale” of Personal Data

We may allow third-party partners to collect information about your activity on our services (for example, through cookies, pixels, or similar technologies) so they can show you ads tailored to your interests over time and across different websites or services. Under TDPSA, some of these activities may be considered **“targeted advertising”** or a **“sale”** of personal data.[web:81][web:86][web:91][web:95][web:98]

You can opt out of these practices as described in Section 8 (Your Rights and Choices).

### 6. Sensitive Personal Data

We may process **sensitive personal data** in limited situations (for example, precise geolocation if you enable it in our apps, or other categories depending on the service). Where required by TDPSA, we will obtain your consent before processing sensitive personal data.[web:81][web:86][web:91]

We will also provide clear notices where sensitive data is involved.

### 7. How Long We Keep Personal Data

We retain personal data for as long as necessary to:

- Provide our services,  
- Comply with our legal and contractual obligations, and  
- Resolve disputes and enforce our agreements.

Retention periods may vary depending on the category of data and the purposes of processing.[web:81][web:86][web:91][web:96]

### 8. Your Rights and Choices (Texas Consumers)

If you are a Texas consumer, TDPSA grants you certain rights, subject to exceptions:

- **Right to know/access:** Request confirmation whether we process your personal data and access to that data.  
- **Right to correction:** Request correction of inaccuracies in your personal data.  
- **Right to deletion:** Request deletion of personal data we have about you, subject to certain exceptions.  
- **Right to data portability:** Request a copy of certain personal data in a portable format.  
- **Right to opt out of:**  
  - Targeted advertising.  
  - Sale of personal data.  
  - Profiling in furtherance of decisions that produce legal or similarly significant effects (where applicable).[web:81][web:86][web:91][web:96][web:98]

You can exercise these rights by:

- Submitting a request at: {{RIGHTS_WEBFORM_URL}}  
- Or emailing us at: {{RIGHTS_EMAIL_ADDRESS}}  

We will respond within the time periods required by TDPSA and may need to verify your identity.[web:81][web:86][web:91]

#### Opting Out of Targeted Advertising and Sale

To opt out of targeted advertising and any activities that may be considered a “sale” of personal data under TDPSA, you can:

- Visit: {{OPTOUT_PAGE_URL}}  
- Adjust your cookie settings: {{COOKIE_SETTINGS_URL}} (if separate).  
- Use browser or platform‑level tools that signal your preferences, if we are required to honor them under TDPSA.[web:81][web:86][web:95][web:96][web:98]

### 9. Appeals

If we decline to act on your request, you may appeal our decision by following the process in Section B (Appeals Workflow). We will explain how you can submit an appeal in our response.[web:81][web:86][web:91][web:96]

### 10. Contact Us

If you have questions about this Notice or our data practices, please contact us at:

- Email: {{PRIVACY_CONTACT_EMAIL}}  
- Mailing Address: {{PRIVACY_CONTACT_ADDRESS}}

---

## PART B – INTERNAL CONSUMER RIGHTS & APPEALS WORKFLOW (TEMPLATE)

> This section is **internal** and should not be published as‑is. It describes how {{ORG_NAME}} handles TDPSA rights requests and appeals.[web:81][web:86][web:91][web:96][web:98]

### 1. Intake Channels

Accepted channels for TDPSA requests from Texas consumers:

- Web form: {{RIGHTS_WEBFORM_URL}}  
- Email: {{RIGHTS_EMAIL_ADDRESS}}  
- (Optional) Postal mail: {{RIGHTS_POSTAL_ADDRESS}}

All staff receiving requests should route them to {{RIGHTS_TEAM}} (e.g., Privacy or Compliance).

### 2. Logging and Categorization

For each request, log:

- Requester identity and contact details.  
- Request type (access, correction, deletion, portability, opt‑out, other).  
- Date received and deadline (per TDPSA timeline).  
- Status (open, in verification, fulfilled, denied, appealed, closed).[web:81][web:86][web:91][web:96]

System used (e.g., spreadsheet, ticketing, GRC tool):

> {{RIGHTS_TRACKING_SYSTEM}}

### 3. Verification

Before acting on a request:

- Verify identity to a reasonable degree, tailored to the sensitivity of the data and risk of harm.  
- For authorized agents, verify authority as required by internal policy.

> {{VERIFICATION_STEPS}}

### 4. Handling by Request Type

Summarize internal handling rules:

- **Access:** Provide a summary of personal data reasonably associated with the requester and basic processing information.  
- **Correction:** Evaluate and correct inaccurate data when supported by reasonable evidence.  
- **Deletion:** Delete personal data where required, or de‑identify it, subject to legal and operational exceptions.  
- **Portability:** Provide an export of applicable data in a portable, commonly used format.  
- **Opt‑outs (sale, targeted ads, profiling):** Record the opt‑out in relevant systems (e.g., consent manager, CRM, ad platforms) and ensure it is honored going forward.[web:81][web:86][web:91][web:96][web:98]

> {{HANDLING_RULES_DETAILS}}

### 5. Timelines

TDPSA requires responses within specified timeframes (often similar to other state laws: typically 45 days with possible extension, but confirm with counsel and statute).[web:81][web:86][web:91][web:96]

Internal targets:

- Acknowledge request: within {{ACK_TIMEFRAME}} (e.g., 5–10 business days).  
- Substantive response: within {{RESPONSE_TIMEFRAME}} (e.g., 45 days), with documented extensions if necessary.

> {{TIMELINE_NOTES}}

### 6. Appeals Process

If {{ORG_NAME}} declines to act on a request:

- Response must explain the reason and how the consumer can appeal.  
- Appeals can be submitted via {{APPEAL_CHANNEL}} (e.g., same web form, specific email).  
- Someone other than the original decision‑maker should review the appeal where feasible.[web:81][web:86][web:91][web:96]

Appeal steps:

1. Log appeal in rights tracker with link to original request.  
2. Assign to {{APPEAL_REVIEWER_ROLE}}.  
3. Re‑examine evidence, legal basis, and any new information.  
4. Provide written outcome within the timeframe required by TDPSA and explain any further recourse (e.g., right to contact the Texas AG).[web:81][web:86][web:91][web:96]

> {{APPEALS_PROCESS_DETAILS}}

### 7. Metrics and Reporting

Track:

- Volume of TDPSA requests by type.  
- Response and completion times.  
- Number and outcomes of appeals.  
- Any patterns in denials or issues that suggest process or systems updates are needed.

> {{METRICS_AND_REPORTING_NOTES}}

### 8. Training

Ensure front‑line staff, support teams, and privacy/compliance handlers receive training on:

- Recognizing TDPSA requests.  
- Directing consumers to the proper channels.  
- Following verification and response procedures.

> {{TRAINING_PLAN_SUMMARY}}

---

**End of Template**
