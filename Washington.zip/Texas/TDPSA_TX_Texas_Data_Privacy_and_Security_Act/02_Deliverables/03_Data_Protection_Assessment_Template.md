# Texas TDPSA – Data Protection Assessment (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Data Protection Assessment (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of This Assessment

This assessment documents how {{ORG_NAME}} evaluates risks and safeguards for a specific processing activity that may require a Data Protection Assessment under TDPSA, such as:

- Targeted advertising.  
- Sale of personal data.  
- Processing of sensitive personal data.  
- Profiling that produces legal or similarly significant effects.[web:81][web:86][web:91][web:94][web:96][web:98]

It is not legal advice and should be reviewed by counsel.

---

## 2. Processing Activity Overview

### 2.1 Basic Information

- **Assessment ID:** {{ASSESSMENT_ID}}  
- **Processing activity name:** {{ACTIVITY_NAME}}  
- **Business owner:** {{BUSINESS_OWNER_NAME}}, {{BUSINESS_OWNER_ROLE}}  
- **Technical owner:** {{TECH_OWNER_NAME}}, {{TECH_OWNER_ROLE}}  

### 2.2 Description of Processing

- Brief description of what {{ORG_NAME}} is doing:  
  > {{PROCESSING_DESCRIPTION}}  

- Purposes for processing:  
  > {{PROCESSING_PURPOSES}}  

- Start date and (if applicable) planned end date: {{START_DATE}} – {{END_DATE}}  

---

## 3. Personal Data Involved

### 3.1 Categories of Personal Data

List categories of personal data processed for this activity:

- Identifiers: {{IDENTIFIERS}}  
- Internet/device data: {{INTERNET_DATA}}  
- Geolocation data: {{GEOLOCATION_DATA}}  
- Commercial/transaction data: {{COMMERCIAL_DATA}}  
- Other: {{OTHER_DATA}}[web:81][web:86][web:91][web:96][web:98]

### 3.2 Sensitive Personal Data

Does this activity involve TDPSA **sensitive personal data** (e.g., precise geolocation, biometric identifiers, health data, children’s data)?[web:81][web:86][web:91]

- ☐ Yes  ☐ No  ☐ Unclear  

If yes, specify:

> {{SENSITIVE_DATA_DESCRIPTION}}

Describe how consent or appropriate notices are obtained:

> {{SENSITIVE_DATA_CONSENT_NOTES}}

---

## 4. Data Flows and Recipients

### 4.1 Data Sources

- Internal sources (systems, logs): {{INTERNAL_SOURCES}}  
- External sources (vendors, partners): {{EXTERNAL_SOURCES}}  

### 4.2 Recipients / Third Parties

List recipients of personal data for this activity (including ad/analytics providers, affiliates, customers):

| Recipient | Role (Processor/Controller/Partner) | Purpose of Disclosure |
|----------|--------------------------------------|-----------------------|
| {{RECIPIENT_1}} | {{ROLE_1}} | {{PURPOSE_1}} |
| {{RECIPIENT_2}} | {{ROLE_2}} | {{PURPOSE_2}} |

Indicate if any disclosures may be considered a **“sale”** under TDPSA (exchange for monetary or other valuable consideration).[web:81][web:86][web:91][web:96]

> {{SALE_ANALYSIS_SUMMARY}}

---

## 5. Legal Basis and TDPSA Triggers

### 5.1 TDPSA Risk Category

Check all that apply:

- ☐ Targeted advertising.  
- ☐ Sale of personal data.  
- ☐ Processing of sensitive personal data.  
- ☐ Profiling with legal or similarly significant effects.  
- ☐ Other high‑risk processing identified by {{ORG_NAME}}.[web:81][web:86][web:91][web:94][web:96][web:98]

### 5.2 Relationship to Other Laws / Obligations

Note any interaction with other laws (e.g., federal sector rules, other state privacy laws) and internal policies:

> {{OTHER_LAWS_POLICIES_NOTES}}

---

## 6. Benefits and Necessity

### 6.1 Benefits

Describe anticipated benefits:

- To {{ORG_NAME}}: {{BENEFITS_ORG}}  
- To consumers or the public: {{BENEFITS_CONSUMERS}}  

### 6.2 Necessity and Proportionality

Explain why this processing is **necessary and proportionate** for its stated purposes, and whether less intrusive alternatives were considered:

> {{NECESSITY_PROPORTIONALITY_NOTES}}[web:81][web:86][web:91][web:96]

---

## 7. Risks to Consumers

Identify material risks to Texas consumers, such as:

- Loss of privacy or unwanted tracking.  
- Misuse of sensitive data.  
- Discrimination or unfair outcomes.  
- Security or breach risks.  
- Confusion due to unclear notices or choices.[web:81][web:86][web:91][web:95][web:98]

Narrative risk summary:

> {{RISK_SUMMARY}}

If helpful, categorize risks as Low / Medium / High:

| Risk | Level | Notes |
|------|-------|-------|
| {{RISK_1}} | {{LEVEL_1}} | {{RISK_1_NOTES}} |
| {{RISK_2}} | {{LEVEL_2}} | {{RISK_2_NOTES}} |

---

## 8. Safeguards and Mitigations

Describe existing and planned controls, for example:

- **Data minimization and retention limits.**  
- **Security controls** (encryption, access controls, logging).  
- **Transparency:** clear privacy notice disclosures for TDPSA (sale, targeted ads, sensitive data).  
- **Choice and control:** opt‑outs (sale/targeted ads), consent for sensitive data, cookie preferences.  
- **Vendor controls:** contracts with ad/analytics or other partners, honoring opt‑outs.  
- **Accuracy and fairness considerations** where applicable.[web:81][web:86][web:91][web:96][web:98]

> {{SAFEGUARDS_DETAILS}}

---

## 9. Residual Risk and Decision

### 9.1 Residual Risk

After applying mitigations, assess residual risk to consumers:

- Overall residual risk level: ☐ Low  ☐ Medium  ☐ High  

Rationale:

> {{RESIDUAL_RISK_RATIONALE}}

### 9.2 Proceed / Modify / Do Not Proceed

- Recommended outcome:  
  - ☐ Proceed as designed.  
  - ☐ Proceed with additional conditions.  
  - ☐ Do not proceed (risk too high).

Conditions or required follow‑ups (if any):

> {{CONDITIONS_NOTES}}

Approvals:

- Business owner: {{BUSINESS_OWNER_NAME}} – ☐ Approved ☐ Not Approved – Date: {{BUSINESS_OWNER_DATE}}  
- Privacy/Legal: {{PRIVACY_LEGAL_NAME}} – ☐ Approved ☐ Not Approved – Date: {{PRIVACY_LEGAL_DATE}}  

---

## 10. Review and Updates

This assessment should be:

- Reviewed at least every {{REVIEW_FREQUENCY}} (e.g., annually), and  
- Updated when there are material changes to processing, technology, or applicable laws.

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
