# Texas TDPSA – Data Broker / High-Risk Processor Check & Registration Calendar (MASTER)

**Laws:**  
- Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94][web:166][web:170]  
- Texas Data Broker Law, Tex. Bus. & Com. Code § 510.001 et seq. (as amended).[web:149][web:161][web:164][web:171][web:162][web:165][web:168][web:169][web:166]  

**Document Type:** Data Broker / High-Risk Processor Assessment Tool & Registration Checklist (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This tool helps {{ORG_NAME}}:

- Decide whether it is a **Texas “data broker”** under Chapter 510.  
- Flag **high‑risk TDPSA processing** that may need extra governance (e.g., profiling, sale, sensitive data, or broker‑style aggregation).  
- Build a registration and compliance calendar if data‑broker obligations apply.[web:149][web:161][web:162][web:165][web:168][web:169][web:166][web:170]

---

## 2. Texas Data Broker Quick Screen

### 2.1 Do You Likely Fit the “Data Broker” Concept?

Answer for {{ORG_NAME}}:

1. Does the business **collect or obtain personal data from sources other than directly from the individuals**, and then **sell, license, or otherwise make that data available to third parties** (often multiple customers)?[web:162][web:163][web:165][web:168][web:169][web:166]  
   - ☐ Yes  ☐ No  ☐ Unclear  

2. Is a **meaningful portion of revenue** derived from that activity (selling/ licensing/ sharing data acquired indirectly)?[web:162][web:165][web:168][web:169][web:166]  
   - ☐ Yes  ☐ No  ☐ Unclear  

3. Are there significant **exemptions** that might take {{ORG_NAME}} out of scope (e.g., GLBA‑regulated financial institution, certain entities already covered under other laws)?[web:162][web:165][web:168][web:171]  
   - ☐ Yes  ☐ No  ☐ Unclear  

Initial conclusion:

> {{DATA_BROKER_SCREEN_SUMMARY}}

If “Yes/Probably” to 1–2 and no clear exemption, {{ORG_NAME}} should assume the data‑broker law **may apply** and proceed to Section 3 with counsel.

---

## 3. Data Broker Obligations – Registration & Online Notice

If {{ORG_NAME}} is a data broker under Chapter 510:

### 3.1 Registration With Texas Secretary of State

Key points:[web:149][web:161][web:164][web:171][web:169]

- Must register **before conducting business as a data broker in Texas**, by filing **Form 4001** (or successor) with the Secretary of State.  
- **Fee:** 300 dollars per registration and per annual renewal.  
- Registration certificate is effective for **one year**; must be renewed annually with the same fee.[web:149][web:161][web:164][web:169]

Registration checklist:

- ☐ Confirm data‑broker status with counsel.  
- ☐ Gather required info for registration statement (legal name, business address, contact, website(s), etc.).[web:171][web:162][web:163]  
- ☐ File Form 4001 and pay 300‑dollar fee.  
- ☐ Store registration certificate and renewal date in compliance calendar.

### 3.2 Data Broker Online Notice & TDPSA Linkage

Texas requires data brokers with websites or apps to post a **clear, accessible notice** that:[web:162][web:165][web:168][web:169][web:166]

- Identifies the entity as a **data broker** under Texas law.  
- Uses prescribed language from the AG or Secretary of State, which currently includes:[web:147]

> “**The entity maintaining this website is a data broker under Texas law. To conduct business in Texas, a data broker must register with the Texas Secretary of State (Texas SOS). Information about data broker registrants is available on the Texas SOS website.**”[web:147]

- Provides **prominently displayed instructions** on how consumers can exercise their **TDPSA rights**, and links to the relevant TDPSA/consumer rights page on the site.[web:162][web:165][web:168][web:166][web:147]

Implementation checklist:

- ☐ Add the “data broker” notice text to website/footer and any app “Privacy/Legal” screens.  
- ☐ Add/link to TDPSA rights page explaining access/correction/deletion/opt‑out and appeal process.  
- ☐ Ensure the same link appears in the data‑broker registration statement filed with the Secretary of State.[web:149][web:161][web:162][web:165][web:168][web:147]

---

## 4. TDPSA High-Risk Processing Check

Even if {{ORG_NAME}} is not a formal “data broker,” the following TDPSA activities should be flagged as **high‑risk** and linked to DPAs and governance:[web:86][web:91][web:94][web:96][web:98][web:166][web:170]

Check any that apply:

- ☐ Large‑scale **sale** of personal data (especially sensitive data).  
- ☐ **Targeted advertising** based on cross‑site tracking.  
- ☐ **Profiling** that produces legal or similarly significant effects (eligibility, pricing, etc.).  
- ☐ Processing of **sensitive personal data** at scale (e.g., health, finance, precise geolocation, children).  
- ☐ Any “data‑broker‑like” aggregation where personal data from multiple sources is combined and licensed or shared widely.

For each flagged activity, record:

| ID | Activity | TDPSA Risk Type | DPA Required? | Notes / Owner |
|----|----------|-----------------|---------------|---------------|
| HR‑01 | {{ACTIVITY_1}} | {{RISK_TYPE_1}} | {{DPA_1}} | {{NOTES_1}} |
| HR‑02 | {{ACTIVITY_2}} | {{RISK_TYPE_2}} | {{DPA_2}} | {{NOTES_2}} |

> {{HIGH_RISK_SUMMARY}}

---

## 5. Registration & Compliance Calendar

If {{ORG_NAME}} is a data broker:

### 5.1 Annual Calendar

| Task | Owner | Due Date / Frequency |
|------|-------|----------------------|
| File initial data‑broker registration (Form 4001 + 300‑dollar fee) | {{LEGAL_OWNER}} | Before conducting broker business in Texas |
| Renew registration and fee | {{LEGAL_OWNER}} | Annually, by {{RENEWAL_DATE}} |
| Review and update data‑broker website/app notice and TDPSA rights link | {{PRIVACY_OWNER}} | At least annually |
| Review comprehensive information security program and risk assessment | {{SECURITY_OWNER}} | At least annually per data‑broker law and TDPSA expectations[web:162][web:163][web:168][web:169][web:166] |

### 5.2 Recordkeeping

Keep:

- Copies/PDFs of filed registration/renewal forms and certificates.  
- Screenshots/PDFs of online data‑broker notices and TDPSA rights pages.  
- Documentation of annual security program review and risk assessments.[web:149][web:161][web:162][web:163][web:168][web:169][web:166]

> {{RECORDKEEPING_NOTES}}

---

## 6. Governance and Review

- This assessment should be updated **annually** and whenever {{ORG_NAME}} launches or acquires a new data product that might qualify as a broker‑style service.  
- Decisions and rationales (why {{ORG_NAME}} is or is not a data broker) should be documented and approved by Privacy/Legal leadership.[web:162][web:165][web:168][web:169][web:166][web:170]

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
