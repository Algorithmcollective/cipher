# Texas TDPSA – Security & Incident Response Baseline (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Security & Incident Response Baseline (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This baseline describes how {{ORG_NAME}}:

- Implements **reasonable administrative, technical, and physical safeguards** for personal data of Texas consumers.  
- Detects, investigates, and responds to security incidents and privacy violations relevant to TDPSA.  
- Documents remediation to support TDPSA’s 30‑day cure concept and ongoing enforcement readiness.[web:81][web:86][web:91][web:96][web:98][web:31][web:97]

---

## 2. Scope

Applies to:

- Systems that store or process personal data of Texas consumers (see TDPSA inventory).  
- Employees, contractors, and vendors with access to those systems.[web:81][web:86][web:91][web:96]

---

## 3. Security Controls – High-Level Baseline

### 3.1 Administrative Safeguards

Examples (fill in specifics):

- Written information security policy (WISP): {{HAS_WISP}} (Y/N)  
- Designated security lead/committee: {{SEC_LEAD}}  
- Access management procedures (onboarding/offboarding, least privilege): {{ACCESS_MGMT_SUMMARY}}  
- Vendor risk management program: {{VENDOR_RISK_SUMMARY}}[web:81][web:86][web:91][web:96]

### 3.2 Technical Safeguards

- Encryption in transit (TLS) and at rest (where applicable): {{ENCRYPTION_PRACTICES}}  
- Multi‑factor authentication (MFA) for admin and remote access: {{MFA_PRACTICES}}  
- Network and endpoint protections (firewalls, EDR): {{NETWORK_ENDPOINT_CONTROLS}}  
- Logging and monitoring (access logs, anomaly detection): {{LOGGING_MONITORING}}[web:81][web:86][web:91][web:96][web:98]

### 3.3 Physical Safeguards

- Data center/office physical security, if applicable: {{PHYSICAL_SECURITY_SUMMARY}}  

---

## 4. Incident Definition and Examples

### 4.1 Definition

For this baseline, an “incident” is:

> Any confirmed or reasonably suspected event that compromises the confidentiality, integrity, or availability of personal data of Texas consumers, or that suggests non‑compliance with TDPSA data handling obligations.[web:81][web:86][web:91][web:96][web:98]

### 4.2 Examples

- Unauthorized access to customer data (e.g., credential stuffing, compromised account).  
- Mis‑sent data exports or reports.  
- Misconfigured databases exposed to the internet.  
- Misapplied TDPSA opt‑outs resulting in improper data use (e.g., continued sale/targeted ads after opt‑out).

---

## 5. Incident Response Workflow

### 5.1 Roles

- **Incident Commander:** {{INCIDENT_COMMANDER_ROLE}}  
- **Security Lead / Team:** {{SEC_TEAM_ROLE}}  
- **Privacy / Legal:** {{PRIVACY_LEGAL_ROLE}}  
- **Comms / Customer Support:** {{COMMS_ROLE}}  

### 5.2 Stages

1. **Detect & Log**  
   - Source: monitoring alerts, user reports, vendor notifications, audits.  
   - Action: record in Incident Register with timestamp, source, summary.[web:81][web:86][web:91][web:96]

2. **Triage & Classify**  
   - Assess severity (e.g., Low/Medium/High) and whether Texas consumers’ personal data is involved.  
   - Decide if immediate containment is needed (e.g., disable a feature, revoke access).

3. **Contain & Eradicate**  
   - Short‑term containment to stop ongoing exposure.  
   - Investigate root cause (technical and procedural).  
   - Apply fixes (e.g., patch, config change, credential reset).

4. **Assess Impact & Obligations**  
   - Determine what data, how many individuals, and which jurisdictions are affected.  
   - With Legal, evaluate notification obligations (e.g., state breach laws, contract terms) and TDPSA exposure.[web:81][web:86][web:91][web:96][web:97]

5. **Notify & Remediate**  
   - If required, notify affected parties and regulators per applicable laws and contracts.  
   - Document remediation steps and monitoring to prevent recurrence.

6. **Review & Close**  
   - Post‑incident review with Security, Privacy, and relevant teams.  
   - Update policies, controls, and training where needed.  
   - Mark incident as “Closed” in register with lessons learned.

---

## 6. TDPSA-Specific Considerations

### 6.1 Cure Period

TDPSA provides a 30‑day cure period before enforcement in many cases, conditioned on fixing violations and providing written assurances.[web:81][web:86][web:91][web:96][web:97][web:31]

Baseline documentation to support a cure:

- Description of violation or deficiency.  
- Steps taken to remedy and prevent recurrence.  
- Timelines and evidence (screenshots, code changes, policy updates).

> {{CURE_PERIOD_PLAYBOOK_SUMMARY}}

### 6.2 Priority Risk Areas

Highlight TDPSA‑sensitive risk areas:

- Location data and online tracking (enforcement focus).  
- Sale/targeted advertising misconfigurations.  
- Security lapses on high‑volume consumer systems.[web:78][web:79][web:95][web:97][web:98][web:31][web:89]

---

## 7. Incident Register Template

**File:** `TX_TDPSA_05_Incident_Register_Template.xlsx` (structure)

Columns:

- Incident ID  
- Date opened / Date closed  
- Reporter / Source  
- Systems affected  
- Texas consumers affected? (Y/N/Unknown)  
- Description  
- Severity (Low/Medium/High)  
- TDPSA‑relevant? (Y/N)  
- Actions taken (containment, eradication, remediation)  
- Notifications sent (Y/N; who)  
- Cure documentation stored? (location)  
- Owner

> {{INCIDENT_REGISTER_NOTES}}

---

## 8. Training and Awareness

Outline:

- Who receives incident‑response training.  
- How often (e.g., annually, after major incidents).  
- How you reinforce phishing awareness, password hygiene, and reporting culture.[web:81][web:86][web:91][web:96]

> {{TRAINING_AWARENESS_SUMMARY}}

---

## 9. Review and Updates

- Review this baseline at least annually or after any major incident.  
- Coordinate changes with broader information security and TDPSA programs.

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
