# Texas TDPSA – Scope & Data Processing Inventory Memo (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Scope & Data Processing Inventory (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of This Memo

This memo helps {{ORG_NAME}}:

- Determine whether it is a **controller** in scope of the Texas Data Privacy and Security Act (TDPSA).  
- Map key processing activities involving Texas consumers’ personal data.  
- Identify priority areas for TDPSA compliance work (privacy notice, consumer rights, data security, data protection assessments).[web:92][web:93][web:94][web:96]

It is not legal advice and should be reviewed by counsel before being relied upon.

---

## 2. Overview of TDPSA (Plain Language)

TDPSA applies to many businesses that conduct business in Texas or produce products or services consumed by Texas residents and that process personal data, regardless of annual revenue or number of records, with exemptions for certain entities and data types (e.g., GLBA, HIPAA).[web:81][web:86][web:91][web:98]

Key concepts:

- **Controller:** Decides why and how personal data is processed.  
- **Processor:** Handles personal data on behalf of a controller.[web:92][web:94][web:96]  
- **Personal data:** Information linked or reasonably linkable to an identified or identifiable individual, excluding de‑identified and publicly available data.[web:81][web:91]  
- **Sensitive personal data:** Includes precise geolocation, biometric data, health data, children’s data, etc., and requires consent for processing.[web:81][web:86][web:91]

The Texas Attorney General has exclusive enforcement authority and can seek penalties up to **7,500 dollars per violation**, after a 30‑day right to cure.[web:77][web:81][web:94][web:96][web:99]

---

## 3. TDPSA Applicability to {{ORG_NAME}}

### 3.1 Business Presence and Activities

Answer the following:

- Does {{ORG_NAME}} conduct business in Texas or target Texas consumers?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Does {{ORG_NAME}} offer products or services that are consumed by Texas residents (online or offline)?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Approximate percentage of customers/users who are Texas residents: {{PCT_TX_CUSTOMERS}}  

### 3.2 Role as Controller and Processor

- Does {{ORG_NAME}} determine purposes and means of processing personal data (controller)?  
  - ☐ Yes  ☐ No  ☐ Mixed (controller for some activities, processor for others)  
- Does {{ORG_NAME}} process personal data solely on behalf of other businesses for some activities (processor)?  
  - ☐ Yes  ☐ No  ☐ Mixed  

Brief description:

> {{CONTROLLER_PROCESSOR_SUMMARY}}[web:92][web:94][web:96]

### 3.3 Exemptions (High-Level Screening)

Note any likely exemptions (e.g., financial institutions under GLBA, HIPAA‑covered entities, some non‑profits) and how they affect scope.[web:81][web:86][web:91]

> {{EXEMPTIONS_NOTES}}

---

## 4. Data Processing Inventory – High-Level Map

### 4.1 Key Systems and Activities

List main systems and activities that involve personal data of Texas consumers (customers, prospects, website/app users).

| ID | System / Activity | Description | Personal Data Types | Texas Consumers Involved? (Y/N/Unknown) |
|----|-------------------|-------------|---------------------|-----------------------------------------|
| P‑01 | {{SYSTEM_1}} | {{DESC_1}} | {{DATA_TYPES_1}} | {{TX_INVOLVED_1}} |
| P‑02 | {{SYSTEM_2}} | {{DESC_2}} | {{DATA_TYPES_2}} | {{TX_INVOLVED_2}} |
| P‑03 | {{SYSTEM_3}} | {{DESC_3}} | {{DATA_TYPES_3}} | {{TX_INVOLVED_3}} |

Examples: website tracking, CRM, marketing email platform, customer portal, mobile app, support system, data broker activities.[web:81][web:86][web:91][web:98]

### 4.2 Sensitive Personal Data

Identify any TDPSA **sensitive personal data** processed for Texas consumers (e.g., precise geolocation, biometric identifiers, health data, children’s data).[web:81][web:86][web:91]

| ID | System / Activity | Sensitive Data Category | Purpose | Consent Obtained? (Y/N/Unknown) |
|----|-------------------|-------------------------|---------|----------------------------------|
| S‑01 | {{SYSTEM_S1}} | {{SENSITIVE_CATEGORY_1}} | {{SENSITIVE_PURPOSE_1}} | {{CONSENT_STATUS_1}} |
| S‑02 | {{SYSTEM_S2}} | {{SENSITIVE_CATEGORY_2}} | {{SENSITIVE_PURPOSE_2}} | {{CONSENT_STATUS_2}} |

---

## 5. Data Uses: Sale, Targeted Advertising, and Profiling

TDPSA grants Texas consumers rights to opt out of **sale of personal data**, **targeted advertising**, and certain **profiling**.[web:81][web:86][web:91][web:96][web:98]

### 5.1 Sale of Personal Data

- Does {{ORG_NAME}} sell personal data as defined by TDPSA (including exchange for monetary or other valuable consideration)?  
  - ☐ Yes  ☐ No  ☐ Unclear  

Describe any activities that might be considered a sale:

> {{SALE_ACTIVITIES_DESCRIPTION}}

### 5.2 Targeted Advertising

- Does {{ORG_NAME}} use data about consumers’ activities across websites or services to display ads based on personal data over time?  
  - ☐ Yes  ☐ No  ☐ Unclear  

Describe targeted advertising practices and tools (e.g., cookies, pixels, ad tech platforms):

> {{TARGETED_AD_PRACTICES}}[web:81][web:86][web:95][web:98]

### 5.3 Profiling in Furtherance of Decisions

- Does {{ORG_NAME}} engage in profiling that produces legal or similarly significant effects on consumers (e.g., eligibility, pricing)?  
  - ☐ Yes  ☐ No  ☐ Unclear  

Describe any such profiling:

> {{PROFILING_PRACTICES_DESCRIPTION}}[web:81][web:86][web:94]

---

## 6. Consumer Rights Readiness Snapshot

For Texas consumers, TDPSA provides rights of access, correction, deletion, portability, and to opt out of sale, targeted ads, and certain profiling.[web:81][web:86][web:91][web:96]

Briefly assess current state:

| Right | Current Capability (Y/N/Partial) | Notes |
|-------|----------------------------------|-------|
| Access | {{ACCESS_STATUS}} | {{ACCESS_NOTES}} |
| Correction | {{CORRECTION_STATUS}} | {{CORRECTION_NOTES}} |
| Deletion | {{DELETION_STATUS}} | {{DELETION_NOTES}} |
| Portability | {{PORTABILITY_STATUS}} | {{PORTABILITY_NOTES}} |
| Opt‑out of sale | {{SALE_OPTOUT_STATUS}} | {{SALE_OPTOUT_NOTES}} |
| Opt‑out of targeted ads | {{TADS_OPTOUT_STATUS}} | {{TADS_OPTOUT_NOTES}} |
| Opt‑out of profiling (where applicable) | {{PROFILING_OPTOUT_STATUS}} | {{PROFILING_OPTOUT_NOTES}} |

---

## 7. High-Risk Processing and Data Protection Assessments

Controllers must conduct and document **data protection assessments** for certain higher‑risk processing activities (e.g., targeted advertising, sale of personal data, sensitive data processing, profiling with significant effects).[web:86][web:91][web:94][web:96][web:98]

Identify candidate activities for TDPSA assessments:

| ID | Activity | Risk Type (Sale/Ads/Sensitive/Profiling) | Assessment Needed? (Y/N) |
|----|----------|------------------------------------------|---------------------------|
| A‑01 | {{ACTIVITY_1}} | {{RISK_TYPE_1}} | {{ASSESSMENT_NEEDED_1}} |
| A‑02 | {{ACTIVITY_2}} | {{RISK_TYPE_2}} | {{ASSESSMENT_NEEDED_2}} |

---

## 8. Enforcement and Exposure Snapshot

Note any facts relevant to enforcement risk:

- Use of high‑risk data such as **precise geolocation** and online tracking without clear notice/consent (a known TDPSA enforcement focus).[web:78][web:79][web:95][web:97][web:98]  
- Participation in data broker or telematics ecosystems.  
- Prior privacy complaints, incidents, or investigations.

Brief narrative:

> {{ENFORCEMENT_RISK_SUMMARY}}

---

## 9. Recommended Next Steps (High Level)

Based on this initial scope and inventory:

1. Confirm TDPSA applicability and any exemptions with counsel.  
2. Update or create a TDPSA‑compliant privacy notice with required disclosures (data categories, purposes, sharing, rights, appeal).[web:81][web:91][web:93][web:96]  
3. Design and implement a **TDPSA consumer rights & appeal workflow** (requests, verification, timelines, appeals).  
4. Address sale/targeted ads/profiling opt‑outs and sensitive data consent practices.  
5. Plan and prioritize TDPSA data protection assessments for high‑risk activities.

Owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} |
| {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} |

---

**End of Template**
