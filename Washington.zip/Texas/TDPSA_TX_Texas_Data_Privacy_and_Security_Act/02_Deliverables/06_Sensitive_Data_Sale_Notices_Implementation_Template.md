# Texas TDPSA – Sensitive Data & Sale Notices + Implementation Checklist (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:92][web:94]  
**Document Type:** Statutory Sale Notices & Website/App Implementation Checklist (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This deliverable provides:

- The **exact TDPSA sale‑of‑sensitive/biometric data notices** your clients must use if they sell that data.  
- A practical checklist for where to place the notices on sites/apps and how to log that they were displayed.[web:92][web:93][web:148][web:152][web:154][web:155][web:156][web:158][web:99]

---

## 2. Statutory Notice Blocks (Copy‑Paste)

Under TDPSA, if {{ORG_NAME}} sells sensitive personal data, it must include this notice:[web:92][web:93][web:148][web:152][web:154][web:155][web:156][web:158][web:99]

> **NOTICE: We may sell your sensitive personal data.**

If {{ORG_NAME}} sells biometric personal data, it must also include:

> **NOTICE: We may sell your biometric personal data.**[web:92][web:93][web:148][web:152][web:154][web:155][web:156][web:158][web:99]

These notices:

- Must use this **exact language**.  
- Must be posted **“in the same location and in the same manner as the privacy notice”** (e.g., near the privacy‑policy link on the website/app).[web:92][web:93][web:148][web:152][web:154][web:155][web:156][web:158][web:99]

---

## 3. When These Notices Are Required

Complete this quick assessment:

1. Does {{ORG_NAME}}’s sale definition include **sensitive personal data** (e.g., health, precise geolocation, children’s data, biometric identifiers used for unique ID) being shared with third parties for monetary or other valuable consideration?[web:92][web:143][web:145][web:155][web:156][web:157][web:158]  
   - ☐ Yes – sensitive‑data sale notice required.  
   - ☐ No – do **not** use the sensitive‑data sale notice.

2. Does {{ORG_NAME}} sell **biometric personal data** (e.g., biometric identifiers used to uniquely identify an individual) to third parties for monetary or other valuable consideration?  
   - ☐ Yes – biometric‑data sale notice required.  
   - ☐ No – do **not** use the biometric‑data sale notice.[web:92][web:143][web:145][web:155][web:156][web:157][web:158]

Summary:

> {{SALE_NOTICE_DETERMINATION}}

---

## 4. Website / App Placement Checklist

TDPSA expects these notices “in the same location and in the same manner as the privacy notice,” typically meaning **wherever you surface the privacy‑policy link.**[web:92][web:93][web:148][web:151][web:155][web:156][web:157][web:160]

### 4.1 Web (Desktop & Mobile)

For each property:

| Site / Domain | Privacy Notice Link Location | Sale Notice Placement Plan |
|---------------|-----------------------------|----------------------------|
| {{SITE_1}} | e.g., footer “Privacy Policy” link | Add the required notice text next to or directly under the privacy‑policy link. |
| {{SITE_2}} | e.g., account‑registration page | Show the notice near the privacy notice link or inline text describing privacy terms. |

Implementation tips:

- Use simple, readable formatting; do **not** bury notice only deep inside the policy.  
- Ensure responsive design so the notice is clearly visible on mobile as well as desktop.

### 4.2 Mobile Apps

For apps that sell sensitive/biometric data:

- Show the notice in the **“Privacy” or “Legal”** screen where the privacy policy appears.  
- If the app uses in‑app browsers or consent screens with privacy‑policy links, display the notice adjacent to those links.[web:151][web:155][web:157][web:160]

---

## 5. Integration With Privacy Policy and Consent

### 5.1 Privacy Policy Text

If {{ORG_NAME}} sells sensitive or biometric data, the privacy policy itself should:

- Disclose that such data is sold.  
- Reference the statutory notice and link to opt‑out mechanisms for sale and targeted advertising.[web:92][web:93][web:145][web:148][web:151][web:155][web:157]

Short example stub to insert into the policy:

> “We may sell certain categories of sensitive and/or biometric personal data as defined by Texas law. NOTICE: We may sell your sensitive personal data. NOTICE: We may sell your biometric personal data. You can opt out of such sales as described in the ‘Your Rights & Choices’ section of this policy.”

> {{PRIVACY_POLICY_INTEGRATION_NOTES}}

### 5.2 Consent and Preference Flows

Ensure that:

- Any consent or cookie‑banner text that implies sale/targeted advertising references the same categories of sensitive/biometric data.  
- Opt‑out flows (Deliverable 4) correctly mark users who opt out of sale of sensitive/biometric data.[web:93][web:145][web:151][web:155][web:157][web:160]

> {{CONSENT_FLOW_NOTES}}

---

## 6. Logging and Evidence for Audits

To defend against TDPSA enforcement, {{ORG_NAME}} should maintain evidence that:

- Notices were deployed correctly.  
- They stayed in place over time.[web:92][web:93][web:148][web:150][web:151][web:155][web:157][web:160]

Suggested logs:

- Screenshots/PDF captures of each relevant page or app screen showing:  
  - Privacy‑policy link.  
  - Statutory sale notice adjacent to it.  
- Change‑management tickets / commits documenting when the notice was added or updated.  
- QA test cases confirming that:  
  - The notice renders correctly on mobile and desktop.  
  - The notice is shown for users geolocated in Texas (if you tailor by region).

Log template:

| Date | Site / App | Page / Screen | Notice(s) Present | Evidence File | Reviewer |
|------|------------|---------------|-------------------|---------------|----------|
| {{DATE_1}} | {{SITE_1}} | {{PAGE_1}} | Sensitive / Biometric | {{FILE_PATH_1}} | {{REVIEWER_1}} |

> {{LOGGING_PROCESS_SUMMARY}}

---

## 7. Governance and Review

- Owner for these notices: {{NOTICE_OWNER_ROLE}} (e.g., Privacy or Marketing Ops).  
- Review cadence: at least **annually**, or whenever:  
  - The organization starts or stops selling sensitive/biometric data.  
  - The privacy‑policy location or design changes (e.g., site redesign).[web:92][web:145][web:148][web:151][web:155][web:157]

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
