# Texas TDPSA – AG Inquiry / Enforcement Defense File & Cure-Period Playbook (MASTER)

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Attorney General Inquiry Response Packet & Cure-Period Playbook (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This document provides:

- A **standard packet structure** for responding to Texas Attorney General (AG) TDPSA inquiries (CIDs, letters, lawsuits).  
- A **playbook** for using TDPSA’s 30‑day cure period (which does not sunset) to reduce enforcement risk and penalties.[web:92][web:148][web:153][web:31][web:83][web:86][web:175][web:174][web:22]

---

## 2. TDPSA Enforcement Snapshot

Key points to include in internal briefings:

- The Texas AG has **exclusive enforcement authority** under TDPSA; there is **no private right of action**.[web:92][web:148][web:153][web:83][web:175][web:86]  
- Civil penalties can reach **7,500 dollars per violation**, plus injunctive relief and recovery of investigation costs.[web:92][web:148][web:153][web:31][web:86][web:174]  
- Before bringing an action, the AG must give at least **30 days’ written notice** identifying alleged violations and allow a **30‑day cure period**.[web:92][web:148][web:153][web:175][web:31][web:174][web:22]  
- To “cure” properly, the business must send a **written statement** within 30 days confirming the violation was cured, consumers were notified (if contact info available), supporting documentation is provided, and internal policies were changed to prevent recurrence.[web:92][web:148][web:173][web:175][web:31][web:174][web:22][web:86]

---

## 3. AG Inquiry Response Packet – Table of Contents

When {{ORG_NAME}} receives a TDPSA inquiry, assemble a packet with:

1. **Cover memo** summarizing allegations, timeline, and status.  
2. **TDPSA scope & inventory** (Deliverable 1).  
3. **Privacy notice & rights workflow** (Deliverable 2).  
4. **Relevant Data Protection Assessments** (Deliverable 3) for the processing at issue.  
5. **Opt-out & consent implementation documentation** (Deliverable 4).  
6. **Security & incident-response baseline** and any relevant incident records (Deliverable 5).  
7. **Sensitive-data sale notices and data-broker status documentation** (Deliverables 6–7).  
8. **Evidence of cure actions** (Section 5 below).[web:83][web:86][web:97][web:148][web:150][web:151][web:174][web:22]

> {{PACKET_LOCATION_NOTES}}

---

## 4. Initial Response Playbook (Day 0–5)

When a TDPSA notice/CID arrives:

1. **Triage & legal hold**  
   - Immediately notify: {{LEGAL_CONTACT}}, {{PRIVACY_CONTACT}}, {{SECURITY_CONTACT}}, {{EXEC_SPONSOR}}.  
   - Place a **legal hold** on relevant systems and instruct vendors to preserve data.  

2. **Scope the allegations**  
   - Identify which TDPSA provisions are cited (e.g., failure to provide sale notice, no rights workflow, sensitive-data consent gaps, targeted ads, data protection assessment issues).[web:92][web:97][web:148][web:150][web:174]  
   - Map allegations to products, systems, and time periods.

3. **Stop potential ongoing violations**  
   - If there is a plausible violation (e.g., missing sale notice, broken opt‑out), **pause the offending practice** while you investigate.[web:97][web:148][web:174][web:22]

> {{INITIAL_RESPONSE_NOTES}}

---

## 5. Cure-Period Execution Plan (Day 0–30)

TDPSA’s permanent 30‑day cure period is only effective if {{ORG_NAME}} issues a **written cure statement** meeting statutory criteria.[web:92][web:148][web:173][web:175][web:31][web:174][web:22][web:86]

### 5.1 Identify and Implement Fixes

For each alleged violation, document:

- **What is wrong** (e.g., missing sensitive-data sale notice, incomplete rights workflow).  
- **Immediate remediation** (e.g., deploy notices, fix opt‑outs, patch policy).  
- **Longer‑term control changes** (e.g., new checks, training, periodic audits).[web:92][web:97][web:148][web:151][web:174][web:22][web:86]

Remediation log template:

| Issue | Fix Implemented | Date | Owner | Evidence |
|-------|-----------------|------|-------|----------|
| {{ISSUE_1}} | {{FIX_1}} | {{DATE_1}} | {{OWNER_1}} | {{EVIDENCE_1}} |

### 5.2 Written Cure Statement – Required Elements

Draft a letter from {{ORG_NAME}} (via counsel) to the AG including the following TDPSA‑required statements:[web:92][web:148][web:173][web:175][web:31][web:174][web:22][web:86]

1. **Acknowledgement & cure**  
   - Statement that {{ORG_NAME}} has **cured the alleged violation(s)** identified in the AG’s notice.  

2. **Consumer notification**  
   - Statement that affected consumer(s) were notified that their privacy issue was addressed, **if contact information was available**, including a high‑level description of how/when they were notified.

3. **Supporting documentation**  
   - Attach or reference documentation showing how the violation was cured (e.g., updated screens, policies, opt‑out logs, configuration screenshots, training records).

4. **Policy/process changes**  
   - Statement describing **changes to internal policies and practices** to ensure that no such further violations will occur (e.g., new review steps, monitoring, controls).

Letter outline:

> {{CURE_STATEMENT_OUTLINE}}

Ensure the letter is **delivered within 30 days** of the AG’s notice (track date carefully).

---

## 6. Evidence Checklist for the Defense File

Include concrete items that align with the AG’s expectations and early TDPSA cases:[web:97][web:148][web:150][web:151][web:174][web:22][web:31][web:83]

- **Screenshots / PDFs** of:  
  - Updated privacy notice and sensitive‑data sale notices.  
  - Opt‑out pages and preference centers.  
  - Data‑broker or other required disclosures (if applicable).  

- **Logs / reports**:  
  - Rights request tracker exports (showing timely responses).  
  - Opt‑out logs and ad/analytics configuration exports.  
  - Data protection assessment approvals and timestamps.  

- **Policy documents**:  
  - TDPSA privacy notice and internal workflows.  
  - Security and incident‑response baseline; relevant incident reports.  

- **Training evidence**:  
  - Materials and completion records for TDPSA/privacy training.

> {{EVIDENCE_FILE_INDEX}}

---

## 7. Governance, Messaging & Follow-Up

### 7.1 Internal Governance

- **Executive briefings:** Summarize risk, potential penalty range, and remediation status for leadership/board.  
- **Post‑mortem:** After cure, run an internal review to confirm root causes and control improvements.[web:83][web:86][web:150][web:170]

### 7.2 External Messaging

- All external responses (media, customers, partners) should be approved by Legal and Communications.  
- Consider **proactive customer messaging** when violations materially affected user experience (e.g., broken opt‑out, misused location data).[web:83][web:97][web:148][web:150][web:174][web:22]

---

## 8. Review and Maintenance

- Update this defense file **annually** and after any TDPSA investigation or significant enforcement action in your sector.  
- Ensure it always reflects your current TDPSA deliverables and system architecture.[web:83][web:86][web:150][web:170]

Version history:

- Version {{VERSION}} – {{VERSION_DATE}} – {{VERSION_NOTES}}

---

**End of Template**
