# Law Profile

## Law Name
Texas Data Privacy and Security Act (TDPSA)

## Citation
Texas Business & Commerce Code, Chapter 541

## Status
Enacted

## Effective Date
July 1, 2024

## Regulatory Scope

Applies to persons that:

- Conduct business in Texas OR produce products/services consumed by Texas residents
- Process personal data
- Are not classified as small businesses under SBA standards (unless selling sensitive data)

Applies regardless of revenue thresholds if not a small business.

Exemptions include:
- State agencies
- Certain financial institutions (GLBA)
- HIPAA-covered entities and business associates
- Nonprofits
- Higher education institutions

## Core Consumer Rights

Consumers have the right to:

- Confirm whether a controller processes their personal data
- Access personal data
- Correct inaccuracies
- Delete personal data
- Obtain a portable copy of personal data
- Opt out of:
  - Targeted advertising
  - Sale of personal data
  - Profiling in furtherance of decisions producing legal or similarly significant effects

## Core Business Obligations

Controllers must:

1. Provide a clear and accessible privacy notice
2. Implement secure and reliable methods for submitting consumer rights requests
3. Establish internal response workflows (45-day response period)
4. Conduct Data Protection Assessments (DPAs) for high-risk processing
5. Obtain consent before processing sensitive data
6. Implement reasonable administrative, technical, and physical safeguards
7. Maintain compliant processor contracts
8. Avoid dark patterns in consent mechanisms

## Sensitive Data Includes

- Racial or ethnic origin
- Religious beliefs
- Mental or physical health diagnosis
- Sexual orientation
- Citizenship or immigration status
- Genetic or biometric data used for identification
- Precise geolocation data
- Data of known children

## Enforcement Authority

Texas Attorney General

No private right of action.

## Penalties

- Civil penalties up to $7,500 per violation
- 30-day cure period (if curable) after AG notice
- Injunctive relief
- Recovery of attorney fees and investigative costs

Each violation may be treated separately.

## Private Right of Action
No

## Tier Classification
Tier 1 – State Consumer Privacy Law

## Revenue Priority
High (Enterprise + AI profiling crossover)

## Target Industries

- E-commerce platforms
- SaaS companies
- Data-driven marketing companies
- AI profiling systems
- Financial services (non-GLBA)
- Retailers
- Health-adjacent tech platforms

## Strategic Positioning

Position as:

Texas Consumer Privacy & AI Profiling Operational Compliance Program.

TDPSA intersects heavily with:

- AI-driven profiling
- Targeted advertising
- Data broker operations
- Sensitive data processing
- Multi-state privacy harmonization

Strong bundling candidate with:
- CUBI (biometrics)
- Colorado Privacy Act
- California CPRA frameworks

## Internal Notes

Primary compliance focus areas:

1. Data Mapping & Applicability Analysis
2. Privacy Notice & Rights Workflow
3. Data Protection Assessment (DPA)
4. Opt-Out Infrastructure
5. Sensitive Data Controls
6. Security & Incident Baseline
7. Vendor Contract Review
8. AG Inquiry Defense File

Key risk driver:
Failure to implement operational rights workflows and profiling opt-out mechanisms.