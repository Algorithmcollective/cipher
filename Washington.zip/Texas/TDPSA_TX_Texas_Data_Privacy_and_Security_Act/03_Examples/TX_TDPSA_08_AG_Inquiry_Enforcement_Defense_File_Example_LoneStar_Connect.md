# Texas TDPSA – AG Inquiry / Enforcement Defense File & Cure-Period Playbook – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Attorney General Inquiry Response Packet & Cure-Period Playbook (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## 1. Purpose

This document shows how LoneStar Connect, Inc. (“LoneStar Connect”) would respond if the Texas AG alleged TDPSA violations related to targeted advertising and sale of sensitive geolocation data, in line with early AG enforcement trends.[web:92][web:97][web:148][web:150][web:151][web:174][web:22][web:31][web:83]

---

## 2. TDPSA Enforcement Snapshot – LoneStar Connect

- LoneStar Connect understands that the Texas AG has **exclusive enforcement authority** for TDPSA and that individuals cannot sue under the statute.[web:92][web:148][web:153][web:83][web:175][web:86]  
- The AG may seek up to **7,500 dollars per violation**, so misconfigured tracking or sale notices affecting large user populations could be high‑exposure events.[web:92][web:148][web:153][web:31][web:174][web:86]  
- LoneStar Connect treats the 30‑day cure period as a **tight remediation window** requiring executive‑level attention.

---

## 3. AG Inquiry Response Packet – Structure

If the AG alleged that LoneStar Connect failed to provide a sensitive‑data sale notice and adequate targeted‑ad opt‑outs, the packet would include:

1. **Cover memo:** Summary of allegations (e.g., failure to post “NOTICE: We may sell your sensitive personal data,” inadequate location consent).[web:97][web:148]  
2. **TDPSA Scope & Inventory Memo** – TX_TDPSA_01_... showing where sensitive data and targeted ads occur.  
3. **Privacy Notice & Rights Workflow** – TX_TDPSA_02_... with updated TDPSA‑aligned policy and internal rights flow.  
4. **Data Protection Assessment – Targeted Ads & Location** – TX_TDPSA_03_... (A‑01 and A‑02).  
5. **Opt‑Out & Consent Implementation Plan** – TX_TDPSA_04_... describing preferences, suppression lists, and location consent.  
6. **Security & Incident Baseline** – TX_TDPSA_05_... with any incident records tied to tracking or location.  
7. **Sensitive‑Data Sale Notice Implementation** – TX_TDPSA_06_... showing where the statutory notice was added.  
8. **Any high‑risk/data‑broker assessment** – TX_TDPSA_07_..., demonstrating that LoneStar Connect is not a data broker.[web:83][web:148][web:150][web:151][web:174][web:22]

---

## 4. Initial Response Playbook (Day 0–5)

Upon receiving an AG notice:

1. **Triage & hold**  
   - Notify General Counsel, Privacy Lead, CISO, and CEO.  
   - Place a legal hold on web/app logs, DPA files, and ad/analytics configurations; instruct key vendors (ad platforms, analytics providers) to preserve relevant data.[web:83][web:150][web:22]

2. **Scope**  
   - Confirm which systems are implicated: marketing site, mobile apps, ad/analytics stack, and sale/opt‑out mechanisms.  
   - Map dates and geographies (Texas traffic) referenced by the AG.[web:97][web:148][web:151][web:174]

3. **Stop potential violations**  
   - If sensitive‑data sale notice is missing, deploy it immediately per TX_TDPSA_06.  
   - If opt‑outs are not honored reliably, pause specific targeted‑ad campaigns for Texas traffic until fixes are verified.[web:97][web:148][web:151][web:174][web:22]

---

## 5. Cure-Period Execution (Day 0–30)

### 5.1 Fixes

LoneStar Connect would log each issue and fix, for example:

| Issue | Fix Implemented | Date | Owner | Evidence |
|-------|-----------------|------|-------|----------|
| Missing “NOTICE: We may sell your sensitive personal data.” near privacy notice | Added notice in website/app footers and Legal & Privacy screens; QA verified visibility on desktop/mobile and for Texas traffic | 2026‑02‑10 | Privacy Lead | Screenshots, Git commit IDs |
| Inconsistent honoring of sale/targeted‑ad opt‑outs in Ad Platform B | Updated CMP integration and suppression list logic; tested with sample accounts | 2026‑02‑15 | Marketing Ops | CMP logs, ad platform screenshot |
| Insufficient disclosure/consent for precise geolocation | Updated privacy notice and in‑app explanation; tightened geolocation toggles | 2026‑02‑17 | Product Lead | App screenshots, release notes |[web:92][web:97][web:148][web:151][web:174][web:22][web:86]

### 5.2 Sample Cure Statement Outline

Within 30 days, LoneStar Connect would send a letter via counsel to the AG that:

1. **States cure:** Confirms that the specific TDPSA violations alleged (e.g., missing sale notice, opt‑outs, consent gaps) have been cured.  
2. **Consumer notification:** Explains that affected users were notified via updated privacy notice changelog, in‑product banner, and/or direct email where appropriate.  
3. **Provides documentation:** Attaches or references evidence (screenshots, logs, DPAs, updated policies, training records) demonstrating the cure.  
4. **Commits to improvements:** Describes internal policy and process changes (e.g., new pre‑launch TDPSA checklist for marketing/product changes, quarterly audits of opt‑outs).[web:92][web:148][web:173][web:175][web:31][web:174][web:22][web:86]

The letter would be logged in the “TDPSA – AG Interactions” folder with date and delivery details.

---

## 6. Evidence Checklist – LoneStar Connect

For a targeted‑ads/sensitive‑data case, LoneStar Connect would include:

- Screenshots/PDFs of updated privacy notice, sensitive‑data sale notice placement, and privacy choices page.  
- CMP logs and ad‑platform exports showing opt‑outs applied for Texas users during and after the cure period.  
- Data Protection Assessment for targeted ads and precise geolocation (TDPSA DPA TDPSA‑DPA‑001).  
- Training materials and attendance records for marketing, product, and engineering staff on TDPSA and opt‑out flows.  
- Any prior correspondence with users complaining about ads or location tracking and how they were resolved.[web:97][web:148][web:150][web:151][web:174][web:22][web:31][web:83]

---

## 7. Governance & Lessons Learned

After resolving the matter (whether cured without penalty or settled):

- LoneStar Connect’s Privacy Lead and CISO will run a **post‑incident review** to check whether additional controls are needed in product‑launch and marketing‑campaign review.  
- Executive team and, where appropriate, the board will receive a summary of the issue, cure steps, and any financial or reputational impact.[web:83][web:86][web:150][web:170]

Version history:

- Version 1.0 – January 31, 2026 – Initial TDPSA AG inquiry / enforcement defense file created for LoneStar Connect.

---

**End of Example**
