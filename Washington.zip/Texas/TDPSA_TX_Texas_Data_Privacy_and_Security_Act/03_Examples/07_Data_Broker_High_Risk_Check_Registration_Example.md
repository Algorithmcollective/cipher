# Texas TDPSA – Data Broker / High-Risk Processor Check & Registration Calendar – LoneStar Connect, Inc.

**Laws:** TDPSA § 541.001 et seq.; Texas Data Broker Law, Chapter 510.[web:94][web:171][web:166][web:170]  
**Document Type:** Data Broker / High-Risk Processor Assessment & Registration Checklist (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## 1. Purpose

This document records LoneStar Connect, Inc.’s (“LoneStar Connect”) assessment of whether it is a Texas “data broker,” flags high‑risk TDPSA processing, and establishes a registration/compliance calendar if broker obligations ever apply.[web:149][web:161][web:162][web:165][web:168][web:169][web:166][web:170]

---

## 2. Texas Data Broker Quick Screen

1. LoneStar Connect collects personal data primarily **directly** from users and small‑business customers via its SaaS platform and website. It does **not** operate a separate business of aggregating third‑party personal data and selling/licensing it as a stand‑alone product.  
2. Its revenue comes from **subscriptions and service fees**, not from selling large data sets or profiles acquired from others.  
3. It does not currently fit the expanded Chapter 510 definition of a data broker whose revenue is largely derived from trading in data collected indirectly.[web:162][web:163][web:165][web:168][web:169][web:166][web:171]

Conclusion:

> LoneStar Connect is **not presently a data broker** under Texas law. It will reassess this conclusion if it ever launches a data‑licensing product or begins sourcing and selling data obtained primarily from third‑party sources.

---

## 3. Data Broker Obligations – Registration & Online Notice

Since LoneStar Connect is not currently a data broker:

- It does **not** file a data‑broker registration with the Secretary of State and has no 300‑dollar fee or annual renewal at this time.[web:149][web:161][web:164][web:171][web:169]  
- It does **not** need to post the Chapter 510 “This entity is a data broker under Texas law” notice on its website or apps.[web:162][web:165][web:168][web:169][web:166]

However, the company keeps:

- A placeholder calendar entry to revisit broker status each January as part of its TDPSA/enterprise‑risk review.  
- A copy of the AG‑prescribed data‑broker website language in case it ever launches a data‑product business.[web:147][web:162][web:165][web:168][web:169][web:166]

---

## 4. TDPSA High-Risk Processing Check

LoneStar Connect identifies the following TDPSA high‑risk activities:

| ID | Activity | TDPSA Risk Type | DPA Required? | Notes / Owner |
|----|----------|-----------------|---------------|---------------|
| HR‑01 | Third‑party ad/analytics tracking on marketing site and apps | Sale/targeted advertising of personal and sensitive data | Yes – TDPSA DPA completed (Deliverable 3) | Owned by Marketing & Privacy. |
| HR‑02 | Processing of precise geolocation in mobile apps for nearby‑business suggestions and reminders | Sensitive personal data | Yes – included in Deliverable 3 and security review | Owned by Product & Engineering. |
| HR‑03 | Potential future scoring/profiling for dynamic pricing or eligibility decisions | Profiling with legal/significant effects | To be determined before launch | Owned by Product, with Privacy sign‑off. |[web:86][web:91][web:94][web:96][web:98][web:166][web:170]

Summary:

> LoneStar Connect is **not a data broker**, but operates several high‑risk TDPSA processing activities (targeted ads, sale‑like sharing, precise geolocation) that are already subject to Data Protection Assessments and enhanced governance.

---

## 5. Registration & Compliance Calendar

Since LoneStar Connect is not currently a data broker, its calendar focuses on **reassessment** rather than registration:

| Task | Owner | Due Date / Frequency |
|------|-------|----------------------|
| Reassess whether any new data‑product offerings create “data broker” status under Chapter 510 | Privacy Lead + Legal | Annually in January; ad hoc before launch of any data‑product |
| Review TDPSA high‑risk activities and update DPAs | Privacy Lead + Security | Annually |
| Confirm TDPSA consumer‑rights page and opt‑outs remain linked from privacy notice and any data‑product pages | Privacy Lead + Marketing | Annually |[web:162][web:165][web:168][web:169][web:166][web:170]

If LoneStar Connect ever becomes a data broker, the calendar will be expanded to include:

- Filing Form 4001 and paying the 300‑dollar fee before starting broker activities and annually for renewals.  
- Posting the required data‑broker website notice and TDPSA rights instructions.[web:149][web:161][web:164][web:171][web:162][web:165][web:168][web:169][web:147]

---

## 6. Governance and Review

- Privacy Lead owns this assessment, with Legal approval recorded in the company’s TDPSA governance folder.  
- Any significant changes in product strategy (e.g., launching a marketplace for anonymized or identifiable user data) trigger an immediate re‑evaluation of data‑broker status.

Version history:

- Version 1.0 – January 31, 2026 – Initial data‑broker and high‑risk processing assessment completed; LoneStar Connect determined **not** to be a data broker as of this date.

---

**End of Example**
