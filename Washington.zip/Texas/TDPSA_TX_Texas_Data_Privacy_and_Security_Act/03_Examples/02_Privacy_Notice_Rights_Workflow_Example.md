# Texas TDPSA – Privacy Notice & Rights Workflow – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Public Privacy Notice + Consumer Rights & Appeals Workflow (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## PART A – PUBLIC-FACING PRIVACY NOTICE (EXAMPLE)

### 1. Introduction

LoneStar Connect, Inc. (“LoneStar Connect,” “we,” “us,” or “our”) provides online scheduling and communication tools to small businesses and their customers. This Privacy Notice explains how we collect, use, and share personal data, and describes your rights under the Texas Data Privacy and Security Act (TDPSA) if you are a Texas consumer.[web:81][web:86][web:91][web:98]

### 2. Personal Data We Collect

We may collect:

- Identifiers, such as your name, email address, phone number, username, and account ID.  
- Commercial information, such as subscription details and transaction history.  
- Internet or device information, such as IP address, device identifiers, browser type, pages visited, and referring URLs.  
- Geolocation data, when you enable location features in our mobile apps.  
- Professional information, such as your role and business details if you are a business user.  
- Information you choose to provide in messages, booking notes, or support communications.

We may receive personal data directly from you, from the business you interact with on our platform, or automatically when you use our services.[web:81][web:86][web:91][web:96]

### 3. How We Use Personal Data

We use personal data to:

- Provide, operate, and improve our platform and related services.  
- Create and manage accounts for businesses and their customers.  
- Send you service-related messages (e.g., confirmations, reminders, updates).  
- Provide customer support and respond to inquiries.  
- Analyze service usage and improve performance and features.  
- Run marketing campaigns and measure their effectiveness, including through targeted advertising.  
- Help prevent fraud, abuse, or security incidents.  
- Comply with legal obligations.[web:81][web:86][web:91][web:96][web:98]

### 4. How We Share Personal Data

We may share personal data with:

- Service providers that help us deliver the services (e.g., hosting, analytics, email delivery, customer support).  
- The business you book with or communicate with through our platform (for example, your appointment details and contact information).  
- Our affiliates, where consistent with this Notice.  
- Third parties when required by law or to protect rights and safety.  
- Other parties with your direction or consent.[web:81][web:86][web:91]

We do not sell your personal data in the sense of selling lists with names and contact details, but some of our use of third‑party advertising and analytics tools may be treated as a “sale” or “targeted advertising” under TDPSA, as described below.[web:81][web:86][web:91][web:96][web:98]

### 5. Targeted Advertising and “Sale” of Personal Data

We use third‑party partners (such as analytics and advertising providers) that may collect information about your activity on our website and apps over time and across different services, in order to help us show you more relevant ads and measure our marketing performance.[web:81][web:86][web:91][web:95][web:98]

Under TDPSA, this kind of data sharing can be considered:

- **Targeted advertising**, and  
- In some cases, a **“sale”** of personal data.

You can opt out of these activities as described in Section 8 below.

### 6. Sensitive Personal Data

We process limited sensitive personal data:

- **Precise geolocation:** When you enable location services in our mobile apps, we may use your precise location to suggest nearby businesses or send location‑based reminders. You can control this via your device settings.  
- **Other sensitive data:** We do not intend to collect health or similar sensitive data, but small businesses using our platform may sometimes enter such details in free‑text notes. We instruct them to avoid entering unnecessary sensitive information.

Where TDPSA requires it, we will obtain consent for processing sensitive personal data or provide clear notices as appropriate.[web:81][web:86][web:91]

### 7. How Long We Keep Personal Data

We retain personal data:

- For as long as you maintain an account with us.  
- For as long as needed to provide services to you or the business you interact with.  
- As necessary to comply with our legal obligations, resolve disputes, and enforce our agreements.

We also apply internal retention schedules that periodically review and delete or de‑identify older data where appropriate.[web:81][web:86][web:91][web:96]

### 8. Your Rights and Choices (Texas Consumers)

If you are a Texas consumer, you may have the following rights under TDPSA:

- **Access:** Request confirmation that we process your personal data and access to that data.  
- **Correction:** Request that we correct inaccurate personal data.  
- **Deletion:** Request that we delete personal data we have about you, subject to certain exceptions.  
- **Portability:** Request a copy of certain personal data in a portable format.  
- **Opt out of:**  
  - Targeted advertising.  
  - Sale of personal data.  
  - Profiling in furtherance of decisions that produce legal or similarly significant effects on you (we do not currently engage in this kind of profiling, but we will honor your rights if that changes).[web:81][web:86][web:91][web:96][web:98]

You can exercise these rights by:

- Submitting a request at: https://privacy.lonestarconnect.com/rights  
- Or emailing: privacy@lonestarconnect.com

We will respond within the time required by TDPSA and may ask you for information to verify your identity.

#### Opting Out of Targeted Advertising and Sale

To opt out of activities that may be considered targeted advertising or a “sale” of personal data:

- Visit our privacy choices page: https://privacy.lonestarconnect.com/choices  
- Adjust your cookie preferences using the “Cookie Settings” link in our website footer.  
- Use any browser or platform‑level privacy controls that we are required to recognize under applicable law.[web:81][web:86][web:95][web:96][web:98]

### 9. Appeals

If we decline to act on your request, we will explain why and how you can appeal our decision. You may submit an appeal by replying to our response email or by following the instructions on our privacy rights page. We will review your appeal and respond within the timeframe required by TDPSA.[web:81][web:86][web:91][web:96]

If you have concerns about how we handled your request after our appeal process, you may contact the Texas Attorney General.

### 10. Contact Us

If you have questions about this Privacy Notice or our data practices, please contact us at:

- Email: privacy@lonestarconnect.com  
- Mail: LoneStar Connect, Inc., Attn: Privacy, 200 Congress Ave, Suite 900, Austin, TX 78701

---

## PART B – INTERNAL CONSUMER RIGHTS & APPEALS WORKFLOW (EXAMPLE)

### 1. Intake Channels

LoneStar Connect accepts TDPSA rights requests through:

- Web form: https://privacy.lonestarconnect.com/rights  
- Email: privacy@lonestarconnect.com

Support staff are trained to forward any rights-related emails or messages to the Privacy team’s queue in the internal ticketing system.[web:81][web:86][web:91][web:96]

### 2. Logging and Categorization

The Privacy team logs each request in a rights‑tracking spreadsheet and ticketing system with:

- Request ID.  
- Requester details (name, email, any account identifiers).  
- Request type (access, correction, deletion, portability, opt‑out, other).  
- Date received, due date, and status.  
- Outcome (fulfilled, partially fulfilled, denied) and brief notes.

System: Jira “Privacy Requests” project with a linked spreadsheet for metrics.[web:81][web:86][web:91][web:96]

### 3. Verification

For logged‑in users, LoneStar Connect treats authenticated sessions as sufficient for many self‑service actions (e.g., access or basic corrections).

For email‑based requests, the Privacy team:

- Confirms control of the email address (reply verification or one‑time code).  
- For sensitive requests (e.g., full data export or deletion), may ask for additional confirmation using account‑linked details or short video/ID checks where proportionate.

Verification steps are documented in an internal SOP.

### 4. Handling by Request Type

- **Access:**  
  - Provide a summary of categories of data processed and, where feasible, a copy of specific data associated with the user (e.g., profile, basic logs, booking history) via secure download.

- **Correction:**  
  - Ask the requester to specify which data is inaccurate and provide supporting information.  
  - Update records where appropriate; in some cases, annotate instead of overwriting historical data.

- **Deletion:**  
  - Close the account (if active) and delete or de‑identify associated personal data from primary systems, subject to legal/contractual retention requirements.  
  - Log any exceptions (e.g., data kept for legal holds or billing records).

- **Portability:**  
  - Provide an export (e.g., JSON or CSV) of key data elements such as profile information, booking history, and relevant communications, delivered via secure channel.

- **Opt‑outs (sale/targeted ads):**  
  - Record the user’s preferences in the consent management platform.  
  - Adjust marketing systems (e.g., mark as “do not profile for ads”) and configure ad/analytics tools where possible to respect the opt‑out.[web:81][web:86][web:91][web:96][web:98]

### 5. Timelines

Internal targets (aligned with TDPSA and similar laws):

- Acknowledge each request within 5 business days.  
- Provide a substantive response within 45 days, with a possible 45‑day extension for complex or voluminous requests (notice of extension documented in writing).

The rights tracker flags any approaching deadlines for follow‑up.[web:81][web:86][web:91][web:96]

### 6. Appeals Process

If the Privacy team denies or partially denies a request:

- The response email explains the reasons and includes a direct link to the appeal form at https://privacy.lonestarconnect.com/appeal.  
- Appeals are reviewed by the Privacy Lead and Legal, who were not the original decision‑makers where feasible.  
- Outcome and rationale are recorded in the rights tracker.

LoneStar Connect aims to resolve appeals within 45 days and informs users of any further steps available, including contacting the Texas Attorney General if they remain dissatisfied.[web:81][web:86][web:91][web:96]

### 7. Metrics and Reporting

Quarterly, the Privacy team compiles:

- Number of TDPSA‑related requests by type.  
- Average and maximum response times.  
- Number of denials and appeals, with outcomes.  
- Common themes or pain points (e.g., deletion in certain systems, opt‑out implementation).

These metrics are shared with senior leadership and used to prioritize process and system improvements.[web:81][web:86][web:91][web:96][web:98]

### 8. Training

LoneStar Connect:

- Trains support and account teams annually on recognizing privacy rights requests and directing them to the Privacy team.  
- Provides more in‑depth training to Privacy, Security, and Engineering teams on TDPSA requirements and internal workflows.  
- Updates training content when significant changes are made to systems or applicable laws.

Training completion is tracked in the HR system.

---

**End of Example**
