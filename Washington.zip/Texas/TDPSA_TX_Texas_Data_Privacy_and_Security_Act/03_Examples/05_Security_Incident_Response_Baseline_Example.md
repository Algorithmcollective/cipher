# Texas TDPSA – Security & Incident Response Baseline – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Security & Incident Response Baseline (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Alex Nguyen, Director of Security  

---

## 1. Purpose

This baseline documents how LoneStar Connect implements reasonable security controls and responds to security/privacy incidents involving Texas consumers’ personal data in line with TDPSA expectations and broader state privacy trends.[web:81][web:86][web:91][web:96][web:98][web:31][web:97]

---

## 2. Scope

Includes:

- Core SaaS platform (web and mobile).  
- Marketing site and tracking stack.  
- CRM, email, and support systems.  
- Employees and contractors with access to these systems, and key vendors providing hosting, analytics, and support.

---

## 3. Security Controls – High-Level Baseline

### 3.1 Administrative Safeguards

- LoneStar Connect maintains a Written Information Security Policy (WISP) covering roles, risk assessments, and acceptable use.  
- Security steering committee meets quarterly and includes Security, Engineering, Privacy, and Operations.  
- Onboarding/offboarding process: access is granted based on job role; accounts are removed within 24 hours of departure.  
- Vendor risk management: due‑diligence questionnaire and security review for key vendors, particularly cloud hosting and analytics/ad partners.[web:81][web:86][web:91][web:96]

### 3.2 Technical Safeguards

- Encryption:  
  - TLS enforced for all web/app traffic.  
  - At‑rest encryption for primary databases and storage buckets.  

- Access controls:  
  - SSO + MFA for admin and engineering accounts.  
  - Role‑based access in production systems, with periodic access reviews.

- Monitoring and logging:  
  - Centralized logging for app, infrastructure, and authentication events.  
  - Alerts for unusual login patterns and privilege escalations.  

- Backups and resilience:  
  - Daily backups and tested restore procedures for critical data sets.[web:81][web:86][web:91][web:96][web:98]

### 3.3 Physical Safeguards

- Core infrastructure hosted with a major cloud provider with strong physical controls.  
- LoneStar’s offices require badge access; visitor logs maintained.

---

## 4. Incident Definition and Examples

LoneStar treats as an incident any event that may compromise the confidentiality, integrity, or availability of customer data or that suggests a TDPSA‑relevant privacy failure.

Examples:

- Unauthorized access to a customer account due to credential stuffing.  
- Misconfigured S3 bucket exposing logs with IP addresses and email addresses.  
- Marketing campaign where opted‑out Texas consumers continue to receive targeted ads due to suppression list issues.[web:81][web:86][web:91][web:96][web:98]

---

## 5. Incident Response Workflow

### 5.1 Roles

- Incident Commander: Director of Security.  
- Security Team: Security engineers and on‑call responders.  
- Privacy / Legal: Privacy Lead and external counsel when needed.  
- Comms / Support: Head of Customer Support and Marketing Comms.

### 5.2 Stages

1. **Detect & Log**  
   - Sources: monitoring alerts, customer tickets, vendor notifications, internal reports.  
   - All suspected incidents logged in the “Security & Privacy Incidents” tracker (Jira project + spreadsheet).

2. **Triage & Classify**  
   - Initial severity assigned (Low/Medium/High).  
   - Confirm whether Texas consumers’ data is involved and whether TDPSA obligations may be triggered.

3. **Contain & Eradicate**  
   - For example, disable a misconfigured API endpoint, revoke compromised credentials, or pause a marketing campaign.

4. **Assess Impact & Obligations**  
   - Determine: data types, approximate number of individuals, jurisdictions (Texas and others).  
   - With Privacy/Legal, decide on any breach notifications or contractual notices and whether the issue could support a TDPSA enforcement theory (e.g., repeated misuse of geolocation or opt‑outs).[web:81][web:86][web:91][web:96][web:97]

5. **Notify & Remediate**  
   - If required, coordinate notifications to affected customers and regulators under applicable breach laws.  
   - Document remediation steps: code/config changes, process improvements, training.

6. **Review & Close**  
   - Post‑incident review within 30 days of closure.  
   - Capture lessons learned and update controls where needed.

---

## 6. TDPSA-Specific Considerations

### 6.1 Cure Period Documentation

If LoneStar receives a notice of alleged TDPSA violation from the Texas AG:

- Security and Privacy will immediately open a dedicated incident ticket and assign ownership.  
- Within the 30‑day cure window, LoneStar will:  
  - Implement necessary fixes (e.g., clarifying privacy notice, correcting opt‑outs, improving geolocation handling).  
  - Document evidence of changes (screenshots, commit IDs, updated configs, training logs).  
  - Prepare a written explanation of remediation steps for Legal to send to the AG.[web:81][web:86][web:91][web:96][web:97][web:31]

This package is stored in a dedicated “TDPSA – Cure Documentation” folder.

### 6.2 Priority Risk Areas for LoneStar Connect

- **Online tracking & ads:** ensure opt‑outs are respected for Texas consumers and that choices are logged (linked to TDPSA DPAs and opt‑out plan).  
- **Location data:** restrict use of precise location to core features; keep it out of marketing/ad funnels.  
- **High‑volume consumer endpoints:** focus extra monitoring on public APIs and auth flows where attacks are more likely.[web:78][web:79][web:95][web:97][web:98][web:31][web:89]

---

## 7. Incident Register

LoneStar’s Incident Register (Excel + Jira) includes:

- Incident ID, dates, systems, and severity.  
- Whether Texas consumers are impacted and approximate count.  
- TDPSA relevance (Y/N and notes).  
- Containment, eradication, remediation steps.  
- Whether cure documentation exists and where it is stored.

Example entry:

| ID | Date Opened | Summary | TX Data? | Severity | TDPSA-Relevant? | Status |
|----|-------------|---------|---------|----------|------------------|--------|
| INC‑2025‑07 | 2025‑07‑14 | TX users continued receiving targeted ads after opt‑out due to CMP mis‑config. | Yes | Medium | Yes – sale/ads opt‑out failure | Closed |

---

## 8. Training and Awareness

- Security awareness training for all staff annually, including phishing, password hygiene, and incident reporting.  
- Specialized incident‑response training for Security, Privacy, and Support teams at least once per year.  
- Playbooks and contact charts accessible in the internal wiki; quick‑reference one‑pager for “What to do if you think something is wrong.”[web:81][web:86][web:91][web:96]

---

## 9. Review and Updates

- Security team reviews this baseline each January alongside broader security program reviews.  
- Any major incident or material TDPSA enforcement development triggers an interim review.

Version history:

- Version 1.0 – January 31, 2026 – Initial TDPSA security & incident-response baseline adopted.

---

**End of Example**
