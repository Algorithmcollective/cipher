# Texas TDPSA – Opt-Out & Consent Implementation Plan – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Opt-Out & Consent Implementation Plan (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## 1. Purpose

This plan explains how LoneStar Connect implements and honors TDPSA opt‑out rights for targeted advertising and any “sale” of personal data, and how it manages consent for precise geolocation in its mobile apps.[web:81][web:86][web:91][web:95][web:96][web:98]

---

## 2. Scope

Includes:

- Public marketing site: https://www.lonestarconnect.com  
- Web application: https://app.lonestarconnect.com  
- Mobile apps: iOS and Android LoneStar Connect apps  
- Key partners: Analytics Provider A, Ad Platforms B and C, consent management platform (CMP).[web:81][web:86][web:91][web:96]

---

## 3. Rights and Consent Types Covered

- TDPSA opt‑outs:  
  - Sale of personal data (where ad/measurement practices qualify).  
  - Targeted advertising.  
  - Profiling with legal/significant effects (not currently used).

- Sensitive data consent:  
  - Precise geolocation in mobile apps used to suggest nearby businesses and send location‑based reminders.[web:81][web:86][web:91]

---

## 4. Front-End Experience

### 4.1 Privacy Choices Page

- URL: https://privacy.lonestarconnect.com/choices  
- Links:  
  - Footer on all pages of main site and logged‑out web app.  
  - Section 8 of the updated privacy notice.

On this page, users can:

- Read a short explanation of “sale” and targeted advertising under Texas law.  
- Toggle “Do not sell or share my personal data” and “Opt out of targeted advertising.”  
- Follow links to browser/app‑level privacy tools.[web:81][web:86][web:91][web:96][web:98]

### 4.2 Cookie / Tracking Banner

- Tool: CMP integrated on LoneStarConnect.com and login pages.  
- For Texas IPs:  
  - Shows a banner on first visit explaining cookies and targeted ads in plain language.  
  - Provides “Accept All,” “Reject Non‑Essential,” and “Customize” options, with “Customize” linking to granular controls including targeted advertising.

### 4.3 App Settings

Mobile apps include a “Privacy & Location” screen:

- Toggles for:  
  - “Use my location to find nearby businesses.”  
  - “Use my data to personalize marketing (where applicable).”  
- Short text explaining how to change OS‑level location permissions.

---

## 5. Data Flow & Enforcement

### 5.1 Preference Storage

- Preferences stored in CMP database keyed to:  
  - Cookie ID, where no login.  
  - Account ID and email, where logged in.  
- Fields: `sale_opt_out`, `ads_opt_out`, `location_consent`, timestamp, source (web/app).[web:81][web:86][web:91][web:96]

### 5.2 Internal Systems

| System | Data Used | How Opt-Out is Applied |
|--------|----------|------------------------|
| CRM | Contact info, engagement | Contacts flagged with `TX_OPTOUT_SALE` / `TX_OPTOUT_ADS`; excluded from future targeted campaigns. |
| Email platform | Email lists, segments | Suppression lists used for TDPSA opt‑outs; no ad‑based enrichment for these users. |
| Data warehouse | Aggregated logs | Identifiers tied to opt‑outs marked; queries for marketing exclude them from ad export sets. |

### 5.3 Vendors / Ad & Analytics Partners

| Vendor | Role | Opt-Out Implementation |
|--------|------|------------------------|
| Analytics A | Processor analytics | Respects CMP consent state; analytics events suppressed or anonymized for users who reject non‑essential cookies. |
| Ad Platform B | Ads / remarketing | LoneStar maintains suppression audience for users who opted out; CMP passes consent string to tag so B does not add them to targeted segments. |
| Ad Platform C | Look‑alike modeling | Contract updated to prohibit use of opted‑out users’ data for look‑alike audiences; suppression lists regularly synced. |

---

## 6. Sensitive Data Consent – Precise Geolocation

- Trigger: When users first access features that use location (e.g., “Find providers near me”).  
- Flow:  
  1. In‑app explanation (“We use your precise location to suggest nearby businesses and reminders; you can turn this off at any time”).  
  2. OS‑level permission prompt.  
  3. If accepted, app sets `location_consent=true` and begins location use; if denied, feature is disabled.[web:81][web:86][web:91]

- Revocation:  
  - Users can disable location in app settings or via OS settings; app listens for revocation and stops requesting/processing location.

LoneStar does **not** share precise location with ad platforms; these data are only used for core service features.

---

## 7. Handling Opt-Out Requests

### 7.1 Intake

- Web choices page writes directly into CMP and triggers downstream sync tasks.  
- Rights requests (from TDPSA Deliverable 2) that include “Do not sell” and “Do not target ads” flags are added into the same preference store.

### 7.2 Timelines

- Internal target: apply opt‑outs to internal systems and major ad partners within 7–10 business days.  
- Nightly jobs update CRM and email suppression lists; weekly jobs sync audiences to ad platforms.

Notes:

> LoneStar documents this timeline in internal SOPs to show reasonable efforts under TDPSA, even though the statute doesn’t prescribe an exact technical window.[web:81][web:86][web:91][web:96]

---

## 8. Testing and Monitoring

LoneStar performs:

- Quarterly tests where privacy team members:  
  - Submit opt‑outs and verify removal from marketing and ad audiences (test accounts).  
  - Confirm CMP flags are respected by analytics/ad tags using browser dev tools and vendor dashboards.  
- Annual review of vendor documentation and contracts to confirm continued support for opt‑out honoring.

Issues are logged in the privacy team’s issue tracker for remediation.[web:81][web:86][web:91][web:96][web:98]

---

## 9. Recordkeeping

LoneStar maintains:

- Screenshots of choices page, cookie banner, and app privacy settings.  
- Exported logs from CMP showing sample opt‑out events and application timestamps.  
- Documentation of suppression list logic for each ad platform.  
- Copies of updated vendor contracts or addenda that reference TDPSA‑style choices.

These are stored in the AI & Privacy Governance SharePoint under “TDPSA – Opt‑Out & Consent.”[web:49][web:81][web:86][web:91][web:96]

---

## 10. Review and Updates

- This plan is reviewed every January along with TDPSA privacy notice and rights workflow.  
- Any major changes to ad tech stack, new sensitive‑data features, or TDPSA enforcement guidance will trigger an interim review.

Version history:

- Version 1.0 – January 31, 2026 – Initial TDPSA opt‑out & consent plan adopted.

---

**End of Example**
