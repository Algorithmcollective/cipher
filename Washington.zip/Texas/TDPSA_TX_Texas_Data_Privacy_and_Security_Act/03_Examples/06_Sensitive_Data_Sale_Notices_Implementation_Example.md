# Texas TDPSA – Sensitive Data & Sale Notices + Implementation Checklist – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:92][web:94]  
**Document Type:** Statutory Sale Notices & Website/App Implementation Checklist (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## 1. Purpose

This document shows how LoneStar Connect, Inc. (“LoneStar Connect”) evaluates whether TDPSA sale notices are required and, if so, how it would deploy and document them on its website and apps.[web:92][web:93][web:143][web:145][web:148][web:151][web:155][web:157]

---

## 2. Statutory Notice Blocks

TDPSA requires the following language if a controller sells sensitive or biometric personal data:[web:92][web:93][web:148][web:152][web:154][web:155][web:156][web:158][web:99]

- Sensitive data sale notice:  
  > **NOTICE: We may sell your sensitive personal data.**

- Biometric data sale notice:  
  > **NOTICE: We may sell your biometric personal data.**

These would be posted in the same location and manner as the privacy‑policy link if LoneStar Connect is determined to be selling those categories.

---

## 3. LoneStar Connect’s Sale Assessment

After reviewing its practices:

- LoneStar Connect **does not sell biometric personal data**; it collects limited precise geolocation and device data, but no biometric identifiers for unique identification.  
- LoneStar Connect **may be considered to “sell” certain sensitive personal data** (e.g., precise geolocation and health‑related appointment metadata) when it shares that data with certain ad/analytics partners for cross‑site tracking or targeted advertising in exchange for value.[web:92][web:93][web:143][web:145][web:151][web:155][web:156][web:157][web:160]

Current stance:

> LoneStar Connect has taken a conservative position that it **treats some use of sensitive personal data in targeted advertising ecosystems as a “sale” under TDPSA** and is preparing to deploy the sensitive‑data sale notice along with strengthened opt‑out options.

Biometric sale notice: **not currently needed**, but the template is retained for future use.

---

## 4. Website / App Placement Plan

### 4.1 Main Marketing Site – www.lonestarconnect.com

- Privacy‑policy link: Footer on every page (“Privacy Policy”).  
- Implementation:  
  - Add the sensitive‑data sale notice directly under the footer privacy‑policy link on desktop and mobile views.  
  - Example footer snippet:

    > Privacy Policy \| Terms of Service  
    >  
    > **NOTICE: We may sell your sensitive personal data.**

### 4.2 Web App – app.lonestarconnect.com

- Privacy‑policy link: “Privacy & Terms” in account settings and on sign‑up screen.  
- Implementation:  
  - On sign‑up page, show the sensitive‑data sale notice immediately below the text referencing the privacy policy.  
  - In the “Privacy & Terms” settings page, display the same notice near the privacy‑policy link.

### 4.3 Mobile Apps (iOS/Android)

- Privacy‑policy link: “Legal & Privacy” section in the Settings menu.  
- Implementation:  
  - Inside “Legal & Privacy,” show the sensitive‑data sale notice just below the privacy‑policy link so it is visible on the same scroll without clicking through.

LoneStar Connect will **not** display the biometric‑data notice unless it later introduces biometric features.

---

## 5. Integration With Privacy Policy and Consent

LoneStar Connect’s updated TDPSA privacy notice (Deliverable 2) will be adjusted to:

- State that certain categories of sensitive data (e.g., precise location and limited health‑adjacent appointment information) may be sold for targeted advertising and analytics.  
- Repeat the statutory sentence “NOTICE: We may sell your sensitive personal data” in the relevant section and point to opt‑out instructions.[web:92][web:93][web:145][web:148][web:151][web:155][web:157][web:160]

Consent and preference flows:

- The cookie/consent banner and privacy choices page (Deliverable 4) will explicitly mention that turning off “sale/targeted advertising” stops these sensitive‑data uses for TDPSA purposes.

---

## 6. Logging and Evidence

LoneStar Connect will document deployment of the sensitive‑data sale notice as follows:

| Date | Site / App | Page / Screen | Notice(s) Present | Evidence File | Reviewer |
|------|------------|---------------|-------------------|---------------|----------|
| 2026‑02‑15 | www.lonestarconnect.com | Global footer | Sensitive sale notice | `screenshots/2026-02-15_marketing_footer_sensitive_notice.png` | Privacy Lead |
| 2026‑02‑15 | app.lonestarconnect.com | Sign‑up page | Sensitive sale notice | `screenshots/2026-02-15_app_signup_sensitive_notice.png` | Privacy Lead |
| 2026‑02‑15 | iOS app | Settings → Legal & Privacy | Sensitive sale notice | `screenshots/2026-02-15_ios_privacy_sensitive_notice.png` | Mobile PM |

Evidence includes PDF captures and a short QA checklist confirming the notice appears on desktop and mobile and for Texas IP ranges where geolocation‑based content is used.[web:92][web:93][web:148][web:150][web:151][web:155][web:157][web:160]

---

## 7. Governance and Review

- Owner: Privacy Lead (Jordan Blake) in partnership with Marketing and Product.  
- Review triggers:  
  - Annual TDPSA review.  
  - Any change in how sensitive data is used or shared with third parties.  
  - Introduction of biometric features that might require the biometric‑sale notice.

Version history:

- Version 1.0 – January 31, 2026 – Sensitive‑data sale notice adopted; biometric‑sale notice template retained for future use.

---

**End of Example**
