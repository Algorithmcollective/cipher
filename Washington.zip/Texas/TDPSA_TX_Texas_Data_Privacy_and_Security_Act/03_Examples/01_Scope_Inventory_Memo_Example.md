# Texas TDPSA – Scope & Data Processing Inventory Memo – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Scope & Data Processing Inventory (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## 1. Purpose of This Memo

This memo evaluates how TDPSA applies to LoneStar Connect, Inc. (“LoneStar Connect”), a Texas‑based SaaS platform that provides scheduling and communication tools to small businesses and their customers. It maps key processing activities involving Texas consumers’ personal data and highlights priority areas for TDPSA compliance work.[web:81][web:86][web:91][web:98]

---

## 2. Overview of TDPSA (Plain Language)

TDPSA applies to many consumer‑facing businesses that conduct business in Texas and process personal data of Texas residents.[web:81][web:86][web:91] LoneStar Connect:

- Is headquartered in Austin, Texas.  
- Offers an online platform to small businesses across the U.S., with a large Texas customer base.  
- Processes personal data (names, contact details, usage data, limited location data) of both business users and end‑customers.

TDPSA defines LoneStar Connect as a **controller** for data collected directly through its website, apps, and services, and as a **processor** for some white‑label services provided to business customers.[web:92][web:94][web:96]

The Texas Attorney General can enforce TDPSA with penalties up to 7,500 dollars per violation, after a 30‑day cure period, and has already brought early enforcement actions around notice, sale, and geolocation data practices.[web:25][web:77][web:81][web:95][web:97]

---

## 3. TDPSA Applicability to LoneStar Connect

### 3.1 Business Presence and Activities

- Conducts business in Texas: **Yes** (Texas HQ, Texas sales).  
- Offers products/services to Texas residents: **Yes** (many Texas SMB customers and their end‑customers).  
- Estimated percentage of total end‑users who are Texas residents: approx. **35–40 percent**.

### 3.2 Role as Controller and Processor

- Controller:  
  - Direct sign‑ups for the LoneStar Connect platform.  
  - Marketing site visitors and app users.  
  - Product analytics and service improvements.  

- Processor:  
  - Some enterprise/white‑label deployments where business clients configure flows and collect customer details through LoneStar Connect infrastructure.

Summary:

> LoneStar Connect is primarily a controller under TDPSA, but must also manage processor obligations for certain B2B services.[web:92][web:94][web:96]

### 3.3 Exemptions

LoneStar Connect is not a GLBA financial institution or HIPAA‑covered entity. No broad entity‑level exemptions appear to apply.[web:81][web:86][web:91]

---

## 4. Data Processing Inventory – High-Level Map

### 4.1 Key Systems and Activities

| ID | System / Activity | Description | Personal Data Types | Texas Consumers Involved? |
|----|-------------------|-------------|---------------------|---------------------------|
| P‑01 | Marketing website & tracking | LoneStarConnect.com, analytics, cookies, pixels. | IP address, device IDs, browsing behavior, referrer, approximate location. | Yes (site accessible globally; significant Texas traffic). |
| P‑02 | Core SaaS platform | Scheduling and messaging between SMBs and their customers. | Names, emails, phone numbers, appointment details, limited free‑text notes. | Yes (Texas SMBs and Texas end‑customers). |
| P‑03 | Mobile apps | iOS/Android apps for SMBs and their customers. | Account credentials, device identifiers, push tokens, app usage metrics. | Yes. |
| P‑04 | Marketing email platform | Email campaigns and onboarding sequences. | Names, emails, engagement metrics (opens, clicks), segment data. | Yes. |
| P‑05 | Support system | Ticketing and chat for customer support. | Names, emails, message content; occasional attachments. | Yes. |

---

## 5. Sensitive Personal Data

LoneStar Connect processes limited categories that may qualify as **sensitive personal data** under TDPSA.[web:81][web:86][web:91]

| ID | System / Activity | Sensitive Data Category | Purpose | Consent Obtained? |
|----|-------------------|-------------------------|---------|-------------------|
| S‑01 | Mobile apps location services | Precise geolocation (approx. within 10–50 meters) when users enable location‑based reminders. | Improve appointment reminders and show nearest provider locations. | Yes – OS‑level permission; privacy notice currently mentions “location” but may need strengthening. |
| S‑02 | Free‑text notes in core platform | Potential health or other sensitive info typed by SMB users about their customers. | Not intended; may appear incidentally in notes. | No explicit additional consent; addressed via terms and guidance to customers. |

---

## 6. Data Uses: Sale, Targeted Advertising, and Profiling

### 6.1 Sale of Personal Data

- LoneStar Connect does **not** currently sell personal data in the traditional sense.  
- However, its use of third‑party ad/analytics tags and sharing of certain identifiers for cross‑site measurement may raise questions under TDPSA’s broad definition of “sale” if value is exchanged.[web:81][web:86][web:91][web:96][web:98]

Description:

> Limited sharing of pseudonymous identifiers and browsing behavior with major ad/analytics platforms for measurement and remarketing. Need to analyze against TDPSA “sale” definition, document position, and potentially treat as sale with clear opt‑outs.

### 6.2 Targeted Advertising

- LoneStar Connect runs targeted advertising campaigns using ad platforms that build audiences based on user interactions across sites and services.  
- This likely qualifies as targeted advertising under TDPSA.

Description:

> TDPSA‑level disclosures and opt‑out mechanisms are needed for Texas consumers, including clear explanations of targeted advertising and simple ways to opt out.[web:81][web:86][web:91][web:95][web:98]

### 6.3 Profiling in Furtherance of Decisions

- LoneStar Connect does basic segmentation for marketing (e.g., role, company size, usage).  
- It does **not** currently use automated profiling to deny service or set materially different prices for consumers.

Description:

> Current profiling appears limited to low‑risk marketing segmentation, but should still be documented and revisited if pricing or eligibility decisions become more automated.[web:81][web:86][web:94]

---

## 7. Consumer Rights Readiness Snapshot

| Right | Current Capability | Notes |
|-------|--------------------|-------|
| Access | Partial | Users can access much of their data in account settings; no dedicated TDPSA request workflow yet. |
| Correction | Partial | Users can edit profiles; some data (logs) not editable but could be annotated. |
| Deletion | Partial | Accounts can be closed on request; back‑end processes for full deletion still being standardized. |
| Portability | No | No structured export for all personal data yet; only limited data can be downloaded. |
| Opt‑out of sale | No / Unclear | No explicit “Do Not Sell or Share” mechanism; relies on generic cookie banner and ad‑platform controls. |
| Opt‑out of targeted ads | Partial | Cookie banner exists; no clear TDPSA‑style description or specific Texas‑focused opt‑out page. |
| Opt‑out of profiling | Not applicable / No | No current automated eligibility/profiling, but future uses need tracking.[web:81][web:86][web:91][web:96][web:98] |

---

## 8. High-Risk Processing and Data Protection Assessments

Candidate activities for TDPSA **data protection assessments**:

| ID | Activity | Risk Type | Assessment Needed? |
|----|----------|----------|--------------------|
| A‑01 | Use of third‑party tracking and ad tech for targeted advertising on marketing site and apps. | Targeted advertising, potential sale | Yes |
| A‑02 | Processing of precise geolocation in mobile apps when enabled by users. | Sensitive personal data | Yes |
| A‑03 | Any future automated scoring/profiling for significant decisions (if introduced). | Profiling with significant effects | To be determined |[web:86][web:91][web:94][web:96][web:98] |

---

## 9. Enforcement and Exposure Snapshot

Relevant factors:

- LoneStar Connect uses online tracking and limited geolocation – two areas where the Texas AG has already signaled enforcement interest under TDPSA (location data, online tracking, unclear opt‑outs).[web:78][web:79][web:95][web:97][web:98]  
- Privacy policy currently does not explicitly describe any “sale” of data or targeted advertising practices, and does not provide a clear TDPSA‑style opt‑out mechanism.  
- No known Texas AG investigations to date; a small number of consumer privacy complaints have been handled informally.

Summary:

> LoneStar Connect has moderate TDPSA exposure due to online tracking, geolocation features, and marketing uses of data. Priority should be to modernize the privacy notice, rights handling, and targeted‑ads/sale opt‑outs to align with TDPSA and reduce enforcement risk, especially given the AG’s early lawsuits around TDPSA notice and geolocation practices.[web:25][web:77][web:81][web:95][web:97][web:98][web:31]

---

## 10. Recommended Next Steps (High Level)

1. Confirm TDPSA applicability and any narrow exemptions with privacy counsel.  
2. Draft and publish an updated privacy notice that meets TDPSA requirements, including:  
   - Categories of personal and sensitive data.  
   - Purposes, sharing, and sale/targeted advertising disclosures.  
   - Consumer rights and appeal instructions.[web:81][web:91][web:93][web:96]  
3. Design a TDPSA‑compliant consumer rights and appeals workflow (requests, verification, timelines, cure documentation).  
4. Implement clear opt‑outs for targeted advertising and any activities considered “sale,” with Texas‑appropriate wording.  
5. Plan and initiate TDPSA Data Protection Assessments for A‑01 and A‑02.

Owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| Update TDPSA privacy notice | Privacy + Legal | April 30, 2026 |
| Implement rights & opt‑out workflow | Product + Engineering | June 30, 2026 |
| Complete first TDPSA assessments (A‑01, A‑02) | Privacy + Security | July 31, 2026 |

---

**End of Example**
