# Texas TDPSA – Data Protection Assessment – Targeted Advertising & Tracking – LoneStar Connect, Inc.

**Law:** Texas Data Privacy and Security Act (TDPSA), Tex. Bus. & Com. Code § 541.001 et seq.[web:94]  
**Document Type:** Data Protection Assessment (Example)  
**Organization:** LoneStar Connect, Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Blake, Privacy Lead  

---

## 1. Purpose of This Assessment

This assessment evaluates LoneStar Connect’s use of third‑party analytics and advertising technologies on its website and mobile apps in light of TDPSA requirements for targeted advertising, potential “sale” of personal data, and sensitive data (precise geolocation).[web:81][web:86][web:91][web:95][web:96][web:98]

---

## 2. Processing Activity Overview

### 2.1 Basic Information

- **Assessment ID:** TDPSA‑DPA‑001  
- **Processing activity name:** Website & App Tracking for Analytics and Targeted Advertising.  
- **Business owner:** Head of Marketing.  
- **Technical owner:** Director of Engineering.

### 2.2 Description of Processing

> LoneStar Connect uses cookies, pixels, SDKs, and similar technologies on its marketing website and mobile apps to:  
> - Measure visits and usage patterns.  
> - Run remarketing and look‑alike campaigns via third‑party ad platforms.  
> - Attribute sign‑ups to marketing channels.

### 2.3 Purposes

- Understand site/app performance and user engagement.  
- Improve marketing efficiency and reduce acquisition costs.  
- Reach likely interested users with ads and measure campaign results.[web:81][web:86][web:91][web:96][web:98]

---

## 3. Personal Data Involved

### 3.1 Categories of Personal Data

- Identifiers: IP address, user IDs, cookie IDs, mobile ad IDs.  
- Internet/device data: pages viewed, time on page, click events, app screens, referrer, browser/device details.  
- Geolocation: approximate geolocation (from IP); precise location when mobile users enable location features.  
- Commercial data: conversions (sign‑ups, upgrades) linked to tracking IDs.

### 3.2 Sensitive Personal Data

Yes – **potential sensitive data** is involved when:

- Mobile apps collect **precise geolocation** (within tens of meters) for location‑based reminders and nearby business suggestions.

Sensitive data description:

> Precise location is collected only when users enable OS‑level permissions. This data is used to show relevant nearby businesses and improve reminder accuracy.

Consent / notice:

> Users grant location permission via device prompts; the privacy notice references “location data” but is being updated to more clearly identify it as sensitive under TDPSA and to describe its uses.[web:81][web:86][web:91]

---

## 4. Data Flows and Recipients

### 4.1 Data Sources

- LoneStarConnect.com website (marketing).  
- Web app dashboard (logged‑in business users).  
- iOS and Android mobile apps.

### 4.2 Recipients / Third Parties

| Recipient | Role | Purpose |
|----------|------|---------|
| Major analytics provider A | Processor | Site/app analytics and performance metrics. |
| Major ad platform B | Third‑party ad partner | Remarketing and campaign measurement. |
| Ad platform C | Third‑party ad partner | Audience building and look‑alike models. |

“Sale” analysis:

> Data sharing with analytics provider A appears to be processing on LoneStar’s behalf (processor). Data sharing with ad platforms B and C for remarketing and look‑alike audiences may be considered a “sale” or part of targeted advertising under TDPSA, particularly where LoneStar benefits economically from broader reach.[web:81][web:86][web:91][web:95][web:96][web:98]

---

## 5. Legal Basis and TDPSA Triggers

### 5.1 TDPSA Risk Category

- ☒ Targeted advertising.  
- ☒ Potential sale of personal data.  
- ☒ Processing of sensitive personal data (precise geolocation).  
- ☐ Profiling with legal/significant effects (not currently – no automated eligibility/pricing decisions).[web:81][web:86][web:91][web:94][web:96][web:98]

### 5.2 Other Laws / Obligations

- Need to coordinate with other state privacy laws (e.g., CCPA/CPRA, VCDPA) for harmonized notices and opt‑outs.  
- Existing internal policies on cookie tracking and security.

---

## 6. Benefits and Necessity

### 6.1 Benefits

- To LoneStar Connect:  
  - Better understanding of which channels and campaigns drive sign‑ups.  
  - More efficient marketing spend.  
- To consumers:  
  - Fewer irrelevant ads; improved app performance via analytics insights.

### 6.2 Necessity and Proportionality

> Tracking for analytics and targeted ads is helpful but not strictly “necessary” for core service delivery. LoneStar Connect decided to keep it but to:  
> - Limit retention of granular identifiers.  
> - Provide clear TDPSA disclosures and opt‑outs.  
> - Avoid combining tracking data with highly sensitive categories beyond what is needed for marketing.[web:81][web:86][web:91][web:96]

---

## 7. Risks to Consumers

Key risks:

- Unwanted cross‑site tracking or perception of surveillance.  
- Use of precise geolocation for marketing may be perceived as intrusive.  
- Potential for data misuse or improper combination by ad partners.  
- Regulatory enforcement risk if notices and opt‑outs are not clear or not honored, especially around location data and online tracking (identified TDPSA enforcement themes).[web:78][web:79][web:95][web:97][web:98]

Risk table:

| Risk | Level | Notes |
|------|-------|-------|
| Lack of clarity about targeted ads and “sale” | Medium | Existing notice is generic and does not use TDPSA language. |
| Location‑based marketing seen as intrusive | Medium / High | Sensitive category with growing regulatory scrutiny. |
| Misconfigured opt‑outs | Medium | Current cookie banner may not cover all ad tech integrations. |

---

## 8. Safeguards and Mitigations

Existing / planned controls:

- **Transparency:**  
  - Update privacy notice to explicitly describe targeted advertising, sale, and location data practices.  
  - Add a Texas‑friendly privacy choices page with clear explanations and links.

- **Choice and control:**  
  - Implement a dedicated “Do Not Sell or Share / Targeted Advertising Opt‑Out” page for Texas and other relevant users.  
  - Enhance cookie banner to allow more granular choices and align with TDPSA language.[web:81][web:86][web:95][web:96][web:98]

- **Sensitive data:**  
  - Restrict precise location use to necessary features only; do not share precise location with ad partners.  
  - Highlight location usage in in‑app notices and allow easy disabling via app settings.

- **Vendor controls:**  
  - Update contracts with ad platforms to clarify roles, honor opt‑outs, and limit use of data for independent purposes.  
  - Ensure tags/SDKs respect user choices (via consent management platform configuration).[web:81][web:86][web:91][web:96][web:98]

- **Security and retention:**  
  - Limit retention of granular identifiers in logs and derived data.  
  - Apply encryption and strict access controls for tracking data.

---

## 9. Residual Risk and Decision

### 9.1 Residual Risk

- Residual risk level: ☒ Medium  

Rationale:

> Even with stronger notices, opt‑outs, and vendor controls, some risk remains due to the nature of cross‑site tracking and location data. However, with planned mitigations, risk is considered acceptable for LoneStar Connect’s risk appetite and consistent with TDPSA expectations for documented assessments.[web:81][web:86][web:91][web:96][web:98][web:31]

### 9.2 Proceed / Modify / Do Not Proceed

- Recommended outcome: ☒ Proceed with conditions.

Conditions:

1. Launch updated TDPSA‑aligned privacy notice and privacy choices page before expanding campaigns further.  
2. Complete contract review and updates with key ad partners within 6 months.  
3. Confirm via testing that opt‑outs are applied correctly across all major ad/analytics tools.

Approvals:

- Business owner (Head of Marketing): Approved – Date: January 30, 2026  
- Privacy/Legal (Privacy Lead + Counsel): Approved with conditions – Date: January 31, 2026  

---

## 10. Review and Updates

- Next review scheduled: January 2027, or sooner if ad tech stack or TDPSA guidance changes significantly.  
- Any incidents or regulator inquiries related to targeted advertising will trigger an interim reassessment.

Version history:

- Version 1.0 – January 31, 2026 – Initial TDPSA DPA for targeted advertising and tracking.

---

**End of Example**
