# Law Profile

## Law Name
California AI Transparency Act (SB 942, as amended by AB 853)

## Citation
California Senate Bill 942 (2024)  
Amended by Assembly Bill 853 (2024)

## Status
Enacted

## Effective Dates

Core Requirements (Covered Providers):  
August 2, 2026  

Additional Requirements (Large Online Platforms & Hosting Platforms):  
January 1, 2027  

Capture Device Manufacturer Requirements:  
January 1, 2028  

## Regulatory Scope

Applies to “covered providers” of generative AI systems that:

- Are publicly accessible in California
- Have 1,000,000+ monthly users or visitors
- Generate synthetic content (text, images, audio, video)

Expanded scope under AB 853 includes:

- Large online platforms (2M+ monthly users)
- Generative AI hosting platforms
- Certain capture device manufacturers (phased timeline)

Excludes:

- Non-user-generated video games
- Film/television streaming content not user-generated
- Systems not publicly accessible

## Core Obligations

Covered providers must:

- Offer a free, publicly accessible AI detection tool
- Provide users the option for manifest (visible) disclosure
- Embed latent disclosure (watermark/metadata) in generated content
- Require licensees to preserve disclosures via contract
- Revoke licenses within 96 hours for non-compliant licensees
- Maintain monitoring and compliance oversight

## Enforcement Authority

California Attorney General  
Local prosecutors (city attorneys, county counsel)

## Penalties

Civil penalties up to $5,000 per violation, per day  

Each day of non-compliance constitutes a separate violation.

## Private Right of Action

No

## Tier Classification

Tier 1 – Flagship AI Transparency Law

## Revenue Priority

High

## Target Industries

- Generative AI providers with large public user bases
- AI image/video/audio generation platforms
- Foundation model deployers offering public-facing tools
- Large online platforms integrating GenAI
- AI hosting platforms distributing model weights

Generally does NOT apply to:

- Small private AI deployments
- Internal enterprise-only AI tools
- Low-user-count niche platforms

## Strategic Positioning

This law establishes California as the leading state in AI content transparency regulation.

It creates operational obligations around detection tooling, watermarking standards, licensing controls, and enforcement procedures.

Strong positioning for organizations deploying consumer-facing generative AI at scale.

## Internal Notes

Primary compliance focus areas:

1. Covered Provider Applicability Analysis
2. GenAI System Inventory & User Threshold Tracking
3. Detection Tool Requirements & Design
4. Manifest & Latent Disclosure Standards
5. Licensee Contract Controls
6. 96-Hour Revocation Runbook
7. Compliance Monitoring & Enforcement Defense File

High regulatory exposure due to per-day penalty structure.