# California AI Transparency Act Scope & Applicability Memo

**Report Title:** California AI Transparency Act Scope & Applicability Memo for BrightPixel Labs, Inc.  
**Prepared For (Client):** BrightPixel Labs, Inc.  
**Prepared By:** Ben Smith, Algorithm Collective LLC  
**Date of Analysis:** January 31, 2026  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> **Purpose:** This memo documents whether BrightPixel Labs, Inc. qualifies as a “covered provider” under the California AI Transparency Act and identifies which generative AI (GenAI) systems are in scope for compliance.

---

## 1. Executive Summary

### 1.1 Conclusion

- Based on current information, **BrightPixel Labs, Inc. is a covered provider** under the California AI Transparency Act as of January 31, 2026.  
- Its flagship consumer image‑generation platform, **BrightArt**, is in scope. Its enterprise‑only document summarization API, **BrightDocs**, is currently out of scope due to limited California reach.

### 1.2 Key Factors Considered

- BrightPixel creates and operates its own generative image model used in the BrightArt web and mobile apps.  
- BrightArt is publicly available to consumers in California with no geo‑blocking.  
- BrightArt has approximately 8.5M global monthly active users (MAU), with an estimated 1.4M MAU located in California, above the 1M threshold.

### 1.3 Recommended Next Steps

- Implement manifest (visible) and latent (technical) AI disclosures for all BrightArt image outputs.  
- Design and deploy a free public detection tool that lets users confirm whether an image was generated or modified by BrightArt.  
- Roll out a monitoring program for BrightDocs in case usage expands materially in California.

---

## 2. Client Profile

### 2.1 Business Overview

- BrightPixel Labs, Inc. is a San‑Francisco–based AI company offering consumer and enterprise generative AI products.  
- Primary revenue comes from subscription access to creative tools (BrightArt) and usage‑based fees for API access (BrightDocs).

### 2.2 Generative AI Offerings

- **BrightArt** – Web and mobile app that generates and edits images from text prompts. Users can download, share, and post images to social media.  
- **BrightDocs** – API service that summarizes long‑form documents and emails for enterprise customers.

- Primary user base:
  - BrightArt: global consumer market, heavy US and EU presence.  
  - BrightDocs: mid‑market and enterprise customers (B2B).

- Access channels:
  - BrightArt: public website and iOS/Android apps.  
  - BrightDocs: authenticated REST API; not directly accessible to the general public.

---

## 3. Covered Provider Test

> **Objective:** Assess whether BrightPixel Labs, Inc. meets the statutory definition of a “covered provider” under the California AI Transparency Act.

### 3.1 Creates / Codes / Produces Generative AI

- BrightPixel develops and maintains its own proprietary image‑generation model powering BrightArt.  
- The company also maintains a proprietary text‑summarization model for BrightDocs, fine‑tuned on internal data.  
- Both models produce novel content (images or summaries) in response to user prompts.

**Assessment:** BrightPixel clearly “creates, codes, or produces” generative AI systems.

### 3.2 Public Availability in California

- BrightArt is accessible worldwide via **brightart.ai** and via mobile apps listed in the US Apple App Store and Google Play Store; no geo‑blocking is applied to California IP addresses.  
- BrightDocs is only accessible via API keys issued to contracted enterprise customers; there is no general public interface, and usage is currently limited to fewer than 20 California‑based client organizations.

**Assessment:** BrightArt is publicly available to users in California. BrightDocs is not broadly “publicly available” but still contributes to overall GenAI activity.

### 3.3 User Scale – Estimated Monthly Active Users in California

- Data sources:
  - Product analytics dashboard (Mixpanel)  
  - Mobile app store analytics  
  - Internal data warehouse, filtered by approximate California geolocation

**Summary Table:**

| System Name | Description                          | Global MAU | Est. CA MAU | Est. % CA Users | Notes on Estimation                            |
|------------|--------------------------------------|-----------:|------------:|----------------:|-----------------------------------------------|
| BrightArt  | Consumer image generation/edit app   | 8,500,000  | 1,400,000   | 16%             | Based on IP geolocation + billing ZIP codes   |
| BrightDocs | Enterprise document summarization API|   120,000  |    35,000   | 29%             | Based on org billing addresses and API usage  |

**Assessment:** BrightArt exceeds the 1M MAU threshold in California and is therefore in scope. BrightDocs does not currently meet the 1M CA MAU threshold.

### 3.4 Overall Covered Provider Determination

- BrightPixel:
  - Produces generative AI systems (BrightArt and BrightDocs).  
  - Makes at least one system (BrightArt) publicly available in California.  
  - Exceeds the 1M California MAU threshold for BrightArt.

**Conclusion:** BrightPixel Labs, Inc. is a covered provider as of January 31, 2026. BrightArt is an in‑scope system; BrightDocs is currently out of scope but should be monitored.

---

## 4. System‑Level Scope Analysis

> **Objective:** Identify which specific GenAI systems are in scope for California AI Transparency Act obligations.

### 4.1 In‑Scope Systems Table

| System Name | Description                        | Channel (Web/App/API) | Content Types (Text/Image/Video/Audio) | Est. CA MAU | In Scope? (Y/N) | Rationale                                                                 |
|------------|------------------------------------|------------------------|-----------------------------------------|------------:|-----------------|---------------------------------------------------------------------------|
| BrightArt  | Consumer image generation/edit app | Web, iOS, Android      | Images                                  | 1,400,000   | Y               | Proprietary GenAI image model, publicly available in CA, >1M CA MAU      |
| BrightDocs | Document summarization API         | API (B2B only)         | Text summaries                          |   35,000    | N               | Enterprise API only, limited org footprint, below 1M CA MAU              |

### 4.2 Out‑of‑Scope Systems

- **BrightDocs** – Currently treated as out of scope due to:
  - Limited number of California enterprise customers.  
  - No public consumer‑facing interface.  
  - Total estimated CA MAU significantly below the 1M threshold.

**Out‑of‑Scope List:**

- BrightDocs – Enterprise‑only summarization API; monitor for future growth.  

---

## 5. Monitoring & Trigger Plan

> **Objective:** Establish how BrightPixel Labs, Inc. will monitor growth and re‑evaluate scope over time.

### 5.1 Metrics to Monitor

- Monthly active users in California for BrightArt and BrightDocs.  
- Volume of BrightArt‑generated images downloaded or shared externally.  
- Adoption of BrightDocs among California‑based customers and end users.

### 5.2 Thresholds & Triggers

- **BrightDocs trigger:** Re‑evaluate scope if estimated CA MAU for BrightDocs exceeds **500,000** users or if a public web/mobile interface is launched.  
- **New products:** Any new GenAI product made publicly available in California triggers a fresh scope assessment prior to or within 30 days of launch.

### 5.3 Roles and Responsibilities

- **Data/Analytics Owner:** Jane Kim, Director of Analytics – produces monthly CA MAU reports.  
- **Product Owners:**  
  - BrightArt – Alex Rivera, VP Product  
  - BrightDocs – Priya Patel, Director of Product  
- **Legal/Compliance Contact:** Maria Lopez, General Counsel – coordinates quarterly re‑assessments and sign‑off.

### 5.4 Re‑Assessment Cadence

- Quarterly re‑assessment of covered provider status and system scope.  
- Ad‑hoc reassessment whenever a major product change or launch occurs that impacts California users.

---

## 6. Recommendations & Next Steps

### 6.1 If BrightPixel Is a Covered Provider (Current Status)

- Begin implementation for BrightArt:
  - Build and deploy a public detection tool for BrightArt‑generated images.  
  - Implement manifest labels and latent watermarks on BrightArt outputs.  
  - Develop partner/licensee controls for any third‑party hosting or integrations.  
- Document governance:
  - Create a California AI Transparency Policy.  
  - Establish a cross‑functional AI Transparency Working Group.

### 6.2 Monitoring for BrightDocs and Future Offerings

- Maintain this memo as formal evidence of scope analysis.  
- Track BrightDocs usage growth and interface changes.  
- Re‑evaluate BrightDocs and any new GenAI products as they approach material California scale.

---

**End of Memo**
