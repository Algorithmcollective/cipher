# California AI Transparency Worksheet

---

## Scope Determination

Business Overview:
GenAI Products:
Build/Fine-Tune/Embed:
Public Availability:
Channels:
Global MAU:
CA MAU:
MAU Data Source:
Geo-Blocking:

---

## System Scope

System Name:
Description:
Channel:
Content Types:
CA MAU:
In-Scope Rationale:
Out-of-Scope Systems:

---

## Inventory

Business Owner:
Technical Owner:
Use Case:
User Group:
External Surfaces:
Output Volume:

---

## Manifest Disclosure

Label Text:
Placement:
Trigger Conditions:
Edge Cases:
Owner:
Rollout Timeline:

---

## Latent Disclosure

Methods:
Standards:
Application Location:
Limitations:
Downstream Risks:
Mitigations:

---

## Detection Tool

Tool Name:
URL:
Supported Types:
Systems Covered:
Detection Approach:
Limitations:
Owner:
Update Triggers:

---

## Governance

Policy Owner:
Product Responsibilities:
Engineering Responsibilities:
Legal Oversight:
Review Cadence:
Metrics:

---

## Contracts

Partners:
Label Obligations:
Detection Cooperation:
Notification Rules:
Partner Risks:

---

## Training

Audiences:
Modules:
Runbooks:
Design Guidance:
Attendance Tracking:

---

## Risk / DPIA

Mislabeling Risks:
Provenance Failure Risks:
Likelihood/Impact:
Controls:
Residual Risk Owner:

---

## Enforcement & Response

Enforcement Scenarios:
Escalation Owners:
Penalty Exposure:
Mitigation Roadmap:
Partner Incident Triggers:
96-Hour Response Owner:

---

## TBD / Follow-Ups

Item:
Owner:
Notes: