# California AI Transparency Discovery Script (SB942 / AB853)

Purpose: Gather information required to prepare California AI Transparency documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Scope & Covered Provider Determination

Say:
“I need to determine whether your organization qualifies as a covered provider.”

Ask:

- Business overview
- Generative AI products/features
- Do you build models, fine-tune, or embed third-party GenAI
- Public availability in California
- Distribution channels
- Estimated MAU (global + California)
- Data sources for MAU estimates
- Any geo-blocking

---

## 🧾 Deliverable: System-Level Scope Analysis

Ask for each GenAI system:

- System name
- Description
- Channel (web/app/API)
- Content types generated (image/audio/video/text)
- Estimated CA MAU
- In-scope rationale
- Out-of-scope systems

---

## 🧾 Deliverable: AI System Inventory & Disclosure Controls

Ask:

- Business owner
- Technical owner
- Primary use case
- User group
- External surfaces where outputs appear
- Typical output volume

---

## 🧾 Deliverable: Manifest Disclosure Design (Visible Labels)

Ask:

- Label text
- Placement locations
- When labels trigger
- Edge cases (mixed content, thumbnails)
- Owner
- Rollout timeline

---

## 🧾 Deliverable: Latent Disclosure (Provenance)

Ask:

- Watermark/metadata methods
- Standards used
- Where markers applied
- Known limitations
- Downstream stripping risks
- Mitigation approach

---

## 🧾 Deliverable: Public Detection Tool

Ask:

- Tool name
- URL/access point
- Supported content types
- Systems covered
- Detection approach
- Reliability limitations
- Owner
- Update triggers

---

## 🧾 Deliverable: Policy & Governance

Ask:

- AI transparency policy owner
- Product responsibilities
- Engineering responsibilities
- Legal oversight
- Review cadence
- Metrics monitored

---

## 🧾 Deliverable: Contracts & Partner Controls

Ask:

- Partners displaying AI outputs
- License terms regarding labels
- Detection cooperation
- Notification obligations
- Known partner risks

---

## 🧾 Deliverable: Training & Implementation

Ask:

- Training audiences
- Modules delivered
- Engineering runbooks
- Product design guidance
- Attendance tracking

---

## 🧾 Deliverable: Risk & DPIA Add-On

Ask:

- Mislabeling scenarios
- Provenance failure risks
- Likelihood/impact ratings
- Controls in place
- Residual risk acceptance owner

---

## 🧾 Deliverable: Enforcement & Response

Ask:

- Enforcement scenarios considered
- Governance escalation owners
- Penalty exposure assumptions
- Mitigation roadmap
- Partner incident triggers
- 96-hour response owner

---

## ✅ Closing

Say:
“That gives us what we need to prepare your California AI Transparency documentation.”