# California AI Transparency Contract Addendum (MASTER TEMPLATE)

**Title:** California AI Transparency Contract Addendum  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Provider:** {{PROVIDER_LEGAL_NAME}} (“Provider”)  
**Customer / Partner:** {{COUNTERPARTY_LEGAL_NAME}} (“Company”)  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> **Purpose:** This Addendum supplements the underlying agreement between Provider and Company to address AI transparency, disclosure, and provenance obligations for generative AI services used or made available in California.[web:4][web:19]

---

## 1. Definitions

- **“AI Services”** means Provider’s generative AI systems and features made available to Company under the Agreement that are capable of generating or materially modifying image, audio, or video content.[web:4]  
- **“Covered Content”** means any image, audio, or video output generated or materially modified by the AI Services for or on behalf of Company that may be accessed by end users located in California.[web:4][web:19]  
- **“Covered Provider”** has the meaning given in the California AI Transparency Act and includes Provider to the extent it meets applicable thresholds.[web:4]  

---

## 2. Manifest and Latent Disclosures

2.1 **Provider Obligations.** Provider will implement and maintain:  
- Clear, conspicuous manifest disclosures indicating when Covered Content is AI‑generated or AI‑modified, in accordance with the California AI Transparency Act; and  
- Embedded, machine‑readable provenance or watermarking signals in Covered Content where technically feasible, designed to enable downstream detection of AI‑generated content.[web:4][web:19]  

2.2 **Company Obligations.** Where Company controls end‑user interfaces that display Covered Content, Company will not remove, obscure, or misrepresent required manifest disclosures provided by Provider and will implement reasonable UI placements consistent with Provider’s documentation.[web:4][web:19]  

---

## 3. Public Detection Tool

- To the extent required by law, Provider will make available a public mechanism (e.g., a web‑based verification tool or API) enabling third parties to test whether specified Covered Content was generated or modified by the AI Services, subject to reasonable technical and security limitations.[web:4][web:10][web:19]  
- Company will not interfere with or misrepresent the results of such detection mechanisms and will route relevant inquiries to Provider’s published verification channels where appropriate.  

---

## 4. Cooperation and Information Sharing

- Upon reasonable written request, and subject to confidentiality obligations, Provider will share with Company high‑level documentation describing:  
  - The types of manifest and latent disclosures implemented;  
  - Supported content formats; and  
  - Any known technical limitations that may affect persistence of disclosures (e.g., social media recompression).[web:4][web:19]  
- Company will promptly notify Provider if it becomes aware that Covered Content is being redistributed or displayed in ways that systematically strip or misrepresent disclosures.  

---

## 5. Compliance, Audit, and Updates

- Each party will use commercially reasonable efforts to comply with applicable AI transparency requirements in its respective role under the Agreement.[web:4][web:19]  
- Provider may update its disclosure implementations over time to align with changes in law, regulatory guidance, or industry standards, provided such changes do not materially reduce the level of transparency required under the California AI Transparency Act.[web:4][web:19]  
- If a change in law or guidance creates a material conflict with this Addendum, the parties will work in good faith to amend this Addendum as necessary.  

---

## 6. Order of Precedence

- In the event of a conflict between this Addendum and the underlying Agreement with respect to AI transparency, provenance, or disclosure obligations, this Addendum will control to the extent of the conflict.[web:4]  

---

**End of Addendum**
