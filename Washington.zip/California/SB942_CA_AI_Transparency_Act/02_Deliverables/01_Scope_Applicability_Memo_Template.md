# California AI Transparency Act Scope & Applicability Memo (MASTER TEMPLATE)

**Report Title:** California AI Transparency Act Scope & Applicability Memo for {{CLIENT_NAME}}  
**Prepared For (Client):** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date of Analysis:** {{REPORT_DATE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> **Purpose:** This memo documents whether {{CLIENT_NAME}} qualifies as a “covered provider” under the California AI Transparency Act and identifies which generative AI (GenAI) systems are in scope for compliance.

---

## 1. Executive Summary

### 1.1 Conclusion

- Summary statement on covered provider status, for example:  
  - “{{CLIENT_NAME}} **is / is not** a covered provider under the California AI Transparency Act as of {{REPORT_DATE}}.”
- Brief description of the GenAI systems determined to be in scope, if any.

### 1.2 Key Factors Considered

- Whether {{CLIENT_NAME}} creates, codes, or produces generative AI systems.  
- Whether those systems are publicly available to users in California.  
- Whether any systems meet or are projected to meet the 1,000,000+ monthly active users threshold in California.

### 1.3 Recommended Next Steps

- High‑level next steps (e.g., implement disclosure controls, build detection tool, begin user‑count monitoring).

---

## 2. Client Profile

### 2.1 Business Overview

- Description of {{CLIENT_NAME}}’s primary business activities.  
- Key products and services, especially those involving AI or digital content.

### 2.2 Generative AI Offerings

- List and brief description of GenAI products and features, including:  
  - {{GENAI_PRODUCT_1}} – {{SHORT_DESCRIPTION_1}}  
  - {{GENAI_PRODUCT_2}} – {{SHORT_DESCRIPTION_2}}  
- Primary user base:
  - Consumer / enterprise / mixed.  
- Access channels:
  - Website, mobile app, API, plug‑ins, platform integrations, etc.

---

## 3. Covered Provider Test

> **Objective:** Assess whether {{CLIENT_NAME}} meets the statutory definition of a “covered provider” under the California AI Transparency Act.

### 3.1 Creates / Codes / Produces Generative AI

- Description of whether {{CLIENT_NAME}} develops or controls a generative AI model or system that outputs content (text, image, video, audio, or multimodal).  
- Indicate if {{CLIENT_NAME}}:
  - Builds models in‑house.  
  - Fine‑tunes or substantially customizes third‑party models.  
  - Provides white‑labeled GenAI capabilities to end users.

**Assessment:** {{NARRATIVE_ASSESSMENT_CREATION}}

### 3.2 Public Availability in California

- Description of how users access each GenAI product:  
  - Public website URLs.  
  - Mobile apps (iOS / Android).  
  - Public APIs or SDKs.  
  - Integrations with third‑party platforms used in California.  
- Note any geo‑blocking or restrictions for California users.

**Assessment:** {{NARRATIVE_ASSESSMENT_PUBLIC_AVAILABILITY}}

### 3.3 User Scale – Estimated Monthly Active Users in California

- Best available estimates of monthly active users (MAU) in California for each GenAI system.  
- Data sources for estimates (analytics tools, internal dashboards, third‑party reports).  

**Summary Table:**

| System Name | Description | Global MAU | Est. CA MAU | Est. % CA Users | Notes on Estimation |
|------------|-------------|-----------:|------------:|----------------:|----------------------|
| {{SYSTEM_1}} | {{DESC_1}} | {{MAU_GLOBAL_1}} | {{MAU_CA_1}} | {{PCT_CA_1}} | {{NOTES_1}} |
| {{SYSTEM_2}} | {{DESC_2}} | {{MAU_GLOBAL_2}} | {{MAU_CA_2}} | {{PCT_CA_2}} | {{NOTES_2}} |

**Assessment:** {{NARRATIVE_ASSESSMENT_USER_SCALE}}

### 3.4 Overall Covered Provider Determination

- Synthesis of Sections 3.1–3.3, leading to a clear conclusion:  
  - “Based on the available information, {{CLIENT_NAME}} **is / is not** a covered provider under the California AI Transparency Act as of {{REPORT_DATE}}.”  
- Note any assumptions, data gaps, or uncertainties.

---

## 4. System‑Level Scope Analysis

> **Objective:** Identify which specific GenAI systems are in scope for California AI Transparency Act obligations.

### 4.1 In‑Scope Systems Table

| System Name | Description | Channel (Web/App/API) | Content Types (Text/Image/Video/Audio) | Est. CA MAU | In Scope? (Y/N) | Rationale |
|------------|-------------|------------------------|-----------------------------------------|------------:|-----------------|-----------|
| {{SYSTEM_1}} | {{DESC_1}} | {{CHANNEL_1}} | {{CONTENT_TYPES_1}} | {{MAU_CA_1}} | {{IN_SCOPE_1}} | {{RATIONALE_1}} |
| {{SYSTEM_2}} | {{DESC_2}} | {{CHANNEL_2}} | {{CONTENT_TYPES_2}} | {{MAU_CA_2}} | {{IN_SCOPE_2}} | {{RATIONALE_2}} |

### 4.2 Out‑of‑Scope Systems

- List GenAI or AI‑related systems that are assessed as out of scope and why, for example:  
  - Internal‑only tools (no public access).  
  - Non‑generative analytics or ranking systems.  
  - Products not accessible in California.  

**Out‑of‑Scope List:**

- {{SYSTEM_OUT_1}} – {{OUT_RATIONALE_1}}  
- {{SYSTEM_OUT_2}} – {{OUT_RATIONALE_2}}

---

## 5. Monitoring & Trigger Plan

> **Objective:** Establish how {{CLIENT_NAME}} will monitor growth and re‑evaluate scope over time.

### 5.1 Metrics to Monitor

- Monthly active users (MAU) in California per GenAI system.  
- Total volume of AI‑generated image, video, and audio content.  
- Launch of new GenAI products or features accessible in California.

### 5.2 Thresholds & Triggers

- Define specific triggers that require re‑evaluation, for example:  
  - Any system exceeding {{TRIGGER_PCT}}% of the 1,000,000 CA MAU threshold (e.g., 700,000 MAU).  
  - Launch of a new public GenAI product with projected rapid growth.

### 5.3 Roles and Responsibilities

- **Data/Analytics Owner:** {{DATA_OWNER_NAME}} – responsible for providing monthly MAU reports.  
- **Product Owner(s):** {{PRODUCT_OWNER_NAMES}} – responsible for flagging new or changed GenAI features.  
- **Legal/Compliance Contact:** {{LEGAL_CONTACT_NAME}} – responsible for coordinating periodic re‑assessments.

### 5.4 Re‑Assessment Cadence

- Recommended cadence for rerunning this scope memo:  
  - Quarterly (standard), or  
  - Monthly (if growth is rapid or near threshold).

---

## 6. Recommendations & Next Steps

### 6.1 If {{CLIENT_NAME}} Is a Covered Provider

- Proceed to implement:
  - GenAI system inventory and detailed usage mapping.  
  - Public detection tool for AI‑generated content.  
  - Manifest (visible) and latent (technical) disclosure mechanisms.  
  - Licensee/partner controls and monitoring.  

- Consider developing:
  - Internal governance policy for the California AI Transparency Act.  
  - Cross‑functional steering group (Product, Engineering, Legal, Compliance).

### 6.2 If {{CLIENT_NAME}} Is Not Yet a Covered Provider

- Maintain this memo as formal documentation of the scope assessment.  
- Implement the monitoring and trigger plan defined in Section 5.  
- Re‑evaluate scope when:
  - Any GenAI system approaches the user threshold, or  
  - New products/features significantly expand public AI content generation in California.

---

**End of Memo**
