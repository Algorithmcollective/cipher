# California AI Transparency Act – AI System Inventory & Disclosure Controls Worksheet (MASTER)

**Worksheet Title:** California AI Transparency Act AI System Inventory & Disclosure Controls for {{CLIENT_NAME}}  
**Prepared For (Client):** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date of Analysis:** {{REPORT_DATE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> **Purpose:** This worksheet operationalizes the Scope & Applicability Memo by inventorying in‑scope GenAI systems and defining required disclosure controls (manifest labels, latent markers, and detection tooling) for {{CLIENT_NAME}}.

---

## 1. Linkage to Scope & Applicability Memo

- Scope Memo Title: **{{SCOPE_MEMO_TITLE}}**  
- Date of Scope Memo: **{{SCOPE_MEMO_DATE}}**  
- Covered Provider Status (from Memo): **{{IS_COVERED_PROVIDER_YN}}**  
- In‑Scope Systems (from Memo): **{{IN_SCOPE_SYSTEM_LIST}}**

> Note: This worksheet **does not** re‑decide scope. It assumes the conclusions of the Scope & Applicability Memo are correct as of {{REPORT_DATE}}.

---

## 2. System Inventory (In‑Scope Only)

> **Objective:** Capture a concise, structured inventory of all GenAI systems deemed “in scope” in the Scope & Applicability Memo.

### 2.1 In‑Scope Systems Table

| System ID | System Name | Business Owner | Technical Owner | Primary Use Case | Main User Group (Consumer/B2B/Internal) | Access Channel(s) (Web/App/API) | Content Types (Text/Image/Video/Audio) |
|----------|-------------|----------------|-----------------|------------------|-----------------------------------------|----------------------------------|----------------------------------------|
| {{SYS_ID_1}} | {{SYSTEM_NAME_1}} | {{BIZ_OWNER_1}} | {{TECH_OWNER_1}} | {{USE_CASE_1}} | {{USER_GROUP_1}} | {{CHANNELS_1}} | {{CONTENT_TYPES_1}} |
| {{SYS_ID_2}} | {{SYSTEM_NAME_2}} | {{BIZ_OWNER_2}} | {{TECH_OWNER_2}} | {{USE_CASE_2}} | {{USER_GROUP_2}} | {{CHANNELS_2}} | {{CONTENT_TYPES_2}} |

### 2.2 Key Volume & Reach Metrics

| System ID | Est. Global MAU | Est. CA MAU | Est. % CA Users | Typical Output Volume (per month) | Primary External Surfaces (e.g., public site, social share, API) |
|----------|-----------------:|------------:|----------------:|-----------------------------------:|------------------------------------------------------------------|
| {{SYS_ID_1}} | {{GLOBAL_MAU_1}} | {{CA_MAU_1}} | {{PCT_CA_1}} | {{OUTPUT_VOLUME_1}} | {{EXTERNAL_SURFACES_1}} |
| {{SYS_ID_2}} | {{GLOBAL_MAU_2}} | {{CA_MAU_2}} | {{PCT_CA_2}} | {{OUTPUT_VOLUME_2}} | {{EXTERNAL_SURFACES_2}} |

---

## 3. Manifest Disclosure Design (Visible AI Labels)

> **Objective:** Define human‑readable indicators that content is AI‑generated or AI‑modified, per the Act’s transparency intent.

### 3.1 Manifest Label Requirements per System

| System ID | User‑Facing Surfaces (UI, emails, files) | Label Text (Working Draft) | Placement (UI location / file location) | When Is Label Shown? (Rules/Conditions) | Owner (Team/Role) | Target Rollout Date |
|----------|-------------------------------------------|----------------------------|-----------------------------------------|-----------------------------------------|-------------------|---------------------|
| {{SYS_ID_1}} | {{SURFACES_1}} | {{LABEL_TEXT_1}} | {{PLACEMENT_1}} | {{CONDITIONS_1}} | {{OWNER_1}} | {{ROLLOUT_DATE_1}} |
| {{SYS_ID_2}} | {{SURFACES_2}} | {{LABEL_TEXT_2}} | {{PLACEMENT_2}} | {{CONDITIONS_2}} | {{OWNER_2}} | {{ROLLOUT_DATE_2}} |

### 3.2 Edge Cases & Exemptions

- **Bulk / API Outputs:** {{BULK_OUTPUT_RULES}}  
- **Tiny or non‑visual surfaces (e.g., icons, thumbnails):** {{TINY_SURFACE_APPROACH}}  
- **Co‑generated content (human + AI):** {{MIXED_CONTENT_RULES}}  

---

## 4. Latent Disclosure Design (Technical Markers)

> **Objective:** Specify technical mechanisms (watermarks, metadata, signatures) used to mark AI content so it can be detected downstream.

### 4.1 Latent Markers per Content Type

| System ID | Content Type | Latent Method (e.g., watermark, cryptographic signature, metadata tag) | Standard/Spec (if any) | Where Applied (file, stream, CDN) | Known Limitations / Degradation Risks | Owner | Implementation Status (Planned/In‑Progress/Live) |
|----------|--------------|-------------------------------------------------------------------------|------------------------|------------------------------------|----------------------------------------|-------|--------------------------------------------------|
| {{SYS_ID_1}} | {{CONTENT_TYPE_1A}} | {{LATENT_METHOD_1A}} | {{STANDARD_1A}} | {{APPLIED_WHERE_1A}} | {{LIMITATIONS_1A}} | {{OWNER_1A}} | {{STATUS_1A}} |
| {{SYS_ID_1}} | {{CONTENT_TYPE_1B}} | {{LATENT_METHOD_1B}} | {{STANDARD_1B}} | {{APPLIED_WHERE_1B}} | {{LIMITATIONS_1B}} | {{OWNER_1B}} | {{STATUS_1B}} |

### 4.2 Third‑Party or Downstream Breakage

- Known transformations that may strip markers (e.g., social media recompression, screenshotting): {{DOWNSTREAM_RISKS}}  
- Mitigations or user education planned: {{DOWNSTREAM_MITIGATIONS}}  

---

## 5. Public Detection Tool Plan

> **Objective:** Define how {{CLIENT_NAME}} will provide a free, reasonable mechanism for the public to test whether content was generated or modified by its in‑scope systems.

### 5.1 Detection Tool Summary

| Attribute | Description |
|----------|-------------|
| Tool Name / Working Name | {{DETECTION_TOOL_NAME}} |
| Access URL / App Entry Point | {{DETECTION_TOOL_URL}} |
| Supported Content Types | {{DETECTION_SUPPORTED_TYPES}} |
| Systems Covered | {{DETECTION_SYSTEMS_COVERED}} |
| Intended Users | {{INTENDED_USERS}} |
| Availability (24/7, beta hours, etc.) | {{AVAILABILITY}} |

### 5.2 Detection Logic & Reliability

- High‑level detection approach (e.g., verify embedded signature vs. statistical classifier): {{DETECTION_APPROACH}}  
- Known accuracy / false positive‑negative considerations: {{DETECTION_LIMITATIONS}}  
- Messaging to users about reliability and safe interpretation: {{DETECTION_USER_COPY}}  

### 5.3 Governance & Maintenance

- Detection tool owner (team/role): {{DETECTION_TOOL_OWNER}}  
- Update triggers (e.g., new model version, new content type): {{DETECTION_UPDATE_TRIGGERS}}  

---

## 6. Implementation Roadmap & RACI

> **Objective:** Turn design decisions into a time‑bound, accountable implementation plan.

### 6.1 Milestone Roadmap

| Milestone ID | Description | Systems Affected | Target Date | Dependency Notes | Status (Planned/In‑Progress/Done) |
|-------------|-------------|------------------|------------|------------------|-----------------------------------|
| M1 | {{M1_DESC}} | {{M1_SYSTEMS}} | {{M1_DATE}} | {{M1_DEPENDENCIES}} | {{M1_STATUS}} |
| M2 | {{M2_DESC}} | {{M2_SYSTEMS}} | {{M2_DATE}} | {{M2_DEPENDENCIES}} | {{M2_STATUS}} |

### 6.2 RACI Matrix (High‑Level)

| Activity | Product | Engineering | Legal/Compliance | Security/Privacy | Data/Analytics |
|---------|---------|-------------|------------------|------------------|----------------|
| Design manifest labels | {{RACI_LABELS_PRODUCT}} | {{RACI_LABELS_ENGINEERING}} | {{RACI_LABELS_LEGAL}} | {{RACI_LABELS_SECURITY}} | {{RACI_LABELS_ANALYTICS}} |
| Implement latent markers | {{RACI_LATENT_PRODUCT}} | {{RACI_LATENT_ENGINEERING}} | {{RACI_LATENT_LEGAL}} | {{RACI_LATENT_SECURITY}} | {{RACI_LATENT_ANALYTICS}} |
| Build detection tool | {{RACI_DETECT_PRODUCT}} | {{RACI_DETECT_ENGINEERING}} | {{RACI_DETECT_LEGAL}} | {{RACI_DETECT_SECURITY}} | {{RACI_DETECT_ANALYTICS}} |

---

## 7. Risks, Gaps, and Open Questions

- Key implementation risks: {{KEY_RISKS}}  
- Dependencies on external standards or vendors: {{EXTERNAL_DEPENDENCIES}}  
- Open questions / decisions needed from leadership: {{OPEN_QUESTIONS}}  

---

**End of Worksheet**
