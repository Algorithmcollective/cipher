# California AI Transparency Implementation Audit Checklist (MASTER TEMPLATE)

**Document Title:** California AI Transparency Implementation Audit Checklist for {{CLIENT_NAME}}  
**Version:** v{{VERSION}}  
**Audit Date:** {{AUDIT_DATE}}  
**Auditor:** {{AUDITOR_NAME}}, {{FIRM_NAME}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> **Purpose:** This checklist provides a structured way to assess whether {{CLIENT_NAME}}’s implemented controls (labels, provenance, detection tool, contracts, and governance) align with its California AI Transparency Act obligations and its own internal documentation (CA_01–CA_06).[file:1][file:2][web:5][web:19]

---

## 1. Documentation Baseline

| Item | Description | Evidence Location | Status (Yes/No/N/A) | Notes |
|------|-------------|-------------------|----------------------|-------|
| 1.1 | Latest Scope & Applicability Memo (CA_01) is approved and dated within last 12 months | {{LINK_CA01}} | {{STATUS_1_1}} | {{NOTES_1_1}} |
| 1.2 | AI System Inventory & Disclosure Worksheet (CA_02) exists for all in‑scope systems | {{LINK_CA02}} | {{STATUS_1_2}} | {{NOTES_1_2}} |
| 1.3 | AI Transparency Policy (CA_03) is approved and in effect | {{LINK_CA03}} | {{STATUS_1_3}} | {{NOTES_1_3}} |
| 1.4 | Standard AI Transparency Contract Addendum (CA_04) is defined | {{LINK_CA04}} | {{STATUS_1_4}} | {{NOTES_1_4}} |
| 1.5 | Training & Implementation Playbook (CA_05) and at least one training session completed in last 12 months | {{LINK_CA05}} | {{STATUS_1_5}} | {{NOTES_1_5}} |
| 1.6 | Public AI Transparency Notice (CA_06) is live and up to date | {{LINK_CA06}} | {{STATUS_1_6}} | {{NOTES_1_6}} |

[file:1][file:2][web:19]

---

## 2. Scope & User Thresholds

| Item | Test | Evidence | Status | Notes |
|------|------|----------|--------|-------|
| 2.1 | Covered provider determination matches latest user metrics and product reach | {{EVIDENCE_2_1}} | {{STATUS_2_1}} | {{NOTES_2_1}} |
| 2.2 | In‑scope systems list in CA_01 and CA_02 matches production inventory | {{EVIDENCE_2_2}} | {{STATUS_2_2}} | {{NOTES_2_2}} |

[file:1][file:2][web:5][web:19]

---

## 3. Manifest Disclosures (Visible Labels)

For each in‑scope system (from CA_02):

| Item | System | Test | Status | Notes |
|------|--------|------|--------|-------|
| 3.1 | {{SYSTEM_1}} | Labels appear in all specified UIs (editor, export, gallery, share) for AI‑generated/modified outputs | {{STATUS_3_1}} | {{NOTES_3_1}} |
| 3.2 | {{SYSTEM_1}} | Label text matches approved wording in Policy/Worksheet and Transparency Notice | {{STATUS_3_2}} | {{NOTES_3_2}} |
| 3.3 | {{SYSTEM_1}} | No AI label shown for purely user‑uploaded, unmodified content | {{STATUS_3_3}} | {{NOTES_3_3}} |

[file:2][web:6][web:19]

---

## 4. Latent Disclosures (Provenance Signals)

| Item | System | Test | Status | Notes |
|------|--------|------|--------|-------|
| 4.1 | {{SYSTEM_1}} | Sample of exported files contains expected watermark/meta
