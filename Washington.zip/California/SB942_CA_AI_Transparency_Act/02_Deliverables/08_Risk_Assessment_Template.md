# California AI Transparency Risk & DPIA Add‑On (MASTER TEMPLATE)

**Document Title:** California AI Transparency Risk & DPIA Add‑On for {{CLIENT_NAME}}  
**Version:** v{{VERSION}}  
**Assessment Date:** {{ASSESSMENT_DATE}}  
**Prepared By:** {{ASSESSOR_NAME}}, {{FIRM_NAME}}  
**Related DPIA / AI Risk Assessment ID:** {{RELATED_ASSESSMENT_ID}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853); related California AI transparency and training‑data laws (e.g., AB 2013, if applicable). [web:19][web:45]

> **Purpose:** This add‑on plugs into existing DPIAs or AI risk assessments to document how {{CLIENT_NAME}} addresses California AI Transparency Act obligations (labels, provenance, detection tool, public documentation) and related transparency requirements for generative AI systems.[web:19][web:82]

---

## 1. System & Use Case Summary

- **System Name:** {{SYSTEM_NAME}}  
- **Product / Feature:** {{PRODUCT_FEATURE}}  
- **Content Types:** {{CONTENT_TYPES}} (e.g., images, audio, video)  
- **User Groups:** {{USER_GROUPS}} (e.g., consumers in California, enterprise admins)  
- **Public Availability:** {{PUBLIC_AVAILABILITY_DESC}} (how California users access the system). [file:1][file:2][web:19]

---

## 2. Transparency Obligations Mapping

| Requirement Area | Applicable? (Y/N) | How Addressed | Evidence (Doc IDs / URLs) |
|------------------|-------------------|---------------|---------------------------|
| Manifest (visible) AI labels for outputs | {{Y_N_1}} | {{MANIFEST_IMPLEMENTATION}} | {{REF_CA02}}, {{REF_CA03}}, {{REF_CA06}} |
| Latent (embedded) provenance markers | {{Y_N_2}} | {{LATENT_IMPLEMENTATION}} | {{REF_CA02}}, {{TECH_DESIGN_DOC}} |
| Public AI detection / verification tool | {{Y_N_3}} | {{DETECTION_IMPLEMENTATION}} | {{VERIFICATION_URL}}, {{REF_CA02}} |
| Public training‑data summary (if AB 2013 applies) | {{Y_N_4}} | {{DATA_SUMMARY_IMPLEMENTATION}} | {{TRAINING_DATA_NOTICE_URL}} | 

[web:19][web:45]

---

## 3. Risk Analysis – Mislabeling & Provenance Failure

### 3.1 Key Risks

- **R1 – Unlabeled AI content:** Users receive AI‑generated content without a clear label, leading to confusion or deception risk. [web:19][web:75]  
- **R2 – Incorrect labeling:** Human‑only content incorrectly labeled as AI, or vice versa, undermining trust and possible regulatory scrutiny. [web:19]  
- **R3 – Stripped or broken provenance:** Downstream platforms remove watermarks/metadata so detection tools cannot reliably identify content. [web:19][web:45]  

### 3.2 Likelihood & Impact (Qualitative)

| Risk ID | Likelihood (Low/Med/High) | Impact (Low/Med/High) | Notes / Scenarios |
|---------|---------------------------|------------------------|-------------------|
| R1 | {{LIKELIHOOD_R1}} | {{IMPACT_R1}} | {{NOTES_R1}} |
| R2 | {{LIKELIHOOD_R2}} | {{IMPACT_R2}} | {{NOTES_R2}} |
| R3 | {{LIKELIHOOD_R3}} | {{IMPACT_R3}} | {{NOTES_R3}} |

[web:19][web:75]

---

## 4. Controls & Mitigations

| Risk ID | Control / Mitigation | Control Owner | Status (Planned/In‑Progress/Live) |
|---------|----------------------|---------------|-----------------------------------|
| R1 | UI label rules documented in CA_02; integration tests ensure AI labels appear on all relevant surfaces before release. | {{PRODUCT_OWNER}} / {{QA_LEAD}} | {{STATUS_C1}} |
| R2 | Policy and design reviews to approve label wording; regression tests for label triggers; incident playbook for corrections. | {{LEGAL_OWNER}} / {{PRODUCT_OWNER}} | {{STATUS_C2}} |
| R3 | Robust watermarking and metadata design; periodic downstream platform testing; Transparency Notice disclosing residual limitations. | {{ENG_OWNER}} / {{TRUST_SAFETY_OWNER}} | {{STATUS_C3}} |

[file:2][web:19][web:49]

---

## 5. Residual Risk & Acceptance

- **Residual Risk Summary:** {{RESIDUAL_RISK_SUMMARY}} (e.g., “Low” overall, with specific caveats around third‑party stripping of metadata).  
- **Risk Acceptance / Further Actions:**  
  - {{ACTION_1}} (e.g., additional testing, partner outreach, UX tweak).  
  - {{ACTION_2}}.  

- **Approver:** {{RISK_APPROVER_NAME}}, {{TITLE}}  
- **Approval Date:** {{APPROVAL_DATE}}  

[web:19][web:82]

---

**End of Add‑On**
