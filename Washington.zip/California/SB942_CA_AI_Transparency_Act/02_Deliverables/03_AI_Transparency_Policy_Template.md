# California AI Transparency Policy (MASTER TEMPLATE)

**Policy Title:** California AI Transparency Policy for {{CLIENT_NAME}}  
**Version:** v{{POLICY_VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Approved By:** {{APPROVER_NAME}}, {{APPROVER_TITLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> **Purpose:** This policy defines how {{CLIENT_NAME}} will satisfy California AI Transparency Act requirements for manifest and latent disclosures, and for providing public AI‑detection capabilities for covered generative AI systems.[web:5][web:19]

---

## 1. Scope

- This policy applies to all generative AI systems operated or offered by {{CLIENT_NAME}} that:
  - Generate or substantially modify image, video, or audio content, and  
  - Are publicly accessible to users located in California, and  
  - Meet the “covered provider” criteria under the California AI Transparency Act.[web:5][web:19]  
- Internal‑only tools and non‑generative analytics systems are out of scope unless specifically designated as in scope by Legal/Compliance.

---

## 2. Roles and Responsibilities

- **AI Transparency Owner (Policy Owner):** {{POLICY_OWNER_ROLE}} – maintains this policy, coordinates updates, and reports to senior leadership.  
- **Product Owners:** Ensure product designs, roadmaps, and releases implement the manifest and latent disclosure requirements defined in this policy.  
- **Engineering / Platform Teams:** Implement technical controls (watermarking, metadata, detection tool), monitor performance, and remediate defects.  
- **Legal & Compliance:** Interpret statutory requirements, validate scope determinations, and oversee compliance documentation.[web:5][web:24]  
- **Security & Privacy:** Assess risks related to provenance data, abuse of detection tools, and potential security impacts.  

---

## 3. Manifest Disclosures (Visible Labels)

- All in‑scope systems must provide a clear, conspicuous, and appropriately placed label indicating when content is AI‑generated or AI‑modified (“manifest disclosure”).[web:19][web:24]  
- At minimum, labels must:
  - Identify content as AI‑generated or AI‑modified.  
  - Be presented in a manner appropriate to the medium (e.g., on‑screen notice, watermark, caption, or badge).[web:19]  
- Product teams must document:
  - Exact label text, placement, and triggering conditions in the AI System Inventory & Disclosure Worksheet for each system.  
  - Any edge‑case handling (e.g., thumbnails, mixed human/AI content).  

---

## 4. Latent Disclosures (Embedded Provenance)

- In‑scope systems must embed machine‑readable provenance information (“latent disclosures”) in AI‑generated or AI‑modified content wherever technically feasible.[web:19][web:24]  
- Latent disclosures must, at a minimum, encode:
  - {{CLIENT_NAME}} as provider,  
  - GenAI system name and version,  
  - Content creation or modification timestamp,  
  - A unique identifier that can be resolved by {{CLIENT_NAME}}’s detection tool.[web:19]  
- Engineering must:
  - Align implementations with recognized industry standards for content authenticity where practical.  
  - Regularly test resilience of latent disclosures against common transformations (compression, resizing, format changes).  

---

## 5. Public AI Detection Tool

- {{CLIENT_NAME}} will provide a free, public detection tool that allows users to check whether specified content was generated or modified by an in‑scope system, consistent with the Act.[web:19][web:10]  
- At minimum, the tool must:
  - Be accessible via a public website and, where appropriate, an API.  
  - Accept supported content types (e.g., image, video, audio) as uploads or via URL.  
  - Return system‑level provenance data without exposing personal data about individual users.[web:19]  
- The AI Transparency Owner and Engineering will define supported formats, rate limits, and abuse‑prevention controls.  

---

## 6. Governance, Monitoring, and Updates

- Scope assessments and system inventory must be reviewed at least **quarterly** or when significant product changes occur, using the Scope & Applicability Memo and Inventory Worksheet as primary artifacts.[file:1][file:2]  
- Policy effectiveness will be monitored via:
  - Periodic audits of labeled content surfaces.  
  - Tests of watermark/metadata integrity across major distribution channels.  
  - Metrics from the public detection tool (usage, error rates, false positive/negative trends).[web:19]  
- This policy will be re‑evaluated upon:
  - Changes in California AI transparency laws or guidance,  
  - Launch of new in‑scope GenAI systems, or  
  - Material incidents involving mislabeling or provenance failures.[web:24]  

---

## 7. Enforcement

- Violations of this policy may expose {{CLIENT_NAME}} to civil penalties and regulatory action under the California AI Transparency Act.[web:19][web:24]  
- Employees and contractors are required to follow this policy and any associated standards or runbooks; non‑compliance may result in disciplinary measures per existing HR and vendor management processes.  

---

**End of Policy**
