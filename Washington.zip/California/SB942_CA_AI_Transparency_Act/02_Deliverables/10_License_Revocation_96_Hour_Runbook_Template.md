# California AI Transparency – License Revocation & 96‑Hour Response Runbook (MASTER TEMPLATE)

**Document Title:** California AI Transparency – License Revocation & 96‑Hour Response Runbook for {{CLIENT_NAME}}  
**Version:** v{{VERSION}}  
**Last Updated:** {{LAST_UPDATED}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California AI Transparency Act (SB 942 / AB 853)  

> Purpose: Provide a step‑by‑step operational playbook for responding when a licensee/partner is non‑compliant with AI transparency obligations, including investigation, notification, remediation, and potential license revocation within required timelines.[web:19][web:85]

---

## 1. When to Trigger This Runbook

Trigger this runbook if any of the following are suspected or confirmed for a licensee/partner:

- Removal or obscuring of required AI labels at scale.  
- Systematic stripping of provenance markers (watermarks/metadata) from AI‑generated content.  
- Misleading re‑labeling of AI content as human‑created.  
- Failure to implement required detection or transparency commitments agreed in contract.  

{{TRIGGER_NOTES}} [web:4][web:19]

---

## 2. Roles & Contact List

| Role | Name / Team | Responsibilities |
|------|-------------|------------------|
| Incident Lead | {{INCIDENT_LEAD}} | Overall coordination, status tracking, decision logging |
| Legal Lead | {{LEGAL_LEAD}} | Contract interpretation, notice language, enforcement options |
| Technical Lead | {{TECH_LEAD}} | Evidence gathering (logs, samples), technical mitigations |
| Partner/Account Lead | {{ACCOUNT_LEAD}} | Direct communication with licensee/partner |
| Comms / PR | {{COMMS_LEAD}} | External messaging if needed |

[web:19][web:85]

---

## 3. 0–24 Hours: Triage & Evidence

1. **Acknowledge and log incident** in CA transparency incident log (link ID, date/time, reporter).  
2. **Assign Incident Lead and core team** (Legal, Technical, Partner).  
3. **Collect evidence:**
   - Sample content showing missing/altered labels or provenance.  
   - Screenshots or recordings from partner’s UI.  
   - Logs or metrics indicating scale and timing.  
4. **Initial risk assessment:** scope (systems, users, geos), potential regulatory exposure.  

{{TRIAGE_CHECKLIST}} [web:19][web:85]

---

## 4. 24–72 Hours: Partner Engagement & Remediation Plan

1. **Legal notifies partner** under contract:
   - Describe issues and contractual obligations.  
   - Request swift remediation and proposed timeline.  
2. **Technical working session** with partner (if cooperative):
   - Identify root cause (e.g., UI cropping labels, CDN stripping metadata).  
   - Agree on short‑term fix and longer‑term prevention measures.  
3. **Interim mitigations**:
   - Consider rate‑limiting or narrowing partner access for highest‑risk use cases.  
   - Update public FAQs if user confusion is likely.  

{{REMEDIATION_NOTES}} [web:4][web:19]

---

## 5. By 96 Hours (or Shorter Internal Target): Decision & Execution

1. **Evaluate partner response:**
   - Has a credible fix been implemented or firmly scheduled?  
   - Is non‑compliance ongoing and material?  
2. **Decision options:**
   - Continue relationship with monitoring (minor issue, fixed quickly).  
   - Suspend portions of the license (e.g., disable certain features or geos).  
   - Fully revoke license / terminate integration for persistent or severe violations.  
3. **Execute decision**:
   - Technical actions (disable API keys, remove integrations).  
   - Legal notices (formal revocation/termination letters).  
   - Internal and, if needed, external communications.  

{{DECISION_CRITERIA}} [web:19][web:85]

---

## 6. Post‑Incident Review & Documentation

- Complete post‑incident review within {{POSTMORTEM_DAYS}} days:
  - Timeline, root cause, partner behavior, remediation.  
  - Lessons learned for partner onboarding, monitoring, and contracts.  
- Update:
  - CA_04 Contract Addendum templates (if needed).  
  - Monitoring & incident log (CA_08).  
  - Enforcement risk assessment (CA_09).  

{{POST_INCIDENT_NOTES}} [web:19][web:85]

---

**End of Runbook**
