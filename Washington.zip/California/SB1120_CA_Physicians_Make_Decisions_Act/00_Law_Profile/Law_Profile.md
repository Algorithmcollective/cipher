# Law Profile

## Law Name
California Senate Bill 1120 – Physicians Make Decisions Act

## Citation
California SB 1120 (2024)

## Status
Enacted

## Effective Date
January 1, 2025

## Regulatory Scope

Applies to:

- Health care service plans (HMOs, managed care organizations)
- Disability insurers
- Specialized health care service plans
- Utilization review (UR) and utilization management (UM) entities
- Contractors performing UR/UM functions on behalf of covered entities
- Medi-Cal managed care plans (subject to federal funding constraints)

This law governs how AI, algorithms, and automated tools may be used in medical necessity determinations.

## Core Prohibitions

Covered entities may NOT:

- Use AI to deny, delay, or modify healthcare services based on medical necessity
- Allow AI to replace physician decision-making
- Base medical necessity determinations solely on group datasets without considering individual patient circumstances

Only licensed physicians or qualified healthcare professionals may make final medical necessity determinations.

AI may assist in triage or case organization but may not make final decisions.

## Core Obligations

Covered entities must:

- Ensure physician oversight for all medical necessity decisions
- Maintain documentation of physician involvement
- Ensure AI tools are open to inspection for audit or compliance review
- Configure systems to prevent automated denial without physician sign-off
- Maintain proper audit logs

## Enforcement Authority

California Department of Managed Health Care (DMHC)  
California Department of Insurance (DOI)

## Penalties

Administrative penalties under utilization review and insurance regulatory authority.

Potential consequences include:

- Regulatory fines
- Corrective action orders
- Increased audit scrutiny
- Potential impact on licensure status

No per-day statutory fine structure specified within SB 1120 itself.

## Private Right of Action

No (enforced through regulatory oversight)

## Tier Classification

Tier 2 – Sector-Specific AI Governance Law

## Revenue Priority

Medium to High (Vertical-Specific)

## Target Industries

- Health insurers
- Managed care organizations
- Disability insurers
- Utilization review vendors
- AI vendors supporting UR/UM systems

Does NOT generally apply to:

- Hospitals making internal clinical decisions outside insurer UR/UM
- Non-insurance healthcare providers not performing utilization review

## Strategic Positioning

This law establishes strict limits on the role of AI in healthcare decision-making, reinforcing physician authority and human oversight.

It is positioned as an AI-assisted clinical governance compliance program, particularly for insurers and managed care organizations.

## Internal Notes

Primary compliance focus areas:

1. AI Usage & Medical Necessity Mapping
2. Physician-Only Determination Policy
3. AI-Assisted Review SOPs
4. System Configuration & Controls Verification
5. Vendor Due Diligence
6. Exception & Escalation Workflow
7. Ongoing Monitoring & Audit Plan

High enforcement exposure due to regulatory audit environment.
Strong positioning in health insurance vertical.