# Physician‑Only Medical Necessity Policy for PacificCare Health Plan

**Policy Title:** Physician‑Only Medical Necessity Policy for PacificCare Health Plan  
**Version:** v1.0  
**Effective Date:** March 1, 2026  
**Approved By:** Karen Liu, MD – Chief Medical Officer  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act (Health care coverage: utilization review)  

> Purpose: This policy establishes that medical‑necessity determinations for PacificCare Health Plan members are made only by licensed physicians or other qualified licensed healthcare professionals, and that AI, algorithms, or software tools may support but may not deny, delay, or modify services based, in whole or in part, on medical necessity.[web:96][web:98][web:101]

---

## 1. Scope

- This policy applies to all PacificCare lines of business subject to California law, including commercial group, individual, and Medicare Advantage products.  
- It governs all utilization review and utilization management activities, including:
  - Prior authorization for inpatient and outpatient services, imaging, and select drugs.  
  - Concurrent and retrospective review.  
  - Claims edits or post‑payment reviews that incorporate medical‑necessity judgments.[web:96][web:105]  
- It covers AI‑enabled tools such as SmartPrior, StaySense, and ClaimEdit360, as well as any delegated UR platforms used by medical groups and IPAs.  

---

## 2. Policy Statement – Physician‑Only Medical Necessity

- Determinations of **medical necessity** for PacificCare members shall be made **only** by:
  - A licensed physician, or  
  - Another licensed healthcare professional (e.g., RN, PA) who is competent to evaluate the specific clinical issues involved and is acting under appropriate supervision and scope of practice.[web:96][web:98]  
- No individual or automated system, other than such licensed professionals, may **deny, delay, or modify** requests for authorization of health‑care services for reasons of medical necessity.[web:96][web:90]  
- AI, algorithms, or software tools configured by PacificCare or its vendors **may not be used** as the sole or primary basis to deny or modify medically necessary services.  

---

## 3. Role of AI, Algorithms, and Software Tools

- PacificCare uses AI and algorithms to:
  - Triage prior‑auth requests by risk and complexity.  
  - Identify cases that may need additional clinical review.  
  - Highlight inconsistencies or potential coding issues in claims.[web:98][web:115]  
- These tools **may** auto‑approve clearly low‑risk, guideline‑conforming requests when criteria are fully met, but **may not**:
  - Auto‑deny or downgrade requests based on medical‑necessity criteria.  
  - Shorten approved lengths of stay or reduce coverage levels without clinician review and documentation.  

In all cases, BrightCare’s UR systems must clearly record the licensed clinician responsible for any adverse medical‑necessity determination.  

---

## 4. Responsibilities

- **Chief Medical Officer (CMO):**
  - Owns this policy, approves clinical criteria, and oversees compliance with SB 1120.  
- **Medical Directors and UM Leadership:**
  - Ensure that adverse determinations (denials, modifications, delays) based on medical necessity are reviewed and signed off by a qualified clinician with appropriate specialty where feasible.  
- **IT / Analytics:**
  - Configure SmartPrior, StaySense, ClaimEdit360, and similar tools so that no configuration can auto‑deny or downgrade services based on medical‑necessity logic without explicit clinician review and decision.  
- **Delegated Entities (e.g., SouthBay IPA):**
  - Must adopt policies consistent with this document; contracts require adherence to SB 1120 and allow PacificCare to audit AI‑assisted UR workflows.[web:96][web:105]  

---

## 5. Documentation Requirements

- For every denial, delay, or modification **based on medical necessity**, PacificCare (or its delegate) must document:
  - Name and credentials of the licensed physician or qualified clinician making the decision.  
  - Clinical rationale, including guidelines applied and patient‑specific factors considered.  
  - Any AI or software output used as decision support, clearly labeled as supporting information.[web:96][web:101]  
- UR letters to providers and members must reflect that a licensed clinician made the medical‑necessity determination, not an AI tool.  

---

## 6. Monitoring and Compliance

- PacificCare will:
  - Conduct quarterly audits of sampled prior‑auth and UR decisions to confirm that a licensed clinician made and documented medical‑necessity determinations, particularly in flows previously flagged as higher risk.  
  - Periodically review AI tool configurations and vendor attestations to ensure they remain consistent with this policy and SB 1120.[web:93][web:101]  
- Violations of this policy may result in:
  - Reconfiguration or suspension of affected tools.  
  - Corrective training for staff.  
  - Remediation or termination of delegation agreements in serious or repeated cases.  

---

**End of Policy**
