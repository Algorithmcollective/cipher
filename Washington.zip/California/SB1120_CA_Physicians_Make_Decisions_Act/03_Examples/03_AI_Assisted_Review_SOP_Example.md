# AI‑Assisted Utilization Review SOPs – Clinical Workflow for PacificCare Health Plan

**Document Title:** AI‑Assisted Utilization Review SOPs – Clinical Workflow for PacificCare Health Plan  
**Version:** v1.0  
**Effective Date:** March 1, 2026  
**Owner:** Director, Utilization Management Operations  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Define standard operating procedures (SOPs) for how AI and other software tools may assist, but not replace, licensed clinicians in PacificCare’s utilization review (UR) and utilization management (UM) workflows, consistent with SB 1120.[web:96][web:105][web:101]

---

## 1. Overview & Principles

- PacificCare uses AI‑enabled tools (SmartPrior, StaySense, ClaimEdit360) to support UR and UM, but **all medical‑necessity determinations are made by licensed clinicians.**[file:2][web:96][web:98]  
- These SOPs apply to prior authorization, concurrent review, and retrospective review for all California lines of business.  

Principles:

- **Human‑in‑the‑loop:** AI can triage and recommend but may not issue final medical‑necessity denials, delays, or modifications.  
- **Patient‑specific:** AI‑assisted reviews must consider each member’s individual clinical circumstances and the requesting provider’s recommendation, not just generalized group data.[web:96][web:101]  

---

## 2. Prior Authorization Workflow (AI‑Assisted, Physician‑Final)

### 2.1 Standard Prior Auth Flow

1. **Intake:**  
   - PA requests enter via provider portal, EDI, or phone; staff capture key data and attach clinical notes.  

2. **AI Triage via SmartPrior:**  
   - SmartPrior (T1) calculates a risk score and routes requests as:  
     - Tier 1 – clearly meets guideline criteria.  
     - Tier 2 – requires RN review.  
     - Tier 3 – requires physician review.[file:2][web:101]  

3. **Tier 1 – Auto‑Approval Only:**  
   - For Tier 1 cases, SmartPrior may **auto‑approve** if:
     - All required criteria fields are present.  
     - Request matches pre‑approved clinical scenarios (e.g., routine imaging per guidelines).  
   - SmartPrior **may not auto‑deny** Tier 1 requests; any potential denial must be escalated to a clinician.  

4. **Tier 2 – RN Review:**  
   - UM nurse reviews clinical documentation, SmartPrior output, and applicable criteria.  
   - If the nurse believes a denial, delay, or modification based on medical necessity is appropriate, the case is **escalated to a physician** for final determination.  

5. **Tier 3 – Physician Review:**  
   - Physician reviews full clinical file, SmartPrior output, and guidelines.  
   - Physician makes and documents the medical‑necessity decision (approve/deny/modify) and rationale.  

6. **Documentation & Communication:**  
   - All adverse determinations based on medical necessity record:
     - Physician name/credentials.  
     - Rationale and criteria applied.  
     - Any SmartPrior recommendations used as decision support.  
   - UR letters state that a licensed clinician made the medical‑necessity decision.  

### 2.2 Prohibited Configurations

- SmartPrior may **not**:  
  - Auto‑deny or auto‑downgrade requests based on medical‑necessity criteria.  
  - Route a case to “deny” without RN or physician review.  
- Any such legacy rules identified in the SB 1120 mapping memo are disabled as of March 1, 2026.[file:2][web:96][web:98]  

---

## 3. Concurrent & Retrospective Review Workflow

### 3.1 Concurrent Review (Inpatient Stays) – StaySense

1. **Data Collection:**  
   - Daily census feed provides LOS, DRG, comorbidities, and progress notes.  

2. **AI Flagging:**  
   - StaySense scores cases for potential extended LOS or variance from guidelines.  

3. **Physician Review:**  
   - For any potential reduction or denial of additional inpatient days **for medical‑necessity reasons**, a UM physician must:
     - Review the medical record and provider input.  
     - Make and document the decision, regardless of the StaySense score.[web:96][web:105]  

4. **Documentation:**  
   - System notes show which cases were flagged by StaySense and the physician’s final decision.  

### 3.2 Retrospective Review and Claims – ClaimEdit360

- ClaimEdit360 flags claims for potential bundling, coding, or clinical appropriateness edits.  
- Any **recoupment, denial, or modification** that rests on medical‑necessity logic requires:
  - Physician or qualified clinician review of the specific claim and record.  
  - Documented clinical rationale in the case file.  
- Automatic, AI‑driven payment reductions based solely on claim patterns without clinician review are disabled.  

---

## 4. Roles & Responsibilities in AI‑Assisted UR

| Role | Responsibilities |
|------|------------------|
| CMO & Medical Directors | Approve criteria; ensure physicians ultimately make medical‑necessity determinations. |
| UM Nurses | Conduct first‑level clinical review; escalate adverse determinations to physicians. |
| UM Operations | Maintain workflows and job aids reflecting this SOP; ensure staff follow escalation rules. |
| IT / Analytics | Configure SmartPrior, StaySense, and ClaimEdit360 to prevent any auto‑denials based on medical necessity; log AI outputs used in decisions. |

[file:2][web:96][web:101]

---

## 5. Quality Assurance & Auditing

- PacificCare’s QA team will:
  - Quarterly, sample at least 100 PA cases and 50 concurrent/retrospective reviews where AI was used.  
  - Confirm that adverse medical‑necessity determinations were made and documented by clinicians, not AI alone.  
  - Review SmartPrior and ClaimEdit360 configuration changes to ensure no new auto‑denial logic has been introduced.  

Findings feed into the SB 1120 Compliance Monitoring & Audit Plan and may trigger additional training or system changes.[web:93][web:101]  

---

**End of SOP**
