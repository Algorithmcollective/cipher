# SB 1120 Vendor & Third‑Party AI Due‑Diligence Questionnaire – SmartPrior Solutions, Inc.

**Document Title:** SB 1120 Vendor & Third‑Party AI Due‑Diligence Questionnaire for PacificCare Health Plan – SmartPrior Solutions, Inc.  
**Version:** v1.0  
**Date Issued:** March 10, 2026  
**Issued By:** Dana Ortiz, Director of Clinical Analytics, PacificCare Health Plan  
**Intended Respondent:** SmartPrior Solutions, Inc.  

> Purpose: Assess whether SmartPrior Solutions’ AI‑enabled prior authorization platform complies with SB 1120’s requirements when used for PacificCare members.[file:2][web:96][web:91]

---

## Section 1 – Basic Information

1. **Organization Name:** SmartPrior Solutions, Inc.  
2. **Contact for SB 1120 Compliance:**  
   - Name: Michael Chen  
   - Title: VP, Regulatory & Clinical Affairs  
   - Email: mchen@smartprior.ai  
3. **Services Provided to PacificCare:**  
   - AI‑enabled prior authorization triage and decision support for selected inpatient and outpatient services.  

---

## Section 2 – Description of AI / Algorithmic Tools

4. **Tools Used:**

   - SmartPrior Core (v3.2) – proprietary ML model plus rules engine used to score and route prior auth requests for PacificCare’s California lines of business.  

5. **Use for Medical‑Necessity‑Based Review:**  
   - Yes. SmartPrior Core evaluates requests against clinical criteria and guidelines that relate to medical necessity, but is configured for PacificCare as a **triage and recommendation tool only**, not as a final decision‑maker.  

[web:96][web:101]

---

## Section 3 – Medical Necessity Decision‑Making

6. **Final Decision Authority:**  
   - SmartPrior is **not configured to issue final denials, delays, or modifications** for PacificCare. All adverse determinations based on medical necessity are made by PacificCare’s licensed clinicians.[web:96][web:143]  

7. **Clinician Decision Process:**  
   - SmartPrior outputs a risk score and suggested routing:
     - “Auto‑approve” (for clearly guideline‑conforming, low‑risk cases).  
     - “RN review recommended.”  
     - “Physician review recommended.”  
   - For PacificCare:
     - The “auto‑approve” path is restricted to approvals only.  
     - Any potential denial, delay, or modification is routed to PacificCare’s UR clinician queues for review and final decision.  

8. **Policies & Procedures:**  
   - SmartPrior provided PacificCare with:
     - Excerpts from its “Client Configuration Guide – Clinical Decision Support Mode.”  
     - A policy statement clarifying that SmartPrior is not to be configured for AI‑only denials in jurisdictions with physician‑only rules (including California SB 1120).  

[web:91][web:101]

---

## Section 4 – Individualized vs. Group‑Only Data

9. **Individualized Inputs:**  
   - For PacificCare, SmartPrior uses:
     - Member diagnosis codes, procedure codes, age, and relevant comorbidities.  
     - Key clinical fields from attached notes (e.g., prior treatment, imaging findings).  
     - Provider type and site of care.  

10. **Avoiding Group‑Only Decisions:**  
   - While SmartPrior’s ML models were trained on aggregated data, production decisions for PacificCare are always based on **individual requests** that include member‑specific inputs.  
   - SmartPrior configuration explicitly prohibits rules that would make a determination “solely on group datasets” without case‑level clinical data, in line with SB 1120.[web:96][web:93][web:143]  

---

## Section 5 – Configuration, Overrides, and Logging

11. **Configuration Controls:**  
   - PacificCare can:
     - Disable any “deny” action within SmartPrior.  
     - Limit auto‑approvals to pre‑defined clinical scenarios approved by PacificCare’s medical directors.  
   - SmartPrior cannot be used to auto‑deny for PacificCare under the current contract and configuration.  

12. **Logging Practices:**  
   - SmartPrior logs:
     - Case ID, timestamp, and SmartPrior score.  
     - Recommended routing (auto‑approve/RN/MD).  
     - Whether the PacificCare clinician followed or overrode the recommendation (if that data is passed back).  

13. **Audit & Inspection:**  
   - SmartPrior agrees that:
     - Model documentation, rule sets, and configuration files relevant to PacificCare are available for review by PacificCare and, as required, California regulators, subject to appropriate confidentiality protections.[web:96][web:130]  

---

## Section 6 – Non‑Discrimination & Fair Application

14. **Fairness Testing:**  
   - SmartPrior performs periodic fairness analysis across major demographic factors (e.g., age, sex, geographic region) on de‑identified datasets.  
   - For PacificCare, SmartPrior commits to support audits of model performance across key subgroups upon request.  

15. **Supporting Documentation:**  
   - SmartPrior provided:
     - A high‑level fairness testing summary report (2025).  
     - A description of its validation methodology for new model releases.  

[web:91][web:101]

---

## Section 7 – Attestations

16. **Authorized Representative Statement:**

> “We attest that the information provided in this questionnaire is accurate to the best of our knowledge. We understand that PacificCare Health Plan relies on our responses to meet its obligations under California SB 1120 and related regulations, and we will promptly notify PacificCare if any material changes occur in our use or configuration of AI tools for utilization review.”

- **Name / Title:** Michael Chen, VP Regulatory & Clinical Affairs  
- **Date:** March 22, 2026  
- **Signature:** _/s/ Michael Chen (electronic)_  

---

**End of Questionnaire**
