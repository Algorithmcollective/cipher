# SB 1120 – AI System Configuration & Controls Checklist for PacificCare Health Plan

**Document Title:** SB 1120 AI System Configuration & Controls Checklist for PacificCare Health Plan  
**Version:** v1.0  
**Date Completed:** March 1, 2026  
**Prepared By:** Dana Ortiz, Director of Clinical Analytics  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Confirm that AI, algorithms, and related software used by PacificCare Health Plan for UR/UM and related claims functions are configured so they cannot deny, delay, or modify services based on medical necessity, and that licensed clinicians retain decision‑making authority.[web:96][web:98][web:106]

---

## 1. Tool Inventory & Ownership

| Tool ID | Tool Name | Vendor / Internal | Primary Use (UR/UM/Claims) | Business Owner | Technical Owner |
|--------|-----------|-------------------|----------------------------|----------------|-----------------|
| T1 | SmartPrior | External vendor | UR – Prior Authorization | VP, Utilization Management | Director, Clinical Analytics |
| T2 | StaySense | Internal | UM – Concurrent Review | VP, Utilization Management | Director, Inpatient Analytics |
| T3 | ClaimEdit360 | External vendor | Claims – Post‑payment Review | VP, Claims Operations | Director, Claims Systems |

[file:2][web:101]

---

## 2. Prohibited Auto‑Decision Logic (Medical Necessity)

### 2.1 Auto‑Decision Controls

| Check ID | Tool ID | Configuration / Behavior | Compliant? (Y/N/N‑A) | Notes / Required Fix |
|----------|---------|-------------------------|----------------------|----------------------|
| 2.1.1 | T1 | SmartPrior cannot auto‑deny prior‑auth requests; all potential denials route to RN/MD queue. | Y | Legacy auto‑deny rules for high‑cost imaging disabled Feb 2026. |
| 2.1.2 | T1 | SmartPrior may auto‑approve only Tier 1 low‑risk cases that fully meet clinical criteria. | Y | Configuration reviewed; approvals only, no downgrades. |
| 2.1.3 | T3 | ClaimEdit360 cannot auto‑reduce payment where edits embed medical‑necessity logic without clinician sign‑off. | Partial | Some bundling edits still auto‑apply; remediation ticket CE‑124 to require MD review for selected rule sets. |

[web:96][web:98][web:126]

---

## 3. Human‑in‑the‑Loop & Documentation

### 3.1 Clinician Decision Capture

| Check ID | Area | Requirement | Compliant? | Notes |
|----------|------|-------------|------------|-------|
| 3.1.1 | Prior Auth | UR platform records MD/RN decision‑maker for any denial, delay, or modification based on medical necessity. | Y | Sample of 50 denials shows named MD; a few RN decisions escalated appropriately. |
| 3.1.2 | Concurrent/Retro Review | Inpatient UM system requires MD sign‑off for reduction of approved days; system blocks closure without MD signature. | Y | Verified in StaySense configuration and sample charts. |
| 3.1.3 | Delegated UR | Delta Medical Group provides clinician decision logs; SouthBay IPA currently provides only aggregate attestations. | Partial | Delegation team to obtain detailed logs or require tooling changes from SouthBay IPA. |

[web:96][web:101][web:114]

---

## 4. Patient‑Specific Inputs & Limits on Group‑Only Data

### 4.1 Individualized Review

| Check ID | Tool ID | Requirement | Compliant? | Notes |
|----------|---------|-------------|------------|-------|
| 4.1.1 | T1 | SmartPrior uses member‑level clinical history, provider notes, and guidelines; not group averages alone. | Y | Vendor documentation and internal validation confirm patient‑specific inputs. |
| 4.1.2 | T2 | StaySense flags rely on LOS and case‑specific data; not solely group benchmarks. | Y | Outlier scoring uses patient LOS vs. norms plus comorbidities. |
| 4.1.3 | T3 | ClaimEdit360 still relies heavily on pattern‑based rules; some edits approximate group‑based medical‑necessity judgments. | Partial | Risk flagged; part of CE‑124 remediation. |

[web:96][web:98][web:106]

---

## 5. Audit Logging & Transparency

### 5.1 Logging

| Check ID | Area | Requirement | Compliant? | Notes |
|----------|------|-------------|------------|-------|
| 5.1.1 | All Tools | AI/algorithm outputs and routing decisions logged with timestamps and case IDs. | Y | Logs available for SmartPrior and StaySense; ClaimEdit360 logs rule IDs per claim. |
| 5.1.2 | All Tools | Logs show when clinicians override AI recommendations. | Partial | SmartPrior records overrides; ClaimEdit360 lacks structured override field—enhancement request opened. |

### 5.2 Inspectability

- SmartPrior and StaySense configuration documents are stored in the AI Governance drive and can be shared for regulator audits as needed.[web:94][web:130]  
- ClaimEdit360 vendor has agreed to provide rule logic disclosures under NDA upon regulator request.  

---

## 6. Overall Assessment & Remediation Plan

- Overall status: **Partial alignment** with SB 1120 configuration requirements. Most UR workflows are compliant; remaining gaps relate to ClaimEdit360’s use of rules that embed medical‑necessity logic without clinician sign‑off and limited transparency into SouthBay IPA’s delegated UR system.[file:2][web:96][web:98]  

**Key Remediations:**

- **CE‑124:** Reconfigure ClaimEdit360 so that clinically driven bundling/appropriateness edits require MD review and documentation before payment reduction. Owner: Director, Claims Systems. Target: June 30, 2026.  
- **DEL‑207:** Require SouthBay IPA to provide case‑level clinician decision logs or to modify its UR platform to record and share clinician decision‑maker info. Owner: Delegation Oversight. Target: September 30, 2026.  

---

**End of Checklist**
