# SB 1120 Training Materials – Clinical & Claims Staff for PacificCare Health Plan

**Document Title:** SB 1120 Training Materials – Clinical & Claims Staff for PacificCare Health Plan  
**Version:** v1.0  
**Last Updated:** March 15, 2026  
**Owner:** Lisa Martinez, Director of Clinical Education  
**Audience:** UM nurses, medical directors, prior auth coordinators, claims examiners, appeals/grievance team  

> Purpose: Provide PacificCare staff with practical guidance on SB 1120, our Physician‑Only Medical Necessity Policy, and the appropriate use of AI tools like SmartPrior, StaySense, and ClaimEdit360 in coverage decisions.[file:2][web:98][web:133]

---

## 1. Training Objectives

By the end of this 60‑minute session, participants will be able to:

- State that **only licensed clinicians** (physicians or other qualified professionals) may make medical‑necessity determinations for PacificCare members.[web:98][web:133]  
- Describe how SmartPrior and StaySense support – but do not replace – clinician review.  
- Recognize when to escalate a case to a physician, especially when an AI tool suggests “deny” or “not medically necessary.”  
- Document decisions and AI involvement in a way that supports compliance and audits.  

---

## 2. Slide / Module Outline

### Module 1 – What Is SB 1120 and Why It Matters

- SB 1120 (“Physicians Make Decisions Act”) limits how health plans can use AI in utilization review and management.  
- Key rule: AI, algorithms, and similar tools **cannot deny, delay, or modify services based, in whole or in part, on medical necessity**; a licensed clinician must make that call after reviewing the member’s specific clinical situation.[web:96][web:133]  

### Module 2 – PacificCare’s Physician‑Only Medical Necessity Policy

- PacificCare policy highlights:
  - All adverse determinations for medical necessity are made and documented by a physician or qualified clinician.  
  - AI tools such as SmartPrior and StaySense provide **decision support**, not final decisions.  
- Staff must never tell a member or provider that “the system” or “the algorithm” denied their request; denials are clinician decisions.  

### Module 3 – How Our AI Tools Work Here

- **SmartPrior:**  
  - Triage only; can auto‑approve simple, clearly appropriate cases.  
  - Cannot auto‑deny; any potential denial is routed to an RN/MD for review.[file:2][web:101]  
- **StaySense:**  
  - Flags long inpatient stays for review; does not itself shorten or deny days.  
- **ClaimEdit360:**  
  - Flags claims for potential edits; clinical payment reductions must be reviewed by a clinician.  

Staff are shown screenshots of each tool’s interface with “What this means” callouts.  

### Module 4 – Escalation Rules & Edge Cases

- Escalate to a physician when:
  - AI suggests that requested services are “not medically necessary.”  
  - The case involves complex comorbidities or unclear guidelines.  
  - The requesting provider strongly disagrees with an AI‑supported recommendation.  
- If a nurse or claims examiner feels pressured to follow an AI suggestion that seems wrong, they are instructed to **stop and escalate** to a medical director.  

### Module 5 – Documentation & Audit Readiness

- For any denial, delay, or modification based on medical necessity, staff must ensure that:
  - The clinician decision‑maker is recorded in the UR or claims system.  
  - Clinical rationale and guidelines are summarized in notes.  
  - AI outputs used are referenced as “SmartPrior recommendation,” “StaySense flag,” etc., not as the decision‑maker.[web:96][web:101]  

---

## 3. Job Aid – “Do / Don’t” Quick Reference

| Situation | You **May** | You **May Not** |
|----------|-------------|-----------------|
| SmartPrior scores case as “Tier 1 – meets criteria” | Approve if all required data is present and the case fits Tier 1 rules. | Deny solely because SmartPrior’s score is low or because the model “doesn’t like” the request. |
| SmartPrior suggests “route to MD – possible not medically necessary” | Gather missing info and route to MD; log SmartPrior suggestion. | Send denial without MD review or document “denied by SmartPrior.” |
| ClaimEdit360 flags claim for potential bundling reduction | Route to clinical reviewer or coding specialist to confirm if reduction is clinically and contractually appropriate. | Let ClaimEdit360 auto‑reduce payment when the rule is effectively a medical‑necessity judgment. |

[web:98][web:133][web:136]

A one‑page PDF of this table is distributed as a desk reference card.  

---

## 4. Scenario Exercises

**Scenario 1 – High‑Cost Imaging Request**

- SmartPrior labels the case “Tier 3 – route to MD, likely not medically necessary.”  
- Question: “You are the UM nurse. What do you do?”  
- Expected answer:
  - Ensure the clinical record is complete.  
  - Route to MD review.  
  - Document SmartPrior’s recommendation as input; MD makes final call and documents rationale.  

**Scenario 2 – Inpatient Stay Flagged by StaySense**

- StaySense flags a 7‑day stay as extended.  
- Expected answer: Physician UM reviewer evaluates clinical notes and either approves continued stay or denies extra days with documented reasoning; AI flag alone is not grounds for denial.  

**Scenario 3 – ClaimEdit360 Suggests Recoupment**

- ClaimEdit360 flags a claim for a bundled service.  
- Expected answer: Claims examiner sends to clinical reviewer; if medical‑necessity rationale is involved, MD decision and notes are required before recoupment.  

---

## 5. Attendance & Acknowledgment

- Training sessions logged in the Learning Management System with:
  - Date, trainer, list of attendees.  
- Each attendee signs electronic acknowledgment:

> “I understand that AI tools used by PacificCare cannot make final medical‑necessity decisions. I will follow escalation rules to licensed clinicians and accurately document decisions in our systems.”  

Copies of acknowledgments are stored for audit purposes.[web:88][web:136]  

---

**End of Training Materials**
