# SB 1120 Compliance Monitoring & Periodic Audit Plan for PacificCare Health Plan

**Document Title:** SB 1120 Compliance Monitoring & Periodic Audit Plan for PacificCare Health Plan  
**Version:** v1.0  
**Effective Date:** April 1, 2026  
**Owner:** Rachel Gomez, VP Compliance & Audit  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Define how PacificCare will monitor, test, and periodically audit its use of AI, algorithms, and related software tools (SmartPrior, StaySense, ClaimEdit360, and delegated UR platforms) in UR/UM and claims functions to ensure ongoing compliance with SB 1120.[file:2][web:96][web:91]

---

## 1. Monitoring Objectives

PacificCare’s SB 1120 monitoring program seeks to:

- Verify that licensed physicians or qualified clinicians, not AI tools, make all medical‑necessity determinations for PacificCare members.[web:96][web:98]  
- Confirm that SmartPrior, StaySense, and ClaimEdit360 operate in a **support‑only** capacity and do not auto‑deny, delay, or modify services based on medical necessity.  
- Ensure tools rely on individualized member data and are applied fairly across populations.  
- Maintain a defensible record of controls and testing for DMHC/DOI audits and onsite medical surveys.[web:96][web:106][web:109]  

---

## 2. Monitoring Activities & Frequency

| Activity | Description | Frequency | Primary Owner |
|---------|-------------|-----------|---------------|
| A1 – UR File Sampling | Sample UR cases (prior auth, concurrent, retrospective) where SmartPrior or StaySense were used. | Quarterly | UM Quality Lead |
| A2 – Claims Sampling | Sample claims where ClaimEdit360 applied or recommended clinical edits. | Quarterly | Claims QA Manager |
| A3 – Configuration Review | Review configurations for SmartPrior, StaySense, and ClaimEdit360 (including rule changes). | Annually + post‑major update | Director, Clinical Analytics |
| A4 – Delegation Oversight | Review UR samples and tool documentation from Delta Medical Group and SouthBay IPA. | Annually + for‑cause | Delegation Oversight Manager |
| A5 – Incident & Complaint Review | Analyze SB 1120‑tagged incidents/complaints (e.g., “AI denial” complaints). | Quarterly | Compliance & Risk |

[file:2][web:96][web:105][web:109]

---

## 3. Sampling Methodology

### 3.1 UR Case Sampling

- **Frame:** All prior‑auth and concurrent review cases for California members where SmartPrior or StaySense were invoked.  
- **Sample Size:**  
  - 150 UR cases per quarter (100 prior auth, 50 concurrent), stratified across Commercial, Individual, and MA lines.  

For each sampled case, auditors verify:

- Presence of a documented clinician decision‑maker for any denial, delay, or modification based on medical necessity.  
- Evidence that SmartPrior/StaySense were used as decision support, not as final decision‑makers (e.g., MD notes referencing AI but making independent judgment).  

[web:96][web:93]

### 3.2 Claims Sampling

- **Frame:** Claims where ClaimEdit360 applied or recommended clinically driven edits (e.g., bundling, “not clinically appropriate”).  
- **Sample Size:**  
  - 75 claims per quarter.  

Auditors confirm:

- That any payment reduction tied to medical‑necessity logic was reviewed and signed off by a clinician (medical director or coding specialist under clinical oversight).  
- That ClaimEdit360 did not auto‑reduce payment without clinician review in those scenarios.  

[file:2][web:96][web:152]

---

## 4. Audit Procedures & Checklists

For each UR or claims case sampled:

1. Check system fields for decision‑maker:
   - Name, credentials, and role of the clinician.  
2. Review case notes:
   - Confirm individualized clinical information and provider rationale were considered.  
   - Confirm guidelines and criteria are cited appropriately.  
   - Confirm AI outputs are labeled as “SmartPrior recommendation” or “StaySense flag,” not “system decision.”[file:2][web:96][web:101]  
3. For any issue, classify severity and document in the SB 1120 audit log.  

PacificCare uses standard checklists aligned with its Physician‑Only Medical Necessity Policy, AI‑Assisted SOPs, and Configuration Checklist.  

---

## 5. Issue Classification & Remediation

- **Minor Deviation:** Documentation incomplete but clinician decision clear.  
- **Significant Deviation:** AI recommendation appears to have been followed as a denial/modification without clear clinician review.  
- **Critical Non‑Compliance:** Evidence that AI or rules auto‑denied or modified services based on medical necessity with no clinician involvement.  

For Significant or Critical findings:

- Open a corrective action plan (CAP) with:
  - Root cause, owner, milestones, and target dates.  
- Consider:
  - Temporarily disabling problematic rules or tool features.  
  - Adding or tightening escalation requirements.  
  - Providing targeted retraining to affected staff.  

[web:96][web:152]

---

## 6. Reporting & Regulator Readiness

- **Quarterly Reports:**
  - Summaries of A1–A5 activities, key metrics (e.g., percentage of sampled cases fully compliant), and CAP status.  
  - Distributed to the Compliance Committee, CMO, and relevant business leaders.  

- **Regulator Audits:**
  - PacificCare maintains:
    - This monitoring plan.  
    - Completed checklists and sampled case documentation.  
    - Up‑to‑date AI tool configuration documents and vendor DDQs.  
  - These materials support DMHC/DOI periodic onsite medical surveys and any focused SB 1120 reviews.[web:96][web:106][web:109]  

---

**End of Plan**
