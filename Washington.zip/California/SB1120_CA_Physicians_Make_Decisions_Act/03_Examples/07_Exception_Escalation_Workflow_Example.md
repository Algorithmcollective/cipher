# SB 1120 Exception & Escalation Workflow for PacificCare Health Plan

**Document Title:** SB 1120 Exception & Escalation Workflow for PacificCare Health Plan  
**Version:** v1.0  
**Effective Date:** March 1, 2026  
**Owner:** Jamie Patel, MD – Senior Medical Director, Utilization Management  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Describe how PacificCare handles cases where AI‑enabled tools (SmartPrior, StaySense, ClaimEdit360) conflict with clinician judgment or provider concerns, ensuring that licensed clinicians make all final medical‑necessity determinations.[file:2][web:96][web:95]

---

## 1. When This Workflow Applies

PacificCare invokes this workflow when:

- SmartPrior suggests that a requested service is “likely not medically necessary,” but the treating provider submits strong clinical justification.  
- A UM nurse believes SmartPrior or StaySense is missing important patient‑specific context.  
- ClaimEdit360 proposes a clinical payment reduction that the reviewing clinician believes would inappropriately deny needed care.  
- A member or provider complains that “the algorithm” or “the system” denied coverage.[web:95][web:119]  

---

## 2. Roles

- **Treating Provider:** Submits prior auth requests and additional clinical information; may request exception review.  
- **UM Nurse / Initial Reviewer:** Reviews AI recommendations and guidelines; flags exception cases.  
- **UM Physician / Medical Director:** Makes final medical‑necessity determination in exception cases.  
- **Appeals & Grievances Team:** Manages formal appeals and member/provider complaints.  

[file:2][web:101]

---

## 3. Step‑by‑Step Exception Handling

### Step 1 – Identify the Conflict

1. Example triggers:
   - SmartPrior routes a high‑cost imaging request as “Tier 3 – likely not medically necessary,” but the ordering specialist documents atypical clinical features.  
   - StaySense flags an extended inpatient stay, yet the attending physician documents ongoing unstable status.  
2. UM nurse selects the “SB 1120 Exception – MD Review Required” flag in the UR system and notes the reasons.  

### Step 2 – Gather Additional Information

1. UM nurse:
   - Requests any missing test results, consult notes, or imaging reports from the provider.  
   - Captures SmartPrior or StaySense outputs (scores, suggested routing) in the case notes.  
   - Summarizes why the AI recommendation may not reflect the member’s specific circumstances.  

[web:96][web:93]

### Step 3 – Escalate to Physician

1. Case is routed to the assigned UM physician or, for complex specialties, to a physician with relevant expertise.  
2. The UM physician:
   - Reviews the full clinical record, including treating provider’s rationale.  
   - Considers SmartPrior/StaySense recommendations as **supporting information only**.  
   - Makes an independent medical‑necessity determination (approve, deny, modify).  
   - Documents:
     - Their decision and rationale.  
     - Whether they agreed or disagreed with the AI recommendation and why.  

Per SB 1120, this physician decision is controlling; SmartPrior or StaySense cannot override it.[web:96][web:95][web:119]  

### Step 4 – Communicate Outcome

1. UR staff send the required decision letter to the member and provider.  
2. Letters state that:
   - A PacificCare physician (or qualified clinician) reviewed the case and made the medical‑necessity determination.  
   - AI tools may have been used as decision support but did **not** make the final decision.  

Staff are instructed to avoid telling callers that “the algorithm denied your care”; instead they reference the physician decision and offer appeal rights.  

---

## 4. Special Cases – Appeals & Complaints

- **Appeals:**  
  - Appeal cases that involve AI‑assisted workflows are assigned to a physician who did not participate in the initial decision whenever possible.  
  - The appeal physician conducts a fresh review of medical necessity, considering any new information and noting any continued disagreement with AI‑supported suggestions.  

- **Complaints about AI Denials:**  
  - Complaints alleging “AI denial” are coded with an SB 1120 tag and evaluated to ensure a physician truly made the decision.  
  - If investigation shows over‑reliance on AI, PacificCare treats it as an incident, updates training, and may adjust tool configurations.  

[web:95][web:136]

---

## 5. Logging & Continuous Improvement

- Each SB 1120 exception is logged with:
  - Case ID, line of business, type of service.  
  - AI recommendation vs. physician decision.  
  - Outcome (approved, approved with modifications, denied).  
- Quarterly, the UM Leadership and Clinical Analytics teams:
  - Review exception logs to identify patterns where SmartPrior or StaySense frequently disagree with physician judgment.  
  - Work with vendors and internal teams to refine criteria or adjust AI configurations.  

Findings feed into PacificCare’s SB 1120 Compliance Monitoring & Periodic Audit Plan.[web:93][web:101]  

---

**End of Workflow**
