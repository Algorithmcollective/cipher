# SB1120 Discovery Call Script – Healthcare AI (Medical Necessity)

Purpose: Gather information required to prepare SB1120 documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: AI Usage & Decision Mapping

Say:
“I need to understand where AI or automated tools touch medical necessity decisions.”

Ask:

- Organization name
- Lines of business
- Functions using AI (prior auth, UM, claims)
- List of tools
- Vendor vs internal
- Inputs used
- Outputs produced
- Whether any tool can deny, delay, or modify services
- Delegated entities using AI

---

## 🧾 Deliverable: Physician-Only Policy

Ask:

- Current written policy exists?
- Who owns policy
- Who can make medical necessity decisions
- Documentation requirements
- Delegated entity expectations
- Monitoring approach

---

## 🧾 Deliverable: AI-Assisted Clinical Workflow

Ask:

- Prior auth intake methods
- AI triage behavior
- Auto-approval rules
- Denial routing process
- Concurrent review workflow
- Retrospective review workflow
- Documentation steps

---

## 🧾 Deliverable: System Configuration Controls

Ask:

- Can tools auto-deny?
- Can tools auto-modify claims?
- Human-in-the-loop controls
- Clinician capture fields
- Override logging
- Individual vs group data usage
- Configuration review frequency

---

## 🧾 Deliverable: Training Program

Ask:

- Who must be trained
- Training format
- Key topics covered
- Escalation guidance
- Documentation training
- Attendance tracking

---

## 🧾 Deliverable: Vendor Due Diligence

Ask:

- Vendors providing AI
- Tools used per vendor
- Can vendor tools auto-deny?
- Clinician decision capture process
- Configuration controls available
- Audit rights
- Bias / fairness testing

---

## 🧾 Deliverable: Exception & Escalation

Ask:

- When AI conflicts with clinician
- Who flags exception
- Escalation path
- Physician decision documentation
- Appeal handling
- Exception logging

---

## 🧾 Deliverable: Monitoring & Audit

Ask:

- UR sampling approach
- Claims sampling approach
- Configuration review cadence
- Delegation oversight
- Incident tracking
- Reporting recipients

---

## ✅ Closing

Say:
“That gives us what we need to prepare your SB1120 compliance documentation.”