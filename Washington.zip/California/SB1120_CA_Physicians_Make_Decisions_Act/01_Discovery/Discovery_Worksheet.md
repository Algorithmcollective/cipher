# SB1120 Discovery Worksheet

---

## AI Usage & Decision Mapping

Organization Name:
Lines of Business:
AI Functions:
Tools List:
Vendor/Internal:
Inputs:
Outputs:
Auto-Decision Capability:
Delegated Entities:

---

## Physician-Only Policy

Policy Exists:
Policy Owner:
Decision Makers:
Documentation Requirements:
Delegation Expectations:
Monitoring Approach:

---

## Clinical Workflow

Prior Auth Intake:
AI Triage Behavior:
Auto-Approval Rules:
Denial Routing:
Concurrent Review:
Retrospective Review:
Documentation Steps:

---

## System Configuration

Auto-Denials Possible:
Auto-Modifications Possible:
Human Controls:
Clinician Capture:
Override Logging:
Individual Data Use:
Config Review Frequency:

---

## Training

Audience:
Format:
Key Topics:
Escalation Training:
Documentation Training:
Attendance Tracking:

---

## Vendor Due Diligence

Vendors:
Tools:
Auto-Decision Capability:
Clinician Capture:
Config Controls:
Audit Rights:
Bias Testing:

---

## Exception & Escalation

Conflict Identification:
Flag Process:
Escalation Path:
Physician Documentation:
Appeals Handling:
Exception Logging:

---

## Monitoring & Audit

UR Sampling:
Claims Sampling:
Config Reviews:
Delegation Oversight:
Incident Tracking:
Reporting Recipients:

---

## TBD / Follow-Ups

Item:
Owner:
Notes: