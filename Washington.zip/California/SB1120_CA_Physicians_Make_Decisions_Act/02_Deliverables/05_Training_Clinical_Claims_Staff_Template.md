# SB 1120 Training Materials – Clinical & Claims Staff (MASTER TEMPLATE)

**Document Title:** SB 1120 Training Materials – Clinical & Claims Staff for {{PLAN_NAME}}  
**Version:** v{{VERSION}}  
**Last Updated:** {{LAST_UPDATED}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Audience:** UM nurses, medical directors, prior auth staff, claims examiners, appeals/grievance staff  

> Purpose: Provide core content and structure for training clinical and claims staff on SB 1120, the physician‑only medical‑necessity rule, and the allowed/forbidden uses of AI and algorithms in coverage decisions.[web:98][web:105][web:133]

---

## 1. Training Objectives

By the end of this training, participants should be able to:

- Explain SB 1120’s requirement that only licensed clinicians make medical‑necessity determinations.  
- Describe how AI and algorithms may be used as **decision support**, not as final decision‑makers.[web:98][web:133]  
- Identify when a case must be escalated to a physician.  
- Apply {{PLAN_NAME}}’s internal policies and SOPs (CA_02, CA_03, CA_04) in daily work.  

---

## 2. Slide / Module Outline

### Module 1 – What Is SB 1120?

- Plain‑language overview:
  - Who it applies to (health plans/insurers using AI in UR/UM).  
  - Core rule: AI tools **cannot deny, delay, or modify services based on medical necessity**; a licensed clinician must make that determination.[web:96][web:133]  
- Why it was passed (concerns about algorithm‑driven denials).  

### Module 2 – Our Physician‑Only Medical Necessity Policy

- Key points from {{PLAN_NAME}}’s policy (CA_02):
  - Only physicians/qualified clinicians make medical‑necessity calls.  
  - AI outputs are inputs to the decision, not the decision itself.  
- Examples of acceptable vs. unacceptable use.  

### Module 3 – How Our AI Tools Work in Practice

- Short descriptions of each AI/algorithmic tool used in UR/UM and claims.  
- For each: what it can do (triage, summarize, flag) and what it may **not** do (auto‑deny, override MD decisions).[web:98][web:101]  

### Module 4 – Escalation Rules & Edge Cases

- When staff **must escalate** to a physician (e.g., any potential medical‑necessity denial or modification).  
- Handling disagreements between AI recommendations and clinician judgment (physician decision controls).[web:102][web:134]  

### Module 5 – Documentation & Audit Readiness

- How to document clinician decision‑makers and rationale.  
- How to note use of AI tools as decision support.  
- Importance of accurate records for regulators and appeals.  

---

## 3. Job Aid – “Do / Don’t” Quick Reference

| Situation | You **May** | You **May Not** |
|----------|-------------|-----------------|
| AI tool says “low risk – approve” | Approve if criteria met and policy allows auto‑approval. | Deny based solely on AI output. |
| AI tool says “deny” or “not medically necessary” | Use as a prompt to gather more info and escalate to MD. | Send denial without MD review and documentation. |
| ClaimEdit suggests payment reduction | Route to clinician/coding review if based on medical‑necessity logic. | Auto‑reduce payment when underlying logic involves medical necessity. |

[web:98][web:133][web:136]

---

## 4. Scenario Exercises (for Live Training)

Create 3–5 brief scenarios such as:

- A high‑cost imaging request where AI suggests denial.  
- An inpatient stay flagged as an outlier by AI.  
- A claim where the rules engine suggests recoupment.  

For each, include:

- Question: “What should you do next?”  
- Answer key: Reinforce escalation, physician decision, and documentation requirements.  

---

## 5. Attendance & Acknowledgment

- Track attendees (name, role, date) for each session.  
- Include a short acknowledgment statement:
  - “I understand that AI tools cannot make final medical‑necessity decisions and that I must follow escalation rules to licensed clinicians.”  

---

**End of Training Template**
