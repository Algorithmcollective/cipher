# SB 1120 Vendor & Third‑Party AI Due‑Diligence Questionnaire (MASTER TEMPLATE)

**Document Title:** SB 1120 Vendor & Third‑Party AI Due‑Diligence Questionnaire for {{PLAN_NAME}}  
**Version:** v{{VERSION}}  
**Date Issued:** {{DATE_ISSUED}}  
**Issued By:** {{ISSUER_NAME}}, {{ROLE}}  
**Intended Respondent:** {{VENDOR_OR_DELEGATE_NAME}}  

> Purpose: Assess whether vendors, delegated entities, or other third parties that provide AI, algorithmic, or software tools for utilization review (UR), utilization management (UM), or related claims functions comply with California SB 1120’s requirements (physician‑only medical‑necessity decisions, individualized review, no AI‑based denials).[web:96][web:91][web:101]

---

## Section 1 – Basic Information

1. **Organization Name:**  
2. **Contact for SB 1120 Compliance (Name, Title, Email):**  
3. **Services Provided to {{PLAN_NAME}}:** (e.g., UR platform, prior auth triage, claims editing, delegated UR/UM).  

---

## Section 2 – Description of AI / Algorithmic Tools

4. List each AI, algorithm, rules engine, or “other software tool” you use for UR/UM or related claims functions for {{PLAN_NAME}} members, including:  
   - Tool name and version.  
   - Whether it is proprietary or third‑party.  
   - Primary use (prior auth, concurrent review, retrospective review, claims, other).[web:96][web:101]  

5. For each tool, indicate whether it is used to **review requests for covered health services based, in whole or in part, on medical necessity.**[web:96][web:143]  

---

## Section 3 – Medical Necessity Decision‑Making

6. Please confirm whether **any** of your tools can issue a final decision that denies, delays, or modifies services **based on medical necessity** without a licensed physician or qualified clinician making and documenting the determination. (Yes/No; if Yes, describe.)[web:96][web:143]  

7. Describe your process for ensuring that a licensed physician or qualified clinician is the final decision‑maker for any medical‑necessity determination (prospective, concurrent, or retrospective). Include:  
   - Roles and credentials.  
   - How decisions are documented.  

8. Provide copies or excerpts of your written policies and procedures that implement these requirements (or link to them).  

---

## Section 4 – Individualized vs. Group‑Only Data

9. Explain how your AI/algorithmic tools ensure that UR/UM decisions are based on **individual enrollee** information, including:  
   - Member’s medical and clinical history.  
   - The treating provider’s recommendation.  
   - Other clinical information in the member’s record.[web:96][web:93][web:101]  

10. Confirm that your tools **do not base determinations solely on group datasets** (e.g., population averages) as prohibited by SB 1120. Describe any safeguards in place.[web:96][web:143]  

---

## Section 5 – Configuration, Overrides, and Logging

11. Can {{PLAN_NAME}} configure or constrain your tools to prevent auto‑denials or modifications based on medical necessity? Describe available configuration controls.[web:91][web:101]  

12. How do you log:  
    - AI/algorithm outputs for specific cases?  
    - Clinician overrides of AI recommendations?  
    - Changes to clinical rules or models?  

13. Are your tools and documentation **available for audit/inspection** by {{PLAN_NAME}} and California regulators (e.g., DMHC/DOI) as required? (Yes/No; details.)[web:96][web:130]  

---

## Section 6 – Non‑Discrimination & Fair Application

14. Briefly describe how you test your AI/algorithmic tools to ensure they do not **discriminate** (directly or indirectly) against enrollees, and that they are fairly and equitably applied.[web:96][web:91]  

15. Provide any summary results, independent assessments, or certifications relevant to fairness, bias, or validation.  

---

## Section 7 – Attestations

16. Authorized representative statement:

> “We attest that the information provided in this questionnaire is accurate to the best of our knowledge. We understand that {{PLAN_NAME}} relies on our responses to meet its obligations under California SB 1120 and related regulations.”

- **Name / Title:**  
- **Date:**  
- **Signature (electronic acceptable):**  

---

**End of Questionnaire**
