# Physician‑Only Medical Necessity Policy (MASTER TEMPLATE)

**Policy Title:** Physician‑Only Medical Necessity Policy for {{PLAN_NAME}}  
**Version:** v{{POLICY_VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Approved By:** {{APPROVER_NAME}}, {{APPROVER_TITLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act (Health care coverage: utilization review)  

> Purpose: This policy establishes that medical‑necessity determinations for {{PLAN_NAME}} members are made only by licensed physicians or other qualified licensed healthcare professionals, and that AI, algorithms, or software tools may support but may not deny, delay, or modify services based, in whole or in part, on medical necessity.[web:96][web:98][web:101]

---

## 1. Scope

- This policy applies to all utilization review (UR) and utilization management (UM) activities conducted by {{PLAN_NAME}} and any delegated entities, including:
  - Prior authorization.  
  - Concurrent and retrospective review.  
  - Any claims adjudication steps that rely on medical‑necessity determinations.[web:96][web:105]  
- It covers any AI, algorithm, rules engine, or other software tool used in connection with these activities.  

---

## 2. Policy Statement – Physician‑Only Medical Necessity

- Determinations of **medical necessity** for health‑care services to {{PLAN_NAME}} members shall be made **only** by:
  - A licensed physician, or  
  - Another licensed healthcare professional who is competent to evaluate the specific clinical issues involved in the requested services.[web:96][web:98]  
- No individual or automated system, other than such licensed professionals, may **deny, delay, or modify** requests for authorization of health‑care services for reasons of medical necessity.[web:96][web:90][web:118]  

---

## 3. Role of AI, Algorithms, and Software Tools

- AI, algorithms, and other software tools **may assist** in utilization review and claims processing by:
  - Triaging or flagging cases for review.  
  - Summarizing clinical records.  
  - Suggesting guideline‑based next steps.  
  - Identifying potential errors or fraud.[web:98][web:115]  
- These tools **may not**:
  - Issue final decisions that deny, delay, or modify services based on medical necessity.  
  - Override or replace the documented judgment of a licensed physician or qualified clinician.  

All AI‑assisted workflows must clearly identify the physician or licensed clinician responsible for the final medical‑necessity determination.  

---

## 4. Responsibilities

- **Chief Medical Officer (CMO) / Medical Director:**  
  - Owns this policy, ensures that medical directors and clinical staff adhere to it, and approves any clinical criteria used in UR/UM.  
- **Utilization Management Leadership:**  
  - Ensures that UR/UM procedures, templates, and automated tools reflect this policy and document the responsible clinician for each decision.  
- **Information Technology / Analytics:**  
  - Configures AI and software tools so they cannot issue medical‑necessity denials, delays, or modifications without clinician review and sign‑off.  
- **Delegated Entities (Medical Groups, IPAs, TPAs):**  
  - Must adopt policies and procedures consistent with this policy and SB 1120 as a condition of delegation.[web:96][web:105]  

---

## 5. Documentation Requirements

- Every denial, delay, or modification **based on medical necessity** must:
  - Identify the licensed physician or qualified clinician who made the determination.  
  - Document the clinical rationale, criteria applied, and supporting information considered (including the treating provider’s recommendation).[web:96][web:101]  
- AI or software outputs used in support of the decision should be noted as decision support, not the decision‑maker.  

---

## 6. Monitoring and Compliance

- {{PLAN_NAME}} will periodically audit UR/UM decisions and sample claims to verify:
  - That a licensed clinician is documented as the decision‑maker for medical‑necessity determinations.  
  - That AI‑driven tools are operating in a support/triage role only.[web:93][web:101]  
- Violations of this policy may result in corrective actions, system reconfiguration, retraining, or sanctions for delegated entities, up to termination of delegation agreements.  

---

**End of Policy**
