# AI‑Assisted Utilization Review SOPs – Clinical Workflow (MASTER TEMPLATE)

**Document Title:** AI‑Assisted Utilization Review SOPs – Clinical Workflow for {{PLAN_NAME}}  
**Version:** v{{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Define standard operating procedures (SOPs) for how AI and other software tools may assist, but not replace, licensed clinicians in utilization review (UR) and utilization management (UM) workflows at {{PLAN_NAME}}, consistent with SB 1120.[web:96][web:105][web:101]

---

## 1. Overview & Principles

- AI tools may support UR/UM by triaging, summarizing, and flagging cases, but **final coverage and medical‑necessity determinations must always be made by a licensed physician or qualified healthcare professional.**[web:96][web:98]  
- These SOPs apply to all UR/UM use of AI, algorithms, and rules engines in prior authorization, concurrent review, and retrospective review.  

Key principles:

- **Human‑in‑the‑loop:** AI never operates without clinician oversight for medical‑necessity decisions.  
- **Patient‑specific:** Any AI‑assisted review must consider the individual enrollee’s clinical circumstances and provider recommendations, not just group datasets.[web:96][web:101]  

---

## 2. Prior Authorization Workflow (AI‑Assisted, Physician‑Final)

### 2.1 Standard Prior Auth Flow

1. **Intake:**  
   - Request received via portal, EDI, fax, or phone; core data fields captured (diagnosis, procedure codes, clinical notes).  

2. **AI Triage (Support Only):**  
   - AI tool {{AI_TOOL_NAME}} evaluates request using configured criteria and historical patterns.  
   - Output: risk score and one of the following routing recommendations:  
     - “Auto‑approve – clearly meets criteria.”  
     - “Route to RN review.”  
     - “Route to physician review.”  

3. **Low‑Risk Auto‑Approval (If Allowed):**  
   - If criteria and this SOP allow auto‑approval, the case may be approved **without clinician review**, but **never denied, delayed, or modified** based on medical necessity.[web:96][web:98]  

4. **Clinical Review (All Non‑Auto‑Approvals):**  
   - RN or physician reviews clinical documentation, AI outputs, and applicable guidelines.  
   - For any **denial, delay, or modification** based on medical necessity, a licensed physician or qualified clinician competent in the clinical issues must:
     - Review the file (including the treating provider’s recommendation).[web:96][web:101]  
     - Make and document the decision.  

5. **Documentation & Communication:**  
   - Record decision‑maker, rationale, criteria, and any AI inputs used as decision support.  
   - Issue UR notice letters compliant with regulatory requirements.  

### 2.2 Prohibited Configurations

- AI or rules that **auto‑deny**, downgrade, or curtail services based on medical‑necessity criteria without clinician review.  
- Workflows where clinician “review” is optional or only occurs on appeal.  

---

## 3. Concurrent & Retrospective Review Workflow

### 3.1 Concurrent Review (Inpatient Stays)

1. **Data Collection:** LOS, DRG/diagnosis, comorbidities, progress notes.  
2. **AI Flagging:** AI tool identifies potential “outlier” stays or variance from guidelines.  
3. **Physician Review:** Only a licensed physician or appropriate clinician may decide to:
   - Approve continued stay.  
   - Modify or deny additional days based on medical necessity.[web:96][web:105]  
4. **Documentation:** Record MD decision, rationale, and AI support used.  

### 3.2 Retrospective Review

- Similar steps: AI may flag for post‑payment review, but any recoupment or denial based on medical necessity requires clinician determination and documentation.  

---

## 4. Roles & Responsibilities in AI‑Assisted UR

| Role | Responsibilities |
|------|------------------|
| Medical Directors / Physicians | Make and document final medical‑necessity decisions; oversee clinical criteria and AI use. |
| UM Nurses / Clinicians | Perform initial clinical reviews; escalate to physicians as required. |
| UM Operations | Ensure workflows and systems follow this SOP; maintain documentation. |
| IT / Analytics | Configure AI tools to follow “support‑only” constraints; prevent auto‑denials. |

[web:96][web:101][web:114]

---

## 5. Quality Assurance & Auditing

- Sample prior‑auth and UR cases each quarter to verify:
  - AI recommendations did not substitute for clinician decisions.  
  - Denials/modifications based on medical necessity show a clinician decision‑maker and rationale.  
- Review AI configurations at least annually or after major updates.  

---

**End of SOP**
