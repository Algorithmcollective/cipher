# SB 1120 Exception & Escalation Workflow (MASTER TEMPLATE)

**Document Title:** SB 1120 Exception & Escalation Workflow for {{PLAN_NAME}}  
**Version:** v{{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Define how {{PLAN_NAME}} handles cases where AI/algorithm recommendations conflict with clinician judgment, member/provider concerns, or policy requirements, ensuring that licensed clinicians make final medical‑necessity determinations as required by SB 1120.[web:96][web:95][web:101]

---

## 1. When This Workflow Applies

Trigger this workflow when **any** of the following occur:

- An AI tool suggests denial, delay, or modification for a service the treating provider believes is medically necessary.  
- A UM nurse or claims examiner disagrees with an AI recommendation regarding medical necessity.  
- A member or provider challenges an adverse decision that appears to have been “made by the system.”  
- A clinician believes AI‑assisted criteria do not fit the member’s individual circumstances.[web:95][web:119]  

---

## 2. Roles

- **Treating Provider:** Submits request and any supporting clinical information; may contest AI‑supported suggestions.  
- **UM Nurse / Initial Reviewer:** Reviews AI output, guidelines, and clinical record; identifies exceptions and escalates.  
- **Utilization Management Physician / Medical Director:** Makes final medical‑necessity decision in exception cases.  
- **Appeals / Grievance Team:** Handles formal appeals and complaints.  

---

## 3. Step‑by‑Step Exception Handling

### Step 1 – Identify the Conflict

1. Reviewer notes that:
   - AI recommendation (e.g., “deny,” “not medically necessary,” “reduce days”) conflicts with the treating provider’s request or clinical judgment, **or**  
   - AI‑driven criteria do not adequately consider the member’s individual clinical situation.  
2. Reviewer flags the case in the UR system as an **“SB 1120 Exception”** (or similar tag).  

### Step 2 – Gather Additional Information

1. Request any missing or clarifying clinical documentation from the provider (if needed).  
2. Capture:
   - AI output (score/recommendation).  
   - Guideline sections or rules involved.  
   - Notes on why the reviewer believes an exception may be appropriate.  

[web:96][web:93]

### Step 3 – Escalate to Physician

1. Route the case, with all documentation and AI outputs, to a designated UM physician or medical director.  
2. The physician:
   - Reviews the full record, provider’s rationale, and AI recommendation.  
   - Makes an **independent medical‑necessity determination** for the member.  
   - Documents the rationale, including whether they **agreed or disagreed** with the AI/tool recommendation.  

Under SB 1120, this physician decision controls and cannot be overridden by AI.[web:96][web:95][web:119]  

### Step 4 – Communicate Outcome

1. Issue required UR notifications to member and provider, clearly indicating that the decision was made by a licensed clinician.  
2. Avoid language suggesting that “the system” or “algorithm” denied care.  

---

## 4. Special Cases – Appeals & Complaints

- If a member or provider appeals an adverse decision they believe was made by AI:
  - Route appeal directly to a physician reviewer **not** involved in the initial decision, where possible.  
  - Physician re‑evaluates medical necessity de novo, considering all available records and any new information.[web:95][web:136]  
  - Document that the appeal decision was made by a licensed clinician, regardless of AI inputs.  

---

## 5. Logging & Continuous Improvement

- Each SB 1120 exception case should be logged with:
  - Case ID, date, line of business.  
  - AI recommendation vs. physician decision.  
  - Whether guidelines or configurations were updated as a result.  
- Periodically review exception patterns to:
  - Adjust criteria or AI configurations that frequently conflict with physician judgment.  
  - Identify training needs for reviewers or providers.  

---

**End of Workflow**
