# California SB 1120 – AI Usage & Medical Necessity Decision Mapping Memo for PacificCare Health Plan

**Report Title:** SB 1120 AI Usage & Medical Necessity Decision Mapping Memo for PacificCare Health Plan  
**Prepared For (Client):** PacificCare Health Plan  
**Prepared By:** Ben Smith, Algorithm Collective LLC  
**Date of Analysis:** January 31, 2026  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – “Physicians Make Decisions Act” (Health care coverage: utilization review)  

> Purpose: This memo documents how PacificCare Health Plan uses AI, algorithms, and software tools in utilization review (UR), utilization management (UM), prior authorization, and claims, and identifies any points where those tools could improperly deny, delay, or modify services based on medical necessity in violation of SB 1120’s physician‑only requirement.[web:96][web:94][web:98]

---

## 1. Executive Summary

### 1.1 Conclusion

- As of January 31, 2026, PacificCare Health Plan appears **partially aligned** with SB 1120. Licensed physicians and nurses make most medical‑necessity determinations, but one legacy claims rules engine and one delegated vendor workflow present **moderate SB 1120 risk**.[web:101][web:109]  
- No system is designed to let AI alone issue final medical‑necessity denials, but in practice an automated claims edit engine and a vendor UR tool can delay or modify payments before a clinician review is clearly documented.  

### 1.2 Key Findings

- AI and algorithmic tools are used to:
  - Triage prior‑auth requests,  
  - Score inpatient admissions for “outlier” risk, and  
  - Apply post‑payment claims edits based on historical patterns.[web:101][web:109]  
- PacificCare’s written UR policies state that only physicians or qualified clinicians make medical‑necessity determinations, but some automated rules effectively act on medical‑necessity criteria before clinician sign‑off is recorded.  
- One delegated medical group uses its own AI‑enabled UR platform; PacificCare has limited documentation of that system’s configuration or guardrails.  

### 1.3 Recommended Next Steps

- Immediately disable or reconfigure any rules that auto‑deny or auto‑modify services or claims **based on medical‑necessity criteria** without a documented clinician decision.  
- Formalize and adopt a physician‑only medical‑necessity policy and AI‑assisted UR SOPs, then push those requirements into vendor and delegate contracts.  
- Stand up a periodic audit program sampling prior‑auth and claims denials to confirm a clinician actually made, and documented, the medical‑necessity determination.  

---

## 2. Client Profile & Scope

### 2.1 Plan Overview

- PacificCare Health Plan is a regional health insurer serving approximately 1.2 million covered lives in California across commercial, individual, and Medicare Advantage products.  
- Utilization review and claims operations are centralized, with certain functions delegated to large medical groups and IPAs in Southern California.  

### 2.2 In‑Scope Functions for SB 1120

- Utilization review and utilization management:
  - Prior authorization for inpatient, outpatient procedures, and high‑cost imaging.  
  - Concurrent review for extended inpatient stays.  
  - Retrospective review for certain procedures.[web:96][web:111]  
- Claims adjudication logic that incorporates medical‑necessity determinations (e.g., bundling edits based on clinical appropriateness).  

---

## 3. AI / Algorithm Inventory in UR, UM, and Claims

### 3.1 Tool Inventory Table

| Tool ID | Tool Name | Vendor / Internal | Primary Use (UR/UM/Claims) | AI / Algorithm Type | Inputs | Outputs |
|--------|-----------|-------------------|----------------------------|---------------------|--------|---------|
| T1 | SmartPrior | External vendor | UR – Prior Authorization | ML model + rules | Diagnosis codes, CPT/HCPCS, demographics, limited history | Risk score + “approve/route_to_MD/route_to_RN” recommendation |
| T2 | StaySense | Internal | UM – Concurrent Review | Rules with some predictive scoring | LOS, DRG, comorbidities, utilization history | Flag for extended stay review; no direct denial |
| T3 | ClaimEdit360 | External vendor | Claims – Post‑payment review | Rules engine with ML prioritization | Final claim, coding, provider patterns | Auto‑adjustments and “pend” decisions for human review |

[web:101][web:109]

### 3.2 Delegated / Third‑Party Functions

- Two large medical groups (Delta Medical Group and SouthBay IPA) perform UR for certain lines of business.  
- SouthBay IPA uses a cloud‑based UR tool with AI‑assisted triage; PacificCare has a high‑level description but no detailed configuration or assurance that AI cannot auto‑deny on medical‑necessity grounds.  

---

## 4. Medical Necessity Decision Points & AI Influence

### 4.1 Medical Necessity Decision Map

| Flow ID | Process | Tool(s) Involved | Who Makes Medical Necessity Determination? | AI Role | SB 1120 Risk Level |
|--------|---------|------------------|--------------------------------------------|--------|--------------------|
| F1 | Pre‑auth for elective inpatient admissions | SmartPrior (T1) | Physician reviewer for medium/high‑risk cases; RN for low‑risk cases | AI scores and routes cases; low‑risk may be auto‑approved; no auto‑denials | Low–Medium |
| F2 | Pre‑auth for high‑cost imaging | SmartPrior (T1) | Physician reviewer; some legacy rules auto‑deny if criteria not met | AI + rules recommend or auto‑deny in limited cases | Medium–High |
| F3 | Concurrent review of long LOS | StaySense (T2) | Physician UM reviewer | AI flags “outliers” only; no auto‑actions | Low |
| F4 | Post‑payment claims edits | ClaimEdit360 (T3) | Claims medical director or coding specialist | Rules engine can auto‑adjust payment amounts based on clinical appropriateness edits | Medium |

[web:96][web:94][web:108]

### 4.2 Workflows Where AI Could Improperly Decide Medical Necessity

- **F2 – High‑cost imaging pre‑auth:**  
  - A small subset of requests that fail strict rules (derived from clinical guidelines) are auto‑denied without a physician reviewing the individual clinical record; SB 1120 expects a licensed clinician to make the medical‑necessity determination.[web:96][web:98][web:108]  
- **F4 – Claims edits:**  
  - ClaimEdit360 can automatically reduce payment based on clinical bundling edits; while framed as “coding,” several rules effectively embed medical‑necessity logic without clinician documentation in the case file.  

Both flows are classified as **non‑compliant or high‑risk zones** under SB 1120’s “AI shall not deny, delay, or modify health‑care services based, in whole or in part, on medical necessity” standard.[web:96][web:98][web:109]  

---

## 5. Compliance Assessment Against SB 1120

### 5.1 Core Legal Requirements (Plain Language)

- Medical‑necessity determinations must be made **only** by a licensed physician or other licensed healthcare professional competent to evaluate the clinical issues.  
- AI/algorithms/software tools **may not** deny, delay, or modify services based, in whole or in part, on medical necessity, even if a human “configured” the rules.[web:96][web:94][web:98][web:108]  

### 5.2 Alignment Table

| Requirement | Observed Practice at PacificCare | Status | Notes / Evidence |
|------------|-----------------------------------|--------|------------------|
| Only licensed clinicians make medical‑necessity determinations | Most prior‑auth and UM decisions are documented by MD or RN reviewers; however, certain high‑cost imaging rules deny without recorded clinician review. | Gaps | Legacy rule table; sample denial letters and UR files. |
| AI tools do not themselves deny/delay/modify based on medical necessity | T1 and T3 can effectively deny/modify based on medical‑necessity logic without a documented clinician determination in some cases. | Gaps | System configuration review; vendor documentation. |
| Delegated entities follow same rules | PacificCare has limited visibility into SouthBay IPA’s AI‑enabled UR configuration. | Unknown / Gaps | Delegate attestation only; no detailed spec or audit. |

[web:96][web:94][web:101]

---

## 6. Findings & Recommended Remediations

### 6.1 High‑Risk Issues

- Auto‑denial rules for high‑cost imaging that operate without documented physician review of individual clinical circumstances.  
- Claims editing rules that function as de facto medical‑necessity denials/modifications without clinician sign‑off.  
- Insufficient oversight of SouthBay IPA’s AI‑assisted UR tool relative to SB 1120 requirements.  

### 6.2 Recommended Remediation Actions

- **Technical / Process:**
  - Reconfigure SmartPrior so that any “deny” or “modify” outcome based on medical‑necessity criteria always routes to a licensed physician (or qualified clinician) for explicit decision and documentation.  
  - Update ClaimEdit360 configurations such that clinically driven payment reductions tied to medical‑necessity logic require clinician review and notation in the case file.  

- **Policy & Governance:**
  - Adopt a formal **Physician‑Only Medical Necessity Policy** and **AI‑Assisted UR SOPs**, clarifying that AI may triage/flag but not make final medical‑necessity determinations.  
  - Require delegated entities (e.g., SouthBay IPA) to attest and provide documentation that their AI tools comply with SB 1120 and allow for audit.  

- **Monitoring:**
  - Implement a quarterly audit of sampled denials and modified claims to confirm a licensed clinician made and documented the medical‑necessity decision in each case.  

---

**End of Memo**
