# SB 1120 – AI System Configuration & Controls Checklist (MASTER TEMPLATE)

**Document Title:** SB 1120 AI System Configuration & Controls Checklist for {{PLAN_NAME}}  
**Version:** v{{VERSION}}  
**Date Completed:** {{DATE_COMPLETED}}  
**Prepared By:** {{AUTHOR_NAME}}, {{ROLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Confirm that AI, algorithms, and related software used by {{PLAN_NAME}} for utilization review (UR), utilization management (UM), and related claims functions are configured so they **cannot deny, delay, or modify services based on medical necessity**, and that licensed clinicians retain decision‑making authority.[web:96][web:98][web:106]

---

## 1. Tool Inventory & Ownership

| Tool ID | Tool Name | Vendor / Internal | Primary Use (UR/UM/Claims) | Business Owner | Technical Owner |
|--------|-----------|-------------------|----------------------------|----------------|-----------------|
| {{TOOL_1_ID}} | {{TOOL_1_NAME}} | {{VENDOR_OR_INTERNAL_1}} | {{USE_1}} | {{B_OWNER_1}} | {{T_OWNER_1}} |
| {{TOOL_2_ID}} | {{TOOL_2_NAME}} | {{VENDOR_OR_INTERNAL_2}} | {{USE_2}} | {{B_OWNER_2}} | {{T_OWNER_2}} |

---

## 2. Prohibited Auto‑Decision Logic (Medical Necessity)

> Objective: Ensure no tool can auto‑deny, delay, or modify services based, in whole or in part, on medical necessity.[web:96][web:98][web:126]

### 2.1 Auto‑Decision Controls

| Check ID | Tool ID | Configuration / Behavior | Compliant? (Y/N/N‑A) | Notes / Required Fix |
|----------|---------|-------------------------|----------------------|----------------------|
| 2.1.1 | {{TOOL_1_ID}} | Tool cannot auto‑deny requests based on medical‑necessity criteria without clinician review. | {{C_2_1_1}} | {{NOTES_2_1_1}} |
| 2.1.2 | {{TOOL_1_ID}} | Tool may auto‑approve only low‑risk, guideline‑conforming requests; no adverse decisions. | {{C_2_1_2}} | {{NOTES_2_1_2}} |
| 2.1.3 | {{TOOL_2_ID}} | Claims edits that effectively rest on medical necessity cannot apply automatically without clinician sign‑off. | {{C_2_1_3}} | {{NOTES_2_1_3}} |

---

## 3. Human‑in‑the‑Loop & Documentation

### 3.1 Clinician Decision Capture

| Check ID | Area | Requirement | Compliant? | Notes |
|----------|------|-------------|------------|-------|
| 3.1.1 | Prior Auth | System records the licensed clinician making any denial, delay, or modification based on medical necessity. | {{C_3_1_1}} | {{NOTES_3_1_1}} |
| 3.1.2 | Concurrent/Retro Review | UM platform requires clinician decision and rationale for adverse determinations. | {{C_3_1_2}} | {{NOTES_3_1_2}} |
| 3.1.3 | Delegated UR | Delegates’ systems capture clinician decision‑makers in a way auditable by {{PLAN_NAME}}. | {{C_3_1_3}} | {{NOTES_3_1_3}} |

[web:96][web:101][web:114]

---

## 4. Patient‑Specific Inputs & Limits on Group‑Only Data

### 4.1 Individualized Review

| Check ID | Tool ID | Requirement | Compliant? | Notes |
|----------|---------|-------------|------------|-------|
| 4.1.1 | {{TOOL_1_ID}} | Tool uses individual clinical history, provider’s recommendation, and case‑specific records in its analysis; not group data alone. | {{C_4_1_1}} | {{NOTES_4_1_1}} |
| 4.1.2 | {{TOOL_2_ID}} | Tool is configured not to base decisions solely on generalized group datasets. | {{C_4_1_2}} | {{NOTES_4_1_2}} |

[web:96][web:98][web:106]

---

## 5. Audit Logging & Transparency

### 5.1 Logging

| Check ID | Area | Requirement | Compliant? | Notes |
|----------|------|-------------|------------|-------|
| 5.1.1 | All Tools | AI/algorithm outputs used in UR/UM are logged with timestamps and case IDs. | {{C_5_1_1}} | {{NOTES_5_1_1}} |
| 5.1.2 | All Tools | System logs show when clinicians overrode AI recommendations. | {{C_5_1_2}} | {{NOTES_5_1_2}} |

### 5.2 Inspectability

- Confirm that configuration and algorithm documentation can be made available for audit by regulators (e.g., DMHC) as required.[web:94][web:130]  

---

## 6. Overall Assessment & Remediation Plan

- Overall SB 1120 configuration status: {{OVERALL_STATUS}} (e.g., Aligned / Partial / Gaps).  
- Key remediation items, owners, and target dates:  
  - {{REMEDIATION_1}}  
  - {{REMEDIATION_2}}  

---

**End of Checklist**
