# SB 1120 Compliance Monitoring & Periodic Audit Plan (MASTER TEMPLATE)

**Document Title:** SB 1120 Compliance Monitoring & Periodic Audit Plan for {{PLAN_NAME}}  
**Version:** v{{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 1120 – Physicians Make Decisions Act  

> Purpose: Define how {{PLAN_NAME}} will monitor, test, and periodically audit its use of AI, algorithms, and software tools in utilization review (UR), utilization management (UM), and related claims functions to ensure ongoing compliance with SB 1120.[web:96][web:91][web:106]

---

## 1. Monitoring Objectives

- Verify that only licensed clinicians make medical‑necessity determinations.[web:96][web:98]  
- Confirm that AI/algorithmic tools are used as decision support only and do not auto‑deny, delay, or modify services based on medical necessity.  
- Ensure tools rely on individualized member information and are fairly and equitably applied.[web:96][web:98][web:91]  
- Maintain evidence for regulators (DMHC, DOI) that AI tools are open to inspection and periodically reviewed.[web:96][web:106]  

---

## 2. Monitoring Activities & Frequency

| Activity | Description | Frequency | Primary Owner |
|---------|-------------|-----------|---------------|
| A1 – UR File Sampling | Sample UR cases (prior auth, concurrent, retrospective) involving AI tools. | Quarterly | UM Quality Lead |
| A2 – Claims Sampling | Sample claims where automated edits or AI tools were involved. | Quarterly | Claims QA Lead |
| A3 – Configuration Review | Review configurations of AI/algorithmic tools and rules engines. | At least annually; after major updates | IT / Clinical Analytics |
| A4 – Delegation Oversight | Review delegated UR entities’ AI practices and logs. | Annually; plus for‑cause | Delegation Oversight |
| A5 – Incident & Complaint Review | Analyze SB 1120‑related complaints and incidents. | Quarterly | Compliance / Risk |

[web:96][web:105][web:109]

---

## 3. Sampling Methodology

### 3.1 UR Case Sampling

- Define sampling frame:
  - All prior auth and concurrent review cases where AI tools (e.g., {{TOOL_NAMES}}) were used during the period.  
- Sample size:
  - Minimum {{N_UR_CASES}} cases per quarter, stratified by:
    - Line of business (e.g., Commercial, MA, Medi‑Cal).  
    - Service type (e.g., inpatient, outpatient, imaging).  

For each sampled case, reviewers check:

- Was AI used? How (triage/flag vs. decision)?  
- Who is recorded as the medical‑necessity decision‑maker?  
- Is clinician rationale documented?  

[web:96][web:93]

### 3.2 Claims Sampling

- Identify claims where automated tools applied edits that may relate to medical necessity.  
- Sample {{N_CLAIMS}} per quarter and verify:
  - A clinician reviewed and approved any adjustment tied to medical‑necessity logic.  
  - AI/algorithm outputs were treated as support only.  

---

## 4. Audit Procedures & Checklists

For each sampled case:

1. Confirm presence of a licensed clinician decision‑maker for any denial/delay/modification based on medical necessity.  
2. Confirm that AI recommendations did not function as the final decision.  
3. Verify documentation of:
   - Individual member clinical information.  
   - Treating provider’s recommendation.  
   - Clinical criteria applied.  
   - Any AI outputs used.  

Use standard audit checklists aligned with CA_03 SOPs and CA_04 configuration controls.[web:96][web:91]

---

## 5. Issue Classification & Remediation

- Classify findings as:
  - **Compliant**, **Minor Deviation**, **Significant Deviation**, or **Critical Non‑Compliance**.  
- For Significant or Critical issues:
  - Open corrective action plans with owners, milestones, and target dates.  
  - Consider temporary suspension or reconfiguration of affected tools.  

Track all issues in a central SB 1120 compliance log.  

[web:96][web:152]

---

## 6. Reporting & Regulator Readiness

- Quarterly internal report to:
  - CMO, Compliance Committee, and relevant business leaders.  
- Include in report:
  - Summary of monitoring activities.  
  - Key findings and trends.  
  - Status of remediation plans.  

Maintain documentation so that:

- AI/algorithm tools are **open to inspection** for audits and onsite surveys.  
- Written policies and procedures reflect current practice and tool configurations.[web:96][web:106][web:109]  

---

**End of Plan**
