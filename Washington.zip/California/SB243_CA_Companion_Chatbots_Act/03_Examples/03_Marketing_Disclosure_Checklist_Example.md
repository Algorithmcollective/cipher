# Marketing & Disclosure Review Checklist – AuroraCompanion
Version: 1.0 • Last Review: Jan 31, 2026 • Reviewer: Product Counsel

## 1. Identity & “Not Human” Disclosure

- [x] App store description states: “AuroraCompanion is an AI chatbot – you are not chatting with a human.”
- [x] On first open, onboarding screen includes: “You’ll be talking with an AI program, not a person.”
- [x] Chat UI header displays “AuroraCompanion (AI)” at all times.

## 2. Professional Status / Claims

- [x] No copy calls AuroraCompanion a “therapist”, “psychologist”, or “doctor”.
- [x] Tagline used: “An AI friend to talk to”, not “AI therapist”.
- [x] Safety note included: “AuroraCompanion does not provide professional mental health or medical advice and is not a substitute for professional care.”

## 3. Companion / Emotional Positioning

- [x] Marketing phrases like “AI friend” and “someone to talk to” are balanced with:
  - “AI chatbot” language.
  - Disclaimers about limitations.
- [x] No promises like “will cure anxiety” or “fix your depression”.

## 4. Minor Suitability & Age Messaging

- [x] App store listing: “Intended for users 16+; may not be suitable for some minors.”
- [x] Website FAQ includes a “For Parents & Guardians” section explaining risks and controls.

## 5. Legal & Policy Hooks

- [x] Terms of Use and Privacy Notice are one click away from landing page and app store listing.
- [x] All references to SB 243 (“California companion chatbot law”) reviewed by Legal before publication.
