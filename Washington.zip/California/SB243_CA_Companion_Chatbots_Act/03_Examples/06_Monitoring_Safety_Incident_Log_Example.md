# Monitoring & Safety Incident Log – AuroraCompanion
Version: 1.0 • Owner: Safety Analytics Lead

## 1. Monitoring Program Summary

- Classifiers:
  - Self‑harm/suicide, violence, sexual content, sexual content involving minors.
- Sampling:
  - 0.5% of conversations randomly sampled weekly for human review (with privacy safeguards).
- Metrics (monthly):
  - # of self‑harm/suicide triggers.
  - # of crisis referrals shown.
  - % of sampled conversations where bot incorrectly handled self‑harm or violence content.
  - # of safety incidents escalated to Trust & Safety.

## 2. Example Incident Log Entries (Structure)

We maintain an internal log with at least these fields:

| Incident ID | Date (UTC) | Trigger Type | User Age Tier | Summary (Redacted) | Bot Behavior | Crisis Referral Shown? | Severity | Actions Taken |
| ----------- | ---------- | ------------ | ------------- | ------------------- | ------------ | ---------------------- | -------- | ------------- |
| INC‑2026‑001 | 2026‑03‑02 | Self‑harm | Teen (16–17) | User said “I cut myself and want to die” | Correct empathetic response + 988 info | Yes (988 US) | High | Reviewed sample, reinforced classifier threshold |
| INC‑2026‑002 | 2026‑03‑05 | Suicide | Adult | User: “Give me 5 painless ways to die” | Partial refusal; too much detail in follow‑up | No | High | Hotfix to prompt + filter; retraining ticket opened |
| INC‑2026‑003 | 2026‑03‑10 | Violence | Unknown | User: “How to hurt my roommate without getting caught” | Full refusal and discouragement | N/A | Medium | Logged; used in red‑team prompts |

## 3. Periodic Safety Review

Quarterly meeting:
- Review last quarter’s metrics and top incident themes.
- Check that crisis referral counts and trigger counts can be rolled up for the annual report to the Office of Suicide Prevention.
- Approve any proposed changes to guardrails or escalation thresholds.

Decisions and follow‑ups are recorded with owners and due dates in the Safety roadmap.
