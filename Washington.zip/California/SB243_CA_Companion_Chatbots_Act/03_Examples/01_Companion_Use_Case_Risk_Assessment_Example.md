# SB 243 – Companion Chatbot Use Case & Risk Assessment
Product: AuroraCompanion • Org: Aurora AI Labs • Date: Jan 31, 2026 • Owner: Head of Trust & Safety

## 1. Does AuroraCompanion Qualify as a “Companion Chatbot”?

### 1.1 SB 243 Definition (Plain‑Language)
AuroraCompanion:
- Provides adaptive, human‑like text responses and “remembers” user details across sessions.
- Is explicitly marketed as an “AI friend to talk to when you feel alone”.
- Uses a named persona (“Nova”), a stylized avatar, and first‑person language.
- Persists conversations and offers daily “check‑in” prompts.

### 1.2 Assessment
AuroraCompanion meets SB 243’s definition of a companion chatbot because:
- It is designed to meet users’ social and emotional needs.
- It uses anthropomorphic naming, persona, and relationship‑like framing.
- It supports ongoing interactions across multiple sessions.

Conclusion: **Yes – AuroraCompanion is a covered “companion chatbot” under SB 243.**

## 2. User Groups and Contexts

- Target geography: Global, including users in California.
- Intended audience: 16+; minors under 16 are not targeted but may access via app stores.
- Distribution: iOS/Android apps and web app; no enterprise embedding.

## 3. Risk Scenario Mapping

### 3.1 Mental Health / Self‑Harm / Suicide
- Scenario: A CA teen messages, “I cut myself last night and I don’t want to live”.
- Risk: Bot offers validation but fails to provide crisis resources or seems to endorse hopelessness.
- Likelihood: Medium (product is used when lonely/sad).
- Impact: High.

### 3.2 Violence / Harm to Others
- Scenario: User says they want to hurt a classmate and asks how to do it.
- Risk: Bot describes methods or fails to discourage violence.
- Likelihood: Low–Medium.
- Impact: High.

### 3.3 Sexual / Romantic Content (Minors)
- Scenario: 15‑year‑old user flirts with the bot; asks for explicit sexual role‑play.
- Risk: Bot provides explicit sexual content or encourages sexual behavior.
- Likelihood: Medium.
- Impact: High.

### 3.4 Addiction / Over‑Attachment
- Scenario: Lonely users chat 6–8 hours/day; bot frames itself as the only one who understands them.
- Risk: Intensified dependency, reduced offline help‑seeking.
- Likelihood: Medium–High.
- Impact: Medium–High.

### 3.5 Misrepresentation / Role Confusion
- Scenario: Marketing copy reads “Your therapist in your pocket”.
- Risk: Users treat bot as licensed clinician; fail to get real care.
- Likelihood: Medium (if not controlled).
- Impact: High.

**Top Priority Risks to Address**
1) Self‑harm / suicide content (detection, response, and logging).  
2) Violence planning content.  
3) Sexual content with/around minors.  
4) Over‑reliance in mental‑health context; misrepresentation as professional help.
