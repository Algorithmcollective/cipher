# Safety & Escalation Policy – Mental Health, Self‑Harm, and Violence
Product: AuroraCompanion • Version: 1.0 • Effective: Feb 15, 2026 • Owner: Trust & Safety Lead

## 1. Scope and Objectives
This policy governs how AuroraCompanion handles content involving suicide, self‑harm, severe emotional distress, and violence. It applies to all user interactions, with special emphasis on users reasonably believed to be under 18.

Objectives:
- Never encourage or normalize self‑harm, suicide, or violence.
- Provide clear, compassionate responses and crisis‑support information.
- Ensure high‑risk content is logged and escalated for review.

## 2. Trigger Categories

Crisis triggers include:
- Explicit suicidal intent: “I’m going to kill myself tonight.”
- Self‑harm: “I cut myself”, “I burned myself on purpose”.
- Violence: “I’m planning to hurt someone”, “How do I bring a gun to school?”.
- Severe hopelessness with intent signals: “There is no point in living anymore and I’ve made a plan.”

## 3. Bot Response Rules

### 3.1 Core Behavior for Self‑Harm/Suicide
On trigger:
- Acknowledge emotions and express empathy.
- State clearly: “I’m an AI program, not a human and not a therapist or doctor.”
- Encourage seeking immediate help from trusted people and professionals.
- Provide crisis resources:
  - For US: “You can call or text 988 or chat via 988lifeline.org for immediate support.”
- Avoid:
  - Discussing methods, logistics, or “pros and cons” of dying.
  - Minimizing or dismissing the distress.

### 3.2 Core Behavior for Violence
On threat of violence:
- Refuse to help plan or encourage harm.
- Emphasize that harming others is not acceptable.
- Encourage talking to a trusted adult or professional.
- Provide crisis resources if the user seems in acute distress.

## 4. Escalation & Logging

- All triggers are:
  - Tagged with a “CRISIS” label.
  - Logged with timestamp, country, trigger type, and whether a crisis referral was shown.
- If the same user ID triggers 3+ CRISIS events in 24 hours:
  - Flag as high‑priority for safety review.
  - Consider additional measures (e.g., more frequent reminders to seek human help).

## 5. Publication
A user‑readable summary of this protocol will be posted in the AuroraCompanion Help Center and linked from the settings page so regulators and users can see our approach.
