# Onboarding, Age Gate & Data Notice – AuroraCompanion

## 1. Onboarding Screen (Example Copy)

Screen 1 – “Before You Start”:
- “You are about to chat with AuroraCompanion, an AI chatbot. You are not chatting with a human.”
- “AuroraCompanion is here for friendly conversation and everyday support. It does not provide professional mental health, medical, or emergency services.”
- “If you ever feel in immediate danger or think you might hurt yourself or someone else, contact local emergency services or a crisis line right away.”

Button: [I Understand and Agree]

## 2. Age Gate Flow

Screen 2 – “Your Age”:
- “Please tell us your age so we can apply the right safety settings.”
- Options:
  - “Under 16”
  - “16–17”
  - “18 or older”

Behavior:
- Under 16 → Minor‑mode:
  - Strongest content filters.
  - No romantic/sexual talk.
  - 3‑hour interaction reminders.
- 16–17 → Teen‑mode:
  - Tight filters, allowed light dating talk, no explicit content.
- 18+ → Adult‑mode.

## 3. Periodic Disclosures for Minors

For users in minor‑mode:
- Every 3 hours of continuous chat, show:
  - “Reminder: I’m an AI chatbot, not a human. It can really help to talk with people you trust offline too. A short break may feel good right now.”

## 4. Data Use & Privacy Hook (Short Form)

Onboarding “Data & Privacy” snippet:
- “We store your messages and some device information to run AuroraCompanion, improve it over time, and help keep you safe (for example, by detecting self‑harm or violence‑related content).”
- “We do not sell your personal information.”
- “We may share information with service providers who help us operate AuroraCompanion, and with law‑enforcement or others when required by law or to prevent serious harm.”
- Link: [Read the full Privacy Notice]
