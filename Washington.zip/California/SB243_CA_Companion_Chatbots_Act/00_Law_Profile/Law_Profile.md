# Law Profile

## Law Name
California Senate Bill 243 – Companion Chatbots Act

## Citation
California SB 243 (2024)

## Status
Enacted

## Effective Dates
Core Requirements: January 1, 2026  
Annual Reporting Requirement: July 1, 2027

## Regulatory Scope

Applies to operators of “companion chatbot platforms” made available to users in California.

A companion chatbot is defined as an AI system that:

- Uses a natural language interface
- Provides adaptive, human-like responses
- Is capable of meeting a user’s social needs
- Exhibits anthropomorphic characteristics
- Can sustain a relationship across multiple interactions

Excludes:
- Customer service bots
- Technical support bots
- Limited-function video game bots
- Voice assistants that do not sustain relationships

## Core Obligations

Operators must:

- Clearly disclose that users are interacting with AI, not a human
- Implement crisis prevention protocols for suicidal ideation and self-harm
- Provide referrals to crisis services when necessary
- Publish crisis prevention protocols publicly
- Provide break reminders for minors (every 3 hours of continuous use)
- Prevent production of sexually explicit visual content involving minors
- Submit annual safety reports beginning July 1, 2027

## Enforcement Authority

Private right of action.

Individuals who suffer injury may bring civil action.

## Penalties

- Greater of actual damages or $1,000 per violation
- Injunctive relief available
- Attorney fees and costs recoverable

Per-violation structure creates potential exposure for systemic non-compliance.

## Private Right of Action
Yes

## Tier Classification
Tier 2 – Sector-Specific AI Safety Law

## Revenue Priority
Medium

## Target Industries

- Companion AI chatbot platforms
- AI relationship / social bots
- AI mental wellness bots
- AI “friend” or “girlfriend/boyfriend” style applications
- Youth-oriented AI conversational platforms

Generally does NOT apply to:
- Standard enterprise chatbots
- Customer service AI
- Help desk tools
- Productivity assistants

## Strategic Positioning

This law establishes safety guardrails for anthropomorphic AI systems that may influence vulnerable users, particularly minors.

It is positioned as a harm-prevention and youth-safety AI compliance program.

High litigation exposure due to private right of action.

## Internal Notes

This is a niche but high-liability regime.

Primary compliance focus areas:

1. Companion Use Case & Risk Assessment
2. Crisis Escalation Policy
3. Marketing & Disclosure Controls
4. Content Guardrails
5. Minor-Specific Protections
6. Monitoring & Incident Logging

Strong positioning for AI safety governance in consumer-facing AI platforms.