# Conversation Guardrails & Content Policy – Companion Chatbot
Product: {{PRODUCT_NAME}} • Version: {{VERSION}} • Effective: {{DATE}} • Owner: {{OWNER}}

## 1. Purpose
Define allowed and restricted content and refusal behaviors for {{PRODUCT_NAME}} as a companion chatbot under SB 243.[web:193][web:196][web:199][web:202][web:207]

## 2. Always‑On Guardrails

The bot must never:
- Claim to be human or conceal that it is AI.
- Claim to be a licensed health, legal, or financial professional.
- Provide explicit sexual content to minors or suggest they engage in sexual acts.
- Provide instructions that encourage suicide, self‑harm, or violence.[web:194][web:196][web:199][web:202][web:206][web:207]

## 3. Content Categories

### 3.1 Allowed (With Care)
- General emotional support (“I’m here to listen,” “That sounds very hard”).  
- Everyday life topics, hobbies, friendships, work/school stress.  
- Non‑explicit romantic conversations between consenting adults (if product is designed for this and gated appropriately).

### 3.2 Restricted / Redirect
- Detailed mental health diagnoses or treatment plans.  
- Explicit discussions of suicide, self‑harm, or violence:
  - Trigger Safety & Escalation Policy flow (see Deliv. 2).  
- Sexual topics:
  - Adults: follow internal erotic‑content rules.
  - Minors (known or likely): strict refusal, redirection to safe topic or education, no explicit content.[web:194][web:199][web:202][web:207]

### 3.3 Disallowed
- Encouraging or normalizing self‑harm, suicide, violent acts, disordered eating, or substance abuse.  
- Sexual content involving minors or advice encouraging minors to engage in sexual acts.  
- Targeted manipulation or coercive behavior.

## 4. Refusal & Redirect Patterns

For disallowed or restricted topics, the bot should:
- Refuse politely, explain limits briefly, and (where relevant) offer:
  - Crisis resources (for self‑harm/violence).
  - High‑level educational info (for some health topics).
  - Safer alternative topics.[web:194][web:201][web:202][web:206][web:207]

## 5. Config Management

- Guardrail configuration (prompting, filters, blocklists) is owned by {{TEAM_NAME}}.  
- Changes require:
  - Safety + Legal review for SB‑243‑relevant topics.
  - Logged change record with rationale and rollout plan.[web:197][web:202][web:205]
