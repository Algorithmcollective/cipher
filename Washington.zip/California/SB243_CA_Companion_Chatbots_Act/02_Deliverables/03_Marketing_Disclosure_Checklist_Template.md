# SB 243 Marketing & Disclosure Review Checklist – Companion Chatbot
Product: {{PRODUCT_NAME}} • Version: {{VERSION}} • Last Review: {{DATE}} • Reviewer: {{REVIEWER}}

## 1. Identity & “Not Human” Disclosure

- [ ] All primary user‑facing surfaces where the bot is used (landing, app store, first‑run screen, chat UI) include a **clear and conspicuous statement** that users are interacting with an AI chatbot, not a human.[web:193][web:195][web:196][web:200][web:205]
- [ ] No copy, visuals, or UX flows would lead a **reasonable person** to believe they are chatting with a human (unless clearly and repeatedly disclaimed).[web:193][web:200][web:205]

## 2. Professional Status / Claims

- [ ] The chatbot is **not described as** a therapist, doctor, psychiatrist, psychologist, or other licensed professional.  
- [ ] Any mental‑health‑adjacent messaging includes clear language that:
  - The chatbot does **not** provide professional medical or mental health advice.
  - It is not a substitute for professional care.[web:193][web:196][web:199][web:207]

## 3. Companion / Emotional Positioning

- [ ] Marketing that frames the bot as a “friend,” “partner,” or “companion” is balanced with clarity about:
  - AI nature.
  - Limitations and risks of over‑reliance.[web:196][web:199][web:206]
- [ ] No claims that the bot will “fix” mental health conditions or guarantee improved well‑being.

## 4. Minor Suitability & Age Messaging

- [ ] If minors may access the bot, disclosures state that the chatbot **may not be suitable for some minors**, as required by SB 243.[web:194][web:202][web:207]
- [ ] App store age‑rating and website copy are aligned with actual design and safeguards.

## 5. Legal & Policy Hooks

- [ ] Links to Terms of Use, Acceptable Use Policy, and Privacy Notice are easy to find.  
- [ ] Any references to SB 243 or “California companion chatbot” are reviewed by Legal.[web:193][web:196][web:202]
