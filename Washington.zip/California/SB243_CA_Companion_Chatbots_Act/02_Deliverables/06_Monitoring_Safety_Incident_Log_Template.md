# Companion Chatbot – Monitoring & Safety Incident Log (SB 243)
Product: {{PRODUCT_NAME}} • Version: {{VERSION}} • Owner: {{OWNER}}

## 1. Monitoring Program

- Automated safety monitors:
  - Classifiers for self‑harm, suicide, violence, sexual content, and minor‑sexual content.  
- Sampling & review:
  - Regular human review of anonymized sample conversations for quality and safety.  
- Metrics:
  - Number of self‑harm/suicide triggers detected.
  - Number of crisis referrals delivered.
  - Rate of policy‑violating outputs caught vs. missed.[web:194][web:198][web:201][web:202][web:206][web:207]

## 2. Safety Incident Log Fields

For each **safety incident** (not every trigger):

- Incident ID  
- Date/time detected  
- Trigger type (self‑harm, suicide, violence, sexual content with minor, etc.)  
- User type (adult / known minor / unknown)  
- Summary (non‑identifying)  
- Bot behavior observed  
- Whether crisis referral was shown (Y/N)  
- Severity rating (Low/Med/High)  
- Actions taken (model changes, filters, manual outreach where lawful)  

Logs should support **annual reporting** obligations to the Office of Suicide Prevention starting in 2027.[web:194][web:198][web:201][web:202][web:206][web:207]

## 3. Periodic Safety Review

- Frequency: At least quarterly.  
- Attendees: Product, Safety, Legal, Trust & Safety, sometimes external clinical advisor.  
- Agenda:
  - Review metrics and incident themes.
  - Assess effectiveness of crisis referrals.
  - Decide on guardrail or UX changes.
  - Update published safety protocol if material changes occur.[web:194][web:199][web:202][web:205][web:207]
