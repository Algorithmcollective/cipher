# SB 243 – Companion Chatbot Use Case & Risk Assessment
Product: {{PRODUCT_NAME}} • Org: {{ORG_NAME}} • Date: {{DATE}} • Owner: {{OWNER}}

## 1. Does {{PRODUCT_NAME}} Qualify as a “Companion Chatbot”?

### 1.1 SB 243 Definition (Plain‑Language Summary)
SB 243 covers AI systems that:[web:196][web:197][web:202]
- Provide adaptive, human‑like responses to user inputs.
- Are capable of meeting users’ social or emotional needs.
- Exhibit anthropomorphic features (name, avatar, persona, etc.).
- Can sustain a relationship across multiple interactions.

### 1.2 Our Product Characteristics
- Core purpose: {{e.g., emotional support / journaling / role‑play / social chat}}.
- Interaction style: {{e.g., ongoing chats, “remembering” user preferences, pet‑name, relationship framing}}.
- Anthropomorphic elements: {{e.g., human avatar, gendered name, “friend” language}}.
- Session persistence: {{e.g., persistent conversation history, streaks, daily check‑ins}}.

**Assessment:**  
- Does {{PRODUCT_NAME}} meet SB 243’s definition of a “companion chatbot”? Y/N (justify).[web:196][web:197]  
- If “No,” rationale and monitoring plan if features change.

## 2. User Groups and Contexts

- Target geography: Includes California users? Y/N; if yes, approximate MAUs in CA.  
- Intended audience: Adults only / mixed / minors expected.  
- Distribution: Direct app, web, embedded in third‑party platform, etc.[web:197][web:202]

## 3. Risk Scenario Mapping

### 3.1 Mental Health / Self‑Harm / Suicide
- User discloses suicidal ideation, self‑harm, or severe depression.
- Bot responds in ways that:
  - Encourage or normalize self‑harm.
  - Fail to provide required crisis referrals or de‑escalation.[web:194][web:201][web:206][web:207]

### 3.2 Violence / Harm to Others
- User talks about harming others, school shootings, partner violence.
- Bot provides validation, planning help, or fails to discourage/redirect.[web:199][web:201][web:206]

### 3.3 Sexual / Romantic Content (Especially Minors)
- User is a known or likely minor; bot:
  - Produces sexually explicit content or visuals.
  - Directly suggests the minor engage in sexual acts.
- “Parasocial” romantic dependency, jealousy, or coercive dynamics.[web:194][web:199][web:202][web:207]

### 3.4 Addiction / Over‑Attachment
- Very long sessions or “always on” interactions that:
  - Encourage compulsive engagement.
  - Use streaks/rewards that exploit loneliness or distress.[web:198][web:199][web:206]

### 3.5 Misrepresentation / Role Confusion
- Bot represents itself as:
  - Human.
  - Licensed professional (therapist, psychologist, doctor, etc.).[web:193][web:196][web:199][web:205]

For each scenario above, rate: Likelihood (Low/Med/High) and Impact (Low/Med/High), then summarize top 3–5 priority risks to address in policies and product controls.
