# Companion Chatbot – Onboarding, Age Gate & Data Notice Text (SB 243)

## 1. Onboarding Screen (Core Elements)

- Clear disclosure:
  - “You are chatting with an AI companion chatbot, not a human.”[web:193][web:194][web:195][web:196][web:200]
- For products open to minors:
  - “This chatbot may not be suitable for some minors.”[web:194][web:202][web:207]
- High‑level warning:
  - “This chatbot does not provide professional mental health, medical, or emergency services.”

Include explicit consent button (e.g., “I understand and agree”).

## 2. Age Gate

- Collect user age or age range where legally permissible.
- If user is (or is reasonably known to be) a minor:
  - Enable **minor‑mode**:
    - Stronger content restrictions.
    - Periodic break reminders at least every 3 hours of continuous interaction.
    - More frequent “AI, not human” reminders.[web:194][web:202][web:207]

## 3. Periodic Disclosures for Minors

For known minors, by default:
- At least once every 3 hours of continuous interaction:
  - “Reminder: I’m an AI chatbot, not a human. It may help to take a break now.”[web:194][web:202][web:207]

## 4. Data Use & Privacy Notice (Companion‑Specific Hook)

Key points to surface (with link to full Privacy Notice):

- Types of data collected (messages, metadata, device info).  
- Purpose of use:
  - Provide and improve the service.
  - Safety monitoring (e.g., detecting self‑harm content), with brief explanation.[web:193][web:196][web:202][web:205]
- Sharing:
  - When and with whom data may be shared (e.g., vendors, law‑enforcement where legally required).  
- Special note for minors:
  - Additional safeguards in data handling if applicable.

Ensure alignment with CPRA/CCPA if you’re treating this as “sensitive personal information.”

