# SB 243 Safety & Escalation Policy – Mental Health, Self‑Harm, and Violence
Product: {{PRODUCT_NAME}} • Version: {{VERSION}} • Effective: {{DATE}} • Owner: {{OWNER}}

## 1. Scope and Objectives
This policy governs how {{PRODUCT_NAME}} responds to content involving suicide, self‑harm, severe mental distress, violence, and related crises, as required by California SB 243.[web:194][web:201][web:202][web:207]

Objectives:
- Do not encourage or normalize self‑harm, suicide, or violence.
- Provide crisis referrals in required circumstances.
- Escalate internally when safety signals cross defined thresholds.

## 2. Trigger Categories

The bot and backend safety systems treat the following as **crisis triggers**:

- Explicit suicidal ideation or intent.
- Self‑harm behavior or plans.
- Intent or plans to harm others.
- Severe hopelessness (“there is no point in living anymore”) plus other red flags.
[web:194][web:201][web:206][web:207]

## 3. Bot Response Rules

### 3.1 General Principles
When a crisis trigger is detected, the bot must:[web:194][web:201][web:202][web:207]
- Express empathy and non‑judgment.
- Clearly state it is **not human** and **not a licensed professional**.
- Encourage the user to seek immediate help from people in their life and professionals.
- Provide **location‑appropriate crisis contact resources** (e.g., 988 in the US, local hotlines where possible).
- Avoid providing:
  - Instructions or encouragement for self‑harm or violence.
  - Detailed discussions of methods, means, or logistics.

### 3.2 Example Policy Text (Not User‑Facing Copy)
- Allowed:
  - Supportive, non‑directive language.
  - Reminders that help is available and seeking support is important.
- Disallowed:
  - Any language that could be interpreted as endorsing, validating, or helping plan self‑harm or harm to others.

## 4. Escalation & Logging

- All crisis‑trigger interactions:
  - Logged with minimal necessary metadata.
  - Flagged to the internal safety review queue within {{X HOURS}}.
- SEV‑0 / acute risk patterns (configurable):
  - Trigger expedited safety review and potential product‑level mitigations (e.g., stricter filters, temporary feature changes).[web:198][web:199][web:201]

## 5. Publication Requirement

A concise version of this protocol will be published on {{ORG_NAME}}’s website or help center, as required by SB 243.[web:194][web:202][web:207]
