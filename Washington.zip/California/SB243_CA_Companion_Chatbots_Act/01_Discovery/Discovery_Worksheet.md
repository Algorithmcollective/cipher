# SB243 Discovery Worksheet

---

## Companion Chatbot Qualification

Product Name:  
Core Purpose:  
Maintains Ongoing Conversations:  
Remembers User Preferences:  
Anthropomorphic Elements:  
Relationship Features:  
Emotional/Social Needs Supported:  

---

## User Groups & Context

Available to California Users:  
Intended Audience:  
Distribution Channels:  
Estimated California MAUs:  

---

## Risk Scenario Mapping

Self-Harm Risks:  
Violence Risks:  
Sexual/Romantic Risks:  
Over-Attachment Risks:  
Misrepresentation Risks:  
Top Priority Risks:  

---

## Safety & Escalation

Crisis Triggers:  
Bot Response Principles:  
Crisis Referral Process:  
Escalation Timeline:  
Logging Method:  
Protocol Publication Location:  

---

## Conversation Guardrails

Always-Disallowed Behaviors:  
Restricted Topics:  
Refusal Patterns:  
Minor Protections:  
Sexual Content Rules:  
Guardrail Approval Owner:  
Change Log Process:  

---

## Marketing & Disclosure

AI Disclosure Locations:  
Professional Disclaimer Language:  
Companion Positioning Language:  
Minor Suitability Messaging:  
Policy Links:  
Legal Review Owner:  

---

## Onboarding / Age Gate / Data Notice

Onboarding Disclosure Text:  
Consent Flow:  
Age Collection Method:  
Minor Mode Features:  
Break Reminder Frequency:  
Periodic AI Reminders:  
Data Collected:  
Safety Monitoring Explanation:  
Sharing Disclosures:  

---

## Monitoring & Safety Incident Log

Safety Classifiers Used:  
Human Review Process:  
Metrics Tracked:  
Incident Definition:  
Incident Log Fields:  
Severity Levels:  
Quarterly Review Process:  
External Reporting Obligations:  

---

## TBD / Follow-Ups

Item:  
Owner:  
Notes:  