# SB243 Discovery Call Script – Companion Chatbot

Purpose: Gather information needed to prepare California SB243 companion chatbot documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Companion Chatbot Qualification

Say:
“I need to understand whether your AI product functions as a companion chatbot.”

Ask:

- Product name  
- Core purpose (emotional support, journaling, role-play, etc.)  
- Does it maintain ongoing conversations  
- Does it remember user preferences  
- Anthropomorphic elements (avatar, persona, name)  
- Persistent relationship features (streaks, daily check-ins)  
- Does it meet emotional or social needs

---

## 🧾 Deliverable: User Groups & Context

Ask:

- Available to California users  
- Intended audience (adults / mixed / minors)  
- Distribution channels (app, web, embedded)  
- Approximate MAUs in California

---

## 🧾 Deliverable: Risk Scenario Mapping

Ask:

- Self-harm / suicide scenarios considered  
- Violence scenarios considered  
- Sexual / romantic interaction risks  
- Over-attachment / addiction concerns  
- Misrepresentation risks (human / therapist confusion)

For each:
- Likelihood  
- Impact  
- Top priority risks

---

## 🧾 Deliverable: Safety & Escalation Policy

Say:
“I want to capture how the product handles crisis situations.”

Ask:

- Crisis triggers defined  
- Bot response principles  
- Crisis referral process (e.g., 988)  
- Escalation timeframe  
- Logging method  
- Publication location for protocol

---

## 🧾 Deliverable: Conversation Guardrails & Content Policy

Ask:

- Always-disallowed behaviors  
- Restricted topics  
- Refusal patterns  
- Minor protections  
- Sexual content rules  
- Who approves guardrail changes  
- Change logging process

---

## 🧾 Deliverable: Marketing & Disclosure

Ask:

- Where AI disclosure appears  
- Professional disclaimer language  
- Companion positioning language  
- Minor suitability messaging  
- Links to terms/privacy  
- Legal review process

---

## 🧾 Deliverable: Onboarding, Age Gate & Data Notice

Ask:

- First-run AI disclosure text  
- Consent flow  
- Age collection method  
- Minor-mode features  
- Break reminders  
- Periodic AI reminders  
- Data collected  
- Safety monitoring explanation  
- Sharing disclosures

---

## 🧾 Deliverable: Monitoring & Safety Incident Log

Ask:

- Safety classifiers used  
- Human review process  
- Metrics tracked  
- Incident definition  
- Incident log fields  
- Severity levels  
- Quarterly review process  
- External reporting obligations

---

## ✅ Closing

Say:

“That gives us what we need to prepare your SB243 documentation. Anything marked TBD we’ll follow up internally.”