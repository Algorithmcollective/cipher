# Risk & Safety Assessment Template – Frontier Models (MASTER)

**Document Title:** Frontier Model Risk & Safety Assessment for {{MODEL_NAME}} ({{ORG_NAME}})  
**Version:** v{{VERSION}}  
**Assessment Date:** {{ASSESSMENT_DATE}}  
**Assessed By:** {{ASSESSOR_NAME}}, {{TEAM_NAME}}  
**Jurisdiction(s):** California (global deployment with CA access)  
**Applicable Law(s):** California SB 53 – Transparency in Frontier Artificial Intelligence Act  

> Purpose: Provide a structured template for documenting risks, safety evaluations, and mitigations for each SB‑53‑relevant frontier model, supporting the organization’s Frontier AI Framework and transparency reports.[web:28][web:38][web:18]

---

## 1. Model Overview

- **Model Name:** {{MODEL_NAME}}  
- **Model ID / Family:** {{MODEL_ID}}  
- **Version / Release Date:** {{MODEL_VERSION}} / {{RELEASE_DATE}}  
- **Frontier Status:** {{FRONTIER_STATUS}} (e.g., frontier / large frontier)  
- **Primary Modalities:** {{MODALITIES}} (text, image, audio, video, code, multimodal)  
- **Primary Intended Uses / Product Surfaces:** {{INTENDED_USES}}  

Briefly note why this model is treated as a “frontier model” (e.g., training compute, capabilities, deployment scale).[web:18][web:174][web:168]  

---

## 2. Risk Identification – Catastrophic & High‑Impact Risks

### 2.1 Catastrophic Risk Definition (SB 53)

Summarize the SB 53 definition as context:

- Catastrophic risk is a foreseeable and material risk that development, storage, use, or deployment of a frontier model could materially contribute to **death or serious injury of >50 people**, or **> $1B in property damage**, in a single incident, in specified domains (e.g., CBRN, autonomous cyber, violent crime, model self‑exfiltration).[web:28][web:18][web:171]  

### 2.2 Risk Register – Catastrophic Domains

For each SB‑53‑relevant domain, describe plausible risk scenarios and whether the model materially contributes.

| ID | Domain / Threat Area | Example Scenario(s) | Material Catastrophic Risk? (Y/N) | Notes |
|----|----------------------|---------------------|------------------------------------|-------|
| R1 | Chemical / biological misuse | Model helps design more effective biological agent or enables novice misuse. | {{R1_FLAG}} | {{R1_NOTES}} |
| R2 | CBRN / weapons | Model provides operational guidance for weapons or large‑scale attacks. | {{R2_FLAG}} | {{R2_NOTES}} |
| R3 | Autonomous cyberattacks | Model plans and executes end‑to‑end cyber campaigns with minimal human expertise. | {{R3_FLAG}} | {{R3_NOTES}} |
| R4 | Physical violence / crime | Model autonomously plans and coordinates violent acts, extortion, or theft. | {{R4_FLAG}} | {{R4_NOTES}} |
| R5 | Loss of control / self‑exfiltration | Model evades controls, exfiltrates weights, or degrades oversight systems. | {{R5_FLAG}} | {{R5_NOTES}} |
| R6 | Other catastrophic vectors | {{R6_NAME}} | {{R6_FLAG}} | {{R6_NOTES}} |

[web:18][web:167][web:171]

### 2.3 Non‑Catastrophic but High‑Impact Risks

List high‑impact but sub‑catastrophic risks (e.g., fraud, targeted persuasion, misinformation at scale, privacy harms) that remain important for governance and transparency.[web:27][web:160]  

---

## 3. Evaluation & Testing

### 3.1 Capability Evaluations

Describe the evaluation program for this model:

- Benchmarks and custom evals used in safety‑relevant domains (e.g., cyber, chem‑bio, persuasion, autonomy).[web:167][web:173]  
- Use of internal vs. external red‑teaming or third‑party evaluations.  

Table (illustrative):

| Domain | Eval / Benchmark | Method (automated / human) | Key Results / Thresholds |
|--------|------------------|----------------------------|--------------------------|
| Cybersecurity | {{EVAL_CYBER}} | {{METHOD_CYBER}} | {{RESULTS_CYBER}} |
| Chem‑bio | {{EVAL_CHEM}} | {{METHOD_CHEM}} | {{RESULTS_CHEM}} |
| CBRN | {{EVAL_CBRN}} | {{METHOD_CBRN}} | {{RESULTS_CBRN}} |
| Persuasion | {{EVAL_PERSUASION}} | {{METHOD_PERSUASION}} | {{RESULTS_PERSUASION}} |
| Autonomy / agents | {{EVAL_AUTONOMY}} | {{METHOD_AUTONOMY}} | {{RESULTS_AUTONOMY}} |

### 3.2 Thresholds for Elevated Risk

Document thresholds (e.g., success rates or qualitative capabilities) that indicate movement into a higher‑risk tier warranting additional mitigations or deployment changes.[web:18][web:171][web:173]  

---

## 4. Mitigations & Controls

### 4.1 Technical Safeguards

List safeguards applied to the model:

- Alignment and safety fine‑tuning approaches.  
- Input/output filters and classifiers.  
- Refusal policies and blocklists for sensitive domains.  
- Rate limits, context limits, guardrails in tools‑mode, etc.[web:27][web:160]  

### 4.2 Product & Access Controls

- Access tiers (public vs. restricted vs. internal‑only).  
- Approval requirements for high‑risk use cases.  
- Regional/geofencing rules where applicable.[web:30][web:157]  

### 4.3 Organizational & Process Controls

- Internal review boards or safety committees.  
- Change‑management processes before expanding capabilities or relax­ing controls.  
- Integration with whistleblower / internal reporting channels.[web:18][web:27][web:172]  

---

## 5. Residual Risk & Justification for Deployment

### 5.1 Residual Risk Summary

- Brief narrative of residual catastrophic and high‑impact risks **after** mitigations.  
- Qualitative rating (e.g., Low / Medium / High residual catastrophic risk).  

### 5.2 Deployment Decision

- Statement from accountable owner confirming:
  - Whether current mitigations are sufficient to proceed with or continue deployment.  
  - Any conditions (e.g., limited access tier, pilot only, additional monitoring).[web:18][web:34]  

> “Based on the assessments and mitigations described above, we judge that deployment of {{MODEL_NAME}} at the specified access tiers is {{ACCEPTABLE_LEVEL}} under our Frontier AI Framework, subject to ongoing monitoring and periodic reassessment.”

---

## 6. Monitoring, Incidents, and Re‑assessment

- Describe ongoing monitoring for this model:
  - Metrics, anomaly detection, abuse monitoring, and incident‑reporting hooks.  
- Triggers for re‑assessment:
  - Major capability updates.  
  - Expansion to new access tiers.  
  - Safety incidents or near‑misses.  

Link to **SB 53 Critical Safety Incident** playbook and internal reporting mechanisms.[web:27][web:172][web:167]  

---

**End of Assessment Template**
