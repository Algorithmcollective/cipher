# SB 53 Critical Safety Incident – Reporting & Escalation Playbook (MASTER)

**Document Title:** SB 53 Critical Safety Incident – Reporting & Escalation Playbook for {{ORG_NAME}}  
**Version:** v{{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Scope:** All SB‑53‑covered frontier models and major deployments  

> Purpose: Define how {{ORG_NAME}} identifies, triages, escalates, and reports **critical safety incidents** related to its frontier models, including 24‑hour vs 15‑day reporting to California authorities, consistent with SB 53.[web:18][web:27][web:160]

---

## 1. Definitions & Scope

### 1.1 Critical Safety Incident (SB 53 – Working Definition)

For operational purposes, {{ORG_NAME}} treats as a **critical safety incident** any event involving a frontier model that:

- Results in, or presents a credible and specific risk of:
  - Death or serious bodily injury to one or more persons, or  
  - Materialized catastrophic harm consistent with SB 53’s catastrophic‑risk concepts; and/or[web:28][web:171]  
- Involves:
  - Unauthorized access, tampering, or loss of control of a frontier model.  
  - Deceptive model behavior that materially increases catastrophic risk.  

Reference: SB 53 statutory definitions and internal catastrophic‑risk framework.  

### 1.2 In‑Scope Systems

- All SB‑53‑covered **frontier** and **large frontier** models.  
- Any internal or external deployments where those models are integrated into products or tools.  

---

## 2. Detection & Intake

### 2.1 Detection Channels

Potential incidents may be detected via:

- Internal monitoring and logs (abuse pipelines, anomaly detectors).  
- Security operations (SIEM alerts, intrusion detection).  
- User or customer reports (support tickets, abuse reports).  
- Employee whistleblower channels.[web:27][web:160]  

### 2.2 Initial Intake Checklist

On receiving a report:

- Record:
  - Date/time discovered.  
  - Who reported it.  
  - Systems/models possibly involved.  
  - Initial description of what happened.  
- Open an incident record in {{INCIDENT_SYSTEM}} with a unique ID.  

---

## 3. Triage & Severity Classification

### 3.1 Triage Questions (Within {{X_HOURS}} Hours)

1. Does the event involve a **frontier model** or its derivatives?  
2. Has there been actual harm (injury, significant property damage) or only potential risk?  
3. Is there evidence of:
   - Loss of control or unauthorized access to model weights or systems?  
   - Deceptive model behavior that could bypass safeguards?  
   - Use of the model in a way that enabled or substantially contributed to serious harm?[web:28][web:174]  

### 3.2 Severity Levels

- **SEV‑0 (Imminent or Ongoing Risk):**
  - Ongoing or imminent risk of death or serious bodily injury, or clear catastrophic harm.  
- **SEV‑1 (Serious but Contained):**
  - Serious harm or high‑impact misuse, but no ongoing imminent threat.  
- **SEV‑2 (Near‑Miss / Lower‑Impact):**
  - No actual harm, but clear signal of elevated risk or control weakness.  

Mark whether the event **meets SB‑53 “critical safety incident” criteria** and, if so, whether it appears to require **24‑hour** (imminent risk) vs **15‑day** reporting.[web:18][web:160][web:157]  

---

## 4. Escalation & Incident Command

### 4.1 Roles

- **Incident Commander (IC):** Usually from Security or Safety; coordinates response.  
- **Safety Lead:** Assesses catastrophic‑risk implications.  
- **Security Lead:** Handles technical containment and forensics.  
- **Legal / Regulatory:** Manages SB‑53 reporting and communications.  
- **Comms / PR:** Coordinates external messaging if needed.  

### 4.2 Escalation Steps

- For SEV‑0 / SEV‑1:
  - IC paged immediately.  
  - Safety, Security, and Legal join incident channel/bridge.  
- For SEV‑0:
  - Begin preparing **24‑hour notification** draft while containment is in progress.[web:18][web:160][web:174]  

---

## 5. Containment, Investigation, and Documentation

### 5.1 Containment

- Stabilize systems:
  - Disable affected endpoints or access tiers if necessary.  
  - Revoke compromised credentials or API keys.  
  - Add temporary guardrails (e.g., tightening filters, disabling tools).  

### 5.2 Investigation

- Determine:
  - Root cause (e.g., misconfiguration, vulnerability, abuse pattern).  
  - Extent of exposure (users affected, geography, time window).  
  - Role of the model in enabling or amplifying harm.  

### 5.3 Documentation Requirements

Maintain a record including:

- Incident timeline (discovery, triage, key decisions).  
- Systems and models involved.  
- Nature and extent of harm or risk.  
- Mitigation steps taken and their effectiveness.  

This record underpins SB‑53 reporting and any future amendments.[web:18][web:27]  

---

## 6. SB‑53 External Reporting

### 6.1 When to Report

If the event meets **critical safety incident** criteria:

- **Imminent risk of death or serious injury:**
  - Notify appropriate public‑safety / law‑enforcement agencies and California Office of Emergency Services (OES) **within 24 hours** of discovery.[web:18][web:160][web:157]  
- **Other critical safety incidents:**
  - Report to OES **within 15 days** of discovery.[web:28][web:182]  

Legal / Regulatory makes the final determination on reportability.  

### 6.2 Report Contents (High‑Level Fields)

Prepare a report that includes:

- Identity of the frontier model(s) involved.  
- Description of the incident (what happened, when, how detected).  
- Nature of harm or risk (including lives/property potentially affected).  
- Steps taken to contain and mitigate.  
- Known or suspected root cause.  
- Any planned or completed follow‑up actions.  

### 6.3 Amendments

If new material information emerges after the initial report, submit an amended report to OES within a reasonable timeframe.[web:32][web:174]  

---

## 7. Post‑Incident Review & Lessons Learned

- Conduct a formal **post‑incident review** within {{Y_DAYS}} of closure.  
- Identify:
  - Control gaps.  
  - Changes needed to:
    - Model safeguards.  
    - Access tiers and policies.  
    - Monitoring and detection.  
- Track remediation items in the SB‑53 risk and compliance register.[web:18][web:167]  

---

## 8. Integration with Whistleblower & Internal Reporting

- Ensure employees who raise concerns about potential critical safety incidents:
  - Have access to anonymous channels.  
  - Are informed of their protections under SB 53.  
  - Receive status updates on their disclosures where required.[web:18][web:27][web:160]  

Reference: {{LINK_WHISTLEBLOWER_POLICY}}.  

---

**End of Playbook Template**
