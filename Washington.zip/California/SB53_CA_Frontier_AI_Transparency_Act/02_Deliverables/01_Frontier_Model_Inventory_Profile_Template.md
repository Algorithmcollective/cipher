# Frontier Model Inventory & Capability Profile (MASTER TEMPLATE)

**Document Title:** Frontier Model Inventory & Capability Profile for {{ORG_NAME}}  
**Version:** v{{VERSION}}  
**Last Updated:** {{LAST_UPDATED}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Jurisdiction(s):** California  
**Applicable Law(s):** California SB 53 – Transparency in Frontier Artificial Intelligence Act  

> Purpose: Identify which of {{ORG_NAME}}’s models are in scope for SB 53 (frontier / large frontier models), and document their core capabilities, safety‑relevant properties, and deployment profiles for transparency and risk management.[web:156][web:160][web:168]

---

## 1. SB 53 Applicability Summary

### 1.1 Organization Status

- {{ORG_NAME}} is classified as:
  - [ ] Non‑frontier developer under SB 53  
  - [ ] **Frontier developer** (meets frontier compute/capability thresholds)  
  - [ ] **Large frontier developer** (meets revenue / scale thresholds)  

Brief rationale (e.g., training FLOPs thresholds, revenue tests, and whether models meet “frontier” definitions under SB 53).[web:18][web:156][web:168]  

### 1.2 Models in Scope for This Inventory

- This inventory covers:
  - All **frontier models** as defined by SB 53.  
  - Any other large‑scale models voluntarily included for consistency.  

List of models in scope: {{MODEL_LIST}}.  

---

## 2. Model Inventory Table (High Level)

> Capture one row per relevant model or major variant; more detail follows in Section 3.[web:30][web:156]

| Model ID | Model Name | Version / Release | Frontier Status (Y/N) | Frontier Tier (frontier / large frontier) | Primary Modalities (text, image, code, audio, video, multi) | Primary Intended Use Cases |
|----------|------------|-------------------|------------------------|-------------------------------------------|-------------------------------------------------------------|----------------------------|
| {{M1_ID}} | {{M1_NAME}} | {{M1_VERSION}} | {{M1_FRONTIER}} | {{M1_TIER}} | {{M1_MODALITIES}} | {{M1_USES}} |
| {{M2_ID}} | {{M2_NAME}} | {{M2_VERSION}} | {{M2_FRONTIER}} | {{M2_TIER}} | {{M2_MODALITIES}} | {{M2_USES}} |

---

## 3. Per‑Model Capability & Safety‑Relevant Profile

Repeat this subsection for each SB‑53‑relevant model (M1, M2, …).[web:30][web:156][web:160]  

### 3.X {{MODEL_NAME}} ({{MODEL_ID}})

#### 3.X.1 Overview

- **Model family / architecture:** {{ARCH_TYPE}} (e.g., decoder‑only transformer).  
- **Parameter scale (approx.):** {{PARAM_COUNT}}.  
- **Training compute (FLOPs, approximate):** {{TRAIN_COMPUTE}}.  
- **Primary modalities:** {{MODALITIES}}.  
- **Primary intended uses:** {{INTENDED_USES}}.  

#### 3.X.2 Capability Profile (High Level)

Describe capabilities relevant to safety and SB 53, such as:[web:30][web:156]

- General‑purpose reasoning and code generation.  
- Scientific and engineering assistance (e.g., chemistry, biology, cybersecurity).  
- Content generation (text, image, audio, video).  
- Agentic / tool‑use capabilities (browsing, code execution, API control).  

Summarize any capability tiers (e.g., base vs. tools‑enabled vs. fine‑tuned variants).  

#### 3.X.3 Safety‑Relevant Domains

For each domain below, mark whether the model exhibits **material capabilities** and note any internal thresholds or tests used to evaluate them (e.g., cyber, chem‑bio, autonomy).[web:18][web:167]  

| Domain | Material Capability? (Y/N) | Notes (e.g., evals used, guardrails present) |
|--------|----------------------------|----------------------------------------------|
| Cybersecurity exploitation / malware assistance | {{X1}} | {{NOTES_X1}} |
| Chemistry / biology assistance (dual‑use risk) | {{X2}} | {{NOTES_X2}} |
| CBRN / weapons‑related information | {{X3}} | {{NOTES_X3}} |
| Personalized persuasion / political manipulation | {{X4}} | {{NOTES_X4}} |
| Autonomy / tool‑use / agents | {{X5}} | {{NOTES_X5}} |
| High‑fidelity synthetic media / deepfakes | {{X6}} | {{NOTES_X6}} |

#### 3.X.4 Deployment Profile

- **Access channels:** (API, hosted UI, on‑prem deployments, fine‑tune endpoints, open‑weight release).  
- **Access tiers:** (e.g., public/default, enterprise, research, high‑risk / privileged).  
- **Geographic scope:** where the model is available (including CA access).[web:30][web:157]  
- **Key downstream products / services using this model:** {{DOWNSTREAM_LIST}}.  

#### 3.X.5 Relationship to Other Models

- Parent/base models and major fine‑tunes.  
- Distinction between **frontier base** vs. smaller distilled / specialized models.  

---

## 4. Governance & Ownership Mapping

| Area | Responsible Owner | Backup / Delegate | Notes |
|------|-------------------|-------------------|-------|
| Frontier model inventory maintenance | {{OWNER_INV}} | {{DELEGATE_INV}} | {{NOTES_INV}} |
| Capability & safety profile updates | {{OWNER_CAP}} | {{DELEGATE_CAP}} | {{NOTES_CAP}} |
| SB 53 reporting & engagement with CA authorities | {{OWNER_REG}} | {{DELEGATE_REG}} | {{NOTES_REG}} |

[web:156][web:162]

---

## 5. Update & Review Cadence

- Inventory updated:
  - At least **annually**, and  
  - Upon major events:
    - New frontier model release.  
    - Substantial model update (e.g., capability jump, new modalities).  
    - Significant change to access tiers or deployment (e.g., open‑weight release).[web:156][web:159]  

- Link or reference to change‑management SOP for adding/removing models from this inventory.  

---

**End of Inventory Template**
