# Whistleblower & Internal Reporting Addendum – SB 53 Frontier AI (MASTER)

**Document Title:** SB 53 Frontier AI – Whistleblower & Internal Reporting Addendum – {{ORG_NAME}}  
**Version:** v{{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Applies To:** All employees and contractors; special provisions for SB‑53 “covered employees”

> Purpose: Operationalize SB 53 whistleblower protections and internal reporting mechanisms for catastrophic‑risk and compliance concerns related to frontier models.[web:18][web:22][web:160][web:178]

---

## 1. Scope and Definitions

- **Frontier model:** Any model meeting {{ORG_NAME}}’s SB‑53 frontier or large‑frontier thresholds.  
- **Covered employees (SB 53):** Employees whose duties include assessing, managing, or addressing risks or incidents involving frontier models.[web:18][web:174][web:64]  
- **Protected disclosure:** A good‑faith disclosure about:
  - (i) a specific and substantial danger to public health or safety from a catastrophic risk; or  
  - (ii) a known or suspected violation of SB 53 or related policies.[web:18][web:22][web:178]  

---

## 2. Protected Activity and Non‑Retaliation

### 2.1 Protected Activity

{{ORG_NAME}} prohibits retaliation against any employee, especially covered employees, who in good faith:

- Raises concerns internally about catastrophic‑risk issues or SB‑53 non‑compliance.  
- Reports such concerns to:
  - Supervisors or functional leaders with risk responsibilities.  
  - Internal safety, security, legal, or compliance teams.  
  - External authorities permitted under SB 53 (e.g., CA Attorney General, federal regulators).[web:18][web:167][web:174][web:28]  

### 2.2 Non‑Retaliation Commitment

- No adverse employment action (termination, demotion, reduced hours, harassment, etc.) may be taken because of a protected disclosure.  
- If an adverse action occurs after a disclosure, {{ORG_NAME}} bears the burden to show it would have taken the same action absent the disclosure, consistent with SB‑53 standards.[web:18][web:157][web:185][web:64]  

---

## 3. Internal Reporting Channels

### 3.1 Anonymous and Confidential Channels

{{ORG_NAME}} provides at least one **anonymous** and confidential reporting mechanism, such as:

- A third‑party whistleblower hotline and secure web portal.  
- An internal reporting email (e.g., frontier‑whistleblower@{{ORG_DOMAIN}}) that can be used via personal devices.[web:18][web:22][web:28][web:64]  

### 3.2 Additional Internal Options

Employees may also report directly to:

- Frontier Safety / Risk team.  
- Security and Incident Response.  
- Legal / Compliance.  
- HR business partners (for concerns involving retaliation or workplace treatment).  

---

## 4. Handling Reports and Feedback to Whistleblowers

### 4.1 Intake and Triage

- All SB‑53‑related reports are logged in {{REPORTING_SYSTEM}} with:
  - Date/time, reporter (if known), and summary.  
  - Whether the reporter is a covered employee.  
  - Whether allegations relate to catastrophic risk or SB‑53 violations.  

### 4.2 Investigation

- A cross‑functional team (Safety, Security, Legal, HR, as needed) will:
  - Assess credibility and urgency.  
  - Coordinate with the **Critical Safety Incident Playbook** where applicable.  
  - Keep the circle of knowledge as tight as practicable to protect confidentiality.[web:18][web:22][web:28]  

### 4.3 Status Updates

For covered employees making protected disclosures:

- {{ORG_NAME}} will provide **at least monthly status updates** on:
  - Whether the report is under investigation.  
  - Whether it has been closed and, where appropriate, high‑level outcomes.[web:18][web:22][web:160]  

---

## 5. Prohibited Agreements and Policies

- {{ORG_NAME}} will **not** use NDAs, employment contracts, or internal policies to:
  - Prevent or discourage employees from making protected disclosures to government authorities, including the CA Attorney General.  
  - Prohibit anonymous reporting about catastrophic risks or SB‑53 violations.[web:177][web:186][web:187][web:64]  

Any contract language that could be read to limit such disclosures is deemed inapplicable to SB‑53‑protected activity.  

---

## 6. Training and Awareness

- Covered employees will receive **specific training** on:
  - SB‑53 whistleblower rights and protections.  
  - Internal and external reporting options.  
  - How their role fits into catastrophic‑risk governance.  

- {{ORG_NAME}} will post notices (e.g., on intranet and in relevant facilities) summarizing SB‑53 whistleblower protections and how to report concerns.[web:18][web:22][web:28][web:64]  

---

## 7. Relationship to Other Policies

This addendum supplements:

- Code of Conduct.  
- Global Whistleblower / Speak‑Up Policy.  
- AI Safety / Frontier AI Framework.  
- SB‑53 Critical Safety Incident Playbook.  

In case of conflict, protections in this SB‑53 addendum and applicable law prevail.  

---

**End of Whistleblower & Internal Reporting Template**
