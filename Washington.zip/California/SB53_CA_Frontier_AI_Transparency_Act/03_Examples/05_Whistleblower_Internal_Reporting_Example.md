# SB 53 Frontier AI – Whistleblower & Internal Reporting Addendum – Aurora AI Labs

**Document Title:** SB 53 Frontier AI – Whistleblower & Internal Reporting Addendum – Aurora AI Labs  
**Version:** v1.0  
**Effective Date:** February 15, 2026  
**Owner:** Elena Martinez, VP, Legal & Compliance  
**Applies To:** All Aurora employees and contractors; special provisions for “covered employees” in Safety, Security, and Risk

> Purpose: Implement SB 53 whistleblower and internal reporting requirements for Aurora’s frontier models, ensuring employees can safely raise catastrophic‑risk and compliance concerns without fear of retaliation.[web:18][web:22][web:160][web:178]

---

## 1. Scope and Definitions

- **Frontier models at Aurora:** Aurora‑1 Frontier, Aurora‑1 Vision, Aurora‑1 Tools, and future models meeting internal frontier thresholds.  
- **Covered employees (SB 53):**  
  - Staff in Frontier Safety, Security Engineering, Incident Response, Risk & Compliance, and related teams whose duties include assessing, managing, or addressing risks and incidents involving frontier models.  

- **Protected disclosure:** Any good‑faith report that:
  - Identifies a specific and substantial danger to public health or safety from catastrophic risks associated with Aurora’s frontier models; or  
  - Alleges a violation of SB 53, including failures in catastrophic‑risk assessment, incident reporting, or whistleblower protections.[web:18][web:174][web:64]  

---

## 2. Protected Activity and Non‑Retaliation

### 2.1 Protected Activity at Aurora

Covered employees are protected when they, in good faith, report:

- Concerns that Aurora’s practices or models pose a catastrophic risk that is not being adequately mitigated.  
- Suspected failures to:
  - Conduct required catastrophic‑risk assessments.  
  - Report critical safety incidents within SB‑53 timelines.  
  - Maintain required internal channels or safeguards.  

Reports may be made internally or externally to regulators, including the California Attorney General or federal agencies.[web:18][web:167][web:174][web:28]  

### 2.2 Non‑Retaliation Commitment

Aurora prohibits retaliation against any employee making a protected disclosure. This includes:

- Firing, demotion, pay cuts, or denial of promotion.  
- Unjustified negative performance reviews or reassignments.  
- Harassment, intimidation, or threats.  

If an adverse employment action follows a disclosure, Aurora must show by clear and convincing evidence that it would have taken the same action regardless of the disclosure, consistent with SB‑53 guidance.[web:18][web:157][web:185][web:64]  

---

## 3. Internal Reporting Channels

### 3.1 Anonymous and Confidential Channels

Aurora provides multiple options:

- **Aurora Speak‑Up Line:** An independent, third‑party hotline and web portal that allows anonymous reporting from any location.  
- **SB‑53 Whistleblower Inbox:** frontier‑whistleblower@aurora.ai, monitored by Legal & Compliance with restricted access.  

Both are available to employees, contractors, and certain long‑term vendors.[web:18][web:22][web:28][web:64]  

### 3.2 Additional Internal Options

Employees may also:

- Raise concerns with their direct manager or any manager in the reporting chain.  
- Contact the Frontier Safety team, Security Incident Response, or the central Compliance team.  
- Discuss retaliation or workplace‑treatment concerns with HR.  

Employees are encouraged, but not required, to use internal channels before going to external authorities.  

---

## 4. Handling Reports and Feedback to Whistleblowers

### 4.1 Intake and Triage

When a report is received:

- It is logged in **Aurora Compliance Tracker (ACT)**, tagged as “SB‑53 Whistleblower” where applicable.  
- Legal & Compliance and Frontier Safety jointly assess:
  - Whether the reporter is a covered employee.  
  - Whether allegations implicate catastrophic‑risk management or SB‑53 compliance.  

### 4.2 Investigation

- A tailored investigation team is formed, led by Legal & Compliance, with participation from Safety, Security, HR, or others as needed.  
- Access to report details is limited to those with a need to know.  

Aurora aligns investigations with the **Critical Safety Incident Playbook** when a reported concern suggests a potential critical safety incident.[web:18][web:22][web:28]  

### 4.3 Status Updates

For covered employees:

- Aurora provides **monthly status updates** until the matter is closed, indicating:
  - Whether the report remains under review.  
  - Whether the investigation is complete and any high‑level, non‑confidential outcomes.  

For anonymous reporters, updates may be provided via the secure third‑party portal where possible.[web:18][web:22][web:160]  

---

## 5. Prohibited Agreements and Policies

- Aurora’s NDAs, IP agreements, and confidentiality policies **do not** prohibit employees from:
  - Making protected disclosures to government agencies or law‑enforcement.  
  - Using anonymous or internal reporting channels to raise catastrophic‑risk concerns.  

Aurora will not enforce any contractual clause in a way that conflicts with SB‑53 whistleblower protections, and will not require prior internal approval before contacting regulators about protected topics.[web:177][web:186][web:187][web:64]  

---

## 6. Training and Awareness

- All covered employees receive onboarding and annual training on:
  - SB‑53 requirements for catastrophic‑risk assessment and incident reporting.  
  - Their rights and protections as whistleblowers.  
  - How to use Aurora’s reporting channels.  

- Aurora posts notices on its internal portal and in California offices summarizing SB‑53 whistleblower protections and providing contact information for internal and external reporting options.[web:18][web:22][web:28][web:64]  

---

## 7. Relationship to Other Policies

This addendum supplements:

- Aurora Code of Conduct and Global Speak‑Up Policy.  
- Frontier AI Framework and SB‑53 Transparency & Safety Reports.  
- SB‑53 Critical Safety Incident – Reporting & Escalation Playbook.  

If any conflict arises, SB‑53 protections and this addendum control for SB‑53‑covered disclosures.  

---

**End of Whistleblower & Internal Reporting Addendum**
