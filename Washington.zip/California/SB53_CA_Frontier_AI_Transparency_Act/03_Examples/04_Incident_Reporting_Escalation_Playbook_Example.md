# SB 53 Critical Safety Incident – Reporting & Escalation Playbook for Aurora AI Labs

**Document Title:** SB 53 Critical Safety Incident – Reporting & Escalation Playbook for Aurora AI Labs  
**Version:** v1.0  
**Effective Date:** February 15, 2026  
**Owner:** Priya Rao, Director of Safety Operations  
**Scope:** Aurora‑1 Frontier, Aurora‑1 Vision, Aurora‑1 Tools and major downstream deployments  

> Purpose: Define how Aurora AI Labs identifies, triages, escalates, and reports critical safety incidents related to its frontier models, including 24‑hour vs 15‑day reporting to California’s Office of Emergency Services (OES), consistent with SB 53.[web:18][web:27][web:160]

---

## 1. Definitions & Scope

### 1.1 Critical Safety Incident (Operational Definition)

Aurora treats as a **critical safety incident** any event where:

- A frontier model or its deployments are reasonably believed to have:
  - Directly contributed to death or serious bodily injury, or  
  - Materially enabled a real‑world incident with large‑scale physical or economic harm; and/or  
- There is credible evidence of:
  - Loss of control or unauthorized access to Aurora‑1 model weights or core infrastructure.  
  - Deceptive model behavior (e.g., systematically bypassing safeguards) that materially increases catastrophic risk.  

This is aligned with SB 53’s focus on severe, high‑bar incidents rather than routine misuse.[web:28][web:174]  

### 1.2 In‑Scope Systems

- Aurora‑1 Frontier (A1‑F).  
- Aurora‑1 Vision (A1‑V).  
- Aurora‑1 Tools (A1‑T).  
- Any products where these models are used as the primary model (Aurora Chat, Aurora Code, major partner integrations).  

---

## 2. Detection & Intake

### 2.1 Detection Channels

Critical signals may come from:

- **Safety monitoring:** Abuse‑detection pipelines flag unusual patterns in high‑risk domains (e.g., weapons, chem‑bio, cyber).[file:2][web:27]  
- **Security operations:** Alerts from the security incident and event management (SIEM) system about anomalous access or exfiltration attempts.  
- **User reports:** Support tickets reporting dangerous or highly concerning outputs or behavior.  
- **Employee reports:** Anonymous or named disclosures via Aurora’s SB‑53 whistleblower channels.  

### 2.2 Initial Intake Checklist

The first responder (on‑call safety or security engineer) must:

- Open an incident in **Aurora Incident Tracker (AIT)** with:
  - Timestamp of discovery.  
  - Reporter identity and contact (if available).  
  - Preliminary description, affected systems, and any observed harm.  
- Tag the incident as “**SB53‑Candidate**” if a frontier model may be involved.  

---

## 3. Triage & Severity Classification

### 3.1 Triage (Within 4 Hours)

The on‑call triage team (Safety + Security) answers:

1. Is a frontier model (A1‑F/A1‑V/A1‑T) implicated?  
2. Is there any evidence of actual death, serious injury, or large‑scale physical/property harm?  
3. Is there evidence of:
   - Unauthorized access to model weights or core systems?  
   - Systematic bypassing of safeguards or deceptive model behavior?  

### 3.2 Severity Levels

- **SEV‑0 – Imminent/Ongoing Threat:**  
  - Clear, specific, and ongoing risk of death or serious injury (e.g., active guidance in a live attack scenario).  

- **SEV‑1 – Serious but Contained:**  
  - Serious harm or misuse has occurred, but no ongoing imminent threat remains (e.g., past event, now contained).  

- **SEV‑2 – Near‑Miss / Elevated Concern:**  
  - No realized harm, but clear indication that a frontier model could have materially contributed to catastrophic risk under slightly different conditions.  

Incidents at SEV‑0 or SEV‑1 that meet SB‑53 criteria are treated as **critical safety incidents** requiring external reporting timelines.[web:18][web:160][web:157]  

---

## 4. Escalation & Incident Command

### 4.1 Roles

- **Incident Commander (IC):**  
  - Rotating senior manager from Safety Operations.  
- **Safety Lead:**  
  - Evaluates catastrophic‑risk aspects and user‑harm dimensions.  
- **Security Lead:**  
  - Leads technical containment and forensic investigation.  
- **Legal / Regulatory:**  
  - Determines SB‑53 reportability and interfaces with OES and other authorities.  
- **Comms / PR:**  
  - Coordinates public statements if needed.  

### 4.2 Escalation Steps

- For **SEV‑0**:
  - Immediate page to IC, Safety Lead, Security Lead, and Legal.  
  - Escalation to executive on‑call.  
  - Begin parallel preparation of a **24‑hour OES notification** draft while actively containing the incident.  

- For **SEV‑1**:
  - IC, Safety, Security, and Legal join within 2 hours.  
  - Assess whether the event meets the SB‑53 “critical safety incident” bar and falls under the **15‑day** reporting window.  

[web:18][web:160][web:174]

---

## 5. Containment, Investigation, and Documentation

### 5.1 Containment

Depending on incident type, actions may include:

- Temporarily disabling affected API endpoints, tools, or access tiers.  
- Rolling back recent configuration changes or model versions.  
- Revoking compromised credentials and rotating keys.  

### 5.2 Investigation

The incident team documents:

- Root cause (e.g., misconfigured filters, exploited vulnerability, partner misuse).  
- Scope (time window, user cohorts, geographies, products).  
- The precise role of the frontier model in enabling or amplifying the harm (versus other systems).  

### 5.3 Documentation Requirements

Each SB53‑Candidate incident record in AIT must include:

- Detailed timeline of events and decisions.  
- Evidence of harm or risk (screenshots, logs, redacted as appropriate).  
- Mitigation steps and current status.  

This forms the basis for any SB‑53 reports and potential amendments.[web:18][web:27]  

---

## 6. SB‑53 External Reporting

### 6.1 When Aurora Reports

Aurora reports to California authorities when an incident:

- Meets the internal **critical safety incident** definition, and  
- Involves users, infrastructure, or operations that include California within the affected scope.  

### 6.2 Timelines

- **Imminent risk of death or serious injury (SEV‑0):**  
  - Notify relevant public‑safety / law‑enforcement entities and the California Office of Emergency Services **within 24 hours** of forming a reasonable belief that the incident occurred.[web:18][web:160][web:157]  

- **Other critical safety incidents (SEV‑1):**  
  - Report to OES **within 15 days** of discovery.[web:28][web:182]  

Legal / Regulatory signs off on timing and content of reports.  

### 6.3 Report Content (Aurora Template Fields)

Each OES report typically includes:

- Frontier models involved (e.g., Aurora‑1 Frontier v1.3).  
- Description of incident: what occurred, when, and how it was discovered.  
- Nature and magnitude of harm or credible risk.  
- Steps taken to contain, mitigate, and prevent recurrence.  
- Whether law‑enforcement or other regulators have been notified.  

### 6.4 Amendments

If new, material information emerges (e.g., revised scope of harm), Aurora sends an updated report to OES as soon as reasonably practicable, referencing the initial report.[web:32][web:174]  

---

## 7. Post‑Incident Review & Lessons Learned

Within 30 days of closing a critical safety incident:

- The IC convenes a **post‑incident review** with Safety, Security, Legal, and relevant engineering/product leads.  
- The team:
  - Identifies control and process gaps.  
  - Proposes changes to:
    - Model safeguards and filters.  
    - Access tiers and product configurations.  
    - Monitoring and detection rules.  
- Action items are entered into the SB‑53 remediation tracker and assigned owners and due dates.[web:18][web:167]  

---

## 8. Integration with Whistleblower & Internal Reporting

Aurora maintains SB‑53‑aligned whistleblower protections:

- Employees can report concerns through:
  - An anonymous hotline and secure web form.  
  - Directly to the Safety or Legal teams.  
- Whistleblowers receive periodic status updates on their disclosures, and retaliation is prohibited by policy and law.[web:18][web:27][web:160]  

This playbook is referenced in employee training to clarify how internal reports can trigger critical‑incident investigations and SB‑53 reporting where appropriate.  

---

**End of Playbook**
