# Frontier Model Risk & Safety Assessment for Aurora‑1 Frontier (Aurora AI Labs)

**Document Title:** Frontier Model Risk & Safety Assessment for Aurora‑1 Frontier (Aurora AI Labs)  
**Version:** v1.0  
**Assessment Date:** January 31, 2026  
**Assessed By:** Frontier Safety Team, Aurora AI Labs  
**Jurisdiction(s):** California (global deployment with CA access)  
**Applicable Law(s):** California SB 53 – Transparency in Frontier Artificial Intelligence Act  

> Purpose: Document the risks, evaluations, and mitigations for Aurora‑1 Frontier as part of Aurora AI Labs’ Frontier AI Framework and SB‑53 transparency obligations.[web:28][web:38][web:18]

---

## 1. Model Overview

- **Model Name:** Aurora‑1 Frontier  
- **Model ID / Family:** A1‑F (Aurora‑1 family)  
- **Version / Release Date:** v1.3 / October 2025  
- **Frontier Status:** Large frontier model under SB 53 thresholds.  
- **Primary Modalities:** Text (multilingual) and code.  
- **Primary Intended Uses / Product Surfaces:**  
  - Aurora Chat (general assistant).  
  - Aurora Code (developer assistant).  
  - Embedded copilots in third‑party SaaS applications.  

Aurora‑1 Frontier is treated as a “frontier model” because its training compute is in the mid‑10²⁶ FLOPs range and it exhibits state‑of‑the‑art general‑purpose capabilities at global scale.[web:18][web:174][web:168]  

---

## 2. Risk Identification – Catastrophic & High‑Impact Risks

### 2.1 Catastrophic Risk Definition (SB 53)

For this assessment, we adopt SB 53’s catastrophic‑risk definition: foreseeable and material risks where Aurora‑1 Frontier’s development, storage, use, or deployment could materially contribute to more than 50 deaths or more than $1B in property damage in a single incident across domains such as CBRN, autonomous cyberattacks, violent crime, or loss of control/self‑exfiltration.[web:28][web:18][web:171]  

### 2.2 Risk Register – Catastrophic Domains

| ID | Domain / Threat Area | Example Scenario(s) | Material Catastrophic Risk? (Y/N) | Notes |
|----|----------------------|---------------------|------------------------------------|-------|
| R1 | Chemical / biological misuse | Aurora‑1 Frontier provides step‑by‑step guidance that uplifts a low‑skill actor to design or deploy a dangerous biological agent. | Y (bounded) | Model can reason about biology and lab protocols. Safety fine‑tuning + filters are designed to block detailed actionable guidance. |
| R2 | CBRN / weapons | Model generates detailed plans for large‑scale attacks or weapons construction. | Y (bounded) | Able to summarize public info; guardrails block operational instructions and weapons design. |
| R3 | Autonomous cyberattacks | Model, when paired with tools, plans and executes multi‑step cyber campaigns. | Y (conditional) | Base model is text‑only; risk increases when connected to tools (Aurora‑1 Tools). Deployment kept to restricted tiers. |
| R4 | Physical violence / crime | Model plans and coordinates violent acts, extortion, or sophisticated theft schemes. | Y (bounded) | Can assist with planning if unguarded; policies and filters are tuned to refuse such content. |
| R5 | Loss of control / self‑exfiltration | Model uses deceptive behavior to bypass oversight or exfiltrate weights. | Y (low‑likelihood, high‑impact) | No such incidents observed; red‑teaming explores deception and control‑evasion behaviors. |
| R6 | Other catastrophic vectors | Large‑scale disinformation driving civil unrest. | Possibly | Treated as high‑impact but below SB‑53 catastrophic thresholds in most scenarios; monitored closely. |

[web:18][web:167][web:171]

### 2.3 Non‑Catastrophic but High‑Impact Risks

- Large‑scale misinformation and disinformation.  
- Targeted persuasive messaging and political manipulation.  
- Fraud and financial crime enablement (e.g., phishing, scams).  
- Privacy harms (e.g., reconstruction of sensitive data from training distributions).  

These are governed under Aurora’s broader AI risk program and described in public transparency materials, though they may not meet SB‑53 catastrophic thresholds.[web:27][web:160]  

---

## 3. Evaluation & Testing

### 3.1 Capability Evaluations

Aurora‑1 Frontier undergoes a mix of standardized benchmarks and custom safety evaluations:

| Domain | Eval / Benchmark | Method | Key Results / Thresholds |
|--------|------------------|--------|--------------------------|
| Cybersecurity | Internal “Aurora‑CyberEval v2” + red‑team scenarios | Human‑in‑the‑loop, simulated attackers | Model can generate exploit‑like code when unconstrained; current deployment filters block >95% of harmful prompts. |
| Chem‑bio | Custom “Aurora‑BioRisk Eval” informed by external best practices | SMEs + scripted test prompts | Model often refuses detailed protocols after safety‑tuning; flagged prompts are audited periodically. |
| CBRN | Targeted prompt suites on weapons‑related topics | Human eval + automated classifier checks | Model limited to high‑level public info; filter blocks detailed operational guidance. |
| Persuasion | Behavioral evals on targeted opinion‑shaping | Human panel + scale tests | Model can generate persuasive content; political persuasion and demographic targeting are blocked in policies. |
| Autonomy / agents | “Aurora‑AgentEval” using tool‑enabled sandbox | Simulated long‑horizon tasks | Model can plan multi‑step tool calls; guardrails constrain tool use and require human approvals for sensitive workflows. |

[web:167][web:173]

### 3.2 Thresholds for Elevated Risk

- Aurora defines internal thresholds (not public) where substantial increases in:
  - Success rate on certain cyber red‑team tasks.  
  - Chem‑bio protocol detail or specificity.  
  - Evidence of emergent deceptive or control‑evasion behaviors.  

Crossing these thresholds triggers a **risk review** and may delay or constrain deployment until additional mitigations are implemented.[web:18][web:171]  

---

## 4. Mitigations & Controls

### 4.1 Technical Safeguards

Key technical measures:

- Safety‑tuning and refusal training on disallowed behaviors.  
- Input/output classifiers for:
  - Weapons, chem‑bio, and violent‑crime prompts.  
  - Cyber exploitation and highly sensitive code.  
  - Political persuasion and targeted influence.  
- Context‑level heuristics to detect long‑horizon operational planning in dangerous domains.  
- Gradient of policies by access tier (public vs. enterprise vs. restricted research).  

[web:27][web:160]

### 4.2 Product & Access Controls

- **Public tier:**  
  - Strongest safety filters, conservative refusal behavior, rate limits.  
  - No tools or code execution.  

- **Enterprise tier:**  
  - Configurable safety profiles, but core catastrophic‑risk policies remain non‑overrideable.  

- **Restricted / internal tier:**  
  - Used for safety research and red‑teaming only, with approval and monitoring.  
  - Access limited to cleared staff; activity logging and review in place.[web:30][web:157]  

### 4.3 Organizational & Process Controls

- Frontier Safety Review Board reviews major releases and policy changes.  
- Change‑management process requires:
  - Updated risk assessment.  
  - Sign‑off from Safety, Security, and Legal for frontier‑model changes.  
- Integration with SB‑53 whistleblower‑protected channels for employees to report concerns.[web:18][web:27][web:172]  

---

## 5. Residual Risk & Justification for Deployment

### 5.1 Residual Risk Summary

- **Catastrophic risk:**  
  - Residual catastrophic risk is assessed as **Low–Medium**, acknowledging that under extreme misuse or systemic failure scenarios, Aurora‑1 Frontier could contribute to serious harms, especially when combined with external tools or actors.  
- **High‑impact risks:**  
  - Meaningful residual risk remains around misinformation, persuasion, and fraud enablement, mitigated but not eliminated by policy and filtering.  

### 5.2 Deployment Decision

> “Based on current evaluations and mitigations, we judge that deployment of Aurora‑1 Frontier to public and enterprise access tiers, without tool‑use, is acceptable under Aurora’s Frontier AI Framework, provided that: (a) catastrophic‑risk safeguards remain enabled across all tiers; (b) high‑risk tool‑use is limited to separate, more restricted models (Aurora‑1 Tools); and (c) this assessment is revisited following major model updates or new evidence of elevated risk.”

Signed:

- **Frontier Safety Lead:** ____________________ (Name, Title, Date)  
- **Chief Security Officer:** ____________________ (Name, Title, Date)  
- **General Counsel / Head of Regulatory:** ____________________ (Name, Title, Date)  

[web:18][web:34]

---

## 6. Monitoring, Incidents, and Re‑assessment

- **Ongoing Monitoring:**  
  - Abuse‑detection pipelines for dangerous domains.  
  - Periodic review of refusal logs, safety‑filter efficacy, and user‑reported incidents.  

- **Re‑assessment Triggers:**  
  - New model versions (e.g., Aurora‑1 Frontier v1.4+).  
  - Enabling new tools or modalities for this model.  
  - Any critical safety incident or credible near‑miss involving catastrophic‑risk vectors.  

Incident data flows into the SB 53 Critical Safety Incident reporting process and informs updates to Aurora’s public Frontier AI Framework and transparency reports.[web:27][web:172][web:167]  

---

**End of Assessment**
