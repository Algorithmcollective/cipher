# Frontier Model Transparency & Safety Report – Aurora‑1 Frontier (Aurora AI Labs)

**Document Title:** Frontier Model Transparency & Safety Report – Aurora‑1 Frontier (Aurora AI Labs)  
**Version:** v1.0  
**Publication Date:** January 31, 2026  
**Prepared By:** Frontier Governance & Safety Team, Aurora AI Labs  

> Purpose: Provide a public overview of Aurora‑1 Frontier’s capabilities, limitations, risks, safety testing, and mitigations, as part of Aurora AI Labs’ compliance with California’s Transparency in Frontier Artificial Intelligence Act (SB 53).[web:156][web:175][web:178]

---

## 1. Model Summary

- **Model name:** Aurora‑1 Frontier  
- **Model family / version:** Aurora‑1, v1.3  
- **Developer:** Aurora AI Labs  
- **Release date:** October 2025 (v1.3)  
- **Modalities:** Text (100+ languages) and code.  
- **Primary intended uses:**  
  - General‑purpose AI assistant for productivity and knowledge tasks.  
  - Developer assistant for code generation, explanation, and debugging.  
  - Enterprise copilots for internal knowledge and workflow support.  
- **Not designed for:**  
  - Providing step‑by‑step instructions for weapons, chemical, biological, or nuclear threats.  
  - Serving as a substitute for licensed professional advice (e.g., medical, legal, financial).  
  - Autonomous operation without human oversight in safety‑critical domains.[web:156][web:176]  

---

## 2. Intended Use, Deployment, and Access Restrictions

### 2.1 Intended Use & User Groups

Aurora‑1 Frontier is intended for:

- Individuals seeking assistance with writing, research, coding, and general knowledge questions.  
- Enterprise customers integrating the model into internal tools and workflows.  
- Developers building applications on top of Aurora’s API, subject to acceptable‑use policies.[web:156][web:181]  

### 2.2 Deployment & Access

Aurora‑1 Frontier is available via:

- Aurora Chat (web and mobile).  
- Aurora Code (IDE integrations).  
- Aurora API endpoints for approved partners.  

The model is accessible to users in many regions, including California, subject to legal and policy restrictions.  

### 2.3 Access Restrictions

Aurora uses multiple access tiers:

- **Public tier:**  
  - Strongest safety filters and rate limits.  
  - No external tools, code execution, or direct internet browsing.  

- **Enterprise tier:**  
  - Configurable policies within guardrails; more flexible integration, but core safety rules remain enforced.  

- **Restricted research tier:**  
  - Limited to internal staff and select research partners under strict controls; may involve experimental features to study safety and alignment.[web:30][web:157][web:175]  

---

## 3. Capabilities, Limitations, and Known Failure Modes

### 3.1 Key Capabilities

Aurora‑1 Frontier can:

- Generate and edit natural‑language text, including emails, summaries, and explanations.  
- Answer questions across many domains, drawing on patterns learned from training data.  
- Generate and explain code in several programming languages.  
- Perform multi‑step reasoning on well‑specified tasks, with limitations.[web:156][web:160]  

### 3.2 Limitations

- Aurora‑1 Frontier does **not** have real‑time access to the internet; its knowledge has a cutoff date and can be outdated.  
- It can “hallucinate” – producing confident but incorrect or fabricated information, citations, or code.  
- It does not have true understanding, beliefs, or intentions; it predicts text based on patterns in training data.  

Users should independently verify critical information and should not rely on the model as a sole source of truth.[web:25][web:179]  

### 3.3 Known Failure Modes

Examples of known failure modes:

- Generating plausible‑sounding but factually incorrect answers.  
- Over‑ or under‑estimating risks when asked unsafe or ambiguous questions.  
- Producing biased or insensitive content if prompted in certain ways, despite mitigation efforts.  

Aurora continuously refines training and filtering to reduce these failures, but cannot fully eliminate them.  

---

## 4. Risk & Safety Assessment (Summary)

### 4.1 Catastrophic‑Risk Assessment (SB 53 Summary)

Aurora‑1 Frontier has been evaluated under Aurora’s Frontier AI Framework for potential **catastrophic risks** as defined in SB 53, including scenarios involving large‑scale harm in chemical/biological, CBRN, cyber, and autonomy domains.[web:28][web:171][web:178]  

High‑level outcomes:

- Without safeguards, the model can produce content that would meaningfully assist certain harmful activities (e.g., exploit‑like code, detailed harmful instructions).  
- In deployed configurations, safety‑tuning and filters are designed to block step‑by‑step operational guidance for weapons, chem‑bio misuse, and serious violent or criminal activity.  
- Residual catastrophic risk is judged to be low under current deployment constraints, though Aurora continues to monitor for emerging risks.  

### 4.2 Other Safety & Risk Considerations

Aurora‑1 Frontier may contribute to non‑catastrophic but significant risks, including:

- Misinformation and disinformation.  
- Fraud and social‑engineering assistance.  
- Over‑reliance on the model in sensitive decision‑making contexts.  

Aurora’s policies restrict certain high‑risk uses (e.g., political persuasion, deceptive behavior, financial scams) and deploy technical and human review processes to reduce these risks.[web:27][web:176]  

### 4.3 Third‑Party Evaluation

Aurora has engaged external red‑team and research partners to:

- Test the model’s behavior in high‑risk domains (e.g., cyber, chem‑bio, persuasive messaging).  
- Provide feedback on safety mitigations and suggested improvements.  

We anticipate expanding third‑party evaluation partnerships as part of our ongoing SB‑53 compliance efforts.[web:156][web:178]  

---

## 5. Testing & Evaluation Overview

### 5.1 Safety Testing Program

Before and after deployment, Aurora‑1 Frontier is evaluated using:

- Internal benchmarks and adversarial test suites targeting:
  - Weapons and violent‑crime content.  
  - Chemical and biological misuse.  
  - Cybersecurity exploitation and malware.  
  - Political persuasion and targeted messaging.  
- Human red‑team exercises that probe the model for policy violations and bypass attempts.[web:167][web:173]  

### 5.2 Representative Evaluation Results

At a high level:

- In controlled tests, safety filters blocked a large majority of disallowed prompts in sensitive domains (we continually refine these metrics).  
- Some evasive or novel prompts can still elicit problematic responses; these cases inform updates to policies, training data, and filters.  

Quantitative details of thresholds and internal evals are withheld to avoid providing a roadmap for misuse, but results are used internally to guide mitigations.  

---

## 6. Safety Mitigations and Governance

### 6.1 Technical Safeguards

Aurora‑1 Frontier incorporates:

- Safety‑tuned training processes to improve refusal behavior.  
- Input and output filtering to detect and block content related to weapons, self‑harm, terrorism, and other prohibited categories.  
- Heuristics and classifiers to detect attempts to circumvent policies (e.g., obfuscated or staged instructions).  

[web:27][web:175]

### 6.2 Product & Policy Safeguards

- Acceptable‑Use Policy and Terms of Service prohibit:
  - Development or deployment of weapons.  
  - Harassment, discrimination, and hateful conduct.  
  - Fraud, scams, and other illegal activities.  
- Additional restrictions apply in political, health, and financial domains, including tighter prompting and output controls.[web:25][web:179]  

### 6.3 Governance & Oversight

- A Frontier Safety Review Board reviews major updates and policy changes for Aurora‑1 Frontier.  
- Governance processes align with Aurora’s broader Frontier AI Framework, which outlines how we assess catastrophic risks and manage scaling‑related safety concerns.[web:156][web:175]  

---

## 7. Monitoring, Incidents, and Updates

### 7.1 Ongoing Monitoring

Aurora monitors Aurora‑1 Frontier by:

- Sampling and reviewing model interactions (with privacy safeguards).  
- Tracking safety‑filter performance and refusal logs.  
- Investigating reports from users, partners, and employees about potential safety issues.[web:27][web:21]  

### 7.2 Incident Reporting

If you believe Aurora‑1 Frontier has been used or has behaved in a way that could cause serious harm:

- Contact our safety team at: **safety@aurora.ai**.  
- Employees can also report concerns through protected internal channels described in our whistleblower policy.  

When incidents meet SB‑53 criteria for **critical safety incidents**, Aurora will notify the California Office of Emergency Services within required timelines.[web:156][web:181][web:178]  

### 7.3 Future Updates

This transparency and safety report will be updated:

- When major new versions of Aurora‑1 Frontier are released.  
- When capabilities or access tiers change in ways that affect risk.  
- After material shifts in our assessment of catastrophic or other significant risks.  

Archived versions of this report will be retained for accountability and comparison over time.[web:156][web:175]  

---

**End of Transparency & Safety Report**
