# Frontier Model Inventory & Capability Profile for Aurora AI Labs

**Document Title:** Frontier Model Inventory & Capability Profile for Aurora AI Labs  
**Version:** v1.0  
**Last Updated:** January 31, 2026  
**Owner:** Maya Chen, Head of Frontier Governance  
**Jurisdiction(s):** California (global deployment with CA access)  
**Applicable Law(s):** California SB 53 – Transparency in Frontier Artificial Intelligence Act  

> Purpose: Identify Aurora AI Labs’ models that qualify as frontier models under SB 53 and document their capabilities, safety‑relevant properties, and deployment profiles to support compliance and risk management.[web:156][web:160][web:168]

---

## 1. SB 53 Applicability Summary

### 1.1 Organization Status

- Aurora AI Labs is classified as a:
  - [ ] Non‑frontier developer  
  - [x] **Frontier developer**  
  - [x] **Large frontier developer**  

Rationale:

- Aurora trained multiple general‑purpose foundation models with training compute exceeding SB 53’s frontier thresholds (on the order of 10²⁶ FLOPs and above).[web:18][web:156]  
- Consolidated annual revenue from frontier‑model products exceeds the “large frontier developer” threshold specified in SB 53, triggering enhanced reporting and safety obligations.[web:159][web:168]  

### 1.2 Models in Scope for This Inventory

This inventory covers:

- Aurora‑1 Frontier (A1‑F) – primary large‑scale text‑first foundation model.  
- Aurora‑1 Vision (A1‑V) – multimodal variant with image and limited video understanding.  
- Aurora‑1 Tools (A1‑T) – tools‑enabled version of Aurora‑1 for code execution and browsing.  

---

## 2. Model Inventory Table (High Level)

| Model ID | Model Name | Version / Release | Frontier Status (Y/N) | Frontier Tier | Primary Modalities | Primary Intended Use Cases |
|----------|------------|-------------------|------------------------|---------------|--------------------|----------------------------|
| A1‑F | Aurora‑1 Frontier | v1.3 (2025‑Q4) | Y | Large frontier | Text (multilingual), code | General‑purpose assistant, coding help, enterprise copilots |
| A1‑V | Aurora‑1 Vision | v1.1 (2025‑Q4) | Y | Frontier | Text + images | Multimodal assistants, document understanding, visual Q&A |
| A1‑T | Aurora‑1 Tools | v1.0 (2026‑Q1) | Y | Large frontier | Text + tools (browser, code exec) | Agentic workflows, automation, research & analysis |

[web:30][web:156]

---

## 3. Per‑Model Capability & Safety‑Relevant Profile

### 3.1 Aurora‑1 Frontier (A1‑F)

#### 3.1.1 Overview

- **Architecture:** Large decoder‑only transformer (dense, >200B parameters).  
- **Approx. parameter count:** 220B.  
- **Training compute:** Estimated mid‑10²⁶ FLOPs (frontier threshold exceeded).[web:18][web:160]  
- **Primary modalities:** Text (100+ languages) and code.  
- **Primary intended uses:**  
  - General‑purpose chat assistant.  
  - Productivity and writing support.  
  - Code generation and debugging.  
  - Enterprise knowledge management.  

#### 3.1.2 Capability Profile (High Level)

- Strong performance on reasoning and coding benchmarks; competitive with other state‑of‑the‑art frontier models.  
- Capable of multi‑step reasoning, high‑quality code synthesis, and summarization across large documents.  
- No built‑in tool use beyond limited code‑interpretation features (more advanced tool use is handled by Aurora‑1 Tools).  

#### 3.1.3 Safety‑Relevant Domains

| Domain | Material Capability? (Y/N) | Notes |
|--------|----------------------------|-------|
| Cybersecurity exploitation / malware assistance | Y | Model can generate exploit‑like code and offensive security content if unguarded; internal red‑teaming and tooling enforce strict policies and filtering. |
| Chemistry / biology assistance (dual‑use risk) | Y (bounded) | Can explain scientific concepts and protocols at a high level; mitigations in place to block step‑by‑step guidance for dangerous applications. |
| CBRN / weapons‑related information | Y (bounded) | Capable of retrieving or synthesizing weapons‑related info; safety layers block detailed or operational instructions. |
| Personalized persuasion / political manipulation | Y | Can generate targeted messaging; guardrails block political persuasion and sensitive demographic targeting where feasible. |
| Autonomy / tool‑use / agents | Limited | Core model is not wired to external tools by default; some internal evals show potential when connected to orchestration frameworks. |
| High‑fidelity synthetic media / deepfakes | N (text‑only) | No direct image/audio/video generation; indirect risk via prompting other systems. |

[web:18][web:167]

#### 3.1.4 Deployment Profile

- **Access channels:**  
  - Public API.  
  - Hosted chat UI at app.aurora.ai (logged‑in users).  
  - Enterprise deployments via VPC peering.  
- **Access tiers:**  
  - Public tier with strict safety filters and rate limits.  
  - Enterprise tier with configurable policies; no raw model weights exposed.  
- **Geographic scope:**  
  - Global availability, including users located in California.  
- **Key downstream uses:**  
  - Aurora Chat, Aurora Code, several third‑party SaaS copilots.  

#### 3.1.5 Relationship to Other Models

- Serves as base for smaller specialized models (Aurora‑Code‑XL, Aurora‑Support‑Pro).  
- Aurora‑1 Tools and Aurora‑1 Vision share core weights but add capabilities.  

---

### 3.2 Aurora‑1 Vision (A1‑V)

#### 3.2.1 Overview

- **Architecture:** Multimodal transformer (text + vision encoders).  
- **Parameter scale:** ~260B equivalent.  
- **Modalities:** Text + images (documents, photos, UI screenshots).  
- **Intended uses:** Document understanding, visual Q&A, enterprise workflows involving PDFs and diagrams.  

#### 3.2.2 Capability & Safety‑Relevant Notes

- Strong OCR and document‑understanding performance, including charts and tables.  
- Can interpret some complex laboratory images or schematics, raising dual‑use concerns in scientific contexts.  
- Safety layers tuned to down‑rank or block harmful visual content requests (e.g., weapons schematics).[web:30][web:156]  

---

### 3.3 Aurora‑1 Tools (A1‑T)

#### 3.3.1 Overview

- **Architecture:** Aurora‑1 Frontier plus tools‑orchestration layer.  
- **Tools enabled:**  
  - Managed browser.  
  - Sandboxed code execution.  
  - Limited connectors (e.g., internal knowledge bases).  

#### 3.3.2 Safety‑Relevant Domains

- Increases risk in cyber, data exfiltration, and autonomy domains when misconfigured.  
- Subject to stricter access controls and internal approvals for high‑risk use cases.[web:18][web:167]  

---

## 4. Governance & Ownership Mapping

| Area | Responsible Owner | Backup / Delegate | Notes |
|------|-------------------|-------------------|-------|
| Frontier model inventory maintenance | Head of Frontier Governance | Lead Program Manager, AI Risk | Quarterly review and ad‑hoc updates on major releases. |
| Capability & safety profile updates | Head of Safety Science | Safety Tech Lead | Synced with major eval rounds and red‑team cycles. |
| SB 53 reporting & CA engagement | Director, Regulatory Affairs | Senior Counsel, AI & Safety | Coordinates submissions to CA authorities and public transparency reports. |

[web:156][web:162]

---

## 5. Update & Review Cadence

- Inventory and capability profiles are reviewed:
  - Quarterly by the Frontier Governance WG.  
  - Immediately following:
    - New SB‑53‑relevant model releases.  
    - Major architecture or training‑compute changes.  
    - New evidence of qualitatively higher‑risk capabilities (e.g., stronger cyber, chem‑bio, or autonomous‑agent performance).[web:156][web:159]  

- Changes are logged in the Aurora Change Management system and linked to SB 53 transparency and safety reports.  

---

**End of Inventory**
