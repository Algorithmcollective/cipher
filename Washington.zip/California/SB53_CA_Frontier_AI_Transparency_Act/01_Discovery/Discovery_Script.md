# SB53 Discovery Call Script (California SB 53)

Purpose: Gather information needed to prepare Frontier AI compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Organization Classification & Frontier Status

Say:
“I need to understand whether your organization develops or deploys advanced AI models.”

Ask:

- Do you train AI models internally?  
- Do you fine-tune large models?  
- Do you release models publicly or via API?  
- Estimated model scale (parameters / compute if known)  
- Revenue / scale indicators relevant to frontier thresholds  
- Organization classification (developer, deployer, both)

---

## 🧾 Deliverable: Frontier Model Inventory & Capability Profile

Ask for each model:

- Model name  
- Model family / architecture  
- Version / release date  
- Modalities (text, image, code, video, multimodal)  
- Primary intended uses  
- Parameter scale (estimate ok)  
- Training compute (estimate ok)  
- Downstream products using the model  
- Access channels (API, UI, enterprise, open weights)

---

## 🧾 Deliverable: Capability & Safety Domains

Ask:

- Cybersecurity capability  
- Chem-bio assistance capability  
- CBRN information capability  
- Persuasion capability  
- Agentic / tool use capability  
- Synthetic media / deepfake capability  
- Internal thresholds used to evaluate capability

---

## 🧾 Deliverable: Risk & Safety Assessment

Ask:

- Catastrophic risk scenarios considered  
- Domains assessed (cyber, chem-bio, autonomy, etc.)  
- Evaluation methods used (benchmarks, red-team, third-party)  
- Thresholds for elevated risk  
- High-impact but non-catastrophic risks identified

---

## 🧾 Deliverable: Mitigations & Controls

Ask:

- Alignment or safety tuning methods  
- Filters / classifiers used  
- Access tiers and restrictions  
- Approval requirements for high-risk use  
- Governance boards or review committees

---

## 🧾 Deliverable: Deployment Decision & Residual Risk

Ask:

- Residual risk rating  
- Who approves deployment  
- Conditions for restricted release  
- Triggers for reassessment

---

## 🧾 Deliverable: Transparency & Safety Report

Ask:

- Intended user groups  
- Known limitations  
- Known failure modes  
- Public disclosures planned  
- Third-party evaluation involvement

---

## 🧾 Deliverable: Incident Reporting & Escalation

Ask:

- How incidents are detected  
- Incident intake system used  
- Severity classification method  
- Incident command roles  
- External reporting decision owner  
- 24-hour vs 15-day reporting criteria

---

## 🧾 Deliverable: Whistleblower & Internal Reporting

Ask:

- Anonymous reporting channel exists  
- Internal reporting email / hotline  
- Who investigates reports  
- Non-retaliation policy exists  
- Status updates to reporters  
- Training for covered employees

---

## ✅ Closing

Say:

“That gives us what we need to prepare your SB53 documentation. Anything marked TBD we’ll follow up on internally.”