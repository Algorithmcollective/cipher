# SB53 Discovery Worksheet

---

## Organization Classification

Develops Models Internally:  
Fine-Tunes Models:  
Release Channels:  
Estimated Model Scale:  
Organization Classification:  

---

## Frontier Model Inventory (repeat per model)

Model Name:  
Architecture:  
Version / Release Date:  
Modalities:  
Intended Uses:  
Parameter Scale:  
Training Compute:  
Downstream Products:  
Access Channels:  

---

## Capability & Safety Domains

Cyber Capability:  
Chem-Bio Capability:  
CBRN Capability:  
Persuasion Capability:  
Agentic Capability:  
Synthetic Media Capability:  
Evaluation Thresholds:  

---

## Risk & Safety Assessment

Catastrophic Scenarios:  
Domains Assessed:  
Evaluation Methods:  
Risk Thresholds:  
High-Impact Risks:  

---

## Mitigations & Controls

Alignment Methods:  
Filters / Guardrails:  
Access Tiers:  
Approval Requirements:  
Governance Bodies:  

---

## Deployment Decision

Residual Risk Rating:  
Deployment Approval Owner:  
Release Conditions:  
Reassessment Triggers:  

---

## Transparency & Safety

User Groups:  
Limitations:  
Failure Modes:  
Public Disclosures Planned:  
Third-Party Evaluation:  

---

## Incident Reporting

Detection Methods:  
Incident System:  
Severity Levels:  
Incident Roles:  
External Reporting Owner:  
Reporting Criteria:  

---

## Whistleblower & Internal Reporting

Anonymous Channel Exists:  
Reporting Email / Hotline:  
Investigation Owner:  
Non-Retaliation Policy:  
Status Updates Process:  
Training Provided:  

---

## TBD / Follow-Ups

Item:  
Owner:  
Notes:  