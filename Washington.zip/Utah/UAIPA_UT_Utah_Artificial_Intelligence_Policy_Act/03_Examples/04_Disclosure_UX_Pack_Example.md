File: UT_04_UAIPA_Disclosure_UX_Pack_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA Disclosure UX Pack (Example – BeehiveHelp, Inc.)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose of this pack

This pack shows how BeehiveHelp implements Utah‑aligned AI disclosures in its AI Chatbot and related features.  
It is used by Product, UX, and Engineering to keep the live experience consistent with the UAIPA AI Disclosure Policy.  

---

## 2. Coverage map

| System ID | System Name             | Channel / Surface                         | UAIPA Disclosure Type (On‑Request / Proactive / Both) | Key Utah Touchpoints (Yes/No + notes)                        |
|-----------|-------------------------|-------------------------------------------|-------------------------------------------------------|--------------------------------------------------------------|
| AI-01     | BeehiveHelp AI Chatbot  | Web chat widget on merchant sites         | On‑Request (general); optional proactive label        | Yes – ~3,200 Utah conversations/month across 27 merchants    |
| AI-02     | Agent Reply Assist      | Internal agent console (no direct chat)   | None (no direct consumer AI interaction)             | Yes – drafts messages for agents who serve Utah customers    |
| AI-03     | KB Article Generator    | Merchant admin console (FAQ drafting)     | None (no real‑time AI chat with consumers)           | Possible – content published to Utah‑facing help centers     |

---

## 3. Web chatbot copy – BeehiveHelp AI Chatbot (AI‑01)

### 3.1 First‑message and label

BeehiveHelp provides a default configuration merchants can enable:

- Chat header label:  
  > “AI‑powered assistant”

- Example first message:  
  > “Hi, I’m an AI‑powered assistant that can help with order questions, returns, and general support. I can also connect you with a person if needed.”

Some merchants keep the label only; others use the full first‑message disclosure.  

### 3.2 On‑request disclosure

The AI Chatbot is configured with a high‑priority rule that triggers on user questions like:

- “Are you a bot?”  
- “Are you AI?”  
- “Is this a real person?”  

Standard response:

> “I am an AI‑powered virtual assistant, not a human.”

Optional extended template (used by some merchants):

> “I am an AI‑powered virtual assistant, not a human. I can connect you with a human support agent if you prefer.”

These responses are hard‑coded in the chatbot configuration rather than left entirely to the model.  

---

## 4. Voice / phone bot scripts (reserved)

BeehiveHelp does not currently operate its own GenAI voice bots.  
If BeehiveHelp adds a phone‑based AI assistant, it will reuse the following patterns:

- Opening:  
  > “This call uses an AI‑powered assistant to help provide information. You can ask for a person at any time.”

- On‑request:  
  > “You’re speaking with an AI‑powered assistant, not a human. I can transfer you to a person if you’d like.”

---

## 5. Email and message templates

For Utah‑facing customer‑service emails drafted with Agent Reply Assist:

- Agents review and edit all AI drafts; messages are sent from a human agent identity.  
- BeehiveHelp does not require a standard AI disclosure in these messages because they are human‑reviewed and used for low‑risk customer service.  

If BeehiveHelp later supports high‑risk uses (e.g., health or financial advice drafts), the following line may be added:

> “This message was prepared with the assistance of AI tools and reviewed by our team.”

---

## 6. Regulated occupation / high‑risk scripts (future use)

BeehiveHelp currently prohibits merchants from using its AI features for clinical, legal, or investment advice in Utah.  
If this changes, BeehiveHelp will require merchants in regulated occupations to add language like:

- Health:  
  > “I use an AI‑powered assistant to help draft information for you, but I review and decide what to share.”

- Financial/legal:  
  > “An AI tool helps me generate information and drafts, but any advice I give is based on my own professional judgment.”

These scripts would appear at the beginning of interactions or in onboarding flows for new customers.  

---

## 7. Advertising & promotions inside BeehiveHelp AI Chatbot

BeehiveHelp’s AI Chatbot can show simple store promotions:

- Example promotion snippet:  
  > “Promotion: Save 10% on your next order with code SAVE10 at checkout.”

UX rules:

- “Promotion:” prefix is included in the message template.  
- Promotional messages use a distinct style (e.g., tag or badge) in the merchant’s theme.  
- Merchants review and approve promotional templates before enabling them.  

---

## 8. UX checklist – AI‑01 BeehiveHelp AI Chatbot

- First‑message disclosure available and documented.  
- On‑request AI/bot disclosure configured and tested for multiple phrasings.  
- Chat header can display “AI‑powered assistant” label.  
- Promotional messages labeled and visually distinct.  
- Screenshots captured and stored at:  
  - `/UX/UT/AI-01/chat_header.png`  
  - `/UX/UT/AI-01/on_request_disclosure.png`  

---

## 9. Maintenance

- Product Manager, Chat Experiences, owns this UX pack for AI‑01.  
- Changes to disclosure text go through Legal/Compliance review prior to release.  
- The pack is revisited at least annually and after any significant changes to Utah AI law or BeehiveHelp’s chatbot flows.
