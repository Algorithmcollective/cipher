File: UT_08_UAIPA_Incident_Complaint_RUNBOOK_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Policy & Consumer Transparency provisions  
Document Type: UAIPA Incident & Complaint Handling Runbook (Example – BeehiveHelp, Inc.)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose

This runbook explains how BeehiveHelp handles incidents and complaints involving its AI Chatbot and AI‑assisted tools when they affect merchants or consumers in Utah.  
It is used by Support, Product, and Compliance to coordinate investigation and remediation.  

---

## 2. Scope

Covers AI‑related issues involving:

- AI‑01 BeehiveHelp AI Chatbot (customer‑facing).  
- AI‑02 Agent Reply Assist (draft responses).  
- AI‑03 KB Article Generator (draft help content).  

Examples in scope:

- A Utah shopper reports that “the bot lied about the return policy.”  
- A merchant reports that the bot failed to admit it is AI when asked.  
- A Utah‑based merchant claims AI drafts are creating confusing messages about shipping or promotions.  

---

## 3. Intake channels

BeehiveHelp receives AI‑related issues via:

- Merchant support tickets in the BeehiveHelp dashboard.  
- Direct emails to support@beehivehelp.com or compliance@beehivehelp.com.  
- Slack/Teams channels for strategic merchants.  
- Internal QA/testing reports.  

All staff who see a potential AI issue:

1. Create or update a ticket in the “AI – Utah” queue in Zendesk.  
2. Tag the ticket with `AI`, `UT`, and the relevant system ID (AI‑01/02/03).  

---

## 4. Initial logging

Support logs at least:

- Ticket ID: e.g., `UT-AI-2026-0007`  
- Date/time: e.g., January 15, 2026, 10:23 AM MST  
- Reporter: Merchant name, contact, or consumer if known  
- Channel: Merchant dashboard ticket  
- Systems involved: AI‑01 (BeehiveHelp AI Chatbot)  
- Description: “Utah customer says bot promised a 20% discount that doesn’t exist.”  
- Utah nexus: Merchant is Utah‑based retailer; complaint references Utah customer.  

Ticket is assigned to the Product Owner, Chat Experiences, with Compliance CC’d for Utah‑tagged cases.  

---

## 5. Triage and severity assessment

The Product Owner and Director of Compliance quickly categorize:

- **Low:** One‑off confusion where the bot gave a vague but not clearly false answer.  
- **Medium:** Several conversations where the bot misstates promotion details for Utah customers, but merchant can easily correct.  
- **High:** Bot repeatedly presents nonexistent or expired promotions to Utah customers, or misstates key rights (e.g., return windows) in a way that could be materially misleading.  

Example:

- For the “20% discount” case, investigation shows the bot improvised a discount based on an outdated training example.  
- Severity set to **Medium**, because it appears limited but is clearly incorrect.  

---

## 6. Investigation steps – example

For ticket `UT-AI-2026-0007`:

1. **Gather artifacts**  
   - Pull conversation logs for the affected session(s).  
   - Capture screenshots from the merchant’s site showing the conversation.  
   - Retrieve current promotion configuration in the merchant’s BeehiveHelp account.  

2. **Reproduce**  
   - Use a test account to ask similar questions (“Any discounts today?”, “Do you have a 20% sale?”) and see if the bot repeats the error.  

3. **Root cause**  
   - Determine that the bot responded with a generic “20% off” message not tied to any active campaign, due to a generic promotion example in the system prompt.  

4. **Impact**  
   - Merchant identified 3 Utah conversations where the incorrect discount was mentioned over a two‑day period.  
   - No completed orders were found that relied on this exact 20% claim, but there is a risk of confusion.  

All findings are stored in the incident details section of the ticket.  

---

## 7. Remediation and communication – example

For the “20% discount” incident, BeehiveHelp:

- Removes generic promotional examples from the system prompt and configures the chatbot to use only structured, merchant‑configured promotions.  
- Pushes a prompt update to all merchants using AI‑01.  
- Provides the Utah merchant with a suggested message they can send to affected customers or post in their FAQ if needed.  

Ticket notes:

- Prompt update deployed January 17, 2026.  
- Merchant confirmed no further incorrect 20% discount messages observed after the fix.  

---

## 8. Escalation to Legal/Compliance and leadership

For this example, the Director of Compliance reviewed the issue and determined:

- No regulatory contact had occurred; the issue was limited to a small number of Utah customers.  
- No immediate need to notify regulators, but the case is recorded as an “UT‑AI” incident for trend analysis.  

If future incidents involve more severe misrepresentations or regulatory inquiries, cases will be escalated to General Counsel and, if necessary, outside counsel.  

---

## 9. Linkage to Utah‑specific risk management

The “20% discount” case is included in BeehiveHelp’s Q1 2026 Utah AI oversight summary:

- Category: Misstated promotion in chatbot.  
- System: AI‑01.  
- Utah nexus: Utah merchant and customers.  
- Key fix: Removal of free‑form promo language from prompts; only campaign‑backed promotions allowed.  

The incident also triggers updates to:

- UT_06 Chatbot Advertising & Targeting Controls (clarified that AI may not invent promotions).  
- Merchant guidance documents.  

---

## 10. Closure and lessons learned

Once remediation is complete and verified:

- The ticket status is changed to “Closed – Remediated.”  
- A brief “lessons learned” note is added:  
  - Avoid generic promotional examples in prompts.  
  - Require structured promos for AI‑surfaced offers.  

This summary is shared in the internal #ai‑risk Slack channel and added to the quarterly AI oversight slide deck.  

---

## 11. Review cadence

BeehiveHelp’s Compliance team reviews all `UT`‑tagged AI incidents quarterly to identify trends.  
Patterns (e.g., recurring disclosure failures or promotions issues) may lead to additional prompt updates, UI changes, or merchant education efforts.  
