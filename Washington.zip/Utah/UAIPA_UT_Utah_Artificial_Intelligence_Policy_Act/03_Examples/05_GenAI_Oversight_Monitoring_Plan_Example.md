File: UT_05_GenAI_Oversight_Monitoring_PLAN_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: GenAI Oversight & Monitoring Plan (Example – BeehiveHelp, Inc.)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose and scope

This plan explains how BeehiveHelp, Inc. oversees and monitors its generative AI systems that are used in customer‑support operations and may interact with Utah consumers.  
It focuses on the BeehiveHelp AI Chatbot and related tools that draft content for customer communications.  

---

## 2. Systems covered

This plan applies to the following systems from BeehiveHelp’s UT_02 inventory:

| ID   | System Name             | Channel / Use Case                                      | Utah Exposure Summary                                   |
|------|-------------------------|---------------------------------------------------------|---------------------------------------------------------|
| AI-01| BeehiveHelp AI Chatbot  | Customer‑facing chat widget on merchant e‑commerce sites| ~3,200 Utah conversations/month across 27 merchants     |
| AI-02| Agent Reply Assist      | Internal draft assistant for agent emails and chats     | Used daily by support teams that serve Utah customers   |
| AI-03| KB Article Generator    | Drafts FAQ/help‑center articles for merchants          | Some generated content published to Utah‑facing sites   |

---

## 3. Oversight roles and responsibilities

- **Product – Chat Experiences (AI‑01):** Owns behavior, guardrails, and roadmap for the AI Chatbot.  
- **Product – Agent Tools (AI‑02, AI‑03):** Owns behavior of drafting tools.  
- **Engineering – Conversational AI:** Implements prompts, configurations, and logging.  
- **Director of Compliance:** Oversees UAIPA compliance and reviews high‑risk issues.  
- **Customer Success:** Escalates unusual AI behavior reported by merchants.  

Each AI system has a designated business owner, technical owner, and compliance contact documented in UT_02.  

---

## 4. Pre‑deployment review

Before deploying or materially changing AI‑01, AI‑02, or AI‑03 for merchants with Utah operations, BeehiveHelp:

1. Confirms whether the changes affect Utah‑facing chat flows, emails, or help content.  
2. Reviews prompts and configuration to ensure:  
   - The chatbot does not claim to be a human.  
   - AI prompts discourage speculation on clinical, legal, or financial topics.  
   - Marketing language remains consistent with merchants’ policies.  
3. Runs test conversations that include:  
   - Typical customer‑service questions.  
   - “Are you a bot?” and similar questions.  
   - Attempts to solicit advice that BeehiveHelp does not support (clinical/legal/financial).  

Results are captured in a short “AI Pre‑Launch Checklist” stored with the relevant product documentation.  

---

## 5. Ongoing monitoring

### 5.1 Sampling and review

BeehiveHelp performs monthly spot checks for AI‑01 and quarterly checks for AI‑02 and AI‑03:

- **AI‑01 – BeehiveHelp AI Chatbot**  
  - Randomly sample 50 conversations each month from merchants with Utah operations.  
  - Review for:  
    - Correct AI disclosure when customers ask if the bot is human.  
    - Misleading information about orders, returns, or promotions.  
    - Inappropriate content or tone.  

- **AI‑02 – Agent Reply Assist**  
  - Quarterly sample of 30 AI‑drafted messages sent to Utah customers (post‑human review).  
  - Confirm that agents edited or rejected drafts that were unclear or too aggressive.  

- **AI‑03 – KB Article Generator**  
  - Quarterly sample of 10 published help‑center articles that originated from AI drafts.  
  - Check for accuracy on policies and basic information.  

All findings are logged in BeehiveHelp’s “AI Monitoring Log” (a shared spreadsheet) with fields for system ID, date, issue description, and severity.  

### 5.2 Automated checks

For AI‑01, BeehiveHelp configures simple keyword alerts:

- Flags conversations containing phrases like “bot,” “real person,” or “AI” to verify the disclosure flow worked as intended.  
- Flags conversations mentioning “diagnosis,” “medical advice,” “legal advice,” or “investment advice” for manual review.  

---

## 6. Incident criteria and escalation

BeehiveHelp treats the following as AI incidents:

- Repeated failures by AI‑01 to disclose that it is AI when asked.  
- AI‑generated responses that could misrepresent order eligibility, pricing, or return rights.  
- AI‑driven content that appears to give clinical, legal, or investment advice.  

When an incident is suspected:

1. The observer (internal or merchant) informs Customer Success or the system owner.  
2. The owner logs the issue in the AI Monitoring Log and notifies the Director of Compliance.  
3. The Director of Compliance classifies the severity and works with Product/Engineering to determine next steps.  

High‑severity incidents are reviewed within two business days.  

---

## 7. Remediation actions

Examples of remediation BeehiveHelp may use:

- Updating the AI‑01 system prompt to further discourage sensitive topics.  
- Tightening or disabling AI‑generated responses for specific intents (e.g., returns eligibility) in favor of rule‑based answers.  
- Temporarily disabling AI features for a specific merchant while issues are addressed.  
- Providing additional training materials to merchants on how to configure safe flows.  

For each incident, BeehiveHelp documents:

- Summary of what occurred.  
- Root cause (e.g., prompt gap, configuration, merchant customization).  
- Fix implemented and date.  
- Any need to revise policies or training.  

---

## 8. Vendor oversight

BeehiveHelp uses a third‑party LLM provider as the backend for AI‑01–03:

- Engineering maintains documentation of the provider’s safety features and configurable parameters.  
- BeehiveHelp uses system prompts and post‑processing to mitigate hallucination and off‑policy behavior.  
- If repeated vendor‑driven issues occur, BeehiveHelp may change model settings, restrict certain features, or consider alternative providers.  

---

## 9. Reporting and metrics

Each quarter, the Director of Compliance prepares a brief AI oversight summary for leadership, including:

- Number of Utah‑related conversations sampled for AI‑01.  
- Any incidents involving Utah merchants or consumers.  
- Trends in merchant configurations that increase or decrease risk.  
- Planned improvements to prompts, monitoring, or training.  

This report is discussed in the Product–Compliance sync and used to prioritize roadmap changes.  

---

## 10. Review and updates

BeehiveHelp will review and update this plan:

- Every January.  
- After any major AI incident involving Utah consumers.  
- When Utah updates AI‑related guidance or BeehiveHelp launches new GenAI products.  

Updates are approved by the Director of Compliance with input from Product and Engineering leadership.
