File: UT_06_Chatbot_Advertising_Targeting_CONTROLS_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Consumer Protection provisions  
Document Type: Chatbot Advertising & Targeting Controls (Example – BeehiveHelp, Inc.)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose and scope

This document explains how BeehiveHelp controls promotional content and targeting inside its AI Chatbot when used by merchants that serve Utah consumers.  
It is designed to demonstrate that promotions surfaced by the chatbot are clearly labeled and accurate.  

---

## 2. Systems covered

| ID   | System Name             | Channel / Surface                             | Type of Offers / Ads                            | Utah Use? (Y/N + notes)                     |
|------|-------------------------|-----------------------------------------------|-------------------------------------------------|---------------------------------------------|
| AI-01| BeehiveHelp AI Chatbot  | Web chat widget on merchant e‑commerce sites  | Merchant discounts, free‑shipping offers        | Yes – used on sites with Utah customers     |
| AI-02| Agent Reply Assist      | Internal agent console (no direct bot ads)    | May suggest phrasing for merchant promotions    | Indirect – agents serve Utah customers      |
| AI-03| KB Article Generator    | Admin console (static help content)           | May include promotional mentions in draft text  | Indirect – some content visible in Utah     |

The primary focus for AI‑delivered promotions is AI‑01 (BeehiveHelp AI Chatbot).  

---

## 3. Labeling and presentation of promotions

### 3.1 Required labeling – AI‑01

BeehiveHelp configures promotional snippets in its default bot flows using a consistent label:

- Example template:

> “Promotion: Save 10% on your next purchase with code SAVE10.”

- Additional examples:

> “Promotion: Free shipping on orders over 50 dollars this weekend.”  
> “Promotion: Members earn double points today.”

Promotions are typically displayed in separate chat bubbles with a “tag” icon in the merchant theme, making them visually distinct from informational responses.  

### 3.2 Visual distinction

- Promotional messages are separated from standard Q&A responses by a small divider and icon.  
- The bubble style uses the merchant’s accent color with a “Promotion” label at the top.  
- BeehiveHelp discourages merchants from embedding promotions directly into policy explanations in a way that might confuse users.  

---

## 4. Use of user input for targeting

BeehiveHelp’s default configuration uses limited context to decide which promotions to show:

- Inputs:  
  - User’s browsing context (e.g., pages viewed, cart contents).  
  - Conversation topic (e.g., questions about shipping, returns, or product category).  

- Targeting logic (plain language):  
  - If a user is asking about shipping and the merchant has a shipping promotion, the bot may surface the relevant shipping offer.  
  - If a user’s cart value is above a threshold, the bot may highlight a discount that applies.  

BeehiveHelp does **not** permit targeting based on sensitive attributes (e.g., health conditions, financial hardship) and does not maintain user profiles specifically for chatbot promotion targeting.  

The behavior is described in BeehiveHelp’s platform documentation and is intended to align with merchants’ own privacy notices.  

---

## 5. Content standards for AI‑generated promotions

BeehiveHelp requires:

- All promotional campaigns (discount values, codes, expiration dates) to be configured by merchants in structured fields, not free‑form prompts.  
- Generative AI to “wrap” or present these structured promotions in natural language, but not to invent offers.  

Examples:

- Structured campaign: “10% off orders over 50 dollars, code SAVE10, valid through March 31, 2026.”  
- AI‑rendered chat message:  
  > “Promotion: Save 10% on orders over 50 dollars through March 31, 2026 with code SAVE10.”

BeehiveHelp blocks the chatbot from generating promotions that are not backed by structured campaign data.  

---

## 6. Human review and approval

Promotional flows in AI‑01 are configured as follows:

1. Merchant marketing staff enter campaign details in the BeehiveHelp promotions panel.  
2. The AI Chatbot uses templates to present the campaign information.  
3. Merchants review preview messages in the dashboard before enabling the promotion.  

BeehiveHelp recommends that merchants:

- Confirm the promotion text matches their own terms and conditions.  
- Verify that the chatbot does not suggest promotions in contexts where they do not apply (e.g., returns outside the promotion window).  

BeehiveHelp’s Customer Success team provides onboarding to walk merchants through these checks.  

---

## 7. Monitoring and issue handling

As part of BeehiveHelp’s monitoring:

- Monthly sampling of AI‑01 conversations includes at least 10 conversations with promotions for Utah merchants.  
- Reviewers verify:  
  - Promotions are labeled with “Promotion:” or similar text.  
  - The promotion details shown match the merchant’s configured campaign.  
  - Promotions are not shown outside their active date ranges.  

If issues are found (e.g., an expired promotion displayed):

1. The reviewer logs the issue in the AI Monitoring Log.  
2. Support contacts the merchant to correct or disable the campaign configuration.  
3. Product or Engineering adjusts templates if the issue stemmed from generic AI text rather than campaign data.  

---

## 8. Merchant configuration controls

BeehiveHelp provides guardrails for merchants:

- In the dashboard, promotions configured for AI‑01 include required fields (discount, eligibility, dates) and a warning if dates are missing or have passed.  
- Merchants can enable or disable AI‑surfaced promotions per channel.  
- BeehiveHelp reserves the right (per terms) to disable AI promotional features for a merchant if repeated misconfiguration creates risk for consumers.  

---

## 9. Review and updates

This advertising and targeting controls document for BeehiveHelp:

- Is reviewed annually by Product, Compliance, and Customer Success.  
- Is updated when BeehiveHelp adds new AI‑driven promotional formats or targeting features.  
- May be shared with merchants, under NDA, as part of due‑diligence or audit responses for Utah compliance.  
