File: UT_02_GenAI_System_Inventory_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: Generative AI System & Use‑Case Inventory (Example)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose of this inventory

This inventory identifies the generative AI systems and use cases at BeehiveHelp, Inc. that interact with Utah residents or influence communications sent to Utah consumers.  
It supports UAIPA compliance by making it clear which systems are in scope for disclosure obligations and consumer‑protection expectations.  

---

## 2. Scope and definitions

BeehiveHelp treats as “GenAI systems” any tools that generate text or other content using large language models and that:

- Interact directly with end‑customers of BeehiveHelp’s merchant clients.  
- Draft messages, responses, or help content that merchant agents send to customers.  

In scope:

- Public‑facing AI chatbot embedded on merchant websites.  
- Agent assist tools where draft responses are routinely sent to customers after review.  

Out of scope (for this document):

- Experimental internal tools that never touch or influence customer communications.  

---

## 3. System inventory table

| ID   | System / Tool Name        | Description / Purpose                                          | Provider / Owner                     | Channel / Surface                         | Consumer-Facing? (Y/N) | Regulated Occupation / High-Risk? (Y/N + notes)          | Utah Use? (Y/N + notes)                    |
|------|---------------------------|----------------------------------------------------------------|--------------------------------------|-------------------------------------------|------------------------|-----------------------------------------------------------|-------------------------------------------|
| AI-01| BeehiveHelp AI Chatbot    | Answers customer service questions on merchant websites        | BeehiveHelp (OpenAI API backend)     | Web chat widget on merchant e‑commerce sites | Y                      | N – retail customer service only                        | Y – used by 27 Utah merchants             |
| AI-02| Agent Reply Assist        | Drafts email/chat replies for merchant support agents          | BeehiveHelp                          | Agent console (internal to merchant staff) | N – drafts only        | N – no regulated occupations supported by default        | Y – Utah agents use for drafting          |
| AI-03| KB Article Generator      | Generates suggested FAQ/knowledge‑base articles for merchants  | BeehiveHelp                          | Admin console for merchant admins          | N                      | N – used by merchant staff, not directly with consumers  | Possible – content may be published to Utah‑facing sites |

---

## 4. Data and interaction profile

### AI‑01 – BeehiveHelp AI Chatbot

1. **User type(s):**  
   - Consumers of BeehiveHelp’s merchant clients (end‑customers).  

2. **Key actions supported:**  
   - Answering order‑status, shipping, and return questions.  
   - Providing store policy information.  
   - Suggesting products based on simple prompts (e.g., “show me summer shirts”).  

3. **Data categories involved:**  
   - Basic account and order information (name, order number, items purchased).  
   - No health, legal, or financial advisory content is permitted.  

4. **Output types:**  
   - Chat responses shown directly to consumers.  

5. **Utah exposure:**  
   - Estimated ~3,200 chatbot conversations per month involving visitors from Utah.  
   - Used by 27 Utah‑based merchants and several national merchants with Utah customers.  

---

### AI‑02 – Agent Reply Assist

1. **User type(s):**  
   - Merchant customer‑support agents.  

2. **Key actions supported:**  
   - Drafting suggested email or chat responses.  
   - Summarizing prior conversation history for agents.  

3. **Data categories involved:**  
   - Customer contact and order data.  
   - Occasional sensitive information if customers share it in free‑text; agents are trained not to rely on AI for clinical, legal, or investment advice.  

4. **Output types:**  
   - Draft responses that agents review and edit before sending.  

5. **Utah exposure:**  
   - Used by multiple teams that support Utah customers, but all messages are human‑reviewed before customers see them.  

---

### AI‑03 – KB Article Generator

1. **User type(s):**  
   - Merchant administrators and knowledge‑base managers.  

2. **Key actions supported:**  
   - Drafting FAQ and help‑center articles based on product and policy prompts.  

3. **Data categories involved:**  
   - Product information, store policies, and general customer‑service topics.  

4. **Output types:**  
   - Draft articles that merchants may publish to their help centers.  

5. **Utah exposure:**  
   - Some generated content is published on help centers accessible to Utah consumers, but BeehiveHelp does not directly control final publication.  

---

## 5. UAIPA‑relevant flags

**AI‑01 – BeehiveHelp AI Chatbot**

- Disclosure requirement type:  
  - On‑request disclosure for consumer‑service interactions; chatbot is configured to disclose it is an AI assistant when customers ask if it is a bot.  
- Advertising / promotions inside AI:  
  - The chatbot may present promotions (“10% off today on shoes”). These snippets are labeled as offers or promotions in the UI.  
- Policy / control links:  
  - UAIPA AI Disclosure Policy, Acceptable Use Policy, AI Output Monitoring SOP.  

**AI‑02 – Agent Reply Assist**

- Disclosure requirement type:  
  - No direct consumer interaction; no UAIPA chatbot disclosure required, but outputs must comply with consumer‑protection standards.  
- Advertising / promotions inside AI:  
  - May suggest promotional language to agents; agents must ensure final messages are accurate and not misleading.  
- Policy / control links:  
  - Agent AI Usage Guidelines, Content Review Checklist.  

**AI‑03 – KB Article Generator**

- Disclosure requirement type:  
  - No direct chat interaction; no real‑time disclosure, but published articles must remain accurate and non‑deceptive.  
- Advertising / promotions inside AI:  
  - May generate promotional copy; merchants are responsible for reviewing for accuracy.  
- Policy / control links:  
  - Content Governance Policy, Merchant Admin Training Guide.  

---

## 6. Ownership and lifecycle

**AI‑01 – BeehiveHelp AI Chatbot**  
- Business owner: Head of Product, Chat Experiences  
- Technical owner: Engineering Manager, Conversational AI  
- Compliance contact: Director of Compliance  
- Status: In production  

**AI‑02 – Agent Reply Assist**  
- Business owner: VP of Customer Success Products  
- Technical owner: Engineering Manager, Agent Tools  
- Compliance contact: Director of Compliance  
- Status: In production  

**AI‑03 – KB Article Generator**  
- Business owner: Product Manager, Knowledge Base  
- Technical owner: Engineering Lead, Content Tools  
- Compliance contact: Director of Compliance  
- Status: In production  

This inventory will be reviewed annually and whenever BeehiveHelp launches, retires, or significantly changes any GenAI system used in connection with Utah consumers.
