File: UT_03_UAIPA_AI_Disclosure_Policy_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA AI Disclosure Policy (Example)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose and scope

This policy describes how BeehiveHelp, Inc. discloses its use of generative artificial intelligence to people in Utah in line with Utah’s AI disclosure requirements.  
It applies to BeehiveHelp’s AI chatbot, AI‑assisted reply tools, and any future GenAI features that interact with, or materially influence communications sent to, Utah consumers.  

---

## 2. Legal background (plain language)

Utah’s AI rules require businesses using generative AI in consumer interactions to:

- Clearly and conspicuously disclose that a person is interacting with GenAI and not a human when the person clearly and unambiguously asks.[web:41][web:55]  
- Make a prominent upfront disclosure when regulated professionals use GenAI in high‑risk interactions with Utah residents.[web:31][web:32][web:46][web:38]  
- Remain responsible for deceptive or unlawful conduct that occurs through the use of GenAI in consumer interactions.[web:33][web:50]  

BeehiveHelp is not a regulated health, financial, or legal provider, but its AI features are used in consumer‑facing customer‑service flows that fall under Utah consumer‑protection laws.  

---

## 3. When disclosure is required

BeehiveHelp considers a GenAI system in scope for this policy if it:

- Interacts directly with merchant customers’ end‑users (consumers) via chat or similar UI; or  
- Generates content that merchant agents send to customers on a regular basis.  

Disclosure is required when:

- A Utah consumer clearly and unambiguously asks if they are interacting with a bot, AI, or a human.  
- BeehiveHelp in the future supports any regulated professional or high‑risk use case in health, finance, or legal advice involving Utah residents.  

---

## 4. Standard disclosure language

### 4.1 Requested disclosure – BeehiveHelp AI Chatbot (AI‑01)

BeehiveHelp configures its AI Chatbot so that, when a user asks “Are you a bot?” or a similar clear question, the bot responds:

> “I am an AI‑powered virtual assistant, not a human.”  

For some merchants, the configuration adds:

> “I am an AI‑powered virtual assistant, not a human. A human team member can review or help if needed.”  

These responses are implemented directly in the BeehiveHelp chatbot configuration and tested before rollout.  

### 4.2 Proactive disclosure (future regulated/high‑risk use)

BeehiveHelp currently does not operate in regulated occupations or high‑risk AI interactions as defined by Utah amendments.  
If BeehiveHelp adds any such use case, the relevant product must include an upfront disclosure in the first message, for example:

> “This service uses an AI‑powered assistant to help provide information. A human professional can review and assist.”  

---

## 5. Channel‑specific implementation

**Web chatbots (AI‑01 – BeehiveHelp AI Chatbot)**  

- The BeehiveHelp widget supports a configurable “first message” and FAQ panel; merchants may optionally display a short “AI assistant” label.  
- The chatbot includes a system prompt and fallback logic that ensures it can recognize and respond appropriately when users ask if it is AI or a bot.  
- BeehiveHelp provides default bot flows that strictly avoid pretending to be a human agent.  

**Agent reply assist (AI‑02 – internal to merchants)**  

- Agent Reply Assist drafts emails and chat messages but does not directly interact with consumers.  
- BeehiveHelp instructs merchants that they should not represent AI‑generated text as personal advice in regulated areas (health, finance, law).  

**Help‑center content (AI‑03 – KB Article Generator)**  

- BeehiveHelp does not require AI disclosure in static help articles, but encourages merchants to review content for clarity and accuracy before publishing.  

---

## 6. Advertising and promotions inside GenAI

BeehiveHelp’s AI Chatbot may present promotional content (e.g., discount codes, featured products) on behalf of merchants.  

- Promotional snippets generated or surfaced by the bot must be clearly recognizable as offers (e.g., “Save 10% today on…”).  
- BeehiveHelp’s template flows treat misleading or inaccurate promotions as a compliance issue and require merchants to review promotional templates before enabling them.  

---

## 7. Roles and responsibilities

- **Product – Chat Experiences:** Owns the disclosure behavior of the AI chatbot, including standard responses and UI labels.  
- **Engineering – Conversational AI:** Implements and tests the requested‑disclosure behavior across all supported languages and merchants.  
- **Customer Success:** Educates merchants about Utah’s AI disclosure expectations and how BeehiveHelp’s bot responses work.  
- **Legal & Compliance:** Monitors Utah AI developments, reviews and approves default disclosure language, and handles escalated questions.  

---

## 8. Training and awareness

BeehiveHelp incorporates UAIPA‑aligned expectations into internal and merchant‑facing materials:

- Internal documentation in the product wiki explaining when the bot must disclose that it is AI.  
- Merchant onboarding guides describing default AI disclosures and how merchants can configure additional notice language if desired.  
- Periodic training sessions for Customer Success and Support on Utah‑specific questions about AI disclosures.  

---

## 9. Monitoring, testing, and enforcement

BeehiveHelp verifies compliance with this policy by:

- Performing quarterly tests of AI‑01 for a sample of merchants, asking if the chatbot is a bot and confirming that it returns the correct disclosure.  
- Reviewing logs of unusual or escalated conversations that mention AI or bots, to confirm the bot’s responses are consistent with this policy.  
- Requiring engineering sign‑off for any changes to core system prompts that affect how the bot describes itself.  

Policy violations or repeated failures to disclose may result in:

- Rolling back problematic prompt changes or configurations.  
- Temporarily disabling certain AI features for affected merchants.  
- Additional training or internal corrective measures.  

---

## 10. Review and updates

This policy will be reviewed:

- Annually each January;  
- After any substantial Utah AI law amendments that affect disclosure obligations; and  
- Following any sustained pattern of Utah complaints related to AI transparency.  

Updated versions will be approved by the General Counsel and the Director of Compliance.
