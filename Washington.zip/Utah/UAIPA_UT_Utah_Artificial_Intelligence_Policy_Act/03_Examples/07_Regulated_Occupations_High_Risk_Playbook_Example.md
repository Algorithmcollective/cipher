File: UT_07_Regulated_Occupations_HighRisk_Playbook_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Policy & Consumer Transparency provisions  
Document Type: Regulated Occupations & High‑Risk Use Playbook (Example – BeehiveHelp, Inc.)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose and scope

This playbook explains how BeehiveHelp’s customers in regulated or high‑risk sectors may use BeehiveHelp’s AI features in Utah‑facing interactions.  
BeehiveHelp itself is not a healthcare, financial, or legal provider, but its tools may be used by merchants that operate in regulated occupations.  

---

## 2. Definitions

For BeehiveHelp’s purposes:

- **Regulated occupation (client side):** Merchants or their staff who are licensed professionals (e.g., telehealth providers, financial advisors, law firms) using BeehiveHelp for client support.  
- **High‑risk AI interaction:** Use of BeehiveHelp AI to draft or deliver communications that:  
  - Discuss health conditions, treatment, or diagnosis.  
  - Provide individualized financial or investment recommendations.  
  - Provide individualized legal advice or guidance on legal rights.  

BeehiveHelp’s default terms discourage or restrict these uses, but some enterprise clients may request tailored configurations.  

---

## 3. Role / use‑case matrix (client‑facing)

| Role / Occupation (Client)     | Utah‑Regulated? (Y/N) | BeehiveHelp AI Feature(s) Used | High‑Risk? (Y/N + notes)                           | Typical Interaction Type                              |
|--------------------------------|-----------------------|--------------------------------|-----------------------------------------------------|-------------------------------------------------------|
| Retail customer support agent  | N                     | AI‑01 Chatbot, AI‑02 Reply Assist | N – consumer retail questions                      | Order status, returns, general FAQs                   |
| Telehealth intake coordinator  | Y (health)            | AI‑02 Reply Assist (pilot only)  | Y – if used for patient communications             | Scheduling, logistics, non‑clinical FAQs              |
| Financial services CSR         | Y (finance)           | AI‑02 Reply Assist (restricted)  | Y – if used for individualized financial info      | Account questions, general info, not advice           |

BeehiveHelp’s default policy prohibits clients from using AI‑01 Chatbot to provide direct clinical, legal, or investment advice, and requires additional review before enabling AI‑assisted drafts in those sectors.  

---

## 4. What BeehiveHelp AI may and may not do for regulated clients

### 4.1 Allowed uses (with proper configuration)

For regulated clients that receive specific approval, BeehiveHelp AI may be used to:

- Draft scheduling and logistics messages (e.g., appointment reminders, rescheduling).  
- Draft general educational content (e.g., “how to prepare for your visit,” “what documents to bring”).  
- Summarize client‑provided information into bullet points for the professional’s internal review.  

### 4.2 Prohibited uses (per BeehiveHelp terms)

BeehiveHelp AI tools must not be configured to:

- Provide diagnosis, treatment plans, or medical risk/benefit assessments.  
- Provide recommendations to buy, sell, or hold specific financial instruments.  
- Advise on legal obligations, rights, or litigation options.  
- Present itself as a doctor, financial advisor, lawyer, or other licensed professional.  

BeehiveHelp’s Acceptable Use Policy sets these boundaries and is referenced in client contracts.  

---

## 5. Disclosure requirements for client professionals

For any Utah client in a regulated occupation that uses BeehiveHelp AI to draft or support communications, BeehiveHelp recommends:

1. **Upfront disclosure** (in their own scripts):  

   Health‑adjacent example:

   > “We use an AI‑powered tool to help draft some of our messages, but your care and decisions are made by our licensed clinical team.”

   Financial/legal‑adjacent example:

   > “We use an AI tool to help prepare information and drafts, but any advice we provide is based on our own professional judgment.”

2. **Clarification of responsibility**  
   - The professional should confirm that they, not the AI, are responsible for the final advice or decision.  

BeehiveHelp does not enforce these disclosures directly, but documents and recommends them to regulated clients as part of onboarding.  

---

## 6. Workflow patterns for regulated clients (guidance)

BeehiveHelp provides the following model workflows to regulated clients:

### 6.1 Intake / logistics workflow (health/financial)

1. Client staff gather necessary information directly from the patient/client (via forms or human conversation).  
2. Staff may use AI‑02 Reply Assist to draft confirmation or reminder messages.  
3. Staff review and edit the AI draft, ensuring it contains no clinical, legal, or financial advice.  
4. Staff send the final message under the organization’s own identity.  

### 6.2 Educational content workflow

1. Professional defines topics (e.g., “preparing for your first visit”).  
2. AI‑03 KB Article Generator drafts educational text.  
3. Professional reviews, edits, and approves the content before publishing to patients/clients.  

---

## 7. Documentation and recordkeeping (client guidance)

BeehiveHelp recommends that regulated clients:

- Record substantive advice and decisions in their own systems of record, not solely in AI chat logs.  
- Note, when required by their regulators, that an AI tool was used in drafting materials.  
- Follow sector‑specific recordkeeping requirements (e.g., HIPAA, financial advice file rules, legal ethics obligations).  

BeehiveHelp does not store or designate its AI chat logs as official patient or client records.  

---

## 8. Training and supervision

BeehiveHelp:

- Provides training materials to Customer Success and Sales so they can explain AI limits to prospective regulated clients.  
- Encourages regulated clients to train their own staff on how to use BeehiveHelp AI tools in compliance with local law, including Utah AI requirements.  

BeehiveHelp may ask high‑risk clients to confirm that they have internal AI use policies and oversight mechanisms before enabling advanced AI features.  

---

## 9. Incident handling for regulated/high‑risk uses

If BeehiveHelp becomes aware that a regulated client is using BeehiveHelp AI in a way that could:

- Provide prohibited advice; or  
- Mislead Utah residents in high‑risk contexts,  

BeehiveHelp may:

1. Contact the client to clarify use and request corrective measures.  
2. Restrict or disable AI features for that client, if necessary.  
3. Document the issue and remediation steps internally (via the AI Monitoring Log and client success records).  

---

## 10. Review and updates

This playbook example is reviewed annually and when:

- BeehiveHelp launches sector‑specific AI features (e.g., healthcare templates).  
- Utah or other regulators issue new guidance affecting AI use in regulated occupations.  

Updates are owned by the Director of Compliance with input from Product and Customer Success.
