File: UT_01_UAIPA_Scope_Applicability_MEMO_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA Scope & Applicability Memo (Example)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose of this memo

This memo explains how BeehiveHelp, Inc. is covered by Utah’s Artificial Intelligence Policy Act and which obligations apply to its use of generative AI with Utah residents.  
It is intended to give Utah regulators a clear map of BeehiveHelp’s in‑scope AI systems, use cases, and supporting compliance documents if the company’s practices are reviewed.  

---

## 2. Overview of UAIPA and who it covers

Utah’s UAIPA is an AI‑specific consumer protection law that requires businesses using generative AI with consumers to make certain disclosures and prohibits them from blaming AI for consumer‑protection violations.  
The law applies to entities that interact with Utah consumers in activities regulated by the Utah Division of Consumer Protection and to regulated occupations in high‑risk AI interactions, and it is administered jointly with the Office of Artificial Intelligence Policy.  

---

## 3. BeehiveHelp profile and Utah footprint

**Business description**  
- BeehiveHelp provides a SaaS customer‑support platform for online retailers, including an AI‑powered chatbot that answers customer questions and drafts responses for human agents.

**Utah touchpoints (2025)**  
- 27 Utah‑based merchant customers.  
- Approximately 40,000 customer service conversations per year involving Utah consumers, primarily via web chat and email.  
- BeehiveHelp does not itself operate a regulated occupation (no clinical, legal, or investment advisory services).  

**Systems and channels involving generative AI and Utah residents**

- Public‑facing web chat widget embedded on merchant websites, powered by BeehiveHelp AI Chat.  
- In‑app AI assistant used by merchant agents to draft email and chat responses.  
- Knowledge‑base article generator that creates suggested FAQ content for merchants.  

---

## 4. Generative AI systems and use cases in scope

| ID   | System / Tool            | Provider / Owner                | Channel                          | Consumer-Facing? | Regulated Occupation / High-Risk? | Utah Use (Yes/No) |
|------|--------------------------|---------------------------------|----------------------------------|------------------|-----------------------------------|-------------------|
| AI-01| BeehiveHelp AI Chatbot   | BeehiveHelp (OpenAI backend)    | Web chat widget on merchant sites| Yes              | No – consumer retail only         | Yes               |
| AI-02| Agent Reply Assist       | BeehiveHelp                     | Agent console (internal only)    | No – drafts only | No                                | Yes               |
| AI-03| KB Article Generator     | BeehiveHelp                     | Admin console (merchant staff)   | No               | No                                | Possible (indirect)|

Notes:

- AI‑01 interacts directly with Utah consumers in connection with consumer sales and customer service.  
- AI‑02 and AI‑03 are internal tools; their outputs may reach consumers but are reviewed and edited by humans before sending.  

---

## 5. UAIPA applicability analysis

### 5.1 Consumer‑protection‑regulated activities

- AI‑01 supports real‑time customer service and sales chat on merchant websites, including order status, returns, and promotions, for Utah consumers.  
- Because these are acts regulated by the Utah Division of Consumer Protection, BeehiveHelp configures AI‑01 so that, if a consumer clearly and unambiguously asks “Are you a bot?” or similar, the chatbot responds with a clear and conspicuous disclosure that it is an AI assistant and not a human.  

### 5.2 Regulated occupation / high‑risk interactions

- BeehiveHelp does not operate in a regulated occupation and prohibits merchant customers from using its AI chatbot for clinical, legal, or financial advice in its Acceptable Use Policy.  
- As of this memo, BeehiveHelp does not treat any of its AI use cases as “high‑risk artificial intelligence interactions”; if a merchant intends to use the platform for such purposes, BeehiveHelp requires separate approval and documentation.  

### 5.3 Advertising and AI‑generated content

- BeehiveHelp AI Chatbot may display merchant promotions such as discounts or product suggestions within chat flows.  
- Standard chatbot templates label these snippets as promotions (e.g., “Offer” or “Promotion”), and BeehiveHelp treats deceptive or misleading AI‑generated promotions as its and the merchant’s responsibility under consumer protection law.  

### 5.4 Regulatory mitigation (AI Learning Laboratory)

- BeehiveHelp is not currently participating in the Utah AI Learning Laboratory Program.  
- If BeehiveHelp applies in the future, it will prepare a separate Learning Lab package detailing its technical capabilities, financial capacity, bounded test plan, and monitoring and remediation commitments, consistent with Utah’s AI regulatory mitigation framework.  

---

## 6. Summary of obligations for BeehiveHelp

BeehiveHelp has identified the following concrete obligations under UAIPA:

- Configure AI‑01 so that consumers receive a clear and conspicuous AI disclosure when they clearly and unambiguously ask if they are interacting with a bot or AI.  
- Maintain and enforce an internal UAIPA AI Disclosure Policy that sets the standard wording and placement for chatbot disclosures and prohibits unapproved use in regulated/high‑risk occupations.  
- Implement monitoring for AI‑generated chat content to detect and correct potentially deceptive or misleading statements, recognizing that BeehiveHelp and its merchants remain responsible for violations even when generated by AI.  
- Keep an inventory of in‑scope AI systems (AI‑01–03) and link each to specific disclosure logic, monitoring procedures, and contractual restrictions with merchants.  

---

## 7. Ownership, review, and updates

- Document owner: Jordan Blake, Director of Compliance  
- Supporting teams: Product Management, Engineering, Customer Success, Legal  
- Review cadence:  
  - Annually each January  
  - Whenever BeehiveHelp launches a new AI chatbot behavior or adds merchants in sensitive sectors  
  - After any Utah‑specific complaint or inquiry relating to AI disclosures or chatbot behavior  
