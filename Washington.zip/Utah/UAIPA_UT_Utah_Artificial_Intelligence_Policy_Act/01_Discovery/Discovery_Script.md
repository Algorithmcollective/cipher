# Utah UAIPA Discovery Script

Purpose: Gather information needed to prepare Utah UAIPA generative AI compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: UAIPA Scope & Applicability Memo

Say:
“I need to understand how your organization interacts with Utah residents and where generative AI is involved.”

Ask:

- Utah customers or users
- Utah marketing or sales activity
- Regulated occupations operating in Utah
- Channels involving Utah residents (web, chat, SMS, email, voice)
- Generative AI systems interacting with Utah users
- High-risk interactions (health, finance, legal, sensitive matters)
- Participation in Utah AI Learning Laboratory
- Prior Utah AI complaints or inquiries

---

## 🧾 Deliverable: Generative AI System Inventory

Say:
“I want to inventory every generative AI system that interacts with Utah residents or creates content sent to them.”

Ask:

- System name and provider
- Description and purpose
- Channel or surface
- Consumer-facing or internal
- Regulated occupation involvement
- Utah exposure (Yes/No)
- Monthly Utah interaction volume
- Data categories involved
- Output types generated
- Business and technical owner

---

## 🧾 Deliverable: UAIPA AI Disclosure Policy

Say:
“I need to confirm how you disclose AI use to Utah consumers.”

Ask:

- On-request disclosure implemented
- Proactive disclosure for regulated/high-risk uses
- Standard disclosure language
- Channel-specific disclosure behavior
- Voice script exists
- Chatbot auto-response rule for ‘Are you a bot?’
- Policy owner
- Last policy review date
- Staff training completed

---

## 🧾 Deliverable: UAIPA Disclosure UX Pack

Say:
“I want to document exactly how disclosures appear in each interface.”

Ask:

- First-message AI label present
- Disclosure placement location
- On-request disclosure rule configured
- High-risk upfront disclosure implemented
- Screenshots stored
- Voice disclosure script tested
- Promotional labeling in chat
- UX owner responsible

---

## 🧾 Deliverable: GenAI Oversight & Monitoring Plan

Say:
“I need to understand how AI outputs are reviewed and monitored for Utah interactions.”

Ask:

- Covered systems list
- Pre-deployment review performed
- Prompt and configuration review
- Test scenarios documented
- Sampling cadence
- Monitoring log exists
- Automated risk filters used
- Incident escalation process
- Quarterly oversight summary produced
- Monitoring owner

---

## 🧾 Deliverable: Chatbot Advertising & Targeting Controls

Say:
“I need to confirm that AI-delivered promotions and targeting comply with Utah consumer-protection rules.”

Ask:

- AI systems delivering promotions
- Promotion labeling standard
- Visual distinction implemented
- Targeting inputs used
- Sensitive targeting restrictions
- Privacy notice alignment
- Human approval for campaigns
- Promotion monitoring included in sampling
- Promotion approval log location

---

## 🧾 Deliverable: Regulated Occupations & High-Risk Playbook

Say:
“I need to document how AI is used by licensed professionals or in high-risk interactions.”

Ask:

- Regulated occupations in Utah
- AI systems used by those roles
- High-risk interaction types
- Upfront disclosure language
- Professional review requirement
- Prohibited AI uses defined
- Workflow documentation
- Training provided to professionals
- Supervision process

---

## 🧾 Deliverable: UAIPA Incident & Complaint Runbook

Say:
“I want to confirm how AI-related complaints involving Utah residents are handled.”

Ask:

- Intake channels for AI complaints
- Incident tracker exists
- UT-tagging mechanism
- Severity levels defined
- Investigation workflow
- Root cause documentation
- Remediation tracking
- Legal escalation criteria
- Quarterly trend review

---

## 🧾 Deliverable: UAIPA Enforcement Readiness & Evidence Binder

Say:
“I need to confirm that you can assemble documentation quickly if Utah regulators inquire.”

Ask:

- Central storage location
- Folder structure defined
- Evidence mapping table exists
- Screenshots and logs retained
- Monitoring summaries stored
- Incident export capability
- Regulatory response checklist
- Binder owner
- Annual tabletop test performed

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Utah UAIPA generative AI compliance documentation.”