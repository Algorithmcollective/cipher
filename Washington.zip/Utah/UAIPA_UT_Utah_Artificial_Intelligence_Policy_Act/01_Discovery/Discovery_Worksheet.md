# Utah UAIPA Discovery Worksheet

---

## Scope & Applicability

Utah Customers:
Utah Marketing Activity:
Regulated Occupations:
Utah Channels:
GenAI Systems in Utah:
High-Risk Interactions:
AI Learning Lab Participation:
Prior Utah Complaints:

---

## GenAI System Inventory

System Names:
Providers:
Channels:
Consumer-Facing:
Regulated Use:
Utah Exposure:
Monthly Utah Volume:
Data Categories:
Output Types:
Business Owner:
Technical Owner:

---

## AI Disclosure Policy

On-Request Disclosure:
Proactive Disclosure:
Standard Language:
Channel Implementation:
Voice Script:
Bot Disclosure Rule:
Policy Owner:
Last Review Date:
Training Completed:

---

## Disclosure UX Pack

First-Message Label:
Disclosure Placement:
On-Request Rule:
High-Risk Upfront Disclosure:
Screenshots Stored:
Voice Disclosure Tested:
Promotion Labeling:
UX Owner:

---

## Oversight & Monitoring

Covered Systems:
Pre-Deployment Review:
Prompt Review:
Test Scenarios:
Sampling Cadence:
Monitoring Log:
Automated Filters:
Incident Escalation:
Quarterly Summary:
Monitoring Owner:

---

## Advertising & Targeting Controls

Promotion Systems:
Labeling Standard:
Visual Distinction:
Targeting Inputs:
Sensitive Restrictions:
Privacy Alignment:
Human Approval:
Promotion Monitoring:
Approval Log Location:

---

## Regulated / High-Risk Use

Regulated Roles:
AI Systems Used:
High-Risk Interactions:
Upfront Disclosure:
Professional Review:
Prohibited Uses:
Workflow Documented:
Training Provided:
Supervision Process:

---

## Incident & Complaint Handling

Intake Channels:
Incident Tracker:
UT Tagging:
Severity Levels:
Investigation Workflow:
Root Cause Logging:
Remediation Tracking:
Legal Escalation:
Quarterly Review:

---

## Enforcement Readiness

Storage Location:
Folder Structure:
Evidence Map:
Screenshots Retained:
Monitoring Reports:
Incident Export:
Response Checklist:
Binder Owner:
Tabletop Test:

---

## TBD

Item:
Owner:
Notes: