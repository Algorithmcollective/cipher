File: UT_05_GenAI_Oversight_Monitoring_PLAN_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: GenAI Oversight & Monitoring Plan (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose and scope

This plan describes how {{ORG_NAME}} oversees and monitors its generative AI (GenAI) systems that interact with, or influence communications sent to, Utah residents.  
It supports UAIPA and consumer‑protection expectations by ensuring {{ORG_NAME}} can detect and correct misleading, harmful, or non‑compliant AI behavior.  

---

## 2. Systems covered

This plan applies to all GenAI systems listed as in scope for Utah in the UT_02 inventory, including:

- Consumer‑facing chatbots and assistants.  
- Internal AI tools that draft content routinely sent to Utah consumers.  
- Any GenAI tools used by regulated occupations or in high‑risk interactions.  

List covered systems here:

| ID   | System Name           | Channel / Use Case                            | Utah Exposure Summary                           |
|------|-----------------------|-----------------------------------------------|-------------------------------------------------|
| AI-01| {{SYSTEM_NAME_1}}     | {{CHANNEL_1}}                                 | {{UT_EXPOSURE_1}}                               |
| AI-02| {{SYSTEM_NAME_2}}     | {{CHANNEL_2}}                                 | {{UT_EXPOSURE_2}}                               |

---

## 3. Oversight roles and responsibilities

- **Product owners:** Define acceptable AI behavior, escalation paths, and guardrails for their systems.  
- **Engineering / AI teams:** Implement controls, monitoring hooks, and logging.  
- **Legal & Compliance:** Assess legal risk, review high‑risk use cases, and advise on remediation.  
- **Support / Operations:** Report issues observed in customer interactions and help execute fixes.  

Each in‑scope system must have:

- A named business owner.  
- A named technical owner.  
- A compliance contact.  

---

## 4. Pre‑deployment review

Before launching or materially changing an in‑scope GenAI system for Utah:

1. **Use‑case review**  
   - Confirm whether the system will interact with Utah consumers or support regulated/high‑risk use cases.  
   - Verify that UAIPA‑required disclosures are designed and implemented (see UT_03 and UT_04).  

2. **Prompt and configuration review**  
   - Review system prompts, instructions, and configuration to avoid:  
     - Misrepresenting AI as a human.  
     - Providing clinical, legal, or financial advice where prohibited.  
     - Making unsubstantiated claims or deceptive statements.  

3. **Test scenarios**  
   - Run test conversations or outputs focusing on:  
     - Common user intents.  
     - Questions about whether the system is AI.  
     - Requests that might trigger high‑risk or sensitive topics.  

Document results and sign‑offs for each system in a simple pre‑deployment checklist.  

---

## 5. Ongoing monitoring

### 5.1 Sampling and review

For each in‑scope system, {{ORG_NAME}} will:

- Define a sampling cadence (e.g., weekly, monthly) based on volume and risk.  
- Review a sample of Utah‑related interactions or outputs, looking for:  
  - Missing or incorrect AI disclosures.  
  - Potentially misleading or deceptive content.  
  - Hallucinated information in sensitive contexts.  
  - Inappropriate responses related to health, finance, or law.  

Findings are logged in an “AI Monitoring Log” with date, system ID, issue type, and disposition.  

### 5.2 Automated checks (where feasible)

Where technically feasible, {{ORG_NAME}} may:

- Use basic filters or rules to detect risky phrases or topics.  
- Flag interactions where users ask if the agent is “real,” “human,” or “a bot” and confirm the correct disclosure was provided.  

---

## 6. Incident criteria and escalation

An “AI incident” under this plan includes:

- A pattern of missing or incorrect AI disclosures in Utah‑facing interactions.  
- AI‑generated content that could mislead consumers about key terms, prices, eligibility, or material facts.  
- AI content that appears to cross into prohibited clinical, legal, or financial advice where {{ORG_NAME}} is not licensed.  

When any team member discovers a potential incident:

1. Log the issue in the AI Monitoring / Incident log with examples.  
2. Notify the system’s business owner and compliance contact.  
3. Determine severity (low, medium, high) based on scope and risk to Utah consumers.  

High‑severity issues are escalated to Legal & Compliance for immediate review and remediation planning.  

---

## 7. Remediation actions

Possible remediation steps include:

- Prompt/config changes to prevent recurrence.  
- Temporary limitation or disabling of specific AI features.  
- Updating disclosure language or placement.  
- Additional human review before sending similar outputs.  
- Communication to affected customers or clients, if appropriate.  

For each incident, record:

- Root cause analysis (e.g., prompt design, vendor model behavior, misconfiguration).  
- Actions taken and date completed.  
- Any need to update policies, training, or documentation.  

---

## 8. Vendor oversight

For vendor‑provided GenAI systems:

- Maintain current documentation on the vendor’s model behavior, safety features, and contract terms.  
- Where possible, configure vendor systems to:  
  - Respond accurately when asked if they are AI.  
  - Respect usage constraints (e.g., no clinical/financial advice).  

If vendor behavior repeatedly causes issues in Utah interactions, {{ORG_NAME}} may:

- Tighten configuration and prompts.  
- Reduce or discontinue use of specific features.  
- Reconsider the vendor relationship.  

---

## 9. Reporting and metrics

At least quarterly, {{ORG_NAME}} will produce a short AI oversight summary for in‑scope systems, including:

- Number of Utah‑related interactions sampled.  
- Number and type of issues found (disclosure, accuracy, prohibited topics, etc.).  
- Key remediation steps taken.  
- Any notable trends or recurring patterns.  

This report is shared with relevant product leadership and Compliance.  

---

## 10. Review and updates

This plan will be reviewed:

- Annually; and  
- After any significant AI incident involving Utah consumers; and  
- When Utah AI requirements change or {{ORG_NAME}} adds new high‑risk AI use cases.  

Updates must be approved by {{PLAN_APPROVER_NAME}}, {{TITLE}}, with Legal & Compliance sign‑off.
