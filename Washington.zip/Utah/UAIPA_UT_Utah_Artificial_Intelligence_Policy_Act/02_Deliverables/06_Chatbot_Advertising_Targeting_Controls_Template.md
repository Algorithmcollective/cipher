File: UT_06_Chatbot_Advertising_Targeting_CONTROLS_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Consumer Protection provisions  
Document Type: Chatbot Advertising & Targeting Controls (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose and scope

This document describes how {{ORG_NAME}} controls advertising, promotions, and targeting logic inside generative AI chatbots and assistants used with Utah consumers.  
It is intended to show that AI‑delivered promotions are clearly identified, accurate, and consistent with Utah consumer‑protection standards.  

---

## 2. Systems covered

List the GenAI systems that can display ads, offers, or promotions in Utah‑facing interactions.

| ID   | System Name         | Channel / Surface                    | Type of Offers / Ads                                | Utah Use? (Y/N + notes) |
|------|---------------------|--------------------------------------|-----------------------------------------------------|-------------------------|
| AI-01| {{SYSTEM_NAME_1}}   | {{CHANNEL_1}}                        | {{OFFERS_TYPE_1}}                                   | {{UT_NOTES_1}}          |
| AI-0X| {{SYSTEM_NAME_2}}   | {{CHANNEL_2}}                        | {{OFFERS_TYPE_2}}                                   | {{UT_NOTES_2}}          |

---

## 3. Labeling and presentation of promotions

### 3.1 Required labeling

All promotions, discounts, or sponsored content displayed by in‑scope AI systems to Utah consumers must:

- Be clearly recognizable as offers or promotions (e.g., prefix, badge, or icon).  
- Avoid implying that a promotion is personalized when it is not.  

Standard text pattern:

> “Promotion: {{PROMO_HEADLINE}}”

Examples:

- “Promotion: Save 10% on your next order with code SAVE10.”  
- “Promotion: Free shipping on orders over 50 dollars.”  

### 3.2 Visual distinction

In product design:

- Promotions should be visually separated from informational responses (e.g., divider, icon, or style).  
- Inline promotions must not be presented in a way that hides their promotional nature.  

---

## 4. Use of user input for targeting

If {{ORG_NAME}} uses user input to decide which promotions to show in AI flows:

- Document the input used (e.g., location, browsing context, conversation intent).  
- Ensure this behavior is consistent with overall privacy and consumer‑protection notices.  
- Do not use sensitive categories (health, financial hardship, legal status) for targeting unless separately assessed and approved.  

For each system, complete:

- Inputs used for promotion selection: {{TARGETING_INPUTS}}  
- Targeting logic description (plain language): {{TARGETING_LOGIC}}  
- Link to applicable privacy / notice documentation: {{PRIVACY_NOTICE_LINK}}  

---

## 5. Content standards for AI‑generated promotions

Promotional content generated or heavily assisted by GenAI must:

- Be factually accurate (prices, eligibility, expiration dates).  
- Match underlying merchant or product rules.  
- Avoid exaggerated or misleading claims.  

Before enabling auto‑serve promotional flows:

- Provide canonical promotion details (discount amounts, eligibility rules) to the AI via configuration, not free‑form prompts.  
- Review example promotional messages for each active campaign.  

---

## 6. Human review and approval

{{ORG_NAME}} will ensure human review in these cases:

- New promotional templates, campaigns, or call‑to‑action flows created with GenAI.  
- Any campaign that uses non‑standard targeting logic.  

Process:

1. Marketing or product team drafts or configures the promotion (optionally using GenAI).  
2. A designated reviewer verifies accuracy and compliance with offers and returns policies.  
3. After approval, the promotion is enabled in the chatbot or assistant.  

Document approvers and dates for each campaign: {{PROMO_APPROVAL_LOG_LOCATION}}.  

---

## 7. Monitoring and issue handling

As part of ongoing monitoring (see UT_05):

- Include promotion‑containing conversations in sampling.  
- Check for:  
  - Misstated discount amounts or eligibility.  
  - Promotions shown outside intended dates or audiences.  
  - Confusing blending of help information and ads.  

If an issue is found:

- Log it in the AI Monitoring / Incident log.  
- Suspend or correct the affected promotion.  
- Update templates, configuration, or campaign data as needed.  

---

## 8. Merchant / client configuration (for B2B platforms)

If {{ORG_NAME}} provides AI tools to clients (e.g., merchants):

- Provide default promotional templates that follow these controls.  
- Offer guidance explaining how labeling, accuracy, and targeting rules work.  
- Reserve the right to disable or adjust client promotional flows that pose undue risk in Utah.  

---

## 9. Review and updates

This controls document will be reviewed:

- At least annually; and  
- When {{ORG_NAME}} launches significant new AI‑driven ad formats; and  
- After any incident involving misleading promotions in AI flows with Utah consumers.  

Updates require approval from {{APPROVER_NAME}}, {{TITLE}}, with Legal/Compliance review.
