File: UT_07_Regulated_Occupations_HighRisk_Playbook_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Policy & Consumer Transparency provisions  
Document Type: Regulated Occupations & High‑Risk Use Playbook (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose and scope

This playbook provides rules and guidance for using generative AI in regulated occupations and other high‑risk interactions with Utah residents.  
It is intended for licensed or certified professionals and business units whose AI‑supported activities could significantly affect individuals’ health, finances, legal rights, or similar interests.[web:31][web:37][web:38]  

---

## 2. Definitions

- **Regulated occupation:** A profession licensed, certified, or otherwise regulated by the Utah Department of Commerce or related boards (e.g., certain health professionals, financial professionals, legal practitioners).[web:31][web:37]  
- **High‑risk AI interaction:** An interaction where AI is used in connection with:  
  - Health or mental‑health information.  
  - Financial suitability, credit, or investment decisions.  
  - Legal rights, status, or remedies.  
  - Other sensitive matters identified by {{ORG_NAME}}’s Legal/Compliance team.[web:31][web:46]  

This playbook applies when GenAI systems are used in, or materially influence, such interactions with Utah residents.  

---

## 3. Role / use‑case matrix

Complete the matrix for each relevant role and AI use case.

| Role / Occupation        | Utah‑Regulated? (Y/N) | AI System(s) Used (IDs) | High‑Risk? (Y/N + notes)                    | Typical Interaction Type                      |
|--------------------------|----------------------|-------------------------|---------------------------------------------|-----------------------------------------------|
| {{ROLE_1}}               | Y/N                  | {{AI_IDS_1}}            | Y/N – {{HIGH_RISK_NOTES_1}}                 | {{INTERACTION_TYPE_1}}                        |
| {{ROLE_2}}               | Y/N                  | {{AI_IDS_2}}            | Y/N – {{HIGH_RISK_NOTES_2}}                 | {{INTERACTION_TYPE_2}}                        |

For each “Yes” in the high‑risk column, this playbook’s stricter rules apply.  

---

## 4. What AI may and may not do

### 4.1 Allowed uses (examples)

GenAI may be used to:

- Draft educational materials or general information summaries.  
- Suggest wording for routine, low‑risk communications.  
- Organize or summarize client‑provided information for the professional’s review.  

### 4.2 Prohibited or restricted uses

GenAI must **not**, on its own:

- Provide a diagnosis, treatment plan, or individualized medical recommendation.  
- Provide individualized financial advice, investment recommendations, or suitability determinations.  
- Provide individualized legal advice about rights, remedies, or litigation strategy.  
- Represent itself as a licensed professional or decision‑maker.[web:31][web:37][web:38]  

Any exceptions must be approved in writing by Legal/Compliance and clearly documented.  

---

## 5. Disclosure requirements in regulated/high‑risk interactions

When a regulated professional uses GenAI in a high‑risk interaction with a Utah resident:

1. **Upfront disclosure**  
   - At the beginning of the interaction (or before GenAI‑assisted content is presented), the professional must disclose that AI tools are being used to assist.  

   Example language:

   > “I use an AI‑powered assistant to help organize information and draft parts of this communication. I review and make the final decisions.”

2. **Clarification of responsibility**  
   - The professional remains responsible for the advice, decisions, and communications; AI is only a tool.  
   - The professional should not suggest that AI is making the final judgment or recommendation.  

3. **On‑request elaboration**  
   - If a patient/client asks how AI is used, the professional should briefly explain the role of the tool and confirm that a human is accountable.  

---

## 6. Workflow patterns

For each high‑risk use case, define a simple workflow:

### 6.1 Example workflow template

1. **Intake**  
   - Professional collects necessary information directly from the patient/client.  
   - If AI is used to structure intake questions, ensure questions have been reviewed and approved.  

2. **AI assistance (optional)**  
   - Professional may use AI to summarize information or draft a preliminary note or explanation.  

3. **Professional review**  
   - Professional carefully reviews AI output, edits or discards as needed, and ensures it is accurate and appropriate.  

4. **Communication to client**  
   - Professional delivers the final advice or communication, with AI‑assisted portions treated as drafts only.  

5. **Documentation**  
   - Record that AI tools were used in preparation (where required by internal policy), but do not store sensitive content in AI systems beyond approved configurations.  

---

## 7. Documentation and recordkeeping

Where {{ORG_NAME}} requires tracking of AI use in high‑risk interactions:

- Note the use of AI in internal records (e.g., “AI‑assisted draft – reviewed by {{PROFESSIONAL_NAME}}”).  
- Do not rely solely on AI chat histories as system‑of‑record documentation.  
- Follow existing sector‑specific recordkeeping rules (e.g., medical records, financial advice files).  

---

## 8. Training and supervision

Regulated professionals using GenAI must receive training covering:

- The limits of AI in their practice area.  
- How to use approved tools safely and within policy.  
- When to escalate questions to supervisors or Legal/Compliance.  

Supervisors should periodically review samples of AI‑assisted work to ensure professional standards are being met.  

---

## 9. Incident handling for regulated/high‑risk uses

If a professional believes AI has contributed to:

- Incorrect or misleading advice in a high‑risk interaction; or  
- A communication that could be harmful or materially confusing to a Utah resident,  

they must:

1. Correct the communication as soon as possible.  
2. Report the issue according to the AI Incident process (see UT_05), noting that it involved a regulated/high‑risk interaction.  
3. Cooperate with any additional review or remedial steps.  

---

## 10. Review and updates

This playbook will be reviewed:

- At least annually; and  
- When {{ORG_NAME}} adds new AI tools for regulated occupations; and  
- When Utah issues updated guidance affecting regulated or high‑risk AI uses.  

Changes must be approved by {{PLAYBOOK_APPROVER_NAME}}, {{TITLE}}, with input from Legal/Compliance.
