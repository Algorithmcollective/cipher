File: UT_01_UAIPA_Scope_Applicability_MEMO_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA Scope & Applicability Memo (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of this memo

This memo documents how **{{ORG_NAME}}** is in scope of the Utah Artificial Intelligence Policy Act and related AI consumer transparency requirements, and which obligations apply to its use of generative AI with Utah residents.  
It is designed so that, if Utah regulators review {{ORG_NAME}}’s AI use, {{ORG_NAME}} can clearly show which activities are covered and what compliance program elements exist.  

---

## 2. Overview of UAIPA and who it covers

UAIPA is an AI‑specific consumer protection framework that:

- Requires clear and conspicuous disclosure when consumers interact with certain generative AI systems.  
- Makes businesses responsible for deceptive acts carried out through generative AI.  
- Creates an Office of Artificial Intelligence Policy and an AI Learning Laboratory Program that can grant regulatory mitigation to eligible AI developers.

UAIPA primarily applies to:

- Businesses and individuals engaging in acts regulated by the Utah Division of Consumer Protection where generative AI interacts with consumers (e.g., consumer sales, telemarketing, charitable solicitations).  
- Regulated occupations overseen by the Utah Department of Commerce that use generative AI in connection with “high‑risk” interactions involving health, finance, law, or similarly sensitive contexts.  

---

## 3. {{ORG_NAME}} profile and Utah footprint

**Business description**  
- {{ONE_PARAGRAPH_BUSINESS_DESCRIPTION}}

**Utah touchpoints**  
- Utah customers (last 12 months): {{NUMBER_OF_UTAH_CUSTOMERS}}  
- Utah leads/prospects reached via sales, marketing, or support: {{UTAH_TOUCHPOINTS_DESCRIPTION}}  
- Regulated occupations present (yes/no; list roles): {{REGULATED_OCCUPATIONS_LIST}}  

**Systems and channels that may involve generative AI and Utah residents**

- Public website, chatbots, and self‑service portals  
- Mobile apps and in‑product help assistants  
- Email, SMS, or messaging‑based support and marketing  
- Professional services delivered by licensed/regulated professionals located in or serving Utah  

---

## 4. Generative AI systems and use cases in scope

Summarize all GenAI systems that interact, or may interact, with people in Utah.

| ID   | System / Tool        | Provider / Owner    | Channel                         | Consumer-Facing? | Regulated Occupation / High-Risk? | Utah Use (Yes/No) |
|------|----------------------|---------------------|---------------------------------|------------------|-----------------------------------|-------------------|
| AI-01| {{SYSTEM_NAME_1}}    | {{VENDOR_OR_INT}}   | Web chatbot on {{SITE}}         | Yes/No           | Yes/No (explain)                  | Yes/No            |
| AI-02| {{SYSTEM_NAME_2}}    | {{VENDOR_OR_INT}}   | In‑product assistant            | Yes/No           | Yes/No                            | Yes/No            |
| AI-03| {{SYSTEM_NAME_3}}    | {{VENDOR_OR_INT}}   | Email/content generation        | Yes/No           | Yes/No                            | Yes/No            |

For each in‑scope system, capture:

- Whether it interacts directly with consumers in Utah in consumer‑protection‑regulated activities.  
- Whether it is used by a regulated occupation in connection with high‑risk interactions (e.g., clinical advice, financial suitability, legal analysis).  

---

## 5. UAIPA applicability analysis

For each in‑scope system, answer:

### 5.1 Consumer‑protection‑regulated activities

- Does the system support consumer sales, telemarketing, charitable solicitations, or other activities enforced by the Division of Consumer Protection?  
- If yes, {{ORG_NAME}} must clearly and conspicuously disclose, at least when clearly and unambiguously asked, that the consumer is interacting with generative AI and not a human.  

### 5.2 Regulated occupation / high‑risk interactions

- Is the system used in a regulated occupation (e.g., doctor, therapist, financial professional, lawyer) and in a “high‑risk artificial intelligence interaction” involving health, financial, legal, or other sensitive data/decisions?  
- If yes, {{ORG_NAME}} must provide proactive, upfront disclosure that the consumer is interacting with generative AI in those high‑risk interactions.  

### 5.3 Advertising and AI‑generated content

- Does the system deliver ads or sponsored content to Utah consumers?  
- If yes, ads must be clearly identified as advertising, and {{ORG_NAME}} remains liable for deceptive AI‑generated advertising.  

### 5.4 Regulatory mitigation (AI Learning Laboratory), if applicable

- Is {{ORG_NAME}} participating in the AI Learning Laboratory?  
- If yes, note that {{ORG_NAME}} must:  
  - Demonstrate technical expertise and financial capacity  
  - Provide a scoped test plan and risk‑mitigation approach  
  - Accept conditions like cure periods and reduced fines in exchange for active monitoring and remediation  

---

## 6. Summary of obligations for {{ORG_NAME}}

Based on the analysis above, {{ORG_NAME}} must at minimum:

- Implement disclosure mechanisms for each in‑scope GenAI interaction with Utah consumers, at least on clear and unambiguous request, and proactively for high‑risk regulated interactions.  
- Maintain a written UAIPA AI Disclosure Policy that sets standards for wording, placement, and timing of disclosures across channels.  
- Establish monitoring and QA for GenAI outputs used with Utah consumers, recognizing that {{ORG_NAME}} is responsible for deceptive or unlawful statements generated by AI.  
- Document any AI Learning Lab participation, including mitigation agreements and ongoing reporting obligations.  

Supporting deliverables (inventory, disclosure UX pack, monitoring plan, complaints runbook, enforcement binder) are maintained separately.  

---

## 7. Ownership, review, and updates

- Document owner: {{DOC_OWNER_NAME}}, {{TITLE}}  
- Supporting teams: Product, Engineering, Customer Support, Legal, Compliance, InfoSec  
- Review cadence: At least annually, and whenever {{ORG_NAME}}:  
  - Launches a new GenAI‑enabled product or chatbot for Utah consumers  
  - Enters a new regulated/high‑risk use case in health, finance, law, or similar occupations  
  - Changes participation in the AI Learning Laboratory or receives new Utah AI guidance  
