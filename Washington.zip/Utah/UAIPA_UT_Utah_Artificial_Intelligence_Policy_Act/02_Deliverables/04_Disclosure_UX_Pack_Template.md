File: UT_04_UAIPA_Disclosure_UX_Pack_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA Disclosure UX Pack (Template – Notices, Scripts, UI Copy)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of this pack

This pack provides standard text, scripts, and UI patterns that {{ORG_NAME}} can use to implement UAIPA‑aligned AI disclosures across channels.  
It is meant to be used alongside the UAIPA AI Disclosure Policy (UT_03) and the GenAI System Inventory (UT_02).  

---

## 2. Coverage map

Complete the table for each in‑scope GenAI system.

| System ID | System Name         | Channel / Surface                  | UAIPA Disclosure Type (On‑Request / Proactive / Both) | Key Utah Touchpoints (Yes/No + notes) |
|-----------|---------------------|------------------------------------|-------------------------------------------------------|----------------------------------------|
| AI-01     | {{SYSTEM_NAME_1}}   | {{CHANNEL_1}}                      | {{DISCLOSURE_TYPE_1}}                                 | {{UT_NOTES_1}}                         |
| AI-02     | {{SYSTEM_NAME_2}}   | {{CHANNEL_2}}                      | {{DISCLOSURE_TYPE_2}}                                 | {{UT_NOTES_2}}                         |

---

## 3. Web / in‑app chatbot copy

### 3.1 First‑message or label text (optional / proactive contexts)

Use where you want the chatbot to signal AI involvement upfront (or where proactive disclosure is required):

- Short label (near chat icon or header):  
  > “AI‑powered assistant”

- First‑message line (optional):  
  > “Hi, I’m an AI‑powered virtual assistant. I can help with {{TASKS}} and connect you to a human if needed.”

### 3.2 On‑request disclosure (required when user clearly asks)

Standard response when a Utah user clearly and unambiguously asks if they are chatting with AI or a bot:

- Base response:  
  > “I am an AI‑powered virtual assistant, not a human.”

- Optional expanded response:  
  > “I am an AI‑powered virtual assistant, not a human. A human team member can review and help if needed.”

Implementation notes:

- Response must be configured as a high‑priority rule, not left to model improvisation.  
- Apply to common phrasings: “Are you a bot?”, “Are you AI?”, “Are you real?”, “Is this a human?”, etc.  

---

## 4. Voice / phone bot scripts

Use for IVR or voice bots that rely on GenAI.

### 4.1 Proactive opening script (for any future high‑risk or regulated use)

> “This call uses an AI‑powered assistant to help provide information. You can ask to speak with a person at any time.”

### 4.2 On‑request disclosure

When a caller clearly asks if they are speaking to AI:

> “You are speaking with an AI‑powered assistant, not a human. I can transfer you to a person if you prefer.”

---

## 5. Email and message templates

When GenAI materially drafts or generates content sent to Utah consumers in a regulated or sensitive context, add a short note where appropriate:

- Footer line (optional):  
  > “This message was prepared with the assistance of AI tools and reviewed by our team.”

For general customer‑service emails drafted by AI but reviewed by staff, no separate disclosure is normally required unless Utah guidance changes or the context is high‑risk.  

---

## 6. Regulated occupation / high‑risk interaction scripts

Use or adapt when a licensed professional uses GenAI in a high‑risk interaction with a Utah resident.

### 6.1 Health‑adjacent example

> “I use an AI‑powered assistant to help gather information and suggest wording. I review and make the decisions about your care.”

### 6.2 Financial / legal‑adjacent example

> “I use an AI‑powered tool to help generate information and drafts. Any advice I provide is based on my own professional judgment.”

Where required, add an upfront statement that AI is involved before collecting sensitive information or giving recommendations.  

---

## 7. Advertising & promotions inside GenAI

When GenAI delivers promotions or ads in chat or other interactive flows:

- Label snippet:  
  > “Promotion: Save 10% on your next order with code SAVE10.”

- Optional short explainer (if needed in UI help text):  
  > “Some offers shown here are automatically suggested by our AI‑powered assistant.”

Ensure promotional blocks are visually distinct (icon, prefix, or styling) so users recognize them as offers.  

---

## 8. UX checklist for each system

For each AI system, record:

- Where does the first disclosure appear (if any)?  
- How is the on‑request disclosure implemented (rule, intent, system message)?  
- Have we tested common user questions about bots/AI?  
- Are promotional messages clearly labeled and reviewed?  

Attach screenshots or recordings in a separate folder (e.g., `/UX/UT/AI-01/`) and reference them here.  

---

## 9. Maintenance

- Product/UX owners are responsible for keeping this pack aligned with live interfaces.  
- Compliance reviews this pack at least annually and after any Utah AI law change or major UX redesign.  
- Changes to disclosure wording must be reviewed by Legal/Compliance before deployment.
