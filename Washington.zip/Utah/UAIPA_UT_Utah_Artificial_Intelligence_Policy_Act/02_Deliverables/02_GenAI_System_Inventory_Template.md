File: UT_02_GenAI_System_Inventory_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: Generative AI System & Use‑Case Inventory (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of this inventory

This inventory identifies all generative AI (GenAI) systems and use cases at {{ORG_NAME}} that may interact with Utah residents or influence communications and decisions affecting Utah consumers.  
It supports UAIPA compliance by making it clear which systems are in scope for disclosure, monitoring, and consumer‑protection obligations.  

---

## 2. Scope and definitions

For this inventory, “GenAI system” includes any tool or service that:

- Generates text, images, audio, code, or other content using machine‑learning models.  
- Interacts directly with consumers or helps create content that will be provided to consumers.  
- Is used in activities regulated by the Utah Division of Consumer Protection or by regulated occupations in high‑risk interactions.  

In scope:

- Consumer‑facing bots, assistants, and self‑service tools.  
- Internal GenAI assistants where outputs are routinely sent to consumers.  
- Tools used by regulated occupations (e.g., health, finance, law) serving Utah residents.  

Out of scope (for this document only):

- Purely internal R&D tools with no impact on consumer communications or decisions.  

---

## 3. System inventory table

Use this table as the master list; each row should map to a specific product configuration or use case.

| ID   | System / Tool Name      | Description / Purpose                                  | Provider / Owner             | Channel / Surface                    | Consumer-Facing? (Y/N) | Regulated Occupation / High-Risk? (Y/N + notes) | Utah Use? (Y/N + notes) |
|------|-------------------------|--------------------------------------------------------|------------------------------|--------------------------------------|------------------------|-----------------------------------------------|-------------------------|
| AI-01| {{SYSTEM_NAME_1}}       | {{SHORT_PURPOSE_1}}                                   | {{VENDOR_OR_INTERNAL_1}}     | {{CHANNEL_1}}                        | Y/N                    | Y/N – {{DETAIL_1}}                             | Y/N – {{DETAIL_2}}      |
| AI-02| {{SYSTEM_NAME_2}}       | {{SHORT_PURPOSE_2}}                                   | {{VENDOR_OR_INTERNAL_2}}     | {{CHANNEL_2}}                        | Y/N                    | Y/N – {{DETAIL_3}}                             | Y/N – {{DETAIL_4}}      |
| AI-03| {{SYSTEM_NAME_3}}       | {{SHORT_PURPOSE_3}}                                   | {{VENDOR_OR_INTERNAL_3}}     | {{CHANNEL_3}}                        | Y/N                    | Y/N – {{DETAIL_5}}                             | Y/N – {{DETAIL_6}}      |

Add rows as needed for additional systems.

---

## 4. Data and interaction profile

For each in‑scope system (Consumer‑Facing = Yes or Utah Use = Yes), complete this mini‑profile:

**System ID:** {{AI_ID}}  
**Name:** {{SYSTEM_NAME}}  

1. **User type(s):**  
   - Consumers directly (end‑users)  
   - Business customers / clients  
   - Regulated professionals (e.g., clinicians, advisors, lawyers)  

2. **Key actions supported:**  
   - {{ACTION_1}} (e.g., answering customer service questions)  
   - {{ACTION_2}} (e.g., suggesting products or services)  
   - {{ACTION_3}}  

3. **Data categories involved:**  
   - Basic contact / account data  
   - Financial or payment‑related data  
   - Health / wellness / clinical‑adjacent data  
   - Legal / rights / contractual data  
   - Other sensitive categories: {{OTHER_SENSITIVE}}  

4. **Output types:**  
   - Chat responses / messages  
   - Emails / letters  
   - Summaries / explanations  
   - Recommendations / personalized offers  

5. **Utah exposure:**  
   - Approximate monthly interactions with Utah residents: {{UT_INTERACTIONS_PER_MONTH}}  
   - Key Utah‑facing products, brands, or clients: {{UT_PRODUCTS_CLIENTS}}  

---

## 5. UAIPA‑relevant flags

For each in‑scope system, record:

- **Disclosure requirement type:**  
  - On‑request disclosure only (consumer‑protection‑regulated activity)  
  - Proactive upfront disclosure (regulated/high‑risk interactions)  
  - Both  

- **Advertising / promotions inside AI:**  
  - Does this system display promotions or sponsored offers? Y/N  
  - Are such promotions clearly labeled as offers/ads? Y/N  

- **Policy / control links:**  
  - Linked policies: {{POLICY_DOCS}} (e.g., UAIPA Disclosure Policy, Acceptable Use Policy)  
  - Linked procedures: {{PROCEDURES_DOCS}} (e.g., Monitoring Plan, Complaint Handling Runbook)  

---

## 6. Ownership and lifecycle

For each system:

- **Business owner:** {{BUSINESS_OWNER_NAME}}, {{TITLE}}  
- **Technical owner:** {{TECH_OWNER_NAME}}, {{TITLE}}  
- **Compliance contact:** {{COMPLIANCE_CONTACT_NAME}}, {{TITLE}}  
- **Status:** In design / Pilot / In production / Sunset  
- **Change triggers:** New Utah clients, new regulated/high‑risk use cases, changes to GenAI vendor or configuration.  

This inventory is reviewed at least annually and updated whenever new GenAI systems are deployed or materially changed for Utah‑facing use.

