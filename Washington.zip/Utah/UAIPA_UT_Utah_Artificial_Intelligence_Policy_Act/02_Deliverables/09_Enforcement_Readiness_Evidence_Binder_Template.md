File: UT_09_UAIPA_Enforcement_Readiness_EVIDENCE_BINDER_EXAMPLE_BeehiveHelp.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Policy, Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA Enforcement Readiness & Evidence Binder (Example – BeehiveHelp, Inc.)  
Organization: BeehiveHelp, Inc.  
Date: January 31, 2026  
Prepared By: Jordan Blake, Director of Compliance  

---

## 1. Purpose

This index shows how BeehiveHelp, Inc. would assemble and present documentation if Utah regulators or auditors reviewed its AI‑powered customer‑support tools.  
It points to specific files and folders demonstrating scope analysis, disclosures, monitoring, and incident handling for Utah.  

---

## 2. Binder structure and storage

Primary location: `/Compliance/AI/Utah_UAIPA/`  

Subfolders:

- `/01_Scope_Applicability/`  
- `/02_System_Inventory/`  
- `/03_Disclosure_Policy/`  
- `/04_Disclosure_UX/`  
- `/05_Monitoring/`  
- `/06_Ads_Targeting/`  
- `/07_Regulated_HighRisk/`  
- `/08_Incidents_Complaints/`  

As of the date of this example, BeehiveHelp does **not** participate in Utah’s AI Learning Laboratory, so `/09_Sandbox_Program/` is reserved for future use.  

---

## 3. UAIPA requirement → evidence map

| Requirement / Topic                                   | Evidence Type                                         | File or Location                                                                 | Owner                         |
|------------------------------------------------------|--------------------------------------------------------|-----------------------------------------------------------------------------------|-------------------------------|
| Scope & applicability documented                     | Memo                                                   | `/01_Scope_Applicability/UT_01_UAIPA_Scope_Applicability_MEMO_BeehiveHelp.md`    | Director of Compliance        |
| GenAI systems inventory for Utah                     | Inventory                                              | `/02_System_Inventory/UT_02_GenAI_System_Inventory_BeehiveHelp.md`               | Director of Compliance        |
| AI disclosure standards & triggers                   | Policy                                                 | `/03_Disclosure_Policy/UT_03_UAIPA_AI_Disclosure_Policy_BeehiveHelp.md`          | Director of Compliance        |
| Live chatbot / UX disclosure implementation          | Screenshots + UX notes                                | `/04_Disclosure_UX/AI-01/` (PNG files, short README)                              | Product Manager, Chat         |
| Monitoring & oversight of GenAI outputs              | Plan + monitoring log summary                         | `/05_Monitoring/UT_05_GenAI_Oversight_Monitoring_PLAN_BeehiveHelp.md`            | Director of Compliance        |
| Controls for promotions / ads in AI                  | Controls doc + config examples                        | `/06_Ads_Targeting/UT_06_Chatbot_Advertising_Targeting_CONTROLS_BeehiveHelp.md`  | Product Manager, Chat         |
| Rules for regulated/high‑risk use                    | Playbook (client‑facing guidance)                     | `/07_Regulated_HighRisk/UT_07_Regulated_Occupations_HighRisk_Playbook_BeehiveHelp.md` | Director of Compliance   |
| Handling of AI‑related incidents & complaints        | Runbook + sample tickets                               | `/08_Incidents_Complaints/UT_08_UAIPA_Incident_Complaint_RUNBOOK_BeehiveHelp.md` | Support Operations Lead       |

---

## 4. Key documents and quick links

1. **UAIPA Scope & Applicability Memo**  
   - `/01_Scope_Applicability/UT_01_UAIPA_Scope_Applicability_MEMO_BeehiveHelp.md`  

2. **GenAI System Inventory**  
   - `/02_System_Inventory/UT_02_GenAI_System_Inventory_EXAMPLE_BeehiveHelp.md`  

3. **AI Disclosure Policy & UX evidence**  
   - Policy: `/03_Disclosure_Policy/UT_03_UAIPA_AI_Disclosure_Policy_EXAMPLE_BeehiveHelp.md`  
   - UX screenshots for AI‑01: `/04_Disclosure_UX/AI-01/`  
     - `chat_header_label.png`  
     - `on_request_disclosure_flow.png`  

4. **Monitoring & Incident Summary (last 12 months)**  
   - Oversight plan: `/05_Monitoring/UT_05_GenAI_Oversight_Monitoring_PLAN_EXAMPLE_BeehiveHelp.md`  
   - Monitoring summary slide: `/05_Monitoring/UT_Monitoring_Summary_2025_Q4.pdf`  
   - Incident log export (UT‑tagged): `/08_Incidents_Complaints/UT_AI_Incident_Log_Export_2025.csv`  

---

## 5. Sample evidence list for AI‑01 BeehiveHelp AI Chatbot

**System ID:** AI‑01  
**System Name:** BeehiveHelp AI Chatbot  

- Scope & risk notes:  
  - See UT_01 memo (section describing consumer‑facing chat with Utah customers).  

- Disclosure UX evidence:  
  - `/04_Disclosure_UX/AI-01/chat_header_label.png` – shows “AI‑powered assistant” label.  
  - `/04_Disclosure_UX/AI-01/on_request_disclosure_flow.png` – conversation where customer asks “Are you a bot?” and sees AI disclosure.  

- Monitoring evidence:  
  - Entries in `UT_AI_Incident_Log_Export_2025.csv` indicating monthly sampling and issues status.  
  - Excerpt from Q4 2025 monitoring summary describing sample size and any Utah incidents.  

- Incident history:  
  - “20% discount” incident documented in `UT_AI_Incident_Log_Export_2025.csv` and detailed in UT_08 runbook example.  

---

## 6. AI Learning Laboratory / regulatory mitigation

BeehiveHelp is not currently enrolled in Utah’s AI Learning Laboratory Program.  

- If BeehiveHelp applies in the future, it will create `/09_Sandbox_Program/` containing:  
  - Application materials;  
  - Utah approval/participation documents;  
  - Required periodic reports;  
  - Internal remediation summaries for any issues discovered during testing.  

Until then, this section remains reserved.  

---

## 7. Internal review checklist before responding to Utah regulators

If BeehiveHelp receives a Utah regulatory inquiry about its AI Chatbot:

1. Confirm the date range and merchants in scope.  
2. Export relevant logs for AI‑01 conversations involving Utah merchants into `/Regulator_Response/UT-AG-YYYY-XX/`.  
3. Copy current versions of:  
   - UT_01, UT_02, UT_03, UT_05, UT_06, and UT_08 example documents into that folder.  
4. Draft a short narrative summarizing:  
   - What AI‑01 does.  
   - How disclosures work in Utah.  
   - How monitoring and incident handling operate.  
5. Have the General Counsel and Director of Compliance review the narrative and evidence before sending any response.  

---

## 8. Maintenance and ownership

- Binder owner: Jordan Blake, Director of Compliance.  
- System‑specific evidence is maintained by the relevant Product Managers and Engineering leads, with quarterly check‑ins.  

BeheiveHelp’s Compliance team performs:

- A quarterly link check to ensure folders and files are current.  
- An annual “table‑top” exercise where they simulate a Utah inquiry and verify that the binder can be assembled within a reasonable timeframe (e.g., 5 business days).  
