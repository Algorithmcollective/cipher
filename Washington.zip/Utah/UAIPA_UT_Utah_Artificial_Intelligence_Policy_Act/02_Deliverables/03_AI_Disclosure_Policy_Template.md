File: UT_03_UAIPA_AI_Disclosure_Policy_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Consumer Transparency & AI Learning Laboratory provisions  
Document Type: UAIPA AI Disclosure Policy (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose and scope

This policy defines how {{ORG_NAME}} will disclose its use of generative artificial intelligence (GenAI) to people in Utah, in line with the Utah AI disclosure requirements.  
It applies to all business units, products, and personnel who deploy or configure GenAI systems that interact with consumers or support services delivered to Utah residents.  

---

## 2. Legal background (plain language)

Utah’s AI rules require businesses that use GenAI with consumers to provide two kinds of disclosures:

1. **Requested disclosure (most businesses)**  
   - If {{ORG_NAME}} uses, prompts, or otherwise causes GenAI to interact with a person in connection with activities regulated by the Utah Division of Consumer Protection, {{ORG_NAME}} must clearly and conspicuously disclose that the person is interacting with GenAI and not a human when the person clearly and unambiguously asks.[web:41][web:55][web:50]  

2. **Proactive disclosure (regulated/high‑risk uses)**  
   - If {{ORG_NAME}} or its professionals operate in a “regulated occupation” (licensed by the Utah Department of Commerce) and use GenAI in specific high‑risk interactions involving sensitive data or significant personal decisions, {{ORG_NAME}} must make a prominent disclosure at the beginning of the interaction.[web:31][web:32][web:46][web:38]  

Utah law also makes {{ORG_NAME}} responsible for deceptive or unlawful conduct carried out through its use of GenAI in consumer interactions.[web:33][web:50]  

---

## 3. When disclosure is required

{{ORG_NAME}} will treat a GenAI system as **in scope** for this policy if it:

- Interacts directly with people in Utah via chat, voice, text, or similar channels; or  
- Generates content that is routinely sent to Utah consumers; or  
- Is used in a regulated occupation in a way that could influence significant health, financial, legal, or similar decisions.  

Disclosure is required in these cases:

- A person clearly and unambiguously asks whether they are interacting with AI, a bot, or a human.  
- A regulated professional uses GenAI in a high‑risk AI interaction with a Utah resident (e.g., personalized health, financial, or legal advice involving sensitive data).[web:31][web:39][web:38]  

---

## 4. Standard disclosure language

### 4.1 Requested disclosure (general consumer interactions)

When a Utah consumer clearly and unambiguously asks if they are interacting with AI or a bot, in‑scope systems must respond with clear and plain language, such as:

> “I am an AI‑powered virtual assistant, not a human.”  

Where appropriate, {{ORG_NAME}} may add brief context, for example:

> “I am an AI‑powered virtual assistant, not a human. A human team member can review and help if needed.”  

The disclosure must be clearly visible or audible in the same channel where the question was asked (chat, voice, SMS, email, etc.).[web:41][web:55][web:57]  

### 4.2 Proactive disclosure (regulated/high‑risk interactions)

For regulated occupations and high‑risk AI interactions with Utah residents, the disclosure must occur **at the beginning** of the interaction:

- **Verbal interactions:** A spoken statement before the GenAI‑supported service begins.  
- **Written or digital interactions:** A clear text statement before or at the start of the GenAI‑enabled exchange.[web:32][web:46][web:37]  

Examples:

- Health context:  
  > “This service uses an AI‑powered assistant to help provide information. A licensed professional will review or can assist.”  

- Financial/legal context:  
  > “This interaction uses an AI tool to help generate information and suggestions. You should not treat this as personalized professional advice without checking with a licensed professional.”  

---

## 5. Channel‑specific implementation

For each GenAI system identified in the UT_02 inventory, {{ORG_NAME}} will define how the disclosure appears:

- **Web chatbots:**  
  - Add a disclosure line in the first message or as a visible label/icon where proactive disclosure is required.  
  - Ensure the bot can answer “Are you a bot?” and similar questions with the standard disclosure language.[web:41][web:55]  

- **Voice/phone bots:**  
  - Play a short disclosure message at the start of the call if used in high‑risk or regulated contexts.  
  - Configure scripts so agents using AI‑assisted prompts can explain that they are using AI tools when needed.  

- **In‑app assistants and help widgets:**  
  - Include a brief disclosure near the assistant’s UI (e.g., “AI‑powered assistant”) and ensure the assistant responds correctly when asked if it is AI.  

- **Email / message generation tools:**  
  - Ensure internal users know when to add a disclosure line in messages where GenAI plays a material role and the interaction is regulated or high‑risk.  

Implementation details for each system should be documented in a separate “Disclosure UX Pack” (UT_04), linked to this policy.  

---

## 6. Advertising and promotions inside GenAI

When GenAI systems present promotions, offers, or other advertising content to Utah consumers:

- Promotional content must be clearly labeled (e.g., “Offer,” “Promotion,” or “Sponsored”).[web:31][web:35]  
- {{ORG_NAME}} will review AI‑generated promotional language for accuracy and non‑deception before deploying templates or allowing auto‑serve behavior.  
- If a system uses consumer input to decide whether to show ads or what ads to show, the practice must be described in applicable notices and must not contradict Utah consumer‑protection rules.  

---

## 7. Roles and responsibilities

- **Product owners:** Ensure GenAI features under their control implement this policy in their UX and logic.  
- **Engineering / technical teams:** Implement and test disclosure behaviors, including triggered responses to consumer questions.  
- **Legal & Compliance:** Interpret Utah AI requirements, approve disclosure language, and review edge cases (e.g., new high‑risk uses).[web:50][web:38]  
- **Customer‑facing teams:** Follow scripts and guidance when explaining the role of AI to customers.  

---

## 8. Training and awareness

{{ORG_NAME}} will:

- Provide training for relevant teams on when and how to disclose AI use with Utah consumers.  
- Include UAIPA expectations in onboarding for teams that deploy or configure GenAI systems.  
- Periodically refresh training when Utah issues new guidance or {{ORG_NAME}} expands high‑risk AI use cases.[web:36][web:53][web:58]  

---

## 9. Monitoring, testing, and enforcement

To ensure this policy is followed:

- Compliance and product teams will periodically test in‑scope GenAI systems by asking if they are AI and confirming that the correct disclosure appears.  
- For regulated/high‑risk systems, spot checks will confirm that disclosures appear at the beginning of interactions and remain visible or audible.  
- Failures to disclose will be logged, investigated, and remediated, and repeated failures may result in disciplinary action or feature changes.  

---

## 10. Review and updates

This policy will be reviewed at least annually, and also when:

- Utah AI laws or guidance materially change.  
- {{ORG_NAME}} launches new GenAI systems or begins operating in a regulated occupation.  
- Significant incidents or complaints involving AI disclosures occur in Utah.  

Updates will be approved by {{POLICY_APPROVER_NAME}}, {{TITLE}}, with Legal and Compliance sign‑off.
