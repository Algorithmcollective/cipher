File: UT_08_UAIPA_Incident_Complaint_RUNBOOK_TEMPLATE.md

Law: Utah Artificial Intelligence Policy Act (UAIPA)  
Citation: Utah Code Ann. Title 13 – AI Policy & Consumer Transparency provisions  
Document Type: UAIPA Incident & Complaint Handling Runbook (Template)  
Organization: {{ORG_NAME}}  
Date: {{DATE}}  
Prepared By: {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This runbook defines how {{ORG_NAME}} identifies, triages, investigates, and remediates incidents and complaints related to generative AI use with Utah residents.  
It is designed to support Utah consumer‑protection expectations and to demonstrate that {{ORG_NAME}} takes AI‑related concerns seriously and acts promptly to correct issues.  

---

## 2. Scope

This runbook applies to:

- All GenAI systems in the UT_02 inventory that interact with Utah consumers or influence communications sent to them.  
- Any complaint, inquiry, or internal report that alleges:  
  - Misleading or harmful AI‑generated content;  
  - Missing or confusing AI disclosure; or  
  - Inappropriate AI use in regulated/high‑risk interactions.  

---

## 3. Intake channels

AI‑related incidents or complaints may arrive via:

- Customer support tickets or helpdesk forms.  
- Direct emails to Compliance, Legal, or Product.  
- Merchant/client escalations (for B2B platforms).  
- Social media or app‑store reviews referencing “AI” or “bot.”  
- Internal reports from employees or contractors.  

All staff receiving a potential AI‑related issue must:

1. Capture the details (see Section 4).  
2. Route it to {{AI_INCIDENT_MAILBOX}} or log it in {{AI_INCIDENT_TRACKER_LINK}}.  

---

## 4. Initial logging

For each incident or complaint, record at minimum:

- Unique ID: {{AUTO_OR_MANUAL_ID}}  
- Date/time received  
- Reporter and contact info (if available)  
- Channel (ticket, email, client escalation, etc.)  
- Systems involved (AI IDs from UT_02)  
- Short description of issue (e.g., “bot gave wrong return info,” “chat refused to disclose it is AI”)  
- Utah connection (e.g., Utah consumer, Utah merchant, Utah IP, or known Utah account)  

Assign an initial owner (usually the product or support owner for the system involved).  

---

## 5. Triage and severity assessment

The owner, with Compliance as needed, assigns a severity level:

- **Low:** Isolated confusion, minor error with limited impact, no clear Utah nexus.  
- **Medium:** Repeated incorrect or unclear AI responses affecting Utah users, but limited financial or legal impact.  
- **High:** AI appears to have contributed to materially misleading information, significant frustration, or potential harm for Utah residents; or involves regulated/high‑risk use.  

Target timelines:

- Low: review within 10 business days.  
- Medium: review within 5 business days.  
- High: review and mitigation plan within 2 business days.  

---

## 6. Investigation steps

For each incident:

1. **Gather artifacts**  
   - Relevant chat/email transcripts or logs.  
   - Screenshots or recordings.  
   - System configuration at the time (prompts, version, flags).  

2. **Reproduce if possible**  
   - Attempt to recreate the problematic behavior using test accounts or staging environment.  

3. **Determine root cause**  
   - Prompt or configuration design?  
   - Model behavior (hallucination or unexpected output)?  
   - Merchant/client customization (for B2B)?  
   - User misuse or misunderstanding?  

4. **Assess impact**  
   - Number of affected Utah users (estimated).  
   - Whether promotions, terms, or policies were misrepresented.  
   - Whether any regulated/high‑risk matters (health, finance, law) were involved.  

Document findings in the incident record.  

---

## 7. Remediation and communication

Based on severity and root cause, define remediation steps such as:

- Adjusting prompts or configuration to block similar responses.  
- Tightening disclosure behavior or adding additional clarifications.  
- Correcting or disabling specific promotions or flows.  
- Providing updated guidance or training to internal teams or clients.  

Where appropriate, consider:

- Proactive communication to affected clients/customers (e.g., updated information or clarification).  
- Credits or other business remedies, according to existing policies.  

Record:

- Actions taken.  
- Responsible owners.  
- Completion dates.  

---

## 8. Escalation to Legal/Compliance and leadership

Mandatory escalation to Legal/Compliance occurs when:

- A Utah consumer alleges deception, unfairness, or harm tied to AI behavior.  
- A regulated/high‑risk interaction appears to have been mishandled using AI.  
- A Utah regulator, attorney, or media outlet contacts {{ORG_NAME}} about AI use.  

Legal/Compliance decides whether to:

- Treat the matter as part of routine complaint handling; or  
- Escalate to executive leadership; or  
- Involve outside counsel.  

---

## 9. Linkage to Utah‑specific risk management

For incidents with clear Utah nexus:

- Tag the incident as “UT‑AI” in the tracker.  
- Include in quarterly Utah AI risk summaries (see UT_05).  
- Evaluate whether changes are needed in UT_03–UT_07 documents (policy, UX, playbooks).  

If {{ORG_NAME}} participates in Utah’s AI Learning Laboratory, consider whether incident details must be reflected in periodic reporting to Utah’s Office of Artificial Intelligence Policy.  

---

## 10. Closure and lessons learned

To close an incident:

- Confirm that remediation actions are complete and tested.  
- Update relevant documentation (policies, prompts, playbooks) as needed.  
- Capture key “lessons learned” and share them with relevant teams.  

The incident status is then set to “Closed,” with a brief closure summary.  

---

## 11. Review cadence

Compliance will review AI incident/complaint data:

- Quarterly, to identify patterns and systemic issues.  
- Annually, to feed into broader AI risk and compliance program updates.  

Any significant trend involving Utah residents will be highlighted in leadership briefings and may trigger additional controls or audits.
