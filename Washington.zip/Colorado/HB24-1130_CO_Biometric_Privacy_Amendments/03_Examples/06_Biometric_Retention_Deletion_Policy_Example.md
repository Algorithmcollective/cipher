# Colorado Biometric Retention, Deletion & Request Handling – Example  
**File:** CO_6_Biometric_Retention_Deletion_and_Requests_examplemd.md  

**Company:** Front Range Logistics  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** 2026-02-01  
**Owner:** Privacy & Compliance  

> **Purpose:** Show how Front Range Logistics manages retention, deletion, and individual requests for biometric data used in Colorado (time clocks, access control, visitor kiosk, and SmartCam safety analytics).

---

## 1. Biometric Retention Schedule

| ID | System Name                 | Biometric Type(s)                    | Population (Employees / Visitors / Customers / Other) | Primary Purpose(s)                               | Standard Retention Period for Biometric Data                           | Trigger for Start of Retention Clock                                   | Exceptions (e.g., legal holds)                                   |
|----|-----------------------------|--------------------------------------|--------------------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------|--------------------------------------------------------------------|
| 1  | KronoTime Biometric Clocks | Fingerprint templates                | Employees                                             | Time and attendance tracking                     | Until employment ends + up to 30 days                                   | Date of last clock‑in/clock‑out or date of termination (whichever later) | Legal holds related to wage/hour disputes or investigations      |
| 2  | SecureGate Access Control  | Hand geometry templates              | Employees, Contractors                                | Secure access to warehouses and cage areas       | While badge is active + up to 7 days after deactivation                  | Date badge is deactivated                                             | Legal holds for security incidents or investigations              |
| 3  | VisitorCheck Lobby Kiosk   | Facial templates (short‑term)        | Visitors, Drivers                                     | Visitor identity verification and badge issuance | Up to 30 days after last visit                                           | Date of last check‑in                                                | Legal holds for security or incident investigations               |
| 4  | SmartCam Safety Analytics  | Facial & posture analytics (derived) | Employees (warehouse & pilot truck drivers)          | Safety and near‑miss detection                   | Event‑level analytics: up to 12 months; raw video: up to 14 days         | Date of event capture                                                  | Legal holds for safety incidents, claims, or regulatory inquiries |

---

## 2. Deletion & De‑Identification Procedures

### 2.1 System‑Level Deletion Matrix

| System Name                 | Data Elements Deleted (Templates, Logs, Backups)                           | Deletion Method (Config / API / Script)                                      | Responsible Team / Role           | Deletion Frequency (Event‑Driven / Batch)          | Evidence (Logs / Reports) Location                                      |
|-----------------------------|----------------------------------------------------------------------------|-------------------------------------------------------------------------------|-----------------------------------|---------------------------------------------------|-------------------------------------------------------------------------|
| KronoTime Biometric Clocks | Fingerprint templates for separated employees                             | HR triggers unenrollment; KronoTech portal configured to auto‑purge templates | HR (initiation), Payroll & Vendor | Event‑driven at termination + nightly batch       | `\\risk\\biometrics\\logs\\KronoTime_Deletion_Reports`                  |
| SecureGate Access Control  | Hand geometry templates tied to deactivated badges                        | Security submits badge deactivation; SecureGate admin console auto‑deletes    | Physical Security; IT Security    | Event‑driven upon badge deactivation             | `\\security\\access\\SecureGate_Deletion_Log.xlsx`                       |
| VisitorCheck Lobby Kiosk   | Visitor facial templates and associated biometric identifiers             | Vendor retention set to 30 days; automatic deletion configured                | Facilities; Vendor Account Owner  | Daily vendor batch purge                        | Vendor portal export; saved quarterly to `\\facilities\\VisitorCheck`   |
| SmartCam Safety Analytics  | Event‑level analytics per person >12 months; raw video >14 days          | SafeVision retention rules configured; scheduled deletion jobs; legal holds   | Safety & Risk; IT                 | Nightly jobs; monthly verification reports       | `\\safety\\SmartCam\\Deletion_Reports`                                   |

### 2.2 Standard Deletion Workflow (Text)

1. **Identify records for deletion**  
   - HR notifies IT and vendors when employees or contractors leave.  
   - Facilities/Security notify IT when badges are deactivated.  
   - Automated jobs identify biometric records beyond standard retention thresholds.

2. **Validate trigger and scope**  
   - Confirm the individual(s), systems, and relevant dates (termination, last visit, badge deactivation).  

3. **Execute deletion**  
   - HR/IT use KronoTech and SecureGate admin tools to unenroll users and trigger template deletion.  
   - Vendors (KronoTech, VisitorCheck, SafeVision) run configured deletion jobs or respond to specific deletion requests.

4. **Verify completion**  
   - Teams review vendor or system logs and export reports confirming deletion.  

5. **Record in Biometric Deletion Log**  
   - Privacy & Compliance records date, system, trigger, and verification.

---

## 3. Biometric Deletion Log (Sample Entries)

| Date       | System Name                | Individual(s) / Group      | Deletion Trigger (Retention / Request / Other) | Data Elements Removed                       | Performed By (Role)        | Verification Method (Log / Vendor Confirm)          | Notes                                             |
|-----------|----------------------------|----------------------------|------------------------------------------------|---------------------------------------------|----------------------------|----------------------------------------------------|---------------------------------------------------|
| 2026-01-10| KronoTime Biometric Clocks | 5 separated employees (Dec)| Retention (employment ended)                   | Fingerprint templates linked to 5 user IDs  | Payroll Specialist         | KronoTech deletion report (job ID 2026-01-10‑A)    | All 5 IDs confirmed deleted within 24 hours.      |
| 2026-01-12| SecureGate Access Control  | Contractor badge #C‑482    | Retention (badge deactivation)                 | Hand geometry template for badge #C‑482     | Security Admin             | SecureGate admin log (ticket SEC‑DEL‑2026‑0112)    | Badge deactivated and template removed.          |
| 2026-01-15| VisitorCheck Lobby Kiosk   | All visitors >30 days old  | Retention (rolling purge)                      | Facial templates older than 30 days         | Facilities Coordinator     | Vendor monthly report (VC‑DEL‑2026‑01)             | Purge verified; report stored in facilities share.|
| 2026-01-20| SmartCam Safety Analytics  | Events >12 months old      | Retention (rolling purge)                      | Event‑level analytics older than 12 months  | Safety & Risk Analyst      | SafeVision deletion summary (SV‑CO‑2026‑01)        | Aggregated metrics retained; PII removed.        |

---

## 4. Individual Requests – Intake & Triage

### 4.1 Intake Channels

- **Primary contact email:** privacy@frontrangelogistics.com  
- **Alternate channels:**  
  - Ethics & Compliance hotline (listed on intranet and posters).  
  - HR Business Partner for employees.

### 4.2 Triage Steps

1. **Identify request type**  
   - Example:  
     - “Do you store my fingerprint?” → Access/information.  
     - “Please delete my biometric data.” → Deletion.  

2. **Authenticate requester**  
   - Employees: verify via HR records and company credentials.  
   - Visitors: verify via visitor log details (name, date, company, ID if applicable).

3. **Check scope**  
   - Determine which systems (KronoTime, SecureGate, VisitorCheck, SmartCam) hold biometric data for this individual.  

4. **Log request**  
   - Create a case in the Privacy Request Tracker with unique ID (e.g., BIOMETRIC‑REQ‑2026‑001).

---

## 5. Individual Requests – Handling Steps

### 5.1 Access / Information Requests (Example Flow)

1. **Locate records**  
   - HR/IT confirm whether the requester is/was enrolled in KronoTime or SecureGate.  
   - Facilities check VisitorCheck logs; Safety checks SmartCam events if applicable.

2. **Prepare response**  
   - Confirm whether biometric data is held, which systems, and for what purposes.  
   - Provide a summary of retention periods and high‑level security measures.  
   - Attach or link to the Biometric Privacy Notice.

3. **Respond**  
   - Provide response via email or agreed channel within the standard timeframe (e.g., 30–45 days), documenting date and content.

### 5.2 Deletion Requests (Employee Example)

1. **Assess feasibility**  
   - If active employee: determine whether biometric use is mandatory for core functions (timekeeping/access). If yes, discuss operational alternatives (badge or PIN) if available.  
   - If ex‑employee: typically eligible for deletion, subject to legal hold checks.

2. **Execute deletion**  
   - HR/IT unenroll from KronoTime and SecureGate; request vendor deletion for VisitorCheck or SmartCam if applicable.

3. **Record and confirm**  
   - Log actions in the Biometric Deletion Log and the request case file.  
   - Confirm to the requester that deletion has been completed and explain any residual data (e.g., non‑biometric logs retained).

### 5.3 Objection / Withdrawal of Consent (SmartCam Example)

- If an employee objects to SmartCam analytics and the program is mandatory for a high‑risk role:  
  - Escalate to HR and Safety to assess accommodation options (e.g., reassignment).  
  - Document outcome and any change in exposure to biometric systems.

---

## 6. Roles & Responsibilities

| Role / Function         | Responsibilities Related to Retention, Deletion & Requests                                                                 |
|-------------------------|-----------------------------------------------------------------------------------------------------------------------------|
| Privacy & Compliance    | Owns this procedure; maintains retention schedule; oversees deletion log and request tracker; coordinates complex cases.  |
| HR / People Operations  | Triggers offboarding events; communicates with employees; supports identity verification and alternative arrangements.     |
| IT / Security           | Implements technical deletion and configuration changes; maintains logs; verifies vendor and system‑level deletions.       |
| Facilities / Security   | Manages access control and visitor systems; triggers deletions upon badge deactivation and visitor log aging.             |
| Safety & Risk           | Manages SmartCam retention settings; reviews and approves any changes impacting safety analytics retention.               |
| Vendors / Processors    | Execute deletions upon instruction; provide logs or certifications; support access/deletion requests where needed.        |

---

## 7. Review and Continuous Improvement

- **Procedure Owner:** Director, Privacy & Compliance  
- **Review Frequency:** Annually each November, or earlier if:  
  - New biometric systems are added or existing ones materially change.  
  - Colorado biometric rules or Company retention standards change.  
  - Significant biometric‑related incident or pattern of complaints occurs.

**Most Recent Review**

- **Review Date:** 2025-11-30  
- **Reviewed By:** Director, Privacy & Compliance; HR Director; Head of IT Security; Director of Safety & Risk  
- **Key Updates:**  
  - Added SmartCam analytics pilot to the retention schedule.  
  - Shortened default retention for visitor facial templates from 60 to 30 days.  
  - Clarified that wage/hour records may require retention of non‑biometric time data even after biometric templates are deleted.
