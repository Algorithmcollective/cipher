# Deliverable 1: Biometric Systems Inventory & Data Map  
**File:** CO_1_Biometric_Systems_Inventory_and_Data_Map_EXAMPLE_FrontRangeLogistics.md  

## 1. Purpose

This inventory identifies all systems that collect, generate, store, or use biometric identifiers or biometric data for Colorado residents. It supports compliance with Colorado’s biometric and privacy requirements by documenting purposes, populations, data flows, vendors, and retention/deletion rules.

## 2. Biometric Systems Inventory Table

Fill one row per system. This example is pre‑filled for “Front Range Logistics,” a multi‑site warehouse and distribution company using biometric time clocks and access control.

| ID | System Name                                | Purpose / Function                           | Biometric Type          | Population         | Locations / Sites                                  | Vendor / Owner                      | Storage Location                                         | Linked Policies / SOPs                                      |
|----|--------------------------------------------|----------------------------------------------|-------------------------|--------------------|----------------------------------------------------|--------------------------------------|---------------------------------------------------------|----------------------------------------------------------------|
| 1  | KronoTime Biometric Time Clocks            | Time and attendance tracking for hourly staff| Fingerprint template    | Employees          | Denver DC, Aurora DC, Colorado Springs Cross‑Dock | Vendor: KronoTech / Owner: HR       | Encrypted in KronoTech US‑based cloud (Oregon region); limited logs on devices | Biometric Policy §3–4; Timekeeping SOP; Retention Schedule Table A |
| 2  | SecureGate Warehouse Access Control        | Secure badge + biometric access to dock doors and cage areas | Hand geometry template | Employees, Contractors | All CO warehouses (site codes CO‑01, CO‑02, CO‑03) | Vendor: GateSecure / Owner: Physical Security | On‑prem access control server at Denver HQ; encrypted backups to CO‑based data center | Biometric Policy §2–4; Physical Security SOP; Access Control Standard |
| 3  | VisitorCheck Lobby Kiosk                   | Visitor identity verification and badge printing | Facial template         | Visitors, Drivers  | Denver DC front lobby                                | Vendor: VisitorCheck / Owner: Facilities | VisitorCheck cloud (US‑only region, vendor‑managed)      | Biometric Policy §3; Visitor Management SOP; Vendor Due Diligence File |
| 4  | FleetID Mobile App                         | Driver authentication for vehicle dispatch app | Fingerprint template    | Employees (Drivers)| Statewide driver fleet                               | Internal app / Owner: IT & Fleet Ops | Encrypted on company‑managed smartphones; no central storage of raw images | Biometric Policy §3; Mobile Device Policy; Driver Handbook Addendum |
| 5  | Pilot SmartCam Analytics (Test Program)    | Safety analytics (near‑miss detection, fatigue indicators) | Facial and posture analytics (pseudonymous templates) | Employees (Drivers, Warehouse staff in pilot) | Pilot at Aurora DC and select trucks | Vendor: SafeVision / Owner: Safety & Risk | SafeVision cloud (US‑only); aggregated metrics in internal BI warehouse | Biometric Policy §2–5; Safety Analytics SOP; DPIA – SmartCam Pilot |

### Field Guidance (for reuse)

- **System Name:** Product or internal system name (e.g., “KronoTime Biometric Time Clocks”).  
- **Purpose / Function:** Time and attendance, secure access control, visitor management, driver authentication, safety analytics, etc.  
- **Biometric Type:** Fingerprint, palm/hand geometry, facial template, iris, voiceprint, other biometric identifier.  
- **Population:** Employees, contractors, visitors, customers, patients, members, etc.  
- **Locations / Sites:** Offices, warehouses, stores, clinics, branches, data centers (city/state or site codes).  
- **Vendor / Owner:** Third‑party provider name and internal system owner (e.g., HR, Security, IT, Facilities).  
- **Storage Location:** On‑device only, on‑prem server, cloud provider (region), hybrid, etc.  
- **Linked Policies / SOPs:** References to the Biometric Policy, retention schedule, incident response playbook, and any local SOPs.

## 3. Biometric Data Flow Map (Text Summary – Example)

Below are example flows for the systems listed above.

#### System ID: 1 – KronoTime Biometric Time Clocks

- **Capture:** Employees place a finger on the KronoTime device at clock‑in and clock‑out stations located at warehouse entrances.  
- **Transmission:** The device converts the fingerprint to a biometric template on‑device, then sends the template and time event over an encrypted VPN tunnel to KronoTech’s cloud service.  
- **Storage:** Biometric templates and time records are stored in KronoTech’s US‑based cloud (Oregon region) with encryption at rest; limited on‑device caches are auto‑cleared every 24 hours.  
- **Access:** Only HR timekeeping admins and designated payroll specialists can access time records; they cannot view raw fingerprints, only templates and time logs.  
- **Sharing:** Time data (not biometric templates) is exported nightly to the payroll system; KronoTech has no right to sell or reuse biometric data beyond the contract.  
- **Deletion:** Biometric templates are deleted within 30 days after employment ends, in line with the biometric retention schedule; periodic deletion reports are generated quarterly.

#### System ID: 2 – SecureGate Warehouse Access Control

- **Capture:** Employees and contractors enroll hand geometry at the Denver HQ security office; enrollment captures a numerical template, not a raw hand image.  
- **Transmission:** Enrollment and access events are transmitted over a segmented internal network to the on‑prem SecureGate server with TLS encryption.  
- **Storage:** Templates and access logs are stored on the SecureGate server at Denver HQ with encrypted backups to a Colorado data center.  
- **Access:** Physical Security and IT admins can manage templates and access logs; managers may receive door‑access reports without seeing biometric templates.  
- **Sharing:** No external sharing of biometric templates; access reports may be shared internally with HR and Compliance for investigations.  
- **Deletion:** Templates are deleted within 7 days after badge deactivation or contract termination; access logs are retained for 2 years for security investigations, then purged.

#### System ID: 3 – VisitorCheck Lobby Kiosk

- **Capture:** Visitors and truck drivers take a photo at the lobby kiosk as part of check‑in; the system creates a facial template for visit verification.  
- **Transmission:** Data is sent via encrypted HTTPS to VisitorCheck’s cloud platform.  
- **Storage:** Facial templates and visit logs are stored in VisitorCheck’s US‑only environment with encryption at rest.  
- **Access:** Facilities and Security teams can see visit logs and check‑in photos; they cannot export biometric templates.  
- **Sharing:** Visitor logs may be shared with Security or Law Enforcement upon valid legal request; VisitorCheck is contractually barred from selling or re‑using biometric data.  
- **Deletion:** Biometric templates are deleted 30 days after the last visit; visit logs (non‑biometric) are retained for one year for security and audit purposes.

#### System ID: 4 – FleetID Mobile App

- **Capture:** Drivers authenticate by using fingerprint unlock on company‑managed smartphones before accessing the dispatch app; the app itself never receives raw fingerprint data.  
- **Transmission:** Biometric processing occurs entirely within the device’s secure enclave; the app only receives a yes/no authentication result.  
- **Storage:** No biometric templates are stored by the FleetID app or company servers; device‑level biometrics are governed by the mobile OS.  
- **Access:** Neither IT nor Fleet Operations can access biometric data; they can only manage app access and device enrollment.  
- **Sharing:** No sharing of biometric identifiers outside the device.  
- **Deletion:** When the device is wiped or the driver leaves the company, device enrollment is removed according to the Mobile Device Policy.

#### System ID: 5 – Pilot SmartCam Analytics (Test Program)

- **Capture:** Smart cameras capture video in loading docks and on pilot trucks; the vendor’s edge device converts faces and postures into pseudonymous analytics signals.  
- **Transmission:** Derived analytics (not full video) is sent via encrypted channel to the SafeVision cloud; raw video is stored for up to 14 days for safety investigations.  
- **Storage:** Analytics and short‑term video are stored in SafeVision’s US cloud; aggregated safety metrics are replicated into the internal BI warehouse.  
- **Access:** Safety & Risk teams view aggregated dashboards; only a limited Safety group can access raw footage for incident review.  
- **Sharing:** No external sharing of biometric analytics; incident footage may be shared internally with HR and Legal during investigations.  
- **Deletion:** Analytics tied to identifiable individuals are retained for up to 1 year; raw footage is auto‑deleted after 14 days except where legal holds apply.

## 4. Ownership & Review

- **Inventory Owner:** Privacy & Compliance in partnership with HR, Security, IT, and Facilities.  
- **Last Updated:** 2026‑01‑15 (Example).  
- **Review Frequency:** At least annually, and whenever a new biometric system is added, modified, or retired.

