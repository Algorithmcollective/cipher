# Colorado Biometric Vendor & Prohibited Uses Controls – Example  
**File:** CO_5_Biometric_Vendor_and_Use_Controls_examplemd.md  

**Company:** Front Range Logistics  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** 2026-02-01  
**Owner:** Privacy & Compliance  

> **Purpose:** Document how Front Range Logistics manages biometric vendors and prevents prohibited or high‑risk uses of biometric identifiers in Colorado.

---

## 1. Biometric Vendor Register

| ID | Vendor Name    | Service / Product (Biometric Use)                     | Systems Covered (IDs) | Biometric Types Processed             | Data Hosting Location(s)                    | Contract Owner (Function) | Contract Expiry | Data Processing Agreement / Addendum Ref                          |
|----|----------------|-------------------------------------------------------|------------------------|---------------------------------------|---------------------------------------------|----------------------------|----------------|--------------------------------------------------------------------|
| 1  | KronoTech      | Biometric time clocks for employee time & attendance  | 1                      | Fingerprint templates                 | US‑based cloud (Oregon region)             | HR / Payroll               | 2028-12-31     | `\\legal\\vendors\\KronoTech\\KronoTech_Biometric_DPA_2025.pdf`    |
| 2  | GateSecure     | Biometric access control for warehouses & cage areas  | 2                      | Hand geometry templates               | On‑prem server (Denver HQ), CO data center | Physical Security / IT     | 2027-06-30     | `\\legal\\vendors\\GateSecure\\GateSecure_CO_Amendment_2024.pdf`   |
| 3  | VisitorCheck   | Lobby kiosk with facial analytics for visitor badges  | 3                      | Facial templates (short‑term)         | US‑only cloud (vendor‑managed)             | Facilities                 | 2026-09-30     | `\\legal\\vendors\\VisitorCheck\\VisitorCheck_DPA_2023_signed.pdf` |
| 4  | SafeVision     | SmartCam safety analytics (pilot – docks & trucks)    | 5                      | Facial & posture analytics (derived)  | US cloud (safety analytics platform)       | Safety & Risk              | 2027-01-15     | `\\legal\\vendors\\SafeVision\\SafeVision_Pilot_DPA_2025.pdf`      |

---

## 2. Vendor Due Diligence Checklist (Biometric‑Specific) – Examples

### 2.1 KronoTech – Biometric Time Clocks (Vendor ID 1)

- **Lawful Purpose and Scope**  
  - ☑ Services limited to time & attendance for employees using fingerprint templates.  
  - ☑ Contract and DPA state KronoTech will not use templates for model training or unrelated analytics.  
  - ☑ Vendor privacy notice reviewed; no conflicting claims identified.

- **Security Controls**  
  - ☑ TLS enforced for device‑to‑cloud connections.  
  - ☑ Templates encrypted at rest with AES‑256 in KronoTech’s US data centers.  
  - ☑ Role‑based access for KronoTech support engineers with MFA; access logs available.  
  - ☑ Documented incident response and breach notification procedures reviewed; SOC 2 Type II report on file.

- **Data Location and Sub‑Processors**  
  - ☑ Data hosted in Oregon region data centers (US only).  
  - ☑ Sub‑processors listed in vendor documentation; all US‑based with equivalent protections.

- **Retention and Deletion**  
  - ☑ Configured to delete templates within 30 days of user unenrollment.  
  - ☑ Vendor supports deletion on demand and provides deletion audit logs upon request.

- **Rights Support and Cooperation**  
  - ☑ Vendor able to locate and delete templates for specific individuals.  
  - ☑ Vendor committed to notify Front Range of any security incident affecting biometric data without undue delay.

### 2.2 SafeVision – SmartCam Safety Analytics (Vendor ID 4)

- **Lawful Purpose and Scope**  
  - ☑ Contract limits use to workplace safety analytics for Front Range; prohibits sale or reuse.  
  - ☑ Any future use of anonymized data for vendor R&D requires prior written consent.

- **Security Controls**  
  - ☑ All analytics and video transferred via TLS and stored encrypted at rest.  
  - ☑ Admin access restricted to named SafeVision roles with MFA; logs reviewed quarterly.

- **Retention and Deletion**  
  - ☑ Front Range‑specific retention: raw video 14 days; event‑level analytics 12 months.  
  - ☑ SafeVision deletion process documented; quarterly deletion attestations provided.

---

## 3. Biometric Contract Clauses – Control Checklist (Sample Outcome)

**Vendor:** KronoTech – Biometric Time Clocks  

- ☑ Purpose Limitation – Contract specifies processing solely for employee timekeeping and related reporting.  
- ☑ No Sale / No Independent Use – Explicit ban on sale, lease, or transfer of biometric identifiers; training data from Front Range is prohibited.  
- ☑ Security Obligations – Contract requires encryption, access controls, and regular security testing.  
- ☑ Incident Notification – Vendor must notify Front Range within 48 hours of confirmed incidents involving biometric data.  
- ☑ Sub‑Processor Controls – KronoTech must maintain an up‑to‑date list of sub‑processors and impose equivalent protections.  
- ☑ Data Subject Rights Support – Vendor will assist with access and deletion requests within agreed timelines.  
- ☑ Return / Deletion at Termination – Vendor must delete all biometric data within 30 days of contract termination and provide written certification.

- **Contract Reviewed By:** Senior Counsel – Commercial Contracts  
- **Review Date:** 2025-11-10  
- **Key Notes / Gaps:**  
  - Added side letter clarifying no use of Front Range biometric data for analytics across other customers.  
  - Confirmed no offshore storage or access for biometric templates.

---

## 4. Prohibited and Restricted Uses Register – Front Range Logistics

| ID | Use Description                                                                                  | Category (Prohibited / Restricted) | Rationale (Legal / Risk)                                                                                      | Approved Exceptions / Conditions                                              | Owner / Approver          |
|----|--------------------------------------------------------------------------------------------------|------------------------------------|----------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------|---------------------------|
| 1  | Selling, leasing, or trading employee or visitor biometric identifiers or biometric templates.   | Prohibited                         | Conflicts with Colorado biometric requirements and Company commitments; high privacy and reputational risk.   | None.                                                                        | Privacy & Compliance      |
| 2  | Using biometric data for marketing, advertising, or customer profiling.                          | Prohibited                         | Outside disclosed purposes (timekeeping, access, safety); high risk of unfair or deceptive practices.         | None.                                                                        | Privacy & Compliance      |
| 3  | Using biometric analytics as the **sole** basis for discipline, termination, or promotion.       | Restricted                         | Risk of inaccuracy or bias; requires human review and corroborating evidence to avoid unfair treatment.       | Allowed only as one input among others, with documented human review.        | HR / Legal                |
| 4  | Continuous biometric‑based monitoring in restrooms, locker rooms, or break rooms.                | Prohibited                         | Material intrusion into privacy; unnecessary for safety or access purposes; high employee‑relations risk.     | None.                                                                        | Safety & Facilities       |
| 5  | Expanding facial analytics to general behavior scoring (e.g., productivity ranking) without DPIA.| Restricted                         | High surveillance and fairness risk; may conflict with worker protections and privacy commitments.            | Only after formal DPIA and executive approval; must be optional where feasible.| Privacy & Compliance; HR  |

---

## 5. Review and Governance

- **Vendor Register Owner:** Privacy & Compliance (with HR, IT, Facilities, Safety input).  
- **Prohibited Uses Register Owner:** Privacy & Compliance, in coordination with HR and Legal.  
- **Review Frequency:** Annually in Q4, and upon onboarding/offboarding any biometric vendor or introducing a new biometric use case.

**Most Recent Review**

- **Review Date:** 2025-12-05  
- **Reviewed By:** Privacy & Compliance Manager; Senior Counsel – Employment; Head of IT Security  
- **Key Changes:**  
  - Added SafeVision SmartCam pilot as Vendor ID 4 with custom retention limits.  
  - Updated prohibited use entry to clarify that biometric data cannot be combined with productivity metrics for ranking without further approval.  
  - Confirmed all biometric vendor contracts include no‑sale and deletion‑at‑termination clauses.
