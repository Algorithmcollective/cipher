# Deliverable 2: Biometric Data Governance Policy (HB 24‑1130 / CPA)  
**File:** CO_2_Biometric_Data_Governance_Policy_EXAMPLE_FrontRangeLogistics.md  

## 1. Purpose and Scope

This **Biometric Data Governance Policy** establishes how Front Range Logistics (“the Company”) collects, uses, stores, shares, and deletes biometric identifiers and biometric data for individuals in Colorado. It is designed to comply with Colorado’s biometric and privacy requirements, including amendments to the Colorado Privacy Act (HB 24‑1130).

This policy applies to:

- All biometric identifiers and biometric data processed in connection with Company operations in Colorado.  
- All employees, contractors, visitors, drivers, and other individuals whose biometric data is collected by or on behalf of the Company.  
- All systems, devices, and vendors that capture, store, or process biometric identifiers or biometric data for the Company.

## 2. Definitions

For purposes of this policy:

- **Biometric Identifier** means a biologically unique characteristic that can be used to identify a person, such as a fingerprint, palm/hand geometry, iris or retina scan, face template, or voiceprint, as defined under Colorado law.  
- **Biometric Data** means any data generated from the measurement or technological processing of a biometric identifier, used to identify an individual or linked to an identifiable individual.  
- **Controller** means the Company when it determines the purposes and means of processing biometric identifiers or biometric data.  
- **Processor/Vendor** means any third party that processes biometric data on behalf of the Company under a contract.

## 3. Biometric Use Cases and Purposes

The Company limits biometric data processing to clearly defined, documented purposes. For Front Range Logistics, current approved use cases include:

- **Time and Attendance:** Fingerprint templates used with KronoTime biometric time clocks to record hourly employees’ work start and end times.  
- **Physical Access Control:** Hand geometry templates used by SecureGate systems to control access to secure warehouse and cage areas.  
- **Visitor Management:** Facial templates used by VisitorCheck lobby kiosks to verify visitor and driver identity and issue badges.  
- **Driver Authentication:** Device‑level fingerprint authentication on company‑managed smartphones used to access the FleetID dispatch application (the app itself does not receive or store biometric templates).  
- **Safety Analytics (Pilot):** Pseudonymous facial and posture analytics produced by SmartCam devices to support safety and near‑miss analysis under a controlled pilot.

Any new use of biometric identifiers or biometric data must be reviewed and approved through the Company’s privacy and security review process before implementation.

## 4. Notice and Consent

The Company provides clear, conspicuous notice and obtains consent before collecting biometric identifiers or biometric data, except where a recognized legal exception applies.

At minimum:

- **Employee and Contractor Notice:**  
  - Employees and contractors receive a written or electronic notice describing what biometric data is collected, for what purposes, how long it will be retained, how it will be stored and protected, and how it may be shared.  
  - Notices are linked from onboarding materials, HR portals, and local workplace postings as appropriate.

- **Employee and Contractor Consent:**  
  - The Company obtains a signed or electronically recorded consent acknowledging the notice, authorizing the collection and use of biometric data for the specified purposes, and describing how consent can be withdrawn.  
  - Where Colorado law requires that consent not be conditioned on employment for certain purposes, the Company will offer alternatives or ensure that biometrics are truly optional.

- **Visitor and Driver Notice:**  
  - For lobby kiosks and similar systems, the Company posts signage and/or on‑screen notices informing individuals that biometric data (e.g., facial templates) may be collected for identity verification, security, or visitor management.  
  - Where required, the Company will obtain express consent (e.g., checkbox or signature) before collection.

Consent records are stored in accordance with Company recordkeeping requirements and may be linked to HR files or visitor management systems.

## 5. Data Minimization and Purpose Limitation

The Company collects and processes only the minimum biometric data necessary to achieve the approved purposes, and does not:

- Use biometric data for purposes that are materially different, unrelated, or incompatible with the original purposes without providing additional notice and, where required, obtaining new consent.  
- Collect or retain raw biometric images where templates or derived data are sufficient (e.g., storing templates instead of full fingerprint images).  
- Use biometric data for generalized monitoring or tracking unrelated to the approved use cases (for example, continuous productivity surveillance without explicit approval through the governance process).

## 6. Retention and Deletion

The Company retains biometric identifiers and biometric data only for as long as reasonably necessary to fulfill the documented purposes or as required by law, whichever is shorter.

### 6.1 Standard Retention Rules (Example)

- **Employee Time and Attendance Templates (KronoTime):**  
  - Retained while the individual is employed and actively using the system.  
  - Deleted within 30 days after employment ends or the individual is no longer enrolled in the biometric timekeeping system, unless legal obligations require longer retention of related time records.

- **Access Control Templates (SecureGate):**  
  - Retained while the badge is active.  
  - Deleted within 7 days of badge deactivation or contract termination.

- **Visitor Facial Templates (VisitorCheck):**  
  - Retained for up to 30 days after the last visit unless a longer retention is needed for security investigations.  
  - Visitor logs (non‑biometric) may be retained for up to one year.

- **Safety Analytics (SmartCam Pilot):**  
  - Identifiable analytics retained for up to one year for safety investigations and trend analysis.  
  - Raw video footage retained for no more than 14 days, unless placed on legal hold.

### 6.2 Deletion Procedures

- Biometric templates and associated data are deleted or irreversibly de‑identified from active systems and backups on or before the applicable retention deadline.  
- Deletions follow documented technical procedures (e.g., vendor APIs, database scripts, storage lifecycle rules) and are logged in a Biometric Deletion Log, including date, system, and action taken.  
- If an individual submits a valid deletion request, the Company will delete biometric data as required by Colorado law and document the response.

## 7. Security and Access Controls

The Company implements appropriate technical and organizational measures to safeguard biometric identifiers and biometric data, including:

- Encryption of biometric templates in transit and at rest where feasible.  
- Network segmentation and secure communication channels for biometric devices and servers.  
- Role‑based access controls limiting who can administer biometric systems or access logs.  
- Strong authentication for administrative access to biometric systems.  
- Vendor security requirements, including incident notification, encryption, and access controls.

Biometric data is never stored or transmitted in plain text where encryption is reasonably feasible.

## 8. Prohibited and Restricted Uses

The Company will not:

- Sell, lease, trade, or otherwise profit from biometric identifiers or biometric data.  
- Disclose biometric data to third parties for their own purposes without appropriate legal basis, contractual protections, and required consents.  
- Use biometric data for automated profiling or decisions that produce legal or similarly significant effects on individuals without appropriate legal review and, if applicable, alignment with AI‑related laws.  
- Use biometric data to retaliate against individuals who exercise their privacy rights or who decline optional biometric programs where law requires those programs to be optional.

Any proposed new use that may be high‑risk or sensitive must go through a privacy and security impact assessment before implementation.

## 9. Data Subject Rights

Individuals whose biometric data is processed by the Company may, subject to applicable law:

- Request confirmation of whether their biometric data is being processed.  
- Request access to information about the categories of biometric data collected, purposes of processing, and relevant retention periods.  
- Request correction of inaccurate personal data associated with their biometric records where appropriate.  
- Request deletion of biometric data, subject to legal and operational constraints.  
- Withdraw consent to biometric processing where processing is based on consent.

The Company provides contact information and response timelines (for example, via a privacy email address or portal) in its privacy notices and employee communications.

## 10. Vendor and Processor Management

The Company will only engage vendors to process biometric data under written contracts that:

- Specify permitted purposes and prohibit any sale, lease, or unrelated use of biometric data.  
- Require appropriate security controls, incident response, and cooperation with the Company’s investigations and notifications.  
- Require the processor to support the Company in responding to access and deletion requests.  
- Require timely and secure deletion or return of biometric data upon contract termination or at the Company’s request.

Vendor risk assessments and due diligence are documented and reviewed periodically.

## 11. Training and Awareness

The Company provides role‑appropriate training for:

- HR, Facilities, Security, and Operations staff who manage or use biometric systems.  
- IT and Security teams responsible for implementing and maintaining biometric technologies.  

Training covers:

- Basic concepts of biometric identifiers and data.  
- Colorado legal requirements and Company policy.  
- Approved use cases and prohibited practices.  
- Incident and complaint reporting channels.

Training is refreshed at least annually and when there are material changes in law, policy, or technology.

## 12. Governance, Oversight, and Review

- **Policy Owner:** Privacy & Compliance, with input from HR, Security, IT, and Facilities.  
- **Approval:** This policy is approved by \[Executive Sponsor / Committee\].  
- **Effective Date:** \[Date\].  
- **Review Cycle:** At least annually and whenever there are material changes in applicable law, Company use of biomet
