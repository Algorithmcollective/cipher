# Colorado Biometric Notice & Consent – Employee Time Clocks and Access Control  
**File:** CO_4_Biometric_Notice_and_Consent_examplemd.md  

**Company:** Front Range Logistics  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** 2026-02-01  
**Owner:** Privacy & Compliance  

> **Purpose:** Provide concrete notice and consent language for Front Range Logistics’ biometric time clocks and access control systems in Colorado, including required disclosures about purpose, retention, sharing, and rights.

---

## 1. Biometric Privacy Notice – Front Range Logistics

### 1.1 Short Form Summary (Poster / Intranet Banner)

> **Biometric Notice – Front Range Logistics**  
>  
> Front Range Logistics collects and uses certain biometric information (such as fingerprint and hand geometry templates) to operate biometric time clocks and secure access systems at our Colorado facilities. We use this information only for timekeeping, security, and safety purposes, and we retain it only as long as needed for those purposes before securely deleting it under our Biometric Data Governance Policy. For more information, including how long we keep biometric data and your rights, please review our full Biometric Privacy Notice or contact privacy@frontrangelogistics.com.

---

### 1.2 Full Biometric Privacy Notice – Employees and Contractors

**1. Introduction**

This Biometric Privacy Notice explains how Front Range Logistics (“Front Range,” “we,” “us,” or “our”) collects, uses, stores, shares, and deletes biometric identifiers and biometric data of employees and contractors who work at our Colorado locations. It supplements our Employee Privacy Notice and applies when you use systems that collect or process your biometric information.

**2. What Biometric Information We Collect**

Depending on your role and job duties, we may collect and process:

- Fingerprint templates used with biometric time clocks.  
- Hand geometry templates used with secure access control devices at warehouse entrances and secure cage areas.

We do not store raw fingerprint or hand images; instead, our systems convert scans into numerical templates that are used to verify identity.

**3. How We Use Your Biometric Information**

We use your biometric information only for the following purposes:

- Recording your work start and end times and breaks for timekeeping and payroll.  
- Verifying your identity to control access to Front Range facilities and secure areas.  
- Supporting security and safety investigations related to facility access.

We will not use your biometric information for unrelated purposes, such as general productivity monitoring or continuous tracking, without providing additional notice and, where required, obtaining your consent.

**4. How Long We Keep Your Biometric Information**

We retain biometric identifiers and biometric data only for as long as reasonably necessary to fulfill the purposes above or as required by law, then securely delete or de‑identify it.

In particular:

- Fingerprint templates used for timekeeping are deleted within 30 days after your employment or engagement ends, or after you are unenrolled from biometric time clocks.  
- Hand geometry templates used for access control are deleted within 7 days after your badge is deactivated or your engagement ends.  
- Access logs that do not contain biometric templates may be kept longer for security and audit purposes, in line with our retention schedule.

**5. How We Share Your Biometric Information**

We may share biometric information with:

- Service providers that operate biometric time clocks and access control systems on our behalf, under contracts that restrict their use of your biometric data and require them to protect it.  
- Government authorities, law enforcement, or other third parties when required by law, court order, or to protect our legal rights or safety.

We do not sell, lease, or trade biometric identifiers, and we do not permit our vendors to sell or use your biometric identifiers for their own independent purposes.

**6. Security Measures**

We implement technical and organizational measures to protect biometric information, including:

- Encryption of biometric templates in transit and at rest where feasible.  
- Restricted access to systems that store biometric data, limited to authorized HR, Security, IT, and Compliance personnel.  
- Network segmentation and secure communication between devices and back‑end systems.  
- Monitoring and logging of administrative access to biometric systems.

**7. Your Rights and Questions**

Subject to applicable law, you may:

- Request information about our collection and use of your biometric information.  
- Request deletion of your biometric templates, subject to legal and operational requirements.  
- Ask questions or raise concerns about biometric systems or this Notice.

You can contact us at:

- **Email:** privacy@frontrangelogistics.com  
- **Mail:** Privacy & Compliance, Front Range Logistics, 1200 Warehouse Way, Denver, CO 80216  

---

## 2. Employee / Contractor Biometric Consent Form – Time Clocks & Access

**Title:** Employee / Contractor Biometric Information Notice & Consent – Front Range Logistics

### 2.1 Notice (to be presented with the consent)

Front Range Logistics uses biometric systems at certain Colorado facilities to:

- Record your work time using fingerprint‑based time clocks.  
- Control access to warehouses, docks, and secure cage areas using hand geometry readers.  

These systems collect and process biometric information about you in the form of fingerprint and/or hand geometry templates. We use this information only to verify your identity for timekeeping and facility access, and for related security and safety investigations.

We retain:

- Fingerprint templates for no longer than 30 days after your employment or engagement ends, or after you are unenrolled from biometric time clocks.  
- Hand geometry templates for no longer than 7 days after your badge is deactivated or your engagement ends.

We share biometric information only with service providers that operate these systems on our behalf, and with government authorities when required by law. We do not sell, lease, or trade your biometric identifiers.

More details are provided in the Front Range Biometric Privacy Notice and Biometric Data Governance Policy, which are available on the HR portal and from your manager or HR representative.

### 2.2 Consent Statement

By signing or electronically confirming below, you acknowledge that:

1. You have received and read the Biometric Information Notice for employees and contractors.  
2. You understand that Front Range Logistics will collect and use your biometric information (fingerprint and/or hand geometry templates) to operate its timekeeping and access control systems and for related security and safety purposes.  
3. You understand how long your biometric information will be retained and how it will be deleted.  
4. You understand that your biometric information may be shared with service providers that operate biometric systems on Front Range’s behalf under contractual protections, and with government authorities when required by law.  
5. You know how to contact Front Range with questions or requests related to your biometric information.

**Employee / Contractor Acknowledgment**

- Name: ___________________________  
- Position / Department: ___________________________  
- Work Location: ___________________________  

☐ I consent to the collection and use of my biometric information by Front Range Logistics as described in this Notice.

Signature: ___________________________    Date: _____________________  

_(For electronic systems, this signature line may be replaced with an electronic acknowledgment checkbox or e‑signature mechanism.)_

---

## 3. Visitor Biometric Notice – Lobby Kiosk (Optional Example)

**Lobby Signage Text:**

> **Biometric Information Notice – Front Desk Check‑In**  
>  
> This facility uses an electronic check‑in system that may capture and process your image to verify your identity and issue a visitor badge. The system generates a facial template from your image and stores it for a short period to support security and visitor management. We do not sell or trade your biometric information. For questions, please contact privacy@frontrangelogistics.com.

**On‑Screen Text at Kiosk:**

> By proceeding, you acknowledge that Front Range Logistics may capture and use your image to verify your identity and manage your visit in accordance with our Biometric Privacy Notice. If you have questions, please see the front desk or contact privacy@frontrangelogistics.com.
