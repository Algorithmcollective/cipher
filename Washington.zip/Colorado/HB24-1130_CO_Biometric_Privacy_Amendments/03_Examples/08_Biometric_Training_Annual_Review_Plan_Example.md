# Colorado Biometric Training & Annual Review Checklist – Example  
**File:** CO_8_Biometric_Training_and_Annual_Review_examplemd.md  

**Company:** Front Range Logistics  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** 2026-02-01  
**Owner:** Privacy & Compliance  

> **Purpose:** Show how Front Range Logistics trains key teams on biometric requirements and runs an annual review of its biometric program in Colorado.

---

## 1. Training Scope and Audience

| Audience Group             | Example Roles / Functions                                      | Training Frequency           |
|----------------------------|----------------------------------------------------------------|------------------------------|
| HR / People Operations     | HRBPs, payroll, recruiters, onboarding coordinators           | On hire + annually          |
| IT / Security              | Identity & access admins, infrastructure, security operations | On role assignment + annually|
| Facilities / Physical Sec. | Facilities managers, guards, SecureGate admins                | On role assignment + annually|
| Safety / Risk              | Safety managers, SmartCam program owners                      | On role assignment + annually|
| Site Managers & Supervisors| Supervisors at biometric‑equipped warehouses and docks        | On role assignment + annually|

---

## 2. Training Content Checklist

Front Range’s biometric training modules cover:

### 2.1 Legal and Policy Basics

- Overview of Colorado biometric requirements and how they amend the Colorado Privacy Act, including definitions of “biometric identifiers” and “biometric data,” notice/consent expectations, and retention rules.  
- Front Range Biometric Data Governance Policy and where to find it on the intranet.

### 2.2 Systems and Use Cases

- KronoTime fingerprint time clocks, SecureGate hand geometry access control, VisitorCheck facial templates for visitors, and SmartCam safety analytics pilots.  
- Which sites use which systems (Denver DC, Aurora DC, Colorado Springs Cross‑Dock).

### 2.3 Notice, Consent, and Alternatives

- How employee biometric notices and consents are presented during onboarding and at worksites.  
- Explanation that SmartCam is used for safety analytics, not performance scoring, and how employees can raise questions or concerns.

### 2.4 Security, Retention, and Deletion

- Basic expectations: do not share admin credentials, report lost badges or suspicious system behavior promptly.  
- Summary of retention periods (e.g., 30 days for fingerprint templates after termination; 7 days after badge deactivation for hand geometry templates; 14 days for SmartCam raw video).

### 2.5 Incident & Complaint Handling

- How supervisors and staff should escalate suspected biometric incidents or complaints to Privacy & Compliance or IT Security.  
- Example scenarios (e.g., someone claiming they never consented; suspected misuse of SmartCam data).

---

## 3. Training Session Log (Sample Entries)

| Session ID | Date       | Audience Group             | Topic / Modules Covered                                               | Trainer / Presenter              | Format (In‑Person / Virtual / LMS) | # Attendees | Attendance Record Location                                  |
|-----------|------------|----------------------------|-----------------------------------------------------------------------|----------------------------------|------------------------------------|------------|-------------------------------------------------------------|
| BT-2025-01| 2025-03-12 | HR / People Operations     | CO Biometric Overview, Notices & Consents, Retention Summary         | Director, Privacy & Compliance   | Virtual (Teams)                    | 18         | `\\training\\attendance\\BT-2025-01_HR_Biometrics.xlsx`     |
| BT-2025-02| 2025-04-05 | IT / Security              | Biometric Systems Architecture, Security Controls, Incident Escalation| Head of IT Security              | In‑Person                          | 12         | `\\training\\attendance\\BT-2025-02_IT_Security.xlsx`       |
| BT-2025-03| 2025-05-10 | Facilities / Physical Sec. | SecureGate & VisitorCheck Usage, Access Deactivation & Deletions     | Facilities Manager               | In‑Person                          | 10         | `\\training\\attendance\\BT-2025-03_Facilities.xlsx`        |
| BT-2025-04| 2025-06-18 | Site Managers & Supervisors| SmartCam Safety Analytics, Employee Messaging, Complaint Handling    | Director, Safety & Risk          | Virtual (Teams)                    | 22         | `\\training\\attendance\\BT-2025-04_Site_Managers.xlsx`     |

---

## 4. Annual Biometric Program Review – Checklist (Front Range 2025 Review)

### 4.1 Systems and Inventory

- Reviewed and updated Biometric Systems Inventory & Data Map; SmartCam pilot (System ID 5) added for Aurora and Denver DC.  
- Confirmed no unapproved biometric systems in use; one proposed pilot for facial recognition at turnstiles was deferred pending DPIA.

### 4.2 Policies, Notices, and Consents

- Biometric Data Governance Policy updated to include SmartCam and revised visitor retention timelines.  
- Employee biometric notice refreshed and re‑uploaded to HR onboarding portal; new posters placed at biometric time clock locations.  
- VisitorCheck signage text updated at Denver DC front lobby to clarify 30‑day retention.

### 4.3 Vendors and Contracts

- Re‑reviewed KronoTech, GateSecure, VisitorCheck, and SafeVision contracts:  
  - All confirmed to include explicit bans on sale/lease of biometric identifiers and deletion‑on‑termination clauses.  
  - SafeVision contract amended to tighten incident notification obligations and limit any vendor R&D use to de‑identified data with Front Range approval.

### 4.4 Retention, Deletion, and Requests

- Spot‑checked KronoTime and SecureGate deletion logs; no overdue biometric records found.  
- VisitorCheck retention setting adjusted from 60 days to 30 days and verified via vendor report.  
- Reviewed 3 deletion/access requests from the year; all responded within 30 days and properly logged.

### 4.5 Incidents and Complaints

- Reviewed three biometric‑related incidents and four complaints:  
  - One SmartCam vendor support account incident (see incident playbook example).  
  - Complaints primarily about awareness of SmartCam and discomfort with cameras; addressed through updated communication and Q&A sessions.  
- Confirmed each significant incident had a post‑incident review with documented actions.

---

## 5. Annual Review Summary Record (2025)

| Field                                | Value                                                                                      |
|--------------------------------------|--------------------------------------------------------------------------------------------|
| Review Period                        | 2025-01-01 – 2025-12-31                                                                   |
| Review Date                          | 2026-01-15                                                                                 |
| Lead Reviewer                        | Director, Privacy & Compliance                                                             |
| Participants                         | CISO; HR Director; Director of Safety & Risk; Facilities Manager; Senior Counsel – Privacy|
| Key Issues Identified                | Need for clearer SmartCam communication; earlier involvement of Privacy in new pilots; ensure visitor retention reduced to 30 days. |
| Remediation / Improvement Actions    | Update notices/posters; refine DPIA process for new biometric pilots; adjust VisitorCheck retention; add SmartCam module to supervisor training. |
| Target Completion Dates for Actions  | Most actions by 2026-03-31; VisitorCheck retention change completed 2026-01-31.           |
| Next Scheduled Review Date           | 2027-01-15                                                                                |

---

## 6. Continuous Improvement Actions Register (Sample)

| Action ID | Source (Incident / Audit / Law Change / Feedback) | Description of Action                                                   | Owner                    | Target Date | Status (Open / In Progress / Closed) | Notes                                                  |
|-----------|----------------------------------------------------|-------------------------------------------------------------------------|--------------------------|------------|--------------------------------------|--------------------------------------------------------|
| BI-IMP-01 | Incident BIO-INC-2026-003                          | Tighten SafeVision admin access controls and add IP allow‑listing      | Head of IT Security      | 2026-02-28 | In Progress                           | Coordinating implementation with vendor.               |
| BI-IMP-02 | Employee Feedback (SmartCam Q&A)                   | Update SmartCam FAQ and add clarifying examples to training materials  | Director, Safety & Risk  | 2026-03-15 | Open                                 | To be included in Q2 2026 supervisor training refresh.|
| BI-IMP-03 | Annual Review 2025                                 | Confirm all Colorado sites display updated biometric posters            | Facilities Manager       | 2026-02-15 | Closed                               | Verified by photo evidence in Facilities checklist.    |
