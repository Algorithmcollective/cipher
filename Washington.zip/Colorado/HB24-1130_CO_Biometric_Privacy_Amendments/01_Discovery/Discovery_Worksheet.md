# Colorado Biometric Discovery Worksheet

---

## Biometric Systems Inventory

System Name:
Purpose:
Biometric Type:
Population:
Locations:
Vendor/Owner:
Storage Location:
Linked Policies:

Capture:
Transmission:
Access Roles:
Sharing:
Deletion Approach:

---

## Governance Policy

Approved Use Cases:
Policy Owner:
Consent Requirements:
Minimization Approach:
Prohibited Uses:
Individual Rights Handling:
Security Controls:
Review Cadence:

---

## Risk & Impact

Lawful Basis:
Necessity Justification:
Optional/Mandatory:
Collection Method:
Storage:
Access Roles:

Privacy Risks:
Security Risks:
Discrimination Risks:
Surveillance Risks:
Mitigations:
Residual Risk:
Approvals:

---

## Notice & Consent

Notice Channels:
Consent Method:
Audiences:
Retention Disclosure:
Sharing Disclosure:
Consent Storage:
Alternatives Offered:

---

## Vendor Controls

Vendors:
Services:
Hosting Locations:
Sub-Processors:
Security Certifications:
Deletion Support:
Contract Clauses:
Prohibited Uses Register:

---

## Retention & Requests

Retention Period:
Retention Trigger:
Deletion Method:
Deletion Frequency:
Evidence Location:
Request Channels:
Authentication Method:
Request Logging:

---

## Incident & Complaint

Incident Definition:
Intake Channels:
Severity Levels:
Investigation Roles:
Vendor Coordination:
Complaint Process:
Breach Triggers:

---

## Training & Annual Review

Training Audiences:
Frequency:
Topics:
Session Logs:
Annual Review Owner:
Metrics:
Improvement Actions:

---

## TBD / Follow-Ups

Item:
Owner:
Notes: