# Colorado Biometric Discovery Script (HB 24-1130)

Purpose: Gather information required to prepare Colorado biometric compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Biometric Systems Inventory & Data Map

Say:
“I need to identify every system that collects or uses biometric information.”

Ask for each system:

- System name
- Purpose (time clock, access control, ID verification, etc.)
- Biometric type (face, fingerprint, voice, iris, etc.)
- Population affected
- Locations/sites
- Vendor or internal owner
- Storage location
- Linked SOPs/policies

Then ask:

- How capture occurs
- How data moves
- Who can access
- Third-party sharing
- Deletion approach

---

## 🧾 Deliverable: Governance Policy

Ask:

- Approved biometric use cases
- Policy owner
- Consent requirements
- Data minimization approach
- Prohibited uses
- Individual rights handling
- Security controls
- Governance review cadence

---

## 🧾 Deliverable: Risk & Impact Assessment

Ask per system:

- Lawful basis
- Why biometrics are necessary
- Optional vs mandatory
- Collection methods
- Storage locations
- Access roles

Then risks:

- Privacy risks
- Security risks
- Discrimination risks
- Surveillance concerns
- Mitigations
- Residual risk
- Approvals

---

## 🧾 Deliverable: Notice & Consent

Ask:

- Notice channels
- Consent method
- Audiences (employees, visitors, customers)
- Retention disclosure
- Sharing disclosure
- Consent storage location
- Alternative options offered

---

## 🧾 Deliverable: Vendor & Use Controls

Ask:

- Vendor list
- Services provided
- Hosting locations
- Sub-processors
- Security certifications
- Deletion support
- Contract clauses
- Prohibited uses register

---

## 🧾 Deliverable: Retention, Deletion & Requests

Ask:

- Retention per system
- Trigger for retention clock
- Deletion method
- Deletion frequency
- Evidence/log location
- Rights request channels
- Authentication method
- Request logging system

---

## 🧾 Deliverable: Incident & Complaint Response

Ask:

- Incident definition
- Intake channels
- Severity levels
- Investigation roles
- Vendor incident coordination
- Complaint process
- Breach notification triggers

---

## 🧾 Deliverable: Training & Annual Review

Ask:

- Training audiences
- Training frequency
- Topics covered
- Session logging
- Annual review owner
- Metrics tracked
- Continuous improvement tracking

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Colorado biometric documentation.”