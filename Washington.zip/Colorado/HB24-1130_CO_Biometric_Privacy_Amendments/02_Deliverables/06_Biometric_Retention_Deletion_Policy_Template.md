# Colorado Biometric Retention, Deletion & Request Handling  
**File:** CO_6_Biometric_Retention_Deletion_and_Requests_md.md  

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}  

> **Purpose:** Define standardized retention rules, deletion workflows, and individual request‑handling steps for biometric identifiers and biometric data used in Colorado.

---

## 1. Biometric Retention Schedule

Document retention rules for each biometric system.

| ID | System Name                      | Biometric Type(s)              | Population (Employees / Visitors / Customers / Other) | Primary Purpose(s)                     | Standard Retention Period for Biometric Data | Trigger for Start of Retention Clock                    | Exceptions (e.g., legal holds)          |
|----|----------------------------------|--------------------------------|--------------------------------------------------------|----------------------------------------|----------------------------------------------|---------------------------------------------------------|----------------------------------------|
| 1  | {{SYSTEM_1_NAME}}                | {{SYSTEM_1_TYPES}}             | {{SYSTEM_1_POPULATION}}                               | {{SYSTEM_1_PURPOSES}}                  | {{SYSTEM_1_RETENTION}}                       | {{SYSTEM_1_TRIGGER}}                                  | {{SYSTEM_1_EXCEPTIONS}}               |
| 2  | {{SYSTEM_2_NAME}}                | {{SYSTEM_2_TYPES}}             | {{SYSTEM_2_POPULATION}}                               | {{SYSTEM_2_PURPOSES}}                  | {{SYSTEM_2_RETENTION}}                       | {{SYSTEM_2_TRIGGER}}                                  | {{SYSTEM_2_EXCEPTIONS}}               |

**Guidance:**  
- Retention must be limited to what is reasonably necessary for the stated purposes or as required by law.  
- Triggers might include last use of the system, termination date, contract end date, or last visit.  

---

## 2. Deletion & De‑Identification Procedures

Describe how biometric data is deleted or de‑identified in each system.

### 2.1 System‑Level Deletion Matrix

| System Name           | Data Elements Deleted (Templates, Logs, Backups) | Deletion Method (Config / API / Script) | Responsible Team / Role     | Deletion Frequency (Event‑Driven / Batch) | Evidence (Logs / Reports) Location         |
|-----------------------|--------------------------------------------------|------------------------------------------|-----------------------------|--------------------------------------------|--------------------------------------------|
| {{SYSTEM_1_NAME}}     | {{SYSTEM_1_ELEMENTS}}                            | {{SYSTEM_1_METHOD}}                      | {{SYSTEM_1_OWNER}}          | {{SYSTEM_1_FREQUENCY}}                     | {{SYSTEM_1_EVIDENCE_LOCATION}}             |
| {{SYSTEM_2_NAME}}     | {{SYSTEM_2_ELEMENTS}}                            | {{SYSTEM_2_METHOD}}                      | {{SYSTEM_2_OWNER}}          | {{SYSTEM_2_FREQUENCY}}                     | {{SYSTEM_2_EVIDENCE_LOCATION}}             |

### 2.2 Standard Deletion Workflow (Text)

1. **Identify records for deletion**  
   - Triggered by: end of employment/engagement, badge deactivation, last visit, account closure, or reaching maximum retention period.  
2. **Validate trigger and scope**  
   - Confirm the individual or group and system(s) in scope.  
3. **Execute deletion**  
   - Use documented method (system configuration, vendor portal, API, or script).  
4. **Verify completion**  
   - Review system logs or vendor confirmation reports to validate that biometric data has been removed or de‑identified.  
5. **Record in Biometric Deletion Log**  
   - Capture key details (see Section 3).

---

## 3. Biometric Deletion Log

Maintain a log of routine and ad‑hoc deletions for audit and compliance.

| Date        | System Name           | Individual(s) / Group | Deletion Trigger (Retention / Request / Other) | Data Elements Removed                        | Performed By (Role)  | Verification Method (Log / Vendor Confirm) | Notes                         |
|------------|-----------------------|------------------------|------------------------------------------------|----------------------------------------------|----------------------|--------------------------------------------|-------------------------------|
| {{DATE_1}} | {{SYSTEM_1_NAME}}     | {{SUBJECT_1}}         | {{TRIGGER_1}}                                  | {{DELETED_ELEMENTS_1}}                       | {{ROLE_1}}           | {{VERIFICATION_1}}                         | {{NOTES_1}}                   |

---

## 4. Individual Requests – Intake & Triage

Define how requests about biometric data are handled (employees, visitors, customers).

### 4.1 Intake Channels

- **Primary contact email:** {{PRIVACY_EMAIL}}  
- **Alternate channel(s):** {{PORTAL_URL_OR_PHONE}}  
- Requests may include: access, deletion, confirmation of processing, or questions about biometric systems.

### 4.2 Triage Steps

1. **Identify request type:** access, deletion, correction (if applicable), objection, or general inquiry.  
2. **Authenticate requester:** verify identity using standard identity‑verification procedures.  
3. **Check scope:** confirm whether the requester’s biometric data is in scope (which systems, time periods, and locations).  
4. **Log request:** open a case in the privacy/requests tracking system with a unique ID.

---

## 5. Individual Requests – Handling Steps

### 5.1 Access / Information Requests

- Locate biometric data and associated records (e.g., enrollment status, time frame, systems involved).  
- Provide a summary including:  
  - What biometric types are collected.  
  - Purposes and retention periods.  
  - High‑level description of where and how data is stored and secured.  
- Provide copies of relevant policy/notice text, not raw biometric templates.  
- Record response date and any limitations applied (e.g., security or legal constraints).

### 5.2 Deletion Requests

1. Confirm if deletion is permitted considering retention obligations and ongoing investigations or legal holds.  
2. If permitted:  
   - Execute system‑level deletion steps (Section 2).  
   - Request vendor deletion if the vendor stores biometric data.  
   - Record actions and confirmations in the Biometric Deletion Log and request case file.  
3. Inform the individual when deletion is completed or explain why full deletion is not possible (e.g., legal requirements).

### 5.3 Other Requests (Objection / Withdrawal of Consent)

- If processing is based on consent or is optional:  
  - Stop further collection where feasible.  
  - Remove individual from future use of biometric systems and offer alternatives (e.g., ID badges, PINs, manual processes).  
- Document system changes and any impact on access or timekeeping workflows.

---

## 6. Roles & Responsibilities

| Role / Function         | Responsibilities Related to Retention, Deletion & Requests                                             |
|-------------------------|--------------------------------------------------------------------------------------------------------|
| Privacy / Compliance    | Owns this procedure; reviews retention rules; oversees request handling; maintains deletion log.     |
| HR / People Operations  | Initiates offboarding triggers; coordinates employee communications and alternatives.                |
| IT / Security           | Implements technical deletion methods; maintains logs and access controls; supports request fulfillment. |
| Facilities / Security   | Triggers deletion for access control systems; ensures devices follow retention and deletion rules.   |
| Vendors / Processors    | Execute deletion upon instruction; provide confirmation; assist with rights requests as needed.      |

---

## 7. Review and Continuous Improvement

- **Procedure Owner:** {{OWNER_FUNCTION}}  
- **Review Frequency:** At least annually, and whenever a new biometric system is added, modified, or retired, or when legal requirements change.  

For each review:

- **Review Date:** {{REVIEW_DATE}}  
- **Reviewed By:** {{REVIEWER_NAME}}  
- **Key Updates (retention changes, workflow updates, new systems):** {{REVIEW_NOTES}}  
