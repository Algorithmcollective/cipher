# Deliverable 1: Biometric Systems Inventory & Data Map

## 1. Purpose

This inventory identifies all systems that collect, generate, store, or use biometric identifiers or biometric data for Colorado residents. It supports compliance with Colorado’s biometric and privacy requirements by documenting purposes, populations, data flows, vendors, and retention/deletion rules.

## 2. Biometric Systems Inventory Table

Fill one row per system.

| ID | System Name                          | Purpose / Function                          | Biometric Type                 | Population           | Locations / Sites           | Vendor / Owner                 | Storage Location                         | Linked Policies / SOPs             |
|----|--------------------------------------|---------------------------------------------|--------------------------------|----------------------|-----------------------------|---------------------------------|-----------------------------------------|------------------------------------|
| 1  |                                      |                                             |                                |                      |                             |                                 |                                         |                                    |
| 2  |                                      |                                             |                                |                      |                             |                                 |                                         |                                    |
| 3  |                                      |                                             |                                |                      |                             |                                 |                                         |                                    |
| 4  |                                      |                                             |                                |                      |                             |                                 |                                         |                                    |
| 5  |                                      |                                             |                                |                      |                             |                                 |                                         |                                    |

### Field Guidance

- **System Name:** Product or internal system name (e.g., “ADP Biometric Time Clock,” “Genetec Access Control,” “Lobby Kiosk”).  
- **Purpose / Function:** Time and attendance, secure access control, fraud prevention, patient/member ID, customer authentication, etc.  
- **Biometric Type:** Fingerprint, palm/hand geometry, facial template, iris, voiceprint, other biometric identifier.  
- **Population:** Employees, contractors, visitors, customers, patients, members, etc.  
- **Locations / Sites:** Offices, warehouses, stores, clinics, branches, data centers (city/state or site codes).  
- **Vendor / Owner:** Third‑party provider name and internal system owner (e.g., HRIS team, Security, IT).  
- **Storage Location:** On‑device only, on‑prem server, cloud provider (region), hybrid, etc.  
- **Linked Policies / SOPs:** References to the Biometric Policy, retention schedule, incident response playbook, and any local SOPs.

## 3. Biometric Data Flow Map (Text Summary)

For each system listed above, describe the data flow in 3–6 bullets:

#### System ID: 1 – \[System Name\]

- Capture: \[How and where biometric identifiers are collected (device type, capture point)\]  
- Transmission: \[How data moves from device to backend systems, and whether it is encrypted in transit\]  
- Storage: \[Primary and backup storage locations, including cloud regions if applicable\]  
- Access: \[Roles or groups that can access biometric data, and through which interfaces\]  
- Sharing: \[Any vendors or third parties that receive biometric data, and for what purposes\]  
- Deletion: \[How and when biometric data is deleted or de‑identified under the retention schedule\]

#### System ID: 2 – \[System Name\]

- Capture:  
- Transmission:  
- Storage:  
- Access:  
- Sharing:  
- Deletion:  

*(Repeat this subsection for each inventory entry.)*

## 4. Ownership & Review

- **Inventory Owner:** \[Role/Team — e.g., Privacy Office, HR, Security, IT Risk\]  
- **Last Updated:** \[Date\]  
- **Review Frequency:** At least annually, and whenever a new biometric system is added, modified, or retired.

