# Colorado Biometric Notice & Consent Template  
**File:** CO_4_Biometric_Notice_and_Consent_md.md  

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}  

> **Purpose:** Provide standard notice and consent language for collecting and using biometric identifiers and biometric data in Colorado, including required disclosures about purpose, retention, and rights, and formats tailored for employees, applicants, visitors, and customers.[web:17][web:18][web:24][web:31]

---

## 1. Biometric Privacy Notice – Master Text

This master notice can be adapted for employees, applicants, visitors, and customers.

### 1.1 Short Form Summary (for posters, on‑screen banners)

> **Biometric Notice – {{COMPANY_NAME}}**  
>  
> {{COMPANY_NAME}} may collect and use biometric identifiers or biometric data (such as {{BIOMETRIC_TYPES}}) for limited purposes, including {{PRIMARY_PURPOSES}} at our Colorado locations. We retain biometric data only for as long as needed for these purposes and then delete it according to our Biometric Data Governance Policy. For more information, including how long we keep biometric data and your rights, please review our full Biometric Privacy Notice or contact us at {{CONTACT_CHANNEL}}.[web:17][web:18][web:24][web:29]

### 1.2 Full Biometric Privacy Notice (General)

**1. Introduction**

This Biometric Privacy Notice explains how {{COMPANY_NAME}} (“we,” “us,” or “our”) collects, uses, stores, shares, and deletes biometric identifiers and biometric data of individuals in Colorado.[web:17][web:22][web:24] It supplements our general privacy notices and applies when you interact with systems that collect or process your biometric information.

**2. What Biometric Information We Collect**

Depending on your role and our systems, we may collect and process:

- Biometric identifiers, such as {{BIOMETRIC_TYPES}}.  
- Biometric data derived from those identifiers (for example, numerical templates or analytics generated from scans or images).[web:17][web:22][web:24]

We do **not** collect biometric information unless it is reasonably necessary for the purposes described in this Notice.

**3. How We Use Your Biometric Information**

We use biometric identifiers and biometric data only for specific, disclosed purposes, which may include:[web:17][web:24][web:26]

- {{USE_CASE_1}} (e.g., recording time and attendance).  
- {{USE_CASE_2}} (e.g., controlling access to secure areas).  
- {{USE_CASE_3}} (e.g., verifying identity for visitor or customer check‑in).  
- {{USE_CASE_4}} (e.g., improving or monitoring workplace safety and security).  

We will not use your biometric information for purposes that are materially different, unrelated, or incompatible with these purposes without providing additional notice and, where required, obtaining your consent.

**4. How Long We Keep Your Biometric Information**

We retain biometric identifiers and biometric data only for as long as reasonably necessary to fulfill the purposes described above, or as required by law, and then delete or de‑identify it according to our Biometric Data Governance Policy.[web:17][web:24][web:29]

Our typical retention periods are:

- {{RETENTION_RULE_1}} (e.g., while you are actively using the system, plus up to X days after your last use).  
- {{RETENTION_RULE_2}} (e.g., up to X days for short‑term video or analytics used for safety review).  

Specific retention periods for each system are documented in our Biometric Retention Schedule, available on request where appropriate.

**5. How We Share Your Biometric Information**

We may share biometric information:

- With service providers or vendors that operate biometric systems on our behalf (for example, time clock, access control, or safety analytics providers), under contracts that restrict their use of your biometric data and require appropriate security measures.[web:17][web:24][web:36]  
- With government authorities, law enforcement, or other third parties when required by law, court order, or to protect our legal rights.  

We do **not** sell, lease, or trade biometric identifiers, and we do not allow vendors to sell or use your biometric identifiers for their own independent purposes.[web:17][web:24][web:33][web:36]

**6. Security Measures**

We implement technical and organizational measures designed to protect biometric information against unauthorized access, disclosure, or misuse, including encryption, access controls, and secure transmission where feasible.[web:17][web:24][web:29]

**7. Your Rights and Choices**

Depending on your relationship with us and applicable law, you may have the right to:

- Request information about our collection and use of your biometric information.  
- Request access to biometric data we maintain about you, where feasible.  
- Request deletion of your biometric information, subject to legal or operational requirements.  
- Withdraw consent where our processing is based on your consent.[web:24][web:29][web:41]  

You can exercise these rights or ask questions by contacting us at:

- **Email:** {{PRIVACY_EMAIL}}  
- **Postal mail:** {{PRIVACY_ADDRESS}}  
- **Other channel (if applicable):** {{PRIVACY_PORTAL_OR_PHONE}}

**8. How to Contact Us**

If you have questions about this Biometric Privacy Notice or our use of biometric information, please contact {{CONTACT_ROLE_OR_TEAM}} at {{CONTACT_CHANNEL}}.

---

## 2. Employee / Contractor Biometric Consent Form

**Title:** Employee / Contractor Biometric Information Notice & Consent – {{COMPANY_NAME}}

### 2.1 Notice

> **IMPORTANT:** Please read this notice carefully before deciding whether to consent to the collection and use of your biometric information.

{{EMPLOYEE_NOTICE_TEXT}}  
*(Insert or reference the relevant parts of the Biometric Privacy Notice tailored to employees/contractors, including what is collected, purposes, retention, sharing, and rights.)*[web:19][web:24][web:31][web:37]

Key points:

- Types of biometric information collected: {{EMPLOYEE_BIOMETRIC_TYPES}}.  
- Purposes: {{EMPLOYEE_PURPOSES}} (e.g., secure facility access, time and attendance, safety monitoring).  
- Retention: {{EMPLOYEE_RETENTION_SUMMARY}}.  
- Sharing: limited to service providers operating systems on our behalf and lawful disclosures.  
- Your rights: access, questions, and, where applicable, withdrawal of consent.

### 2.2 Consent Statement

By signing or confirming below, you acknowledge that:

1. You have received and read the Employee Biometric Privacy Notice.  
2. You understand that {{COMPANY_NAME}} will collect and use your biometric information for the purposes described in that Notice.  
3. You understand how long your biometric information will be retained and how it will be deleted.  
4. You understand that your biometric information may be shared with service providers operating biometric systems on {{COMPANY_NAME}}’s behalf, under contractual protections.  
5. You understand how to contact {{COMPANY_NAME}} with questions, or to exercise your rights with respect to biometric information.

_optional clause when consent cannot be a condition of employment for certain uses:_  

6. Your decision to provide or withhold consent for **optional** biometric uses will not be used to unlawfully retaliate against you, and where required by law you will be offered a reasonable alternative.

**Employee / Contractor Acknowledgment**

- Name: ___________________________  
- Position / Department: ___________________________  
- Location: ___________________________  

☐ I consent to the collection and use of my biometric information as described in the Employee Biometric Privacy Notice.  

Signature: ___________________________    Date: _____________________  

_(For electronic consent, this may be replaced with an electronic acknowledgment mechanism.)_

---

## 3. Applicant Biometric Notice & Consent (Optional Module)

Use this when biometrics are used during hiring or background checks.

**Short Notice (e.g., in application portal):**

> As part of our application or onboarding process, we may collect and use certain biometric information (such as {{APPLICANT_BIOMETRIC_TYPES}}) for {{APPLICANT_PURPOSES}} (for example, identity verification or secure access to facilities). We will provide more detail and obtain your consent before collecting this information.[web:19][web:24][web:33][web:37]

Include a link or popup with the full Biometric Privacy Notice and a consent checkbox:

☐ I have read and understand the Biometric Privacy Notice for applicants and consent to the collection and use of my biometric information as described.

---

## 4. Visitor / Customer Biometric Notice (Signage / On‑Screen)

### 4.1 Physical Signage Template

> **Biometric Information Notice**  
>  
> This facility uses systems that may collect and process biometric information (such as {{VISITOR_BIOMETRIC_TYPES}}) for purposes including {{VISITOR_PURPOSES}} (for example, identity verification, access control, or security monitoring) at this Colorado location.  
>  
> For more information about how we use, protect, and retain biometric information, please review our Biometric Privacy Notice at {{NOTICE_URL_OR_QR}} or contact us at {{CONTACT_CHANNEL}}.[web:24][web:26][web:30]

### 4.2 On‑Screen or Kiosk Text

> By continuing, you acknowledge that {{COMPANY_NAME}} may collect and use your biometric information (such as {{VISITOR_BIOMETRIC_TYPES}}) for {{VISITOR_PURPOSES}} in accordance with our Biometric Privacy Notice.  
>  
> \[View Biometric Privacy Notice\] (link button)

_optional consent checkbox where explicit consent is required:_  

☐ I consent to the collection and use of my biometric information for the purposes described.

---

## 5. Recordkeeping Fields

For each notice/consent implementation, document:

- **System / Use Case:** {{SYSTEM_OR_USE_CASE}}  
- **Audience:** {{AUDIENCE_TYPE}} (Employees / Contractors / Applicants / Visitors / Customers)  
- **Notice Version / ID:** {{NOTICE_VERSION}}  
- **Consent Capture Method:** {{CONSENT_METHOD}} (paper, e‑signature, portal checkbox, etc.)  
- **Effective Date:** {{NOTICE_EFFECTIVE_DATE}}  
- **Location of Stored Consents:** {{CONSENT_STORAGE_LOCATION}}  

This section should be maintained by the owner function to demonstrate compliance with Colorado’s disclosure and consent requirements for biometric identifiers.[web:17][web:24][web:29][web:41]
