# Colorado Biometric Vendor & Prohibited Uses Controls  
**File:** CO_5_Biometric_Vendor_and_Use_Controls_md.md  

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}  

> **Purpose:** Provide a standardized checklist and documentation structure to ensure vendors handling biometric data meet Colorado requirements and that prohibited or high‑risk uses of biometric identifiers are prevented or controlled.[web:17][web:24][web:33][web:36]

---

## 1. Biometric Vendor Register

List all vendors/processors that collect, store, or process biometric identifiers or biometric data on behalf of the Company.

| ID | Vendor Name       | Service / Product (Biometric Use) | Systems Covered (IDs) | Biometric Types Processed | Data Hosting Location(s) | Contract Owner (Function) | Contract Expiry | Data Processing Agreement / Addendum Ref |
|----|-------------------|------------------------------------|------------------------|---------------------------|--------------------------|----------------------------|----------------|------------------------------------------|
| 1  | {{VENDOR_1_NAME}} | {{VENDOR_1_SERVICE}}              | {{SYSTEM_IDS_1}}       | {{VENDOR_1_TYPES}}        | {{VENDOR_1_LOCATIONS}}   | {{VENDOR_1_OWNER}}         | {{VENDOR_1_END}} | {{VENDOR_1_DPA_REF}}                     |
| 2  | {{VENDOR_2_NAME}} | {{VENDOR_2_SERVICE}}              | {{SYSTEM_IDS_2}}       | {{VENDOR_2_TYPES}}        | {{VENDOR_2_LOCATIONS}}   | {{VENDOR_2_OWNER}}         | {{VENDOR_2_END}} | {{VENDOR_2_DPA_REF}}                     |

---

## 2. Vendor Due Diligence Checklist (Biometric‑Specific)

For each biometric vendor, complete this checklist and retain evidence.

### 2.1 Lawful Purpose and Scope

- ☐ Vendor’s services and biometric processing are limited to defined, documented purposes consistent with our Biometric Data Governance Policy.[web:17][web:24]  
- ☐ Vendor does **not** use biometric data for its own independent purposes (e.g., product training) without our explicit authorization and required consents.[web:17][web:24][web:36]  
- ☐ Vendor’s privacy notice and documentation are reviewed for any conflicting claims about how biometric data is used or shared.

### 2.2 Security Controls

- ☐ Encryption of biometric data in transit (e.g., TLS) is confirmed.  
- ☐ Encryption of biometric data at rest (where feasible) is confirmed.[web:24][web:29]  
- ☐ Access to biometric data at the vendor is limited to necessary personnel with strong authentication.  
- ☐ Vendor maintains and tests incident response and breach notification procedures.[web:17][web:36]  
- ☐ Independent security certifications or assessments (if available) have been reviewed (e.g., SOC 2, ISO 27001).

### 2.3 Data Location and Sub‑Processors

- ☐ Primary data hosting locations (countries/regions) are documented.  
- ☐ Any sub‑processors that may access biometric data are disclosed and contractually bound to equivalent protections.[web:23][web:24]  
- ☐ Transfers outside the U.S. (if any) are assessed for legal and risk implications.

### 2.4 Retention and Deletion

- ☐ Vendor supports deletion of biometric data upon our instruction, including at contract end.  
- ☐ Vendor’s default retention settings are aligned with our Biometric Retention Schedule or can be configured to align.  
- ☐ Vendor provides documentation or logs confirming deletion upon request.[web:17][web:24][web:29]

### 2.5 Rights Support and Cooperation

- ☐ Vendor can support our responses to access/deletion requests involving biometric data.  
- ☐ Vendor provides appropriate logging so we can investigate incidents or complaints.  
- ☐ Vendor will notify us promptly of any security incident impacting biometric data.[web:17][web:36]

---

## 3. Biometric Contract Clauses – Control Checklist

For each biometric vendor, confirm that the contract or DPA includes the following elements.

- ☐ **Purpose Limitation:** Processing of biometric data only for specified purposes and on our documented instructions.[web:17][web:24][web:36]  
- ☐ **No Sale / No Independent Use:** Explicit prohibition on selling, leasing, or trading biometric identifiers, or using them for the vendor’s own products, analytics, or marketing.[web:17][web:24][web:33]  
- ☐ **Security Obligations:** Reasonable and appropriate technical and organizational security measures, including encryption, access controls, and secure development practices.[web:24][web:29]  
- ☐ **Incident Notification:** Obligation to notify us promptly of security incidents affecting biometric data, and to cooperate in investigation and remediation.[web:17][web:36]  
- ☐ **Sub‑Processor Controls:** Conditions for adding or changing sub‑processors that will process biometric data (notice, equal protection, and right to object if appropriate).[web:23][web:24]  
- ☐ **Data Subject Rights Support:** Commitment to assist us in fulfilling rights requests involving biometric data (access, deletion, etc.).[web:24][web:29]  
- ☐ **Return / Deletion at Termination:** Clear requirements to delete or return biometric data (and certify deletion) at contract end, subject to applicable law.[web:17][web:24][web:29]  

Record contract review outcome:

- **Contract Reviewed By:** {{CONTRACT_REVIEWER}}  
- **Review Date:** {{CONTRACT_REVIEW_DATE}}  
- **Key Notes / Gaps:** {{CONTRACT_REVIEW_NOTES}}  

---

## 4. Prohibited and Restricted Uses Register

Document uses of biometric identifiers/data that are **prohibited** or **restricted** within the Company, to prevent non‑compliant or high‑risk practices.

| ID | Use Description                                  | Category (Prohibited / Restricted) | Rationale (Legal / Risk)                    | Approved Exceptions / Conditions          | Owner / Approver          |
|----|--------------------------------------------------|------------------------------------|--------------------------------------------|-------------------------------------------|---------------------------|
| 1  | {{USE_1_DESC}}                                   | {{USE_1_CATEGORY}}                 | {{USE_1_RATIONALE}}                        | {{USE_1_EXCEPTIONS}}                      | {{USE_1_OWNER}}           |
| 2  | {{USE_2_DESC}}                                   | {{USE_2_CATEGORY}}                 | {{USE_2_RATIONALE}}                        | {{USE_2_EXCEPTIONS}}                      | {{USE_2_OWNER}}           |

Example entries you can adapt per client:

- Using biometric data for marketing or advertising.  
- Using biometric data for continuous productivity scoring or “always‑on” behavioral monitoring without specific approval.  
- Using biometric analytics as the **sole** basis for discipline, termination, or promotion decisions.  
- Selling or licensing biometric identifiers to third parties.

---

## 5. Review and Governance

- **Vendor Register Owner:** {{REGISTER_OWNER}}  
- **Prohibited Uses Register Owner:** {{USES_OWNER}}  
- **Review Frequency:** At least annually, and upon onboarding or offboarding a biometric vendor, or when introducing a new biometric use case.[web:29][web:41]  

Document each review:

- **Review Date:** {{REVIEW_DATE}}  
- **Reviewed By:** {{REVIEWER_NAME}}  
- **Key Changes (vendors added/removed, uses updated):** {{REVIEW_CHANGES}}  
