# Colorado Biometric Training & Annual Review Checklist  
**File:** CO_8_Biometric_Training_and_Annual_Review_md.md  

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}  

> **Purpose:** Provide a standardized structure to train relevant personnel on biometric requirements and to perform an annual review of the Company’s biometric program, including systems, vendors, retention, and incident/complaint trends.[web:17][web:24][web:29][web:41]

---

## 1. Training Scope and Audience

Identify the roles that require biometric‑specific training.

| Audience Group            | Example Roles / Functions                            | Training Frequency           |
|---------------------------|------------------------------------------------------|------------------------------|
| HR / People Operations    | HRBPs, payroll, recruiting, onboarding staff        | On hire + annually          |
| IT / Security             | Identity & access, infrastructure, security ops     | On role assignment + annually|
| Facilities / Physical Sec.| Facilities managers, guards, access control admins  | On role assignment + annually|
| Safety / Risk             | Safety managers, risk analysts                      | On role assignment + annually|
| Managers in Biometric Areas| Supervisors in biometric‑equipped sites            | On role assignment + annually|

---

## 2. Training Content Checklist

Each biometric training session should cover, at minimum:

### 2.1 Legal and Policy Basics

- ☐ Overview of Colorado biometric requirements and how they amend the Colorado Privacy Act (definitions, obligations, and restricted practices).[web:17][web:24][web:41]  
- ☐ Company Biometric Data Governance Policy (scope, purposes, retention, prohibited uses).  

### 2.2 Systems and Use Cases

- ☐ Which systems use biometrics (time clocks, access control, visitor kiosks, analytics, etc.) and for what purposes.  
- ☐ Who is affected (employees, contractors, visitors, customers) and where (sites/locations).  

### 2.3 Notice, Consent, and Alternatives

- ☐ How and when notices and consents are provided and documented.  
- ☐ When biometric use is mandatory vs. optional, and how to handle questions or objections.  

### 2.4 Security, Retention, and Deletion

- ☐ Basic security expectations around biometric systems (access controls, password hygiene, reporting suspicious activity).  
- ☐ High‑level understanding of retention limits and who initiates/executes deletion.  

### 2.5 Incident & Complaint Handling

- ☐ How to recognize a potential biometric incident or complaint.  
- ☐ How and where to escalate (contacts, incident and complaint IDs, timelines).  

---

## 3. Training Session Log

Record completed training events.

| Session ID | Date       | Audience Group           | Topic / Modules Covered                 | Trainer / Presenter        | Format (In‑Person / Virtual / LMS) | # Attendees | Attendance Record Location                  |
|-----------|------------|---------------------------|-----------------------------------------|----------------------------|------------------------------------|------------|---------------------------------------------|
| {{ID_1}}  | {{DATE_1}} | {{GROUP_1}}              | {{TOPICS_1}}                            | {{TRAINER_1}}              | {{FORMAT_1}}                       | {{COUNT_1}}| {{ATTENDANCE_LOCATION_1}}                  |

---

## 4. Annual Biometric Program Review – Checklist

Conduct at least once per year.

### 4.1 Systems and Inventory

- ☐ Review and update the **Biometric Systems Inventory & Data Map** (Deliverable 1) to confirm:  
  - No unapproved biometric systems are in use.  
  - New systems have been added and documented.  
  - Decommissioned systems have appropriate archival records.[web:24][web:29][web:41]  

### 4.2 Policies, Notices, and Consents

- ☐ Confirm the Biometric Data Governance Policy reflects current law and practice.  
- ☐ Review all notice and consent templates for accuracy and clarity; update as needed.  
- ☐ Spot‑check that notices are actually posted/communicated at relevant locations and in onboarding materials.

### 4.3 Vendors and Contracts

- ☐ Review the **Biometric Vendor Register** and due diligence/contract checklists (Deliverable 5).  
- ☐ Confirm contracts still include required protections (no sale, purpose limitation, deletion on termination, incident notification).  
- ☐ Verify that any new biometric vendors have been onboarded through the full review process.[web:17][web:24][web:36][web:41]

### 4.4 Retention, Deletion, and Requests

- ☐ Review the **Biometric Retention Schedule** and Deletion Logs (Deliverable 6) for:  
  - Alignment between configured retention and policy.  
  - Evidence of regular deletion and any exceptions (legal holds).  
- ☐ Sample a small number of access/deletion requests to ensure procedures are followed and documented.

### 4.5 Incidents and Complaints

- ☐ Review the **Biometric Incident Log** and complaint cases (Deliverable 7) from the past year.  
- ☐ Identify patterns (recurring root causes, systems, sites, or vendors).  
- ☐ Confirm all significant incidents had post‑incident reviews and resulting actions tracked.

---

## 5. Annual Review Summary Record

Capture the outcome of the annual biometric review.

| Field                                | Value                                  |
|--------------------------------------|----------------------------------------|
| Review Period                        | {{PERIOD_START}} – {{PERIOD_END}}     |
| Review Date                          | {{REVIEW_DATE}}                        |
| Lead Reviewer                        | {{REVIEW_LEAD}}                        |
| Participants                         | {{REVIEW_PARTICIPANTS}}               |
| Key Issues Identified                | {{KEY_ISSUES}}                         |
| Remediation / Improvement Actions    | {{ACTIONS}}                            |
| Target Completion Dates for Actions  | {{TARGET_DATES}}                       |
| Next Scheduled Review Date           | {{NEXT_REVIEW_DATE}}                   |

---

## 6. Continuous Improvement Actions Register

Track actions resulting from training feedback, incidents, audits, or law changes.

| Action ID | Source (Incident / Audit / Law Change / Feedback) | Description of Action                                    | Owner             | Target Date | Status (Open / In Progress / Closed) | Notes                         |
|-----------|----------------------------------------------------|----------------------------------------------------------|-------------------|------------|--------------------------------------|-------------------------------|
| {{AID_1}} | {{SOURCE_1}}                                      | {{ACTION_DESC_1}}                                       | {{ACTION_OWNER_1}}| {{DATE_1}} | {{STATUS_1}}                         | {{ACTION_NOTES_1}}           |

---
