# Colorado Biometric Incident & Complaint Response Playbook  
**File:** CO_7_Biometric_Incident_and_Complaint_Response_md.md  

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130) and Colorado data breach law (C.R.S. § 6‑1‑716)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}  

> **Purpose:** Establish a standardized protocol for identifying, investigating, and responding to security incidents and complaints involving biometric identifiers and biometric data, including coordination with Colorado breach‑notification requirements and vendor obligations.[web:17][web:21][web:32][web:36][web:41]

---

## 1. Scope and Definitions

This playbook applies to:

- Any **data security incident** that may compromise the confidentiality, integrity, or availability of biometric identifiers or biometric data processed for Colorado residents.  
- Any **complaint or concern** raised by employees, visitors, customers, or regulators regarding the Company’s biometric practices (collection, notice, consent, use, retention, deletion, or sharing).

**Key terms:**

- **Biometric Incident:** A suspected or confirmed event where biometric identifiers or biometric data are accessed, disclosed, altered, or lost in an unauthorized or unintended way (including vendor incidents).[web:17][web:32][web:36][web:41]  
- **Complaint:** Any reported concern that biometric data is being collected, used, or retained in violation of Company policy or law (e.g., lack of notice/consent, misuse, over‑retention).

---

## 2. Roles and Contact Points

| Role / Function         | Responsibilities in Biometric Incidents & Complaints                                          |
|-------------------------|------------------------------------------------------------------------------------------------|
| Incident Response Lead  | Coordinates security incident handling and decision‑making.                                   |
| Privacy & Compliance    | Assesses legal/privacy impact; manages complaints; determines notice obligations.             |
| IT / Security           | Investigates technical aspects; contains and remediates security issues.                      |
| HR / People Operations  | Manages employee communications and HR‑related complaints.                                    |
| Facilities / Security   | Handles incidents and complaints related to physical access and visitor systems.              |
| Vendors / Processors    | Notify Company of incidents; cooperate in investigation and remediation as required.          |

**Primary contact group (distribution list):** {{INCIDENT_DL_EMAIL}}  

---

## 3. Incident Response Workflow (Biometric Data)

### 3.1 Step 1 – Identification and Initial Triage

1. **Receive alert** from:  
   - Security tools, IT, or vendor notifications.  
   - Employee, visitor, or customer reports (via hotline, email, or manager).  

2. **Record event** in the incident management system with a unique ID (e.g., BIO‑INC‑{{YYYY}}‑{{NNN}}).  

3. **Confirm scope:**  
   - Does the event involve biometric identifiers or biometric data (templates, analytics, associated logs)?  
   - Which systems, vendors, and populations are potentially affected?  

4. **Assign severity level** (e.g., Low / Medium / High) and Incident Response Lead.

### 3.2 Step 2 – Containment

- Isolate affe
