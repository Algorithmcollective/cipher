# Colorado Biometric Risk & Impact Assessment Template  
**File:** CO_3_Biometric_Risk_and_Impact_Assessment_md.md  

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado Privacy Act (as amended by HB 24‑1130)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}  

> **Purpose:** Provide a standardized template to assess risks associated with each biometric use case, including privacy, security, discrimination, and surveillance concerns, and to document mitigations, approvals, and review cycles.

---

## 1. System Overview

- **System / Tool Name:** {{SYSTEM_NAME}}  
- **System ID (from Inventory):** {{SYSTEM_ID}}  
- **Vendor / In‑House:** {{VENDOR_OR_INHOUSE}}  
- **Business Owner:** {{BUSINESS_OWNER}}  
- **Technical Owner:** {{TECHNICAL_OWNER}}  
- **Primary Purpose(s):** {{PRIMARY_PURPOSES}}  
- **Biometric Type(s):** {{BIOMETRIC_TYPES}}  
- **Population(s) Affected:** {{POPULATIONS}}  
- **Locations / Sites:** {{LOCATIONS}}  

---

## 2. Legal and Purpose Basis

### 2.1 Lawful Basis and Necessity

- **Lawful basis for processing biometric data (e.g., consent, security, fraud prevention):**  
  {{LAWFUL_BASIS}}  

- **Why biometrics are necessary for this purpose (vs. non‑biometric alternatives):**  
  {{NECESSITY_JUSTIFICATION}}  

- **Is use of biometrics optional or mandatory for affected individuals?**  
  {{OPTIONAL_OR_MANDATORY}}  

- **If mandatory, justification and any alternatives offered (if applicable):**  
  {{MANDATORY_JUSTIFICATION}}  

### 2.2 Purpose Limitation

- **Primary purposes of biometric processing:**  
  {{PRIMARY_PURPOSES_DETAIL}}  

- **Any secondary uses (analytics, auditing, safety, fraud, etc.):**  
  {{SECONDARY_USES}}  

- **Confirmation that purposes are disclosed in notices and consents (Y/N):**  
  {{PURPOSES_DISCLOSED_FLAG}}  

---

## 3. Data Flows and Storage

### 3.1 Collection and Transmission

- **Collection method (device type, capture points):**  
  {{COLLECTION_METHOD}}  

- **Transmission paths and protections (e.g., TLS, VPN, network segmentation):**  
  {{TRANSMISSION_SECURITY}}  

### 3.2 Storage and Access

- **Storage locations (on‑device, on‑prem, cloud, regions):**  
  {{STORAGE_LOCATIONS}}  

- **Retention period for biometric templates / data:**  
  {{RETENTION_PERIOD}}  

- **Deletion / de‑identification method:**  
  {{DELETION_METHOD}}  

- **Roles with access to biometric data and related logs:**  
  {{ACCESS_ROLES}}  

---

## 4. Risk Identification

For each category below, identify relevant risks and note whether risk is **Low / Medium / High** before mitigations.

### 4.1 Privacy and Data Protection Risks

- **Collection or retention beyond what is necessary:**  
  {{PRIVACY_RISK_COLLECTION}}  

- **Insufficient notice or consent practices:**  
  {{PRIVACY_RISK_NOTICE_CONSENT}}  

- **Inadequate transparency about uses or sharing:**  
  {{PRIVACY_RISK_TRANSPARENCY}}  

### 4.2 Security Risks

- **Unauthorized access to biometric templates or logs:**  
  {{SECURITY_RISK_ACCESS}}  

- **Inadequate encryption / network protections:**  
  {{SECURITY_RISK_ENCRYPTION}}  

- **Weak admin controls or logging:**  
  {{SECURITY_RISK_ADMIN_CONTROLS}}  

### 4.3 Discrimination and Fairness Risks

- **Use of biometrics in ways that may differentially burden protected groups (e.g., false match rates, mis‑identification):**  
  {{FAIRNESS_RISK_MISIDENTIFICATION}}  

- **Use in conjunction with AI or analytics that could affect hiring, promotion, discipline, or other consequential decisions:**  
  {{FAIRNESS_RISK_AI_LINK}}  

### 4.4 Surveillance and Workplace / Customer Relations Risks

- **Perceived or actual continuous monitoring / tracking:**  
  {{SURVEILLANCE_RISK_MONITORING}}  

- **Impact on trust, morale, or willingness to participate:**  
  {{SURVEILLANCE_RISK_TRUST}}  

---

## 5. Mitigations and Controls

For each identified risk, document mitigations in place or planned.

### 5.1 Technical Controls

- **Encryption in transit and at rest:**  
  {{CONTROL_ENCRYPTION}}  

- **Network segmentation and device hardening:**  
  {{CONTROL_NETWORK}}  

- **Access controls and authentication:**  
  {{CONTROL_ACCESS}}  

### 5.2 Policy and Process Controls

- **Biometric Data Governance Policy references:**  
  {{CONTROL_POLICY_REFERENCE}}  

- **Retention schedule alignment and deletion workflows:**  
  {{CONTROL_RETENTION}}  

- **Vendor contractual controls (no sale/lease, incident notice, deletion on termination):**  
  {{CONTROL_VENDOR}}  

### 5.3 Operational and Human Controls

- **Training for staff using or administering biometric systems:**  
  {{CONTROL_TRAINING}}  

- **Complaint / incident reporting channels:**  
  {{CONTROL_COMPLAINTS}}  

- **Limitations on use (e.g., restricted camera coverage, no use in rest areas, no 24/7 tracking without justification):**  
  {{CONTROL_LIMITATIONS}}  

---

## 6. Residual Risk Evaluation

After applying mitigations, rate residual risk for each category.

| Risk Category     | Residual Risk (Low / Medium / High) | Summary Explanation                          |
|-------------------|--------------------------------------|---------------------------------------------|
| Privacy           | {{RESIDUAL_PRIVACY}}                | {{RESIDUAL_PRIVACY_NOTES}}                  |
| Security          | {{RESIDUAL_SECURITY}}               | {{RESIDUAL_SECURITY_NOTES}}                 |
| Discrimination    | {{RESIDUAL_DISCRIMINATION}}         | {{RESIDUAL_DISCRIMINATION_NOTES}}           |
| Surveillance      | {{RESIDUAL_SURVEILLANCE}}           | {{RESIDUAL_SURVEILLANCE_NOTES}}             |

If any category remains **High**, document additional actions or compensating controls, or consider redesign / non‑deployment.

---

## 7. Decisions, Approvals, and Conditions

- **Overall assessment outcome (Proceed / Proceed with Conditions / Do Not Proceed):**  
  {{ASSESSMENT_OUTCOME}}  

- **Conditions or limitations (scope, locations, time‑bound pilot, population exclusions, etc.):**  
  {{ASSESSMENT_CONDITIONS}}  

- **Required follow‑up actions (e.g., update notices, tighten access controls, add monitoring):**  
  {{FOLLOW_UP_ACTIONS}}  

### 7.1 Approvals

- **Business Owner Approval:**  
  - Name: {{BUSINESS_OWNER_NAME}}  
  - Title: {{BUSINESS_OWNER_TITLE}}  
  - Date: {{BUSINESS_OWNER_APPROVAL_DATE}}  

- **Privacy / Compliance Approval:**  
  - Name: {{PRIVACY_APPROVER_NAME}}  
  - Title: {{PRIVACY_APPROVER_TITLE}}  
  - Date: {{PRIVACY_APPROVAL_DATE}}  

- **Security / IT Approval (if applicable):**  
  - Name: {{SECURITY_APPROVER_NAME}}  
  - Title: {{SECURITY_APPROVER_TITLE}}  
  - Date: {{SECURITY_APPROVAL_DATE}}  

---

## 8. Review and Monitoring

- **Next scheduled review date:** {{NEXT_REVIEW_DATE}}  
- **Triggers for earlier review (e.g., new features, vendor change, incident, legal change):**  
  {{EARLY_REVIEW_TRIGGERS}}  

- **Monitoring metrics (e.g., incidents, complaints, false match rates, participation rates):**  
  {{MONITORING_METRICS}}  

- **Location of related documentation (logs, incident reports, change records):**  
  {{RELATED_DOCS_LOCATION}}  
