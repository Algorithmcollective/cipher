# Deliverable 2: Biometric Data Governance Policy (HB 24‑1130 / CPA)  
**File:** CO_2_Biometric_Data_Governance_Policy_TEMPLATE_Generic.md  

## 1. Purpose and Scope

This **Biometric Data Governance Policy** establishes how \[Organization Name\] (“the Company”) collects, uses, stores, shares, and deletes biometric identifiers and biometric data for individuals in Colorado. It is designed to align with Colorado biometric and privacy requirements, including amendments to the Colorado Privacy Act (HB 24‑1130).

This policy applies to:

- All biometric identifiers and biometric data processed in connection with Company operations in Colorado.  
- All individuals whose biometric data is collected by or on behalf of the Company.  
- All systems, devices, and vendors that capture, store, or process biometric identifiers or biometric data for the Company.

## 2. Definitions

For purposes of this policy:

- **Biometric Identifier** means a biologically unique characteristic that can be used to identify a person, such as a fingerprint, palm/hand geometry, iris or retina scan, face template, or voiceprint, as defined under Colorado law.  
- **Biometric Data** means any data generated from the measurement or technological processing of a biometric identifier, used to identify an individual or linked to an identifiable individual.  
- **Controller** means the Company when it determines the purposes and means of processing biometric identifiers or biometric data.  
- **Processor / Vendor** means any third party that processes biometric data on behalf of the Company under a contract.

## 3. Biometric Use Cases and Purposes

The Company limits biometric data processing to clearly defined, documented purposes.

Approved use cases may include, for example:

- Time and attendance tracking.  
- Physical access control to facilities or restricted areas.  
- Visitor or customer identity verification and badge issuance.  
- User or customer authentication to systems or applications.  
- Safety, fraud prevention, or security analytics.

Any new use of biometric identifiers or biometric data must be reviewed and approved through the Company’s privacy and security review process before implementation.

## 4. Notice and Consent

The Company provides clear, conspicuous notice and obtains consent before collecting biometric identifiers or biometric data, except where a recognized legal exception applies.

At minimum:

- **Employee and Contractor Notice:**  
  - A written or electronic notice describing what biometric data is collected, for what purposes, how long it will be retained, how it will be stored and protected, and how it may be shared.  
  - Notice is provided through appropriate channels such as onboarding materials, HR portals, or workplace postings.

- **Employee and Contractor Consent:**  
  - Signed or electronically recorded consent acknowledging the notice, authorizing the collection and use of biometric data for the specified purposes, and describing how consent can be withdrawn.  
  - Where law requires that certain biometric uses be optional, the Company will not condition employment or continued employment on participation in those uses.

- **Visitor / Customer Notice (and Consent, where applicable):**  
  - Signage, on‑screen notices, or other clear disclosures for visitor or customer‑facing systems explaining that biometric data may be collected and for what purposes.  
  - Where required, an explicit consent mechanism (e.g., checkbox, signature, or equivalent).

Consent records are stored in accordance with Company recordkeeping requirements.

## 5. Data Minimization and Purpose Limitation

The Company collects and processes only the minimum biometric data necessary to achieve the approved purposes and does not:

- Use biometric data for purposes that are materially different, unrelated, or incompatible with the original purposes without additional notice and, where required, consent.  
- Collect or retain raw biometric images where templates or derived data are sufficient.  
- Use biometric data for generalized monitoring or tracking unrelated to the approved purposes.

## 6. Retention and Deletion

The Company retains biometric identifiers and biometric data only for as long as reasonably necessary to fulfill the documented purposes or as required by law, whichever is shorter.

### 6.1 Retention Rules

The Company will define and maintain a **Biometric Retention Schedule** specifying, at a minimum, for each biometric system:

- System name and purpose.  
- Category of individuals affected.  
- Standard retention period for biometric templates and associated data.  
- Conditions that may extend retention (e.g., legal holds, ongoing investigations).

### 6.2 Deletion Procedures

- Biometric templates and associated data are deleted or irreversibly de‑identified from active systems and backups on or before the applicable retention deadline.  
- Deletions follow documented technical procedures (e.g., vendor APIs, system configuration, storage lifecycle rules).  
- Deletion activities are logged in a **Biometric Deletion Log**, including: date, system, type of data deleted, and responsible role.  
- If an individual submits a valid deletion request, the Company will delete biometric data as required by Colorado law and document the response.

## 7. Security and Access Controls

The Company implements appropriate technical and organizational measures to safeguard biometric identifiers and biometric data, which may include:

- Encryption of biometric templates in transit and at rest where feasible.  
- Network segmentation and secure communication channels for biometric devices and servers.  
- Role‑based access controls limiting who can administer biometric systems or access logs.  
- Strong authentication for administrative access to biometric systems.  
- Monitoring and logging of administrative access and configuration changes.

Biometric data is never stored or transmitted in plain text where encryption is reasonably feasible.

## 8. Prohibited and Restricted Uses

The Company will not:

- Sell, lease, trade, or otherwise profit from biometric identifiers or biometric data.  
- Disclose biometric data to third parties for their own purposes without appropriate legal basis, contractual protections, and required consents.  
- Use biometric data for automated profiling or decisions that produce legal or similarly significant effects on individuals without appropriate legal review.  
- Use biometric data to retaliate against individuals who exercise their privacy rights or who decline optional biometric programs where law requires those programs to be optional.

Any proposed high‑risk or novel use of biometric data must undergo a privacy and security impact assessment before implementation.

## 9. Individual Rights

Individuals whose biometric data is processed by the Company may, subject to applicable law:

- Request confirmation of whether their biometric data is being processed.  
- Request access to information about the categories of biometric data collected, purposes of processing, and relevant retention periods.  
- Request correction of inaccurate personal data associated with biometric records where appropriate.  
- Request deletion of biometric data, subject to legal and operational constraints.  
- Withdraw consent to biometric processing where processing is based on consent.

The Company will provide contact details and response timelines in its privacy notices and employee communications.

## 10. Vendor and Processor Management

The Company will only engage vendors to process biometric data under written contracts that:

- Specify permitted purposes and prohibit any sale, lease, or unrelated use of biometric data.  
- Require appropriate security controls, incident response, and cooperation with the Company’s investigations and notifications.  
- Require the processor to support the Company in responding to access and deletion requests.  
- Require timely and secure deletion or return of biometric data upon contract termination or at the Company’s request.

Vendor risk assessments and due diligence are documented and reviewed periodically.

## 11. Training and Awareness

The Company will provide role‑appropriate training for personnel who manage or interact with biometric systems, including:

- An overview of biometric identifiers and biometric data.  
- Applicable Colorado legal requirements and this policy.  
- Approved use cases and prohibited practices.  
- How to recognize and report incidents or complaints involving biometric data.

Training is refreshed at least annually and when there are material changes in law, policy, or technology.

## 12. Governance, Oversight, and Review

- **Policy Owner:** \[Role/Team – e.g., Privacy & Compliance\].  
- **Approval:** This policy is approved by \[Executive Sponsor / Committee\].  
- **Effective Date:** \[Date\].  
- **Review Cycle:** At least annually and whenever there are material changes in applicable law, Company use of biometrics, or associated risks.

Any exceptions to this policy must be documented, justified, time‑bound, and approved by the Policy Owner and the appropriate executive sponsor.
