# Law Profile

## Law Name
Colorado House Bill 24-1130 – Biometric Identifier & Biometric Data Amendments

## Citation
Colorado HB 24-1130 (2024)  
Amending the Colorado Privacy Act (CPA)

## Status
Enacted

## Effective Date
July 1, 2025

## Regulatory Scope

Amends the Colorado Privacy Act to expand protections for biometric identifiers and biometric data.

Applies to controllers and processors subject to the Colorado Privacy Act that:

- Collect biometric identifiers
- Process biometric data for identification purposes
- Use biometric systems for authentication or identity verification

Biometric identifiers include:
- Facial recognition data
- Retina or iris scans
- Fingerprints
- Voiceprints
- Other unique biological characteristics used for identification

## Core Obligations

Covered entities must:

- Provide clear notice before collecting biometric identifiers
- Obtain consent where required under the CPA
- Limit use of biometric data to disclosed purposes
- Maintain reasonable data security safeguards
- Conduct data protection assessments for high-risk processing
- Implement retention and destruction schedules
- Restrict unauthorized disclosure or sale of biometric data
- Ensure processor contracts include biometric-specific safeguards

## Enforcement Authority

Colorado Attorney General  
District Attorneys

## Penalties

Enforced under the Colorado Consumer Protection Act.

Civil penalties may reach:
- Up to $20,000 per violation
- Each affected consumer may constitute a separate violation

No private right of action.

## Private Right of Action
No

## Tier Classification
Tier 2 – Biometric & AI-Adjacent Privacy Law

## Revenue Priority
Medium to High (Identity / Surveillance / AI Deployments)

## Target Industries

- Employers using biometric timekeeping systems
- Companies deploying facial recognition
- AI-powered identity verification platforms
- Security and surveillance providers
- Retail loss prevention using biometric identification
- Authentication technology vendors

Generally does NOT apply to:
- Non-identification AI systems
- Businesses not collecting biometric identifiers

## Strategic Positioning

This law strengthens biometric protections within Colorado’s privacy regime and creates heightened compliance risk for AI systems performing identity recognition.

Strong crossover with:
- AI facial recognition
- Identity verification systems
- Employment biometric tracking
- Security technology deployments

Position as a biometric governance and risk mitigation compliance program.

## Internal Notes

Primary compliance focus areas:

1. Biometric Data Inventory
2. Consent & Notice Controls
3. Data Retention & Destruction Policy
4. Vendor & Processor Safeguards
5. Data Protection Assessment
6. Incident Response & Breach Handling
7. Enforcement Defense File

High enforcement leverage due to per-consumer violation structure.