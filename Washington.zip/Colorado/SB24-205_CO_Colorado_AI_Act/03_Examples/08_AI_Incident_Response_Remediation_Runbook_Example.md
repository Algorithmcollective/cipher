Name this file: CO_8_High-Risk_AI_Incident_and_Remediation_Log_EXAMPLE_FrontRange.md

Company: FrontRange Finance LLC  
Jurisdiction: Colorado  
Document: High‑Risk AI Incident, Complaint & Remediation Log – Example Entry  
Owner: AI Risk & Compliance Office  
Effective Date: 02/01/2026  

> Example only – illustrates how a Colorado high‑risk AI incident might be documented for a CreditScoreX underwriting issue involving potential algorithmic discrimination in auto lending.

---

## 1. Incident & Complaint Log (Summary Row)

| Incident ID    | Date Opened | Source                                | High‑Risk System               | Consequential Decision Type | Summary of Allegation / Issue                                                                 | Interim Risk Rating | Owner                 |
|----------------|-------------|----------------------------------------|--------------------------------|-----------------------------|------------------------------------------------------------------------------------------------|---------------------|-----------------------|
| INC‑2026‑004   | 01/15/2026  | Customer complaint + monitoring alert | HR‑AI‑001 CreditScoreX Engine | Auto credit underwriting    | Alleged lower approval rates and worse pricing for applicants from predominantly Latino ZIPs. | High                | Director, AI Risk Ops |

---

## 2. Detailed Incident Record

### 2.1 Core Details

- Incident ID: INC‑2026‑004  
- Date Opened: 01/15/2026  
- High‑Risk AI System: HR‑AI‑001 – CreditScoreX Decision Engine  
- Business Area / Use Case: Auto Finance – Retail Underwriting  
- Consequential Decision Type: Credit approval and pricing (APR and term)  
- Jurisdictions Impacted: Colorado (focus), plus preliminary signal from a multi‑state portfolio slice  
- Source of Issue:  
  - Initial customer complaint (denied applicant) routed via Customer Care  
  - Same week, quarterly fairness monitoring flagged elevated decline and higher APR patterns in certain ZIP clusters

### 2.2 Description & Scope

- Description of Allegation or Issue:  
  A Colorado auto‑finance applicant from a predominantly Latino neighborhood was declined despite a credit profile they believed should qualify. They alleged discriminatory treatment based on location and ethnicity. Internal fairness monitoring in Q4 2025 separately flagged higher decline rates and worse pricing for applications from several ZIP codes with high percentages of Latino residents.

- Time Period of Impacted Decisions:  
  10/01/2025 – 01/15/2026 (initial review window)

- Population Potentially Affected:  
  Approximately 2,150 Colorado applications scored by HR‑AI‑001 in the identified ZIP clusters during the review window; subset estimated at ~600 borderline decisions potentially most affected.

- Protected Classes Potentially Implicated (if known or suspected):  
  - National origin / ethnicity (Latino / Hispanic)  
  - Potential indirect linkage to race via geographic and demographic correlations

### 2.3 Initial Triage & Containment

- Initial Triage Date: 01/16/2026  
- Initial Reviewer / Team: Director, AI Risk Ops; Senior Fair Lending Analyst; Product Owner – Auto Finance  
- Immediate Actions Taken:  
  - Implemented mandatory human review override for all borderline declines in the flagged ZIP clusters.  
  - Paused rollout of the most recent CreditScoreX model parameter update for Colorado until investigation completed.  
- Interim Risk Rating and Rationale: High – involves potential fair‑lending–style discrimination in credit decisions, across a non‑trivial population and time window.

---

## 3. Investigation & Analysis

### 3.1 Investigation Steps

- Data and Period Reviewed:  
  - All auto‑finance applications scored by HR‑AI‑001 in Colorado from 10/01/2025 – 01/15/2026.  
  - Stratified comparison across ZIP codes with varying proportions of Latino residents.  
  - Focus subset on applicants with similar credit scores and DTI profiles.

- Methods Used:  
  - Selection‑rate and outcome comparisons across geographic and demographic proxies.  
  - Adverse‑impact style ratios using available proxy methods for ethnicity.  
  - Side‑by‑side comparison of decisions under prior vs current model parameterization.  
  - Review of vendor documentation for most recent model update.

- Parties Involved:  
  - AI Risk & Compliance  
  - Fair Lending / Legal  
  - Data Science (Model Governance)  
  - Business Line Owner – Auto Finance  
  - CreditScoreX vendor contact for model details.

### 3.2 Findings

- Was algorithmic discrimination identified?  
  - Yes – investigation concluded that the model, as configured and weighted in the October 2025 parameter update, contributed to materially higher decline rates and worse pricing for applicants from certain ZIP codes highly correlated with Latino populations, beyond what would be expected from credit risk alone.

- Summary of Key Findings:  
  - ZIP‑level variables and certain credit attributes with strong geographic correlation were given increased weight in the October 2025 configuration.  
  - For similarly situated applicants (similar scores, income, DTI), applicants from the flagged ZIP clusters experienced measurably lower approval rates and higher APRs.  
  - Adverse‑impact style ratios based on ethnicity proxies fell below internal thresholds that trigger concern.  
  - The vendor’s generic fairness documentation did not specifically analyze these geographic patterns in the FrontRange portfolio.

- Impact Assessment:  
  - Approximately 260 Colorado applicants likely received a decline or materially worse pricing than comparable peers during the review window.  
  - Impact includes lost access to auto credit, higher cost of credit, and potential reputational and regulatory exposure for FrontRange.

---

## 4. Remediation Plan & Actions

### 4.1 Remediation Decisions

- Decision on System Status:  
  - Continue using CreditScoreX in Colorado with immediate configuration changes and strengthened monitoring; maintain manual review overlay for borderline cases until post‑remediation validation is complete.

- Remediation Actions:

  - Action 1: Reduce or remove problematic ZIP‑correlated variables and adjust weights to limit geographic proxies.  
    - Owner: Head of Model Governance  
    - Target Date: 02/10/2026  
    - Completed: 02/08/2026  

  - Action 2: Implement additional fairness tests focused on geographic and ethnicity‑proxy patterns in Colorado portfolios, with automated alerts.  
    - Owner: Fair Lending Analytics Lead  
    - Target Date: 02/28/2026  
    - Completed: [In progress]  

  - Action 3: Update vendor documentation requirements and contract language to require portfolio‑specific fairness analysis for major configuration changes.  
    - Owner: Vendor Management / Legal  
    - Target Date: 03/15/2026  
    - Completed: [Planned]

### 4.2 Consumer & Stakeholder Handling

- Consumer‑Facing Remediation:  
  - Offer reconsideration to identified affected applicants where appropriate, including the original complainant.  
  - For approved reconsiderations, provide updated terms reflecting the remediated model outcome and/or additional manual underwriting.

- Communications with Vendor / Developer:  
  - 01/22/2026 – Notice sent to CreditScoreX outlining the issue, investigation findings, and required configuration and documentation changes for Colorado use.  
  - Vendor agreed to support additional fairness diagnostics and participated in revising the configuration.

---

## 5. Notifications to Colorado Attorney General & Others

- Does this incident involve a high‑risk AI system that has caused algorithmic discrimination affecting Colorado consumers?  
  - Yes.

- Date of Determination: 02/01/2026  

- Deadline for Notice to Colorado Attorney General (90 days from discovery): 04/30/2026  
- Date Notice Sent to Colorado Attorney General: 02/20/2026  
- Method: Written notice via designated AG AI‑reporting channel and certified letter.  
- Summary of Information Provided (high‑level):  
  - Description of the CreditScoreX use case in Colorado auto‑finance underwriting.  
  - Nature and scope of the algorithmic discrimination identified.  
  - Steps taken to mitigate and remediate the impact, including model changes and reconsideration offers.  
  - Plan for enhanced monitoring and governance going forward.

Additional notifications:

- Date Notice Sent to Developer / Vendor: 01/22/2026  
- Other Regulators / Oversight Bodies Notified:  
  - None at this stage; Fair Lending Legal to reassess after post‑remediation validation.

---

## 6. Closure & Lessons Learned

- Date Incident Closed: 05/15/2026 (projected for example)  
- Final Risk Rating: Medium (post‑remediation, with enhanced monitoring in place)

- Final Outcome Summary:  
  - Root cause traced to a configuration change increasing the influence of ZIP‑correlated variables without adequate Colorado‑specific fairness review.  
  - Model was re‑configured, additional fairness monitoring was implemented, and affected applicants were offered reconsideration where feasible.  
  - Required notice was provided to the Colorado Attorney General within the 90‑day window.

- Policy / Process / Control Updates:  
  - Updated AI risk management policy to require state‑specific fairness checks before enabling configuration changes for high‑risk AI systems.  
  - Strengthened vendor contract language to mandate timely disclosure of fairness risks and cooperation with portfolio‑specific testing.  
  - Added new control that any fair‑lending‑relevant configuration change must be signed off by Fair Lending Legal and AI Risk.

- Added to Training or Awareness Materials?  
  - Yes – summarized as a case study in annual AI risk and fair‑lending training for underwriting, data science, and vendor‑management teams.

- Approval of Closure:  
  - Name / Title: Jamie Rivera, Chief Risk Officer  
  - Date: 05/15/2026
