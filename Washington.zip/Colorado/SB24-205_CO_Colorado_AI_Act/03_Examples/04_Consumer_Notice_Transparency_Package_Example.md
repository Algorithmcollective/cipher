# Colorado High‑Risk AI Consumer Notice & Adverse Decision Template

**Company:** FrontRange Finance LLC  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**System Name:** CreditScoreX Decision Engine  
**Decision Type:** Personal loan approval decision  
**Channel:** Email + secure portal message  
**Version:** v1.0  
**Last Updated:** 2026-02-15

> **Purpose:** Provide a standard notice to Colorado consumers when a high‑risk AI system is used to make or substantially influence a loan approval decision, and, in the case of a decline, explain the main reasons, data sources, and how to seek correction or human review.

---

## 1. General AI Use Notice (Pre‑Decision or At Decision)

> **How We Use Automated Systems in Decisions**  
>  
> FrontRange Finance LLC uses automated tools, including artificial intelligence (“AI”) systems, to help make or substantially influence certain decisions about our customers, such as personal loan approvals and credit line increases. These tools analyze information you provide and information we obtain from other sources to help us make consistent and timely decisions.  
>  
> Human team members oversee these tools and may review and, where appropriate, change the decisions they support.

---

## 2. Adverse Decision Notice (Core Body)

> **Subject:** Important information about your personal loan application  
>  
> Dear Jordan Smith,  
>  
> We have completed our review of your **personal loan application dated 2026‑02‑10**. Based on this review, we are **unable to approve** your request at this time.  
>  
> An automated tool, which includes artificial intelligence (“AI”), was used to help make or substantially influence this decision. Human reviewers oversee this tool and may correct errors or override decisions where appropriate.

---

## 3. Principal Reasons for the Decision

> **Why this decision was made**  
>  
> The main factors that led to this decision include:  
> - Your recent credit history shows multiple late payments in the past 12 months.  
> - Your current monthly debt payments are high compared to your stated income.  
> - Your total available credit is heavily utilized across several accounts.  
>  
> The automated tool weighed these and other factors together. No single factor was the only reason for this outcome.

---

## 4. Data Types and Sources Used

> **What information the AI system used**  
>  
> To support this decision, the AI system processed information from:  
> - The details you provided to us in your application and supporting documents.  
> - Our existing records about your relationship with us, if any.  
> - Third‑party sources, where allowed by law, including major credit bureaus.  
>  
> If you would like more information about the types of data we used for this decision, you can contact us using the details below.

---

## 5. How to Correct Your Information

> **How to correct your information**  
>  
> If you believe any of the information we used about you is wrong or incomplete, you can ask us to review and correct it. To do this, please contact us at:  
>  
> - Email: corrections@frontrangefinance.com  
> - Phone: 1‑800‑555‑0123  
> - Secure portal: https://portal.frontrangefinance.com/corrections  
>  
> When you contact us, please tell us what you believe is incorrect and, if possible, provide documents to support the correction. We will review your request and let you know the outcome.

---

## 6. How to Request Human Review / Appeal

> **How to request human review of this decision**  
>  
> You may ask us to have a qualified person review this decision. A human reviewer will look at your information, consider any updates or corrections you provide, and decide whether to confirm or change the outcome.  
>  
> To request a human review or appeal:  
> - Contact us within **30 days** of the date of this notice using one of the following:  
>   - Email: appeals@frontrangefinance.com  
>   - Phone: 1‑800‑555‑0456  
>   - Secure portal: https://portal.frontrangefinance.com/appeals  
> - Please include your full name, your application ID (FR‑PL‑2026‑10427), and any information you would like us to consider.  
>  
> We will confirm we received your request and aim to complete our review within **15 business days**. We will then tell you in writing whether the decision has been confirmed or changed, and why.

---

## 7. Contact Details and Additional Information

> **Questions or complaints**  
>  
> If you have questions about this notice, how we use automated tools in decisions, or how your information is handled, you can contact:  
>  
> - Name: Casey Lopez  
> - Role: Director of Customer Care  
> - Email: compliance@frontrangefinance.com  
> - Phone: 1‑800‑555‑0987  
>  
> You can also learn more about your rights and our obligations under Colorado’s AI law in our AI and data‑use statement at: https://www.frontrangefinance.com/ai‑and‑data‑use.

