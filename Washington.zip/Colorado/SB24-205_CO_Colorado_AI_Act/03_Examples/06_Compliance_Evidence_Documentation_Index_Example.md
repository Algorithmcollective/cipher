# Colorado High‑Risk AI Compliance Evidence Index

**Company:** FrontRange Finance LLC  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**Scope:** High‑Risk AI Systems (Deployers)  
**Owner:** Jamie Rivera, Chief Risk Officer  
**Last Updated:** 2026-02-20

> **Purpose:** Provide a single index of documents and records that demonstrate FrontRange Finance LLC’s compliance with the Colorado AI Act for high‑risk AI systems, including inventory, governance, assessments, notices, appeals, vendor documentation, and monitoring evidence.

---

## 1. System Inventory & Classification (Deliverable 1)

- **Document:** Colorado High‑Risk AI System Inventory & Classification  
- **File / Location:**  
  - `\\CO_AI_Act\01_Inventory\CO_1_High_Risk_AI_Inventory_MASTER.xlsx`  
- **Contents:** List of all high‑risk AI systems (e.g., CreditScoreX Decision Engine), sectors (finance, employment), decision types, deployer role, Colorado‑in‑scope flag, retirement and retention dates.

---

## 2. Governance & Risk Management Policy (Deliverable 2)

- **Document:** High‑Risk AI Governance & Risk Management Policy (Colorado)  
- **File / Location:**  
  - `\\CO_AI_Act\02_Governance\CO_2_High_Risk_AI_Governance_POLICY_MASTER.docx`  
- **Contents:** Roles (CRO, Legal, business owners), lifecycle governance, inventory/approval process, risk assessments, monitoring, documentation and annual review requirements.

---

## 3. System‑Level Impact & Risk Assessments (Deliverable 3)

For each high‑risk AI system:

| System Name               | System ID  | Latest Assessment File                                                        | Assessment Date | Next Review Due |
|---------------------------|-----------|-------------------------------------------------------------------------------|-----------------|-----------------|
| CreditScoreX Decision Engine | HR‑AI‑001 | `\\CO_AI_Act\03_Assessments\HR-AI-001_CreditScoreX_Assessment_2026-02-15.docx` | 2026-02-15      | 2027-02-15      |

- **Template:** `CO_3_High_Risk_AI_Impact_Assessment_MASTER.md`  
- **Typical Location Pattern:**  
  - `\\CO_AI_Act\03_Assessments\{{SYSTEM_ID}}_{{SYSTEM_NAME}}_Assessment_{{DATE}}.docx`

---

## 4. Consumer Notices & Adverse Decision Templates (Deliverable 4)

- **Document:** Colorado High‑Risk AI Consumer Notice & Adverse Decision Template  
- **Template Location:**  
  - `\\CO_AI_Act\04_Notices\CO_4_High_Risk_AI_Consumer_Notice_TEMPLATE_MASTER.docx`  

- **System‑Specific Implementations:**  
  - CreditScoreX Decision Engine:  
    - `\\CO_AI_Act\04_Notices\CreditScoreX_Loan_Decline_Notice_Template_v1.0.docx`

- **Evidence Samples:**  
  - PDFs of loan decline emails and portal messages for Colorado applicants (last 12 months):  
    - `\\CO_AI_Act\04_Notices\Samples\CreditScoreX_Decline_Examples_2025.pdf`

---

## 5. Appeals & Human Review Procedure (Deliverable 5)

- **Document:** Colorado High‑Risk AI Appeal & Human Review / Oversight Procedure  
- **File / Location:**  
  - `\\CO_AI_Act\05_Appeals\CO_5_High_Risk_AI_Appeal_and_Human_Review_PROCEDURE_MASTER.docx`  

- **Related Evidence:**  
  - **Appeals Log:**  
    - `\\CO_AI_Act\05_Appeals\CreditScoreX_Appeals_Log_2025.xlsx`  
  - **Example Case Files:**  
    - `\\CO_AI_Act\05_Appeals\Cases\FR-PL-2025-08731_Appeal_File.zip` (includes applicant request, reviewer notes, final response)

---

## 6. Vendor Due Diligence & Contracts

For each vendor‑provided high‑risk AI system:

| System Name               | Vendor         | Due‑Diligence File                                                    | Contract / Addendum                                                   | Last Vendor Review |
|---------------------------|----------------|------------------------------------------------------------------------|------------------------------------------------------------------------|--------------------|
| CreditScoreX Decision Engine | CreditScoreX Inc. | `\\CO_AI_Act\06_Vendors\CreditScoreX\Due_Diligence_QA_2025-05.pdf`       | `\\CO_AI_Act\06_Vendors\CreditScoreX\CO_SA_Addendum_Executed_2025.pdf` | 2025-11-30         |

- **Folder Pattern:**  
  - `\\CO_AI_Act\06_Vendors\{{VENDOR_NAME}}\`  
- **Contents:** Vendor security/privacy questionnaires, AI fairness documentation, SB 24‑205 cooperation clauses, DPAs and main MSA.

---

## 7. Monitoring, Incidents, and Remediation

- **Monitoring Reports Folder:**  
  - `\\CO_AI_Act\07_Monitoring\Reports\`  
    - Example: `CreditScoreX_Quarterly_Fairness_Report_Q4_2025.pdf`  

- **Incident Log:**  
  - `\\CO_AI_Act\07_Monitoring\Incidents_Log.xlsx`  

- **Remediation Records:**  
  - `\\CO_AI_Act\07_Monitoring\Remediation\HR-AI-001_CreditScoreX_Remedation_2025-12.docx`  

Each record captures: incident description, system impacted, affected groups, root cause analysis, actions taken, dates opened/closed.

---

## 8. Training & Awareness

- **AI Governance / Colorado AI Act Training Materials:**  
  - `\\CO_AI_Act\08_Training\CO_AI_Act_Overview_Training_2025-10.pptx`  

- **Attendance Records:**  
  - `\\CO_AI_Act\08_Training\Attendance_Records_2025-10.xlsx`  

Covers lending leadership, risk, compliance, data science, and relevant IT staff.

---

## 9. Retention & Archived Systems

- **Retired Systems Register:**  
  - `\\CO_AI_Act\09_Archive\Retired_Systems_Register.xlsx`  
  - Example entry:  
    - System: LegacyRules Loan Scoring Tool (HR‑AI‑0003)  
    - Retirement Date: 2025-12-31  
    - Last Decision Date: 2025-12-15  
    - Retention End Date: 2028-12-31  
    - Archive Location: `\\CO_AI_Act\09_Archive\LegacyRules_Loan_Scoring_Archive_2025.zip`

- **Archive Locations:**  
  - Read‑only compressed folders with frozen documentation, configs, and logs for retired systems.

---

## 10. Index Maintenance

- This index is reviewed and updated at least annually, and whenever:  
  - A new high‑risk AI system is added or an existing one is retired.  
  - Core documents (governance policy, templates, contracts) are revised.  
  - New incident or monitoring report types are introduced.

**Last Index Review:** 2026-02-20  
**Reviewed By:** Morgan Patel, Associate General Counsel – Consumer Products
