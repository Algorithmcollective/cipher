# Colorado High‑Risk AI Impact & Risk Assessment

**Company:** FrontRange Finance LLC  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**System Name:** CreditScoreX Decision Engine  
**System ID (Inventory Reference):** HR‑AI‑001  
**Assessment Version:** v1.0  
**Assessment Date:** 2026-02-15  
**Prepared By:** Alex Kim, Senior Risk Analyst  
**Reviewed By (Legal / Compliance):** Morgan Patel, Associate General Counsel  
**Approved By (Governance Owner):** Jamie Rivera, Chief Risk Officer

> **Purpose:** Document how this high‑risk AI system is used to support consequential decisions about Colorado consumers, the data and logic it relies on, the risks of algorithmic discrimination and other harms, and the safeguards, testing, and monitoring implemented to comply with the Colorado AI Act.

---

## 1. System Overview

- **Business Domain:** Lending – Consumer Credit  
- **Primary Use Case:** Automated unsecured personal loan approvals for Colorado residents  
- **Consequential Decisions Supported:** Approve / decline personal loan applications; set initial credit line  
- **Deployer / Developer Role:** Deployer (vendor model with FrontRange‑configured rules and thresholds)  
- **Colorado Consumers in Scope:** Colorado residents applying for unsecured personal loans via web and mobile channels  
- **Estimated Annual Decision Volume (CO):** ~25,000 decisions/year

---

## 2. Data and Model Description

### 2.1 Input Data

- **Data Categories Used:**  
  - Identity and contact (name, address, email, phone)  
  - Financial (income, existing debt obligations, bank account history)  
  - Credit history (credit bureau scores, delinquencies, inquiries, utilization)  
  - Employment (employment status, tenure, employer type)  

- **Sources:**  
  - Internal: online loan application forms, existing customer records  
  - External / Third‑Party: major credit bureaus, fraud‑screening vendor  

- **Potential Proxy or Sensitive Features:**  
  - ZIP code (potential proxy for race and socioeconomic status)  
  - Length of employment and employer type (potential proxy for age or disability in some cases)

### 2.2 Model / Logic

- **Model Type / Approach:** Gradient‑boosted decision tree model provided and maintained by vendor  
- **Vendor / Platform:** CreditScoreX Cloud Platform  
- **Key Outputs:** Risk score between 0 and 1; “Approve / Refer / Decline” recommendation  
- **Human Interaction:**  
  - Scores above 0.7 → automatic “Approve” (subject to fraud checks)  
  - Scores between 0.5–0.7 → “Refer” for human underwriter review  
  - Scores below 0.5 → auto “Decline”, with option for customer‑initiated appeal

---

## 3. Risk Identification

### 3.1 Algorithmic Discrimination Risks

- **Risk 1:** Disparate approval/decline rates by race and ethnicity  
  - Potentially affected groups: Black, Hispanic, Native American applicants  
  - Drivers: correlation between ZIP code, income, and historical credit bureau data; historical bias embedded in prior lending decisions  

- **Risk 2:** Age‑related discrimination in credit decisions  
  - Potentially affected groups: older applicants (55+) and very young adults  
  - Drivers: employment history length, credit history length, and debt‑to‑income patterns  

- **Risk 3:** Indirect discrimination against applicants with disabilities  
  - Potentially affected groups: applicants with inconsistent employment patterns due to health or disability  
  - Drivers: heavy weighting of employment stability and gaps without context

### 3.2 Other Material Risks

- **Privacy and data misuse risks:**  
  - Unauthorized access to detailed credit and income data; over‑retention of rejected applicants’ data.  

- **Security and misuse risks:**  
  - Potential adversarial manipulation of input fields (false income, synthetic identities).  

- **Transparency / explainability risks:**  
  - Difficulty explaining individual decline decisions in plain language to consumers.  

- **Operational / reliability risks:**  
  - Model performance drift if macroeconomic conditions change significantly (e.g., recession).

---

## 4. Safeguards and Controls

### 4.1 Design and Data Safeguards

- **Feature selection / engineering controls:**  
  - Geographical inputs (ZIP code) bucketed into broad regions to reduce granularity.  
  - No explicit use of protected‑class variables (race, religion, etc.).  

- **Data quality checks:**  
  - Automated validation of required fields, format checks, and basic range checks on income and age.  
  - Monthly reconciliation between application records and bureau pulls to detect data feed issues.  

- **Proxy‑mitigation steps:**  
  - Periodic analysis of ZIP‑code‑bucket contribution to decisions; thresholds adjusted if strong proxy effects detected.

### 4.2 Process and Governance Safeguards

- **Human oversight / review points:**  
  - All “Refer” cases reviewed by trained underwriters with authority to override recommendations.  
  - Random sample (5%) of auto‑declines reviewed monthly.  

- **Override policies and escalation paths:**  
  - Underwriters can override if they document rationale; escalations to Team Lead for edge cases.  

- **Access control and change‑management procedures:**  
  - Only designated risk and IT staff may change thresholds; all changes logged and approved by Governance Owner.

### 4.3 Consumer‑Facing Safeguards

- **Notices (if applicable):**  
  - Adverse‑action notices include: statement that an automated system contributed to the decision, key reasons (e.g., high utilization, short credit history), and instructions for requesting human review.  

- **Appeal / human review mechanisms:**  
  - Consumers may request human review via phone or secure portal within 30 days of decline.  
  - Appeal outcomes logged and compared to original model outputs.  

- **Channels for complaints or questions:**  
  - Customer service hotline and secure portal messaging; complaints tagged as “AI/decisioning” for tracking.

---

## 5. Testing and Evaluation

- **Testing Period Covered:** 2025-01-01 to 2025-12-31  
- **Population / dataset used for evaluation:** All Colorado unsecured personal loan applications in 2025 (n ≈ 22,800)  

- **Key fairness / disparity metrics evaluated:**  
  - Approval and decline rates by race/ethnicity proxies and ZIP‑code buckets.  
  - False‑positive and false‑negative rates by age group.  
  - Override rates and appeal outcomes by demographic segments.  

- **Key performance metrics:**  
  - Model AUC: 0.82 overall.  
  - Default rate within 12 months for approved loans: 3.1% (within risk appetite).  

- **High‑level results:**  
  - Black and Hispanic applicants had approval rates 6–8 percentage points lower than the overall average, even controlling for credit score bands.  
  - Older applicants (55+) showed slightly higher decline rates, but differences were within pre‑defined tolerance bands after adjusting for income and credit history length.  
  - Appeals resulted in reversal of 9% of initial declines, concentrated in borderline score ranges (0.45–0.55).  

- **Link to detailed report (if separate):**  
  - `\\risk\CO_AI_Act\assessments\CreditScoreX_Fairness_Evaluation_2025.pdf`

---

## 6. Residual Risk and Mitigation Plan

### 6.1 Residual Risk Rating

- **Residual risk of algorithmic discrimination:** Medium  
- **Rationale:**  
  - Observed approval‑rate disparities by race/ethnicity exceed internal target thresholds in some credit‑score bands, but mitigation measures (bucketed geography, human review of referrals, appeal process) reduce severity. Further mitigations are planned.

### 6.2 Mitigation Actions

| Action ID | Mitigation Description                                                                 | Owner                 | Due Date   | Status      |
|----------|-----------------------------------------------------------------------------------------|----------------------|-----------|------------|
| A‑01     | Re‑train model with reduced reliance on geographic and employment‑stability features.  | Head of Data Science | 2026-04-30 | Planned     |
| A‑02     | Increase random review sample of auto‑declines from 5% to 10% for six months.          | Head of Underwriting | 2026-03-01 | In Progress |
| A‑03     | Update adverse‑action/appeal notice to more clearly explain human‑review option.       | Compliance Director  | 2026-02-28 | In Progress |
| A‑04     | Add quarterly fairness review meeting (Risk, Legal, Lending) to review metrics/actions.| Chief Risk Officer   | 2026-03-31 | Planned     |

---

## 7. Monitoring Plan

- **Monitoring cadence:** Quarterly for fairness metrics; monthly for basic performance and override rates.  
- **Key indicators tracked:**  
  - Approval / decline rates by race/ethnicity proxies, age group, and ZIP‑code bucket.  
  - Override and appeal rates and outcomes by group.  
  - Default rates within 12 months by group for approved loans.  
  - Volume and nature of AI‑related complaints.  

- **Responsibility for monitoring:**  
  - Primary: Risk Analytics team  
  - Support: Lending Operations, Compliance  

- **Triggers for re‑assessment or escalation:**  
  - Any group’s approval rate falling more than 10 percentage points below overall average, controlling for credit score.  
  - Significant model re‑training or threshold changes.  
  - Regulator inquiry or material increase in AI‑related complaints.

---

## 8. Assessment Summary and Sign‑Off

- **Overall conclusion:**  
  - The CreditScoreX Decision Engine may continue operating for Colorado consumers, subject to completion of the mitigation actions in Section 6.2 and ongoing monitoring described in Section 7.  

- **Conditions / limitations for use:**  
  - Must not change model version, feature set, or score thresholds without updating this assessment.  
  - Quarterly fairness reviews must be documented; any material deterioration triggers re‑assessment.

**Prepared By:**  
- Name: Alex Kim  
- Role: Senior Risk Analyst  
- Date: 2026-02-15  

**Reviewed By (Legal / Compliance):**  
- Name: Morgan Patel  
- Role: Associate General Counsel  
- Date: 2026-02-16  

**Approved By (Governance Owner):**  
- Name: Jamie Rivera  
- Role: Chief Risk Officer  
- Date: 2026-02-17
