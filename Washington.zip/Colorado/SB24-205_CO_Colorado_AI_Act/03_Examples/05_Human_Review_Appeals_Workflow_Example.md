# Colorado High‑Risk AI Appeal & Human Review / Oversight Procedure

**Company:** FrontRange Finance LLC  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**Applies To System(s):** CreditScoreX Decision Engine (personal loans)  
**Procedure Owner:** Jamie Rivera, Chief Risk Officer  
**Effective Date:** 2026-02-15  
**Last Reviewed:** 2026-02-15

> **Purpose:** Define how FrontRange Finance LLC provides human review and oversight for personal‑loan decisions supported by the CreditScoreX Decision Engine, including how Colorado consumers can appeal, how reviewers handle cases, and how results are logged and monitored, consistent with the Colorado AI Act.

---

## 1. Scope

This procedure applies to:

- All **personal‑loan approval and decline decisions** for Colorado residents where the CreditScoreX Decision Engine is used to make or substantially influence the decision.  
- All **appeals** or review requests submitted by affected applicants in relation to those decisions.  
- All staff designated as **loan‑decision human reviewers** (underwriters and team leads).

---

## 2. Roles

- **Appeals & Review Coordinator:** Risk Operations Manager  
  - Monitors the “AI Appeals” inbox and portal queue.  
  - Assigns cases to underwriters, tracks timelines, and ensures responses are sent.

- **Human Reviewers:** Senior Underwriters in Consumer Lending  
  - Conduct substantive review of appealed decisions and may confirm, modify, or overturn AI‑supported outcomes.

- **Legal / Compliance:** Associate General Counsel – Consumer Products  
  - Advises on complex or high‑risk cases and reviews appeal patterns quarterly.

- **Governance Owner:** Chief Risk Officer  
  - Reviews appeal statistics and outcomes as part of overall AI oversight.

---

## 3. How Consumers Request Human Review / Appeal

1. **Channels:** Applicants may request human review using:  
   - Email: appeals@frontrangefinance.com  
   - Phone: 1‑800‑555‑0456 (ask for “AI decision review”)  
   - Secure portal: https://portal.frontrangefinance.com/appeals  

2. **Required information:**  
   - Full name and contact details.  
   - Application ID (e.g., FR‑PL‑2026‑10427).  
   - Short explanation of why they believe the decision may be wrong or incomplete, plus any supporting documents (optional).

3. **Time window:**  
   - Appeals must normally be submitted within **30 days** of the date on the decline notice.

4. **Acknowledgment:**  
   - Risk Operations sends an acknowledgment within **3 business days**, confirming receipt and an expected review timeline of **15 business days**.

---

## 4. Human Review Process

For each appeal:

1. **Case assignment:**  
   - Risk Operations assigns the case to a Senior Underwriter who was **not** the person who handled any prior manual review of that application.

2. **Information gathering:**  
   - Reviewer accesses:  
     - Original application and documents.  
     - CreditScoreX score and recommendation and decision log.  
     - Reasons listed in the adverse‑action notice.  
     - Any new information or corrections from the applicant (e.g., updated income proof).

3. **Substantive review:**  
   - Reviewer checks:  
     - Whether input data (income, debts, employment) was accurate and complete.  
     - Whether any obvious anomalies or data‑feed issues occurred.  
     - Whether lending policy and risk thresholds are correctly applied.  
   - Reviewer is empowered to **override** or modify the AI‑supported decision if warranted.

4. **Decision options:**  
   - **Confirm** decline (no change).  
   - **Modify** (e.g., approve for a lower amount, require a co‑signer).  
   - **Overturn** (change from decline to approval under standard terms).

5. **Timeframe for completion:**  
   - Human review is normally completed within **15 business days** from acknowledgment, unless additional information is requested from the applicant.

---

## 5. Communication Back to the Consumer

- Risk Operations sends a written response via email and the secure portal that:  
  - States the final outcome (confirmed, modified, overturned).  
  - Explains in plain language the main reasons for the final decision.  
  - Notes any corrections or new information that affected the outcome.  
  - Reminds the applicant how to raise further concerns or complaints if needed.

---

## 6. Logging, Metrics, and Oversight

For each appeal, the following is recorded in the **High‑Risk AI Appeals Log – CreditScoreX**:

- Applicant name and application ID.  
- Date appeal received and date acknowledged.  
- Reviewer assigned and completion date.  
- Outcome (confirmed / modified / overturned).  
- High‑level reason for outcome (e.g., “data error corrected”, “policy correctly applied”).  

On a **quarterly** basis, the Chief Risk Officer and Compliance review:

- Number of appeals and appeal rate vs total declines.  
- Percentage of decisions overturned or modified.  
- Any patterns by applicant segment that may indicate algorithmic discrimination or process issues.  
- Required changes to the model, lending policy, notices, or training.

---

## 7. Exceptions and Safety Constraints

The CreditScoreX Decision Engine does not have safety‑based limitations on human review; all declined applications for Colorado residents are eligible for appeal under this procedure.

---

## 8. Review of this Procedure

This procedure is reviewed **annually in February**, and sooner if:

- The CreditScoreX model, thresholds, or decision workflow are materially changed.  
- Colorado AI law or related guidance changes in a way that affects appeal rights.  
- Monitoring shows significant changes in appeal volume or overturn rates.

Updates are approved by the Chief Risk Officer and Associate General Counsel – Consumer Products before implementation.
