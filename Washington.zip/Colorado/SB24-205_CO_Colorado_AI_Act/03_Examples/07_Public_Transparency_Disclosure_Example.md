Name this file: CO_7_Public_High-Risk_AI_Transparency_Statement_EXAMPLE_FrontRangeFinance.md

Company: FrontRange Finance LLC  
Jurisdiction: Colorado  
Document: Public Statement on High-Risk AI Systems  
Effective Date: 02/01/2026  
Contact: Compliance & AI Governance Office, compliance@frontrangefinance.com, (303) 555‑0199  

> This statement is intended to satisfy Colorado requirements to provide a clear, publicly available summary of the high‑risk AI systems we deploy in Colorado, how we manage risks of algorithmic discrimination, and the nature, source, and extent of information we use. [web:16][web:127]

---

## 1. Overview of Our Use of High‑Risk AI

FrontRange Finance LLC uses certain high‑risk artificial intelligence systems to help make or substantially influence consequential decisions about individuals, including auto finance credit decisions and credit‑line management for Colorado residents. [web:124][web:128]  
These systems support, but do not replace, human decision‑making, and we maintain documented processes to identify, monitor, and address potential algorithmic discrimination. [web:16][web:81]

---

## 2. High‑Risk AI Systems We Deploy

The following high‑risk AI systems are currently deployed in Colorado:

| System Name                       | Purpose / Decision Type                                     | Area                  | Developer / Vendor      | Colorado In‑Scope Since |
|-----------------------------------|-------------------------------------------------------------|-----------------------|-------------------------|-------------------------|
| CreditScoreX Decision Engine      | Automated credit underwriting and pricing recommendations   | Auto Finance Lending  | CreditScoreX Inc.       | 07/2025                 |
| Delinquency Risk Tiering Model    | Predictive risk tiering for collections treatment strategies| Servicing / Collections | Internal (FrontRange Data Science) | 10/2025        |

These systems qualify as “high‑risk AI systems” because they are used to make or substantially influence consequential decisions about access to credit and related financial services for Colorado consumers. [web:16][web:124]

---

## 3. How We Manage Algorithmic Discrimination Risk

FrontRange Finance maintains an AI risk management program designed to use reasonable care to protect consumers from known or reasonably foreseeable risks of algorithmic discrimination arising from our high‑risk AI systems. [web:16][web:17]

Key elements of our program include:

- A written AI governance and risk management policy aligned with recognized frameworks such as the NIST AI Risk Management Framework. [web:81][web:122]  
- System‑specific impact assessments for each high‑risk AI system completed before deployment, refreshed at least annually, and updated within 90 days of intentional and substantial model modifications. [web:16][web:81]  
- Pre‑deployment and periodic testing to evaluate performance, monitor outcome patterns, and detect potential disparate impacts on protected classes where feasible. [web:124][web:54]  
- Human review for adverse consequential decisions where technically feasible and appropriate, including escalation paths for special circumstances. [web:81][web:118]  
- Training and guidance for relevant staff on responsible AI use, fair lending and anti‑discrimination standards, and incident escalation procedures. [web:114][web:122]

If we determine that a deployed high‑risk AI system has caused or is reasonably likely to have caused algorithmic discrimination, we will investigate, take appropriate corrective action, and notify the Colorado Attorney General and other required parties within applicable timeframes. [web:16][web:126]

---

## 4. Information We Collect and Use

For our high‑risk AI systems, we collect and use information relevant to the credit and servicing decisions being made, which may include: [web:124][web:118]

- Identification and contact information, such as name, address, date of birth, and contact details.  
- Application and credit information, such as stated income, employment details, vehicle and dealer information, requested loan amount, credit bureau attributes, and prior credit history.  
- Internal account and servicing data, such as payment history, delinquency status, and prior interactions with FrontRange Finance.  

We do not design our systems to intentionally use protected characteristics such as race, color, religion, national origin, sex, disability, or other characteristics protected under Colorado or federal law, except where permitted or required by law (for example, in fairness testing or compliance analysis). [web:16][web:127]  
We retain data, model documentation, and impact assessments for at least the minimum periods required by the Colorado AI Act and applicable financial services record‑retention rules. [web:81][web:120]

---

## 5. Consumer Notices, Rights, and Appeals

When we use a high‑risk AI system to make or substantially influence a consequential decision, such as approving or denying an auto finance application, we provide clear notice that an AI‑based tool is used in our decision‑making process. [web:16][web:109]  
If an outcome is adverse (for example, a credit denial or less favorable terms), we provide information about the principal reasons for the decision, how the AI system contributed, the types of data used, how to correct inaccurate data where applicable, and how to request review, including human review where technically feasible. [web:124][web:81]

Consumers can contact the Compliance & AI Governance Office using the contact details at the top of this statement to ask questions about our use of high‑risk AI, or to request information about appealing an adverse consequential decision. [web:124][web:125]

---

## 6. Updates to This Statement

FrontRange Finance will review and update this statement periodically and within a reasonable time after making significant changes to the high‑risk AI systems we deploy in Colorado or to our AI risk management practices, so that the statement remains accurate and current. [web:16][web:126]
