# Colorado High‑Risk AI System Inventory & Classification

**Company:** Acme Lending Corp  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**Last Updated:** 2026-02-01  
**Owner:** Risk & Compliance

> **Purpose:** Identify and classify all AI systems used by the organization, flag which ones qualify as “high‑risk AI systems” making consequential decisions under the Colorado AI Act, and capture key details needed for impact assessments, notices, governance, and record‑keeping.

---

## 1. System‑Level Inventory Table

| ID | System / Tool Name                  | Vendor / In‑House | Business Owner     | Deployer / Developer / Both | Primary Use Case                 | Sector (Employment / Finance / Healthcare / Housing / Education / Legal / Gov / Other) | Consequential Decision Type | High‑Risk AI? (Y/N) | In Scope for CO AI Act? (Y/N) | Go‑Live Date | Status (Active / Pilot / Retired) |
|----|-------------------------------------|-------------------|--------------------|-----------------------------|----------------------------------|----------------------------------------------------------------------------------------|-----------------------------|---------------------|---------------------------------|-------------|-----------------------------------|
| 1  | CreditScoreX Decision Engine        | Vendor – FinTech  | Head of Underwriting | Deployer                    | Consumer loan approvals          | Finance                                                                                | Loan approval / denial      | Y                   | Y                               | 2024-06-15  | Active                            |
| 2  | TalentRank Applicant Screening Tool | Vendor – HRTech   | Head of Talent     | Deployer                    | Applicant pre‑screening          | Employment                                                                            | Hiring recommendation        | Y                   | Y                               | 2025-03-01  | Active                            |

---

## 2. System Detail Sheet (for each High‑Risk AI system)

### CreditScoreX Decision Engine – High‑Risk AI Detail

- **System ID:** 1  
- **Vendor / Build:** CreditScoreX Cloud / Vendor‑Hosted SaaS  
- **Deployer / Developer Role:** Deployer (Acme configures rules; vendor owns model)  
- **Business Owner:** Director of Consumer Lending  
- **Technical Owner:** VP, Data Engineering  
- **Primary Sector:** Finance  
- **Consequential Decisions Supported:** Unsecured personal loan approvals and credit line increases for Colorado consumers  
- **Colorado Consumers Affected (Y/N):** Y  
- **Estimated Volume of Decisions per Year (CO):** ~25,000 decisions/year  

#### 2.1 Inputs, Models, and Outputs

- **Key Inputs / Features Used:** Credit bureau scores, income, employment status, existing debt, prior delinquencies, geographic location  
- **Data Sources (internal / external):** Internal loan application data, external credit bureaus, fraud vendor signals  
- **Model Type / Vendor Description:** Gradient‑boosted decision tree model maintained by vendor; Acme controls threshold and business‑rule overlays  
- **Primary Outputs (scores, ranks, classifications, recommendations, decisions):** Risk score (0–1), “Approve / Refer / Decline” recommendation

#### 2.2 Known Risks and Safeguards

- **Known fairness / discrimination risks:** Potential disparate impact on protected classes through correlated features (ZIP code, income, employment gaps)  
- **Existing safeguards (thresholds, overrides, business rules, human review):**  
  - Human underwriter review required for “Refer” cases and all declines above certain score.  
  - Geolocation features bucketed to reduce granularity.  
  - Monthly monitoring of decline rates by protected‑class proxies.  
- **Link to most recent impact assessment:** `\\compliance\CO_AI_Act\assessments\CreditScoreX_Impact_Assessment_2025.pdf`

#### 2.3 Documentation Links

- System design / technical docs: `\\data\projects\CreditScoreX\Design_Spec_v3.1.docx`  
- Vendor contract and due diligence: `\\legal\vendors\CreditScoreX\CO_Addendum_Executed.pdf`  
- Consumer notice templates referencing this system: `\\comms\templates\CO_AI_Act_Loan_Decision_Notice.docx`  
- Monitoring and incident logs: `\\risk\monitoring\CreditScoreX\CO_Monitoring_Log_2025.xlsx`

---

## 3. Retirement & Record‑Keeping

Track systems that are decommissioned but must remain in records for at least 3 years after discontinuing use.

| System / Tool                  | Retirement Date | Final Decision Date | Records Retention End Date (≥ 3 years after discontinuation) | Location of Archived Records                             |
|--------------------------------|-----------------|---------------------|----------------------------------------------------------------|----------------------------------------------------------|
| LegacyRules Loan Scoring Tool  | 2025-12-31      | 2025-12-15          | 2028-12-31                                                     | `\\archive\legacy_ai\LegacyRules_Loan_Scoring.zip`       |
