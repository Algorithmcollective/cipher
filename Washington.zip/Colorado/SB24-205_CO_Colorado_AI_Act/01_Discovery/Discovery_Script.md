# Colorado High-Risk AI Discovery Script (SB 24-205)

Purpose: Gather information needed to complete all high-risk AI compliance deliverables.

If unknown → mark TBD

---

## 🧾 Deliverable: High-Risk AI Inventory

Say:
“I need to identify every AI system used to make or influence important decisions about people.”

For EACH system ask:

- System name
- Vendor vs in-house
- Business owner
- Developer / deployer role
- Primary use case
- Sector (employment, lending, healthcare, housing, etc.)
- Consequential decision type
- Is it used on Colorado residents?
- Go-live date
- Status (pilot / active / retired)

Then system details:

- Inputs used
- Data sources
- Model type
- Outputs
- Human involvement
- Estimated decision volume

---

## 🧾 Deliverable: Governance Policy

Ask:

- AI governance owner
- Approval process for new AI
- Risk review process
- Departments involved
- Monitoring cadence
- Vendor review process
- Documentation storage location

---

## 🧾 Deliverable: Impact & Risk Assessment

For each high-risk system ask:

- Purpose
- Decisions supported
- Data categories
- Sensitive/proxy features
- Model description
- Fairness risks
- Privacy risks
- Security risks
- Operational risks

Controls:

- Human oversight
- Overrides
- Access controls
- Testing performed
- Residual risk rating
- Mitigation actions
- Monitoring KPIs
- Reassessment triggers

---

## 🧾 Deliverable: Consumer Notice

Ask:

- Where AI notice appears
- Decision types needing notice
- Adverse decision explanation process
- Data sources disclosed
- Correction channel
- Appeals contact
- Timeline for review
- Sample notice files

---

## 🧾 Deliverable: Appeals & Human Review

Ask:

- Appeal intake channels
- Required information from consumer
- Time window
- Acknowledgment timeline
- Reviewer roles
- Override authority
- Decision logging method
- Metrics tracked

---

## 🧾 Deliverable: Compliance Evidence File

Ask:

- Document storage location
- Naming conventions
- Assessment file paths
- Vendor due diligence folder
- Monitoring reports
- Incident logs
- Retention period

---

## 🧾 Deliverable: Public Transparency Statement

Ask:

- Systems to list publicly
- Decision areas
- Risk management description
- Testing approach summary
- Data categories used
- Consumer rights description
- Contact details

---

## 🧾 Deliverable: Incident & Remediation Log

Ask:

- What triggers an AI incident
- Who logs incidents
- Investigation process
- Fairness testing methods
- Remediation options
- Regulator notification process
- 90-day reporting owner
- Lessons learned tracking

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Colorado high-risk AI compliance package.”