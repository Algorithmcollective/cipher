

Company: [Company Name]  
Jurisdiction: Colorado  
Document: High‑Risk AI Incident, Complaint & Remediation Log  
Owner: [AI Risk / Compliance Owner]  
Effective Date: [MM/DD/YYYY]  

> Purpose: Central log to capture complaints, incidents, investigations, outcomes, and regulatory notifications related to potential or actual algorithmic discrimination by high‑risk AI systems, and to evidence “reasonable care” and 90‑day reporting where required. [web:16][web:132][web:137]

---

## 1. When to Open an Entry

Open a new incident entry in this log whenever any of the following occur: [web:18][web:133]

- Internal testing, monitoring, or review suggests a high‑risk AI system may be causing disparate outcomes or algorithmic discrimination.  
- A complaint, appeal, or inquiry from a consumer, applicant, employee, regulator, or advocacy group alleges unfair, biased, or discriminatory AI‑driven decisions.  
- A vendor/developer notifies you of known or reasonably foreseeable risks of algorithmic discrimination in a high‑risk AI system you deploy.  

---

## 2. Incident & Complaint Log (Table)

Maintain one row per incident or cluster of closely related complaints.

| Incident ID | Date Opened | Source (Monitoring / Complaint / Vendor Notice / Regulator) | High‑Risk System | Consequential Decision Type | Summary of Allegation / Issue | Interim Risk Rating (L/M/H) | Owner |
|------------|-------------|--------------------------------------------------------------|------------------|-----------------------------|--------------------------------|-----------------------------|-------|
| [INC‑YYYY‑###] | [MM/DD/YYYY] | [e.g., Customer complaint, quarterly fairness test] | [System ID / Name] | [Hiring / Lending / Housing / etc.] | [Short description] | [L/M/H] | [Name/Role] |

This table should be exportable for review by senior management and, if necessary, the Colorado Attorney General. [web:114][web:136]

---

## 3. Detailed Incident Record (Per Incident)

For each Incident ID above, maintain a detailed record using this structure.

### 3.1 Core Details

- Incident ID: [INC‑YYYY‑###]  
- Date Opened: [MM/DD/YYYY]  
- High‑Risk AI System: [System ID / Name]  
- Business Area / Use Case: [e.g., Auto Lending – Underwriting]  
- Consequential Decision Type: [e.g., Credit approval, employment decision] [web:81][web:135]  
- Jurisdictions Impacted: [Colorado only / multi‑state including Colorado]  
- Source of Issue: [Internal monitoring / Consumer complaint / Employee complaint / Vendor notice / Regulator query / Other]  

### 3.2 Description & Scope

- Description of Allegation or Issue:  
  [Narrative description of what triggered the incident, including any claims of discrimination or unfair outcomes.]

- Time Period of Impacted Decisions:  
  [Start date] – [End date or “ongoing”]

- Population Potentially Affected:  
  [Approximate number of decisions / consumers / applicants potentially affected; note if Colorado residents specifically.] [web:16][web:137]

- Protected Classes Potentially Implicated (if known or suspected):  
  [e.g., race, color, national origin, sex, age, disability, etc.] [web:18][web:134]

### 3.3 Initial Triage & Containment

- Initial Triage Date: [MM/DD/YYYY]  
- Initial Reviewer / Team: [Name / role]  
- Immediate Actions Taken (if any):  
  - [e.g., paused specific model version, added manual review, tightened decision thresholds]  
- Interim Risk Rating and Rationale:  
  [Low / Medium / High, with brief explanation.] [web:114]

---

## 4. Investigation & Analysis

### 4.1 Investigation Steps

- Data and Period Reviewed: [datasets, date ranges, segments]  
- Methods Used:  
  - [e.g., selection rate analysis, adverse impact ratios, segmentation by protected class proxies, error analysis, scenario testing] [web:81][web:137]  
- Parties Involved: [Risk, Legal, Data Science, Business Owner, external counsel, vendor]  

### 4.2 Findings

- Was algorithmic discrimination identified?  
  - [Yes / No / Inconclusive – needs further monitoring] [web:16][web:132]  
- Summary of Key Findings:  
  [Clear bullet points summarizing what was or was not found.]  
- Impact Assessment:  
  - Number of affected or likely affected decisions  
  - Severity of impact on individuals (e.g., lost job offer, loan denial, worse pricing) [web:18][web:133]  

---

## 5. Remediation Plan & Actions

### 5.1 Remediation Decisions

- Decision on System Status:  
  - [Continue as‑is with monitoring / Modify configuration or thresholds / Retrain or replace model / Temporarily pause deployment in Colorado / Fully decommission for this use case] [web:81][web:114]  

- Remediation Actions (with dates and owners):  
  - Action 1: [Description] – Owner: [Name] – Target Date: [MM/DD/YYYY] – Completed: [Y/N / Date]  
  - Action 2: [Description] – Owner: [Name] – Target Date: [MM/DD/YYYY] – Completed: [Y/N / Date]  

### 5.2 Consumer & Stakeholder Handling

- Consumer‑Facing Remediation (if applicable):  
  - [e.g., re‑review decisions, offer reconsideration, corrective notices, adjustments to pricing or terms.] [web:124][web:135]  
- Communications with Vendor / Developer (if applicable):  
  - Date and summary of notice sent to vendor about issue and requested fixes. [web:132][web:133]  

---

## 6. Notifications to Colorado Attorney General & Others

Use this section to track if/when the 90‑day reporting trigger is met.

- Does this incident involve a high‑risk AI system that **has caused algorithmic discrimination** affecting Colorado consumers? [Yes / No] [web:16][web:137]  
- Date of Determination: [MM/DD/YYYY]  

If “Yes”:

- Deadline for Notice to Colorado Attorney General (90 days from discovery): [MM/DD/YYYY] [web:16][web:120]  
- Date Notice Sent to Colorado Attorney General: [MM/DD/YYYY]  
- Method: [Portal / Email / Letter / Other]  
- Summary of Information Provided (high‑level):  
  [Short description – do not paste full letter here.]  

If applicable:

- Date Notice Sent to Developer / Vendor: [MM/DD/YYYY]  
- Date Any Regulator or Oversight Body (other than CO AG) Notified: [MM/DD/YYYY]  

---

## 7. Closure & Lessons Learned

- Date Incident Closed: [MM/DD/YYYY]  
- Final Risk Rating: [L/M/H]  
- Final Outcome Summary:  
  [Concise narrative of what happened, what was found, and how it was fixed.]  

- Policy / Process / Control Updates:  
  - [e.g., update AI risk policy, change monitoring thresholds, add new fairness test, revise vendor contract clauses.] [web:114][web:81]  

- Added to Training or Awareness Materials? [Yes / No]  
  - If Yes, describe how this incident will be used in future training.  

- Approval of Closure:  
  - Name / Title: [e.g., Chief Risk Officer / General Counsel]  
  - Date: [MM/DD/YYYY]  

---

## 8. Log Governance

- Review Frequency: [e.g., Quarterly review by AI Risk Committee; annual review by Executive Risk Committee] [web:114][web:137]  
- Retention:  
  - Maintain this log and supporting records for at least [X years] from closure of each incident, consistent with Colorado AI Act requirements and internal record‑retention policies. [web:16][web:120]
