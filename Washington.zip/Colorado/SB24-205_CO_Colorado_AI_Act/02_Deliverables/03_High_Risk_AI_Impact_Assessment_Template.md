# Colorado High‑Risk AI Impact & Risk Assessment

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**System Name:** {{SYSTEM_NAME}}  
**System ID (Inventory Reference):** {{SYSTEM_ID}}  
**Assessment Version:** {{ASSESSMENT_VERSION}}  
**Assessment Date:** {{ASSESSMENT_DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{PREPARER_ROLE}}  
**Reviewed By (Legal / Compliance):** {{REVIEWER_NAME}}, {{REVIEWER_ROLE}}  
**Approved By (Governance Owner):** {{APPROVER_NAME}}, {{APPROVER_ROLE}}

> **Purpose:** Document how this high‑risk AI system is used to support consequential decisions about Colorado consumers, the data and logic it relies on, the risks of algorithmic discrimination and other harms, and the safeguards, testing, and monitoring implemented to comply with the Colorado AI Act.[web:54][web:74][web:76][web:79][web:80][web:81]

---

## 1. System Overview

- **Business Domain:** {{DOMAIN}} (e.g., Employment, Lending, Insurance, Healthcare, Housing, Education, Legal, Government Services)[web:16][web:54][web:82]  
- **Primary Use Case:** {{USE_CASE}} (e.g., applicant screening, loan approval, claim denial, rental approval)  
- **Consequential Decisions Supported:** {{DECISIONS}}  
- **Deployer / Developer Role:** {{ROLE}} (Deployer / Developer / Both)[web:75][web:80]  
- **Colorado Consumers in Scope:** {{CO_SCOPE_DESCRIPTION}}  
- **Estimated Annual Decision Volume (CO):** {{DECISION_VOLUME}}

---

## 2. Data and Model Description

### 2.1 Input Data

- **Data Categories Used:**  
  - {{DATA_CAT_1}} (e.g., identity, contact, financial, employment, health, behavioral, location)  
  - {{DATA_CAT_2}}  
  - {{DATA_CAT_3}}  

- **Sources:**  
  - Internal: {{INTERNAL_SOURCES}}  
  - External / Third‑Party: {{EXTERNAL_SOURCES}}  

- **Potential Proxy or Sensitive Features:**  
  - {{POTENTIAL_PROXIES}} (e.g., ZIP code, school, job history, device or network signals)

### 2.2 Model / Logic

- **Model Type / Approach:** {{MODEL_TYPE}} (e.g., gradient‑boosted trees, neural network, rules‑based, vendor black‑box)  
- **Vendor / Platform:** {{VENDOR_PLATFORM}}  
- **Key Outputs:** {{OUTPUTS}} (e.g., score, rank, “approve/decline”, recommendation)  
- **Human Interaction:** {{HUMAN_INTERACTION}} (e.g., fully automated decision, decision support with human final say)

---

## 3. Risk Identification

### 3.1 Algorithmic Discrimination Risks

Describe potential ways the system could create unfair or discriminatory outcomes for protected or vulnerable groups.[web:74][web:76][web:79][web:81]

- **Risk 1:** {{RISK_1_DESCRIPTION}}  
  - Potentially affected groups: {{RISK_1_GROUPS}}  
  - Drivers (features, data, or logic involved): {{RISK_1_DRIVERS}}  

- **Risk 2:** {{RISK_2_DESCRIPTION}}  
  - Potentially affected groups: {{RISK_2_GROUPS}}  
  - Drivers: {{RISK_2_DRIVERS}}  

- **Risk 3:** {{RISK_3_DESCRIPTION}}  

### 3.2 Other Material Risks

- **Privacy and data misuse risks:** {{PRIVACY_RISKS}}[web:60][web:82]  
- **Security and misuse risks (e.g., adversarial use, prompt injection):** {{SECURITY_RISKS}}  
- **Transparency / explainability risks:** {{EXPLAINABILITY_RISKS}}  
- **Operational / reliability risks (e.g., outages, bad data feeds):** {{OPERATIONAL_RISKS}}

---

## 4. Safeguards and Controls

### 4.1 Design and Data Safeguards

- **Feature selection / engineering controls:** {{FEATURE_CONTROLS}}  
- **Data quality checks (ingest, preprocessing, labeling):** {{DATA_QUALITY_CONTROLS}}  
- **Proxy‑mitigation steps (e.g., bucketing, removing certain variables):** {{PROXY_MITIGATIONS}}  

### 4.2 Process and Governance Safeguards

- **Human oversight / review points:** {{HUMAN_REVIEW_POINTS}}  
- **Override policies and escalation paths:** {{OVERRIDE_POLICIES}}  
- **Access control and change‑management procedures:** {{ACCESS_CHANGE_CONTROLS}}  

### 4.3 Consumer‑Facing Safeguards

- **Notices (if applicable):** {{NOTICE_DESCRIPTION}}[web:54][web:76][web:81]  
- **Appeal / human review mechanisms (if applicable):** {{APPEAL_MECHANISMS}}  
- **Channels for complaints or questions:** {{COMPLAINT_CHANNELS}}

---

## 5. Testing and Evaluation

Use this to summarize fairness / performance testing; you can link to a separate detailed bias‑audit or evaluation report.[web:74][web:76][web:79][web:81]

- **Testing Period Covered:** {{TEST_PERIOD}}  
- **Population / dataset used for evaluation:** {{EVAL_DATASET}}  
- **Key fairness / disparity metrics evaluated:** {{METRICS}} (e.g., approval rates, error rates, false positive / negative rates, by group)  
- **Key performance metrics (accuracy, AUC, etc.):** {{PERFORMANCE_METRICS}}  

- **High‑level results:**  
  - {{RESULT_1}}  
  - {{RESULT_2}}  
  - {{RESULT_3}}  

- **Link to detailed report (if separate):** {{REPORT_LINK}}

---

## 6. Residual Risk and Mitigation Plan

### 6.1 Residual Risk Rating

- **Residual risk of algorithmic discrimination:** {{RESIDUAL_RISK_LEVEL}} (Low / Medium / High)  
- **Rationale:** {{RESIDUAL_RISK_RATIONALE}}

### 6.2 Mitigation Actions

List concrete actions to reduce risk further.

| Action ID | Mitigation Description           | Owner        | Due Date   | Status (Planned / In Progress / Complete) |
|----------|-----------------------------------|-------------|-----------|-------------------------------------------|
| A‑01     | {{ACTION_1_DESC}}                | {{OWNER_1}} | {{DUE_1}} | {{STATUS_1}}                               |
| A‑02     | {{ACTION_2_DESC}}                | {{OWNER_2}} | {{DUE_2}} | {{STATUS_2}}                               |
| A‑03     | {{ACTION_3_DESC}}                | {{OWNER_3}} | {{DUE_3}} | {{STATUS_3}}                               |

---

## 7. Monitoring Plan

Describe how the system will be monitored over time, as the Act expects an iterative, regularly reviewed risk‑management process.[web:54][web:74][web:78][web:80][web:81]

- **Monitoring cadence:** {{CADENCE}} (e.g., monthly, quarterly, annually)  
- **Key indicators tracked:** {{MONITORING_KPIS}} (e.g., outcome distribution by group, override rates, appeals, complaints, incident counts)  
- **Responsibility for monitoring:** {{MONITORING_OWNER}}  
- **Triggers for re‑assessment or escalation:** {{TRIGGERS}} (e.g., metric thresholds, new data sources, major model changes, new law/guidance)

---

## 8. Assessment Summary and Sign‑Off

- **Overall conclusion:** {{OVERALL_CONCLUSION}}  
  (e.g., “Acceptable to operate with defined mitigations and monitoring” or “Deployment deferred pending additional mitigations.”)  
- **Conditions / limitations for use:** {{CONDITIONS}}  

**Prepared By:**  
- Name: {{PREPARER_NAME}}  
- Role: {{PREPARER_ROLE}}  
- Date: {{PREPARER_DATE}}

**Reviewed By (Legal / Compliance):**  
- Name: {{REVIEWER_NAME}}  
- Role: {{REVIEWER_ROLE}}  
- Date: {{REVIEWER_DATE}}

**Approved By (Governance Owner):**  
- Name: {{APPROVER_NAME}}  
- Role: {{APPROVER_ROLE}}  
- Date: {{APPROVER_DATE}}
