# Colorado High‑Risk AI System Inventory & Classification

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**Last Updated:** {{LAST_UPDATED_DATE}}  
**Owner:** {{OWNER_FUNCTION}}

> **Purpose:** Identify and classify all AI systems used by the organization, flag which ones qualify as “high‑risk AI systems” making consequential decisions under the Colorado AI Act, and capture key details needed for impact assessments, notices, governance, and record‑keeping.

---

## 1. System‑Level Inventory Table

| ID | System / Tool Name | Vendor / In‑House | Business Owner | Deployer / Developer / Both | Primary Use Case | Sector (Employment / Finance / Healthcare / Housing / Education / Legal / Gov / Other) | Consequential Decision Type | High‑Risk AI? (Y/N) | In Scope for CO AI Act? (Y/N) | Go‑Live Date | Status (Active / Pilot / Retired) |
|----|--------------------|-------------------|----------------|-----------------------------|------------------|------------------------------------------------------------------------------------------------|-----------------------------|---------------------|---------------------------------|-------------|-----------------------------------|
| 1  | {{SYSTEM_1}}       | {{VENDOR_1}}      | {{OWNER_1}}    | {{ROLE_1}}                  | {{USE_CASE_1}}   | {{SECTOR_1}}                                                                               | {{DECISION_TYPE_1}}         | {{HR_FLAG_1}}       | {{SCOPE_FLAG_1}}                | {{GOLIVE_1}} | {{STATUS_1}}                      |
| 2  | {{SYSTEM_2}}       | {{VENDOR_2}}      | {{OWNER_2}}    | {{ROLE_2}}                  | {{USE_CASE_2}}   | {{SECTOR_2}}                                                                               | {{DECISION_TYPE_2}}         | {{HR_FLAG_2}}       | {{SCOPE_FLAG_2}}                | {{GOLIVE_2}} | {{STATUS_2}}                      |

**Notes:**

- **Deployer / Developer / Both:** whether you are only using the system (deployer), building it (developer), or both.  
- **Consequential Decision Type:** e.g., hiring, promotion, loan approval, rate setting, claim denial, housing approval, benefits eligibility, admission, grading, sentencing support.  
- **High‑Risk AI?:** “Y” if the system fits the Act’s “high‑risk AI system” definition (used to make or substantially influence consequential decisions about consumers).  
- **In Scope for CO AI Act?:** “Y” if the system is both high‑risk *and* used in Colorado for covered consumers.

---

## 2. System Detail Sheet (for each High‑Risk AI system)

For each row where **High‑Risk AI? = Y**, create a section like this.

### {{SYSTEM_NAME}} – High‑Risk AI Detail

- **System ID:** {{SYSTEM_ID}}  
- **Vendor / Build:** {{VENDOR_NAME}} / {{IN_HOUSE_OR_VENDOR}}  
- **Deployer / Developer Role:** {{ROLE_DETAIL}}  
- **Business Owner:** {{BUSINESS_OWNER}}  
- **Technical Owner:** {{TECH_OWNER}}  
- **Primary Sector:** {{SECTOR}}  
- **Consequential Decisions Supported:** {{DECISION_TYPES}}  
- **Colorado Consumers Affected (Y/N):** {{CO_CONSUMERS_FLAG}}  
- **Estimated Volume of Decisions per Year (CO):** {{DECISION_VOLUME}}  

#### 2.1 Inputs, Models, and Outputs

- **Key Inputs / Features Used:** {{INPUTS}}  
- **Data Sources (internal / external):** {{DATA_SOURCES}}  
- **Model Type / Vendor Description:** {{MODEL_TYPE}}  
- **Primary Outputs (scores, ranks, classifications, recommendations, decisions):** {{OUTPUTS}}  

#### 2.2 Known Risks and Safeguards

- **Known fairness / discrimination risks:** {{KNOWN_RISKS}}  
- **Existing safeguards (thresholds, overrides, business rules, human review):** {{SAFEGUARDS}}  
- **Link to most recent impact assessment:** {{IMPACT_ASSESSMENT_LINK}}  

#### 2.3 Documentation Links

- System design / technical docs: {{DESIGN_DOC_LINK}}  
- Vendor contract and due diligence: {{VENDOR_DOC_LINK}}  
- Consumer notice templates referencing this system: {{NOTICE_LINK}}  
- Monitoring and incident logs: {{MONITORING_LOG_LINK}}  

---

## 3. Retirement & Record‑Keeping

Track systems that are decommissioned but must remain in records for at least 3 years after discontinuing use.

| System / Tool | Retirement Date | Final Decision Date | Records Retention End Date (≥ 3 years after discontinuation) | Location of Archived Records |
|---------------|-----------------|---------------------|----------------------------------------------------------------|------------------------------|
| {{SYSTEM_R1}} | {{RETIRE_DATE}} | {{FINAL_DECISION}}  | {{RETENTION_END}}                                               | {{ARCHIVE_LOCATION}}         |
