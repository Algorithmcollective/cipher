# Colorado High‑Risk AI Appeal & Human Review / Oversight Procedure

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**Applies To System(s):** {{SYSTEMS_IN_SCOPE}} (e.g., CreditScoreX Decision Engine, TalentRank Hiring Screen)  
**Procedure Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Last Reviewed:** {{LAST_REVIEWED_DATE}}

> **Purpose:** Define how {{COMPANY_NAME}} provides human review and oversight for consequential decisions supported by high‑risk AI systems, including how consumers can appeal, how reviewers handle cases, and how results are logged and monitored, consistent with the Colorado AI Act.[web:16][web:54][web:87][web:88][web:90][web:93][web:95]

---

## 1. Scope

This procedure applies to:

- All **high‑risk AI systems** used by {{COMPANY_NAME}} to make or substantially influence consequential decisions about Colorado consumers (e.g., hiring, loan approvals, claim decisions, housing approvals).  
- All **appeals** or review requests submitted by affected consumers in relation to those decisions.  
- All staff designated as **human reviewers** or approvers for such decisions.[web:16][web:54][web:87][web:88][web:93]

---

## 2. Roles

- **Appeals & Review Coordinator:** {{COORDINATOR_NAME}} / function (e.g., Risk Ops / Customer Care)  
  - Monitors incoming appeals, assigns cases to reviewers, tracks timelines, and ensures responses are sent.  

- **Human Reviewers:** designated staff in relevant business units (e.g., underwriters, HR managers, claims specialists).  
  - Conduct substantive review of appealed decisions and may confirm, modify, or overturn AI‑supported outcomes.  

- **Legal / Compliance:**  
  - Advises on complex or high‑risk cases, patterns of appeals, and regulatory implications.  

- **Governance Owner:**  
  - Reviews appeal statistics and outcomes as part of overall AI oversight.

---

## 3. How Consumers Request Human Review / Appeal

1. **Channels:** Consumers may request human review using any of the following:  
   - Email: {{APPEALS_EMAIL}}  
   - Phone: {{APPEALS_PHONE}}  
   - Online portal / web form: {{APPEALS_PORTAL_URL}}  

2. **Required information:**  
   - Full name and contact details.  
   - Reference for the decision (e.g., application ID, claim number).  
   - Brief description of why they believe the decision may be wrong or incomplete, and any supporting information (optional).

3. **Time window:**  
   - Appeals must normally be submitted within **{{APPEAL_WINDOW}}** (e.g., 30 days) of the decision notice, unless extended by law or internal policy.[web:16][web:54][web:88][web:93]

4. **Acknowledgment:**  
   - The Appeals & Review Coordinator sends an acknowledgment within **{{ACK_TIMELINE}}** (e.g., 3 business days) confirming receipt and expected review timeline.

---

## 4. Human Review Process

For each appeal:

1. **Case assignment:**  
   - Coordinator assigns the case to a qualified Human Reviewer who **was not the person** who configured or initiated the original decision, where practicable.

2. **Information gathering:**  
   - Reviewer accesses:  
     - Original application/record and AI system output.  
     - Reasons for the original decision (from the AI impact assessment and decision logs).  
     - Any new information or corrections provided by the consumer.  

3. **Substantive review:**  
   - Reviewer independently evaluates:  
     - Whether the input data was accurate and complete.  
     - Whether any obvious errors or anomalies are present in the AI output.  
     - Whether policies and underwriting/employment/claims criteria have been applied correctly.  
   - Reviewer is empowered to **override or modify** the AI‑supported decision where appropriate.

4. **Decision options:**  
   - **Confirm** the original decision.  
   - **Modify** the decision (e.g., approve with conditions, different offer, alternative role/property/product).  
   - **Overturn** the decision (e.g., change from decline to approval).

5. **Timeframe for completion:**  
   - Reviews are normally completed within **{{REVIEW_TIMELINE}}** (e.g., 15 business days) from acknowledgment, unless additional information is required from the consumer.[web:16][web:54][web:87][web:88][web:93]

---

## 5. Communication Back to the Consumer

- The Coordinator or Reviewer sends a written response (email or portal message, with letter as needed) that:  
  - States the outcome (confirmed, modified, overturned).  
  - Explains in plain language the main reasons for the final decision.  
  - Indicates any updates made due to corrections or new information.  
  - Reiterates how the consumer can raise further concerns or complaints if applicable.[web:16][web:54][web:88][web:90][web:93][web:95]

---

## 6. Logging, Metrics, and Oversight

For each appeal, the following are recorded in the **High‑Risk AI Appeals Log**:

- Consumer identifier and decision reference.  
- High‑risk AI system involved.  
- Date appeal received and acknowledged.  
- Reviewer assigned and date completed.  
- Outcome (confirmed / modified / overturned).  
- High‑level reason for outcome.  

On a **{{REPORTING_CADENCE}}** basis (e.g., quarterly), the Governance Owner and Compliance review:

- Number of appeals by system and decision type.  
- Percentage of decisions overturned or modified.  
- Patterns suggesting potential algorithmic discrimination or systemic errors.  
- Required changes to models, policies, notices, or training.[web:54][web:74][web:78][web:93][web:95]

---

## 7. Exceptions and Safety Constraints

If a particular high‑risk AI system is used in contexts where human review is not technically feasible or would create significant safety risks (e.g., certain real‑time security applications), any limitations on appeals or human review:

- Must be documented here: {{EXCEPTIONS_DESCRIPTION}}.  
- Must be reviewed and approved by Legal / Compliance and the Governance Owner.  
- Must be clearly disclosed to affected consumers where appropriate.[web:16][web:87][web:88][web:93]

---

## 8. Review of this Procedure

This procedure is reviewed at least annually and whenever:

- New high‑risk AI systems with consequential decisions are added.  
- Laws, regulations, or guidance on consumer rights, notices, or appeals are updated.  
- Monitoring reveals trends in appeals that require process changes.

Updates require approval from the Procedure Owner and Legal / Compliance before implementation.
