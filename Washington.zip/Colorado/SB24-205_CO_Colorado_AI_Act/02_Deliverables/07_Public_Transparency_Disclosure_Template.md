Name this file: CO_7_Public_High-Risk_AI_Transparency_Statement_TEMPLATE.md

Company: [Company Name]  
Jurisdiction: Colorado  
Document: Public Statement on High-Risk AI Systems  
Effective Date: [MM/DD/YYYY]  
Contact: [Title / Dept], [Email], [Phone]

> This statement is intended to satisfy the requirement to make a clear, publicly available summary of the high‑risk AI systems the company deploys in Colorado, how it manages risks of algorithmic discrimination, and the nature, source, and extent of information it uses. [web:16][web:115][web:109]

---

## 1. Overview of Our Use of High‑Risk AI

We use certain high‑risk artificial intelligence systems to help make or substantially influence “consequential decisions” about individuals, such as [hiring, promotions, consumer lending, housing decisions, insurance eligibility, education admissions, essential services]. [web:16][web:122]  
These systems are used to support, not replace, human decision‑making, and we maintain processes to identify and address potential algorithmic discrimination. [web:81][web:118]

---

## 2. High‑Risk AI Systems We Deploy

For each system, complete a row in this table.

| System Name | Purpose / Decision Type | Area (e.g., Hiring, Lending) | Developer / Vendor | Colorado In‑Scope Since |
|------------|-------------------------|------------------------------|--------------------|-------------------------|
| [System 1] | [e.g., rank applicants] | [e.g., Hiring]               | [Vendor]           | [MM/YYYY]               |
| [System 2] | [e.g., credit scoring]  | [e.g., Lending]              | [Vendor]           | [MM/YYYY]               |

These systems qualify as “high‑risk AI systems” because they are used to make or substantially influence consequential decisions about Colorado residents. [web:16][web:122]

---

## 3. How We Manage Algorithmic Discrimination Risk

We maintain an AI risk management program designed to use reasonable care to protect consumers from known or reasonably foreseeable risks of algorithmic discrimination arising from our high‑risk AI systems. [web:16][web:118][web:121]

Our program includes:

- Documented AI governance and risk management policies aligned with recognized frameworks (such as the NIST AI Risk Management Framework or ISO/IEC 42001). [web:81][web:114]  
- Impact assessments for each high‑risk AI system before deployment, at least annually, and after material changes. [web:81][web:54]  
- Pre‑deployment and periodic testing to monitor model performance and detect potential disparate impacts on protected classes. [web:81][web:118]  
- Human review for adverse consequential decisions where technically feasible and appropriate. [web:81][web:119]  
- Internal training for relevant staff on responsible AI use, anti‑discrimination obligations, and escalation procedures. [web:114][web:122]

If we discover that a high‑risk AI system we deploy has caused or is reasonably likely to have caused algorithmic discrimination, we will investigate, take appropriate corrective action, and notify the Colorado Attorney General as required. [web:16][web:118][web:120]

---

## 4. Information We Collect and Use

For each high‑risk AI system, we collect and use information relevant to the decision being made, which may include:

- Identification and contact information (for example, name, address, contact details). [web:118][web:122]  
- Application or transaction data (for example, job history, education, income, account history, property information, coverage information, service usage). [web:118][web:122]  
- Internal records related to our prior interactions with the consumer. [web:118][web:122]

We do not intentionally use data elements in a way that directly targets protected characteristics such as race, color, religion, national origin, sex, disability, or other classifications protected under Colorado or federal law, except where permitted or required by law (for example, to test for fairness). [web:16][web:118][web:121]

We retain data, model documentation, and impact assessments for at least the periods required under the Colorado AI Act and our internal record‑retention policies. [web:81][web:120]

---

## 5. Consumer Notices, Rights, and Appeals

When we use a high‑risk AI system to make or substantially influence a consequential decision about a consumer, we provide clear notice that AI is being used. [web:16][web:119]  
If we make an adverse decision (for example, not hiring a candidate or declining a loan), we provide information about that decision and how the consumer can correct inaccurate information or request review, including human review where technically feasible. [web:81][web:118]

Consumers may contact us using the details at the top of this statement to:

- Ask questions about our use of high‑risk AI systems in Colorado. [web:16][web:115]  
- Request information about how to appeal an adverse consequential decision. [web:81][web:118]  

---

## 6. Updates to This Statement

We will review and update this statement periodically and within a reasonable time after making significant changes to the high‑risk AI systems we deploy or to our AI risk management practices, so that it remains accurate and current. [web:16][web:117][web:120]
