# Colorado High‑Risk AI Consumer Notice & Adverse Decision Template

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**System Name:** {{SYSTEM_NAME}}  
**Decision Type:** {{DECISION_TYPE}} (e.g., loan approval, hiring decision, claim decision, rental approval)  
**Channel:** {{CHANNEL}} (email / letter / portal message / on‑screen)  
**Version:** {{VERSION}}  
**Last Updated:** {{LAST_UPDATED_DATE}}

> **Purpose:** Provide a standard notice to Colorado consumers when a high‑risk AI system is used to make or substantially influence a consequential decision about them, and, in the case of an adverse decision, explain the main reasons, data sources, and how to seek correction or human review, consistent with the Colorado AI Act.[web:16][web:54][web:87][web:88][web:90][web:93][web:94][web:95]

---

## 1. General AI Use Notice (Pre‑Decision or At Decision)

You can use this language in application flows, consent screens, or pre‑decision emails.

> **How We Use Automated Systems in Decisions**  
>  
> {{COMPANY_NAME}} uses automated tools, including artificial intelligence (“AI”) systems, to help make or substantially influence certain decisions about our customers, such as {{EXAMPLES_OF_DECISIONS}}. These tools analyze information you provide and information we obtain from other sources to help us make consistent and timely decisions.  
>  
> Human team members oversee these tools and may review and, where appropriate, change the decisions they support.

---

## 2. Adverse Decision Notice (Core Body)

Use this when the outcome is negative for the consumer (e.g., decline, reduction, denial).

> **Subject / Heading:** Important information about your {{DECISION_TYPE}}  
>  
> Dear {{CONSUMER_NAME}},  
>  
> We have completed our review of your **{{DECISION_TYPE}}** (for example: “personal loan application dated {{APPLICATION_DATE}}” / “rental application for {{PROPERTY}}” / “claim number {{CLAIM_ID}}”). Based on this review, we are **unable to approve** your request at this time.  
>  
> An automated tool, which includes artificial intelligence (“AI”), was used to help make or substantially influence this decision.[web:16][web:54][web:87][web:88][web:93][web:94] Human reviewers oversee this tool and may correct errors or override decisions where appropriate.

---

## 3. Principal Reasons for the Decision

Explain clearly and in simple terms.

> **Why this decision was made**  
>  
> The main factors that led to this decision include:  
> - {{REASON_1}} (e.g., “your recent payment history shows multiple late payments in the past 12 months”).  
> - {{REASON_2}} (e.g., “your current debt payments are high compared to your stated income”).  
> - {{REASON_3}} (optional).  
>  
> The automated tool weighed these and other factors together. No single factor was the only reason for this outcome.[web:16][web:88][web:90][web:93][web:95]

If required, you can add any legally mandated adverse‑action reasons (e.g., under credit or insurance laws) in a separate section.

---

## 4. Data Types and Sources Used

> **What information the AI system used**  
>  
> To support this decision, the AI system processed information from:  
> - The details you provided to us (for example: your application information and documents).  
> - Our existing records about your relationship with us (if any).  
> - Third‑party sources, where allowed by law (for example: {{THIRD_PARTY_SOURCES}} such as credit bureaus, background‑check services, or public records).[web:16][web:54][web:88][web:90][web:93]  
>  
> If you would like more information about the types of data we used for this decision, you can contact us using the details below.

---

## 5. How to Correct Your Information

> **How to correct your information**  
>  
> If you believe any of the information we used about you is wrong or incomplete, you can ask us to review and correct it. To do this, please contact us at:  
>  
> - Email: {{CORRECTIONS_EMAIL}}  
> - Phone: {{CORRECTIONS_PHONE}}  
> - Online portal (if applicable): {{PORTAL_URL}}  
>  
> When you contact us, please tell us what you believe is incorrect and, if possible, provide documents to support the correction. We will review your request and let you know the outcome.[web:16][web:87][web:88][web:90][web:93]

---

## 6. How to Request Human Review / Appeal

> **How to request human review of this decision**  
>  
> You may ask us to have a qualified person review this decision. A human reviewer will look at your information, consider any updates or corrections you provide, and decide whether to confirm or change the outcome.  
>  
> To request a human review or appeal:  
> - Contact us within **{{APPEAL_WINDOW}}** (for example: 30 days) using one of the following:  
>   - Email: {{APPEALS_EMAIL}}  
>   - Phone: {{APPEALS_PHONE}}  
>   - Online portal: {{APPEALS_PORTAL_URL}}  
> - Please include your full name, the decision reference (for example: application ID or claim number), and any information you would like us to consider.  
>  
> We will confirm we received your request and aim to complete our review within **{{APPEAL_TIMELINE}}** (for example: 15 business days). We will then tell you in writing whether the decision has been confirmed or changed, and why.[web:16][web:54][web:88][web:89][web:93][web:95]

*(If there are safety‑related limits on appeals/human review for certain systems, describe them clearly.)*

---

## 7. Contact Details and Additional Information

> **Questions or complaints**  
>  
> If you have questions about this notice, how we use automated tools in decisions, or how your information is handled, you can contact:  
>  
> - {{COMPANY_CONTACT_NAME}}  
> - Role: {{COMPANY_CONTACT_ROLE}}  
> - Email: {{COMPANY_CONTACT_EMAIL}}  
> - Phone: {{COMPANY_CONTACT_PHONE}}  
>  
> You can also learn more about your rights and our obligations under Colorado’s AI law in our AI and data‑use statement at: {{AI_STATEMENT_URL}}.[web:16][web:54][web:87][web:93]
