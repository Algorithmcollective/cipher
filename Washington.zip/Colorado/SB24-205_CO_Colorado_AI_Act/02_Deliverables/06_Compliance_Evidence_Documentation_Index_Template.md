# Colorado High‑Risk AI Compliance Evidence Index

**Company:** {{COMPANY_NAME}}  
**Jurisdiction:** State of Colorado  
**Applicable Law:** Colorado AI Act (SB 24‑205)  
**Scope:** High‑Risk AI Systems (Developers/Deployers)  
**Owner:** {{OWNER_NAME}}, {{OWNER_ROLE}}  
**Last Updated:** {{LAST_UPDATED_DATE}}

> **Purpose:** Provide a single index of documents and records that demonstrate {{COMPANY_NAME}}’s compliance with the Colorado AI Act for high‑risk AI systems, including inventory, governance, assessments, notices, appeals, vendor documentation, and monitoring evidence.[web:16][web:54][web:74][web:79][web:81][web:93]

---

## 1. System Inventory & Classification (Deliverable 1)

- **Document:** Colorado High‑Risk AI System Inventory & Classification  
- **File / Location:** {{INVENTORY_PATH}} (e.g., `\\CO_AI_Act\01_Inventory\CO_1_High_Risk_AI_Inventory_MASTER.xlsx`)  
- **Contents:** List of all high‑risk AI systems, sectors, decision types, roles, Colorado scope flags, and retirement / retention dates.[web:16][web:54][web:57][web:61]

---

## 2. Governance & Risk Management Policy (Deliverable 2)

- **Document:** High‑Risk AI Governance & Risk Management Policy (Colorado)  
- **File / Location:** {{GOVERNANCE_POLICY_PATH}} (e.g., `\\CO_AI_Act\02_Governance\CO_2_High_Risk_AI_Governance_POLICY_MASTER.docx`)  
- **Contents:** Roles, responsibilities, lifecycle governance, inventory/approval process, assessments, monitoring, documentation and review requirements.[web:54][web:74][web:75][web:80][web:81]

---

## 3. System‑Level Impact & Risk Assessments (Deliverable 3)

For each high‑risk AI system:

| System Name | System ID | Latest Assessment File | Assessment Date | Next Review Due |
|------------|-----------|------------------------|-----------------|-----------------|
| {{SYSTEM_1}} | {{ID_1}} | {{ASSESS_PATH_1}}      | {{DATE_1}}      | {{NEXT_1}}      |
| {{SYSTEM_2}} | {{ID_2}} | {{ASSESS_PATH_2}}      | {{DATE_2}}      | {{NEXT_2}}      |

- **Template:** CO_3_High_Risk_AI_Impact_Assessment_MASTER.md  
- **Typical Location:** `\\CO_AI_Act\03_Assessments\{{SYSTEM_ID}}_Assessment_{{YEAR}}.docx`[web:54][web:74][web:76][web:79][web:80][web:81]

---

## 4. Consumer Notices & Adverse Decision Templates (Deliverable 4)

- **Document:** Colorado High‑Risk AI Consumer Notice & Adverse Decision Template  
- **File / Location:** {{NOTICE_TEMPLATE_PATH}} (e.g., `\\CO_AI_Act\04_Notices\CO_4_High_Risk_AI_Consumer_Notice_TEMPLATE_MASTER.docx`)  
- **System‑Specific Implementations:**  
  - {{SYSTEM_1}}: {{SYSTEM_1_NOTICE_PATH}}  
  - {{SYSTEM_2}}: {{SYSTEM_2_NOTICE_PATH}}  

- **Evidence Samples:**  
  - PDFs / screenshots of notices as presented in UI, emails, or letters for recent decisions.[web:16][web:54][web:87][web:88][web:90][web:93][web:95]

---

## 5. Appeals & Human Review Procedure (Deliverable 5)

- **Document:** Colorado High‑Risk AI Appeal & Human Review / Oversight Procedure  
- **File / Location:** {{APPEAL_PROC_PATH}} (e.g., `\\CO_AI_Act\05_Appeals\CO_5_High_Risk_AI_Appeal_and_Human_Review_PROCEDURE_MASTER.docx`)  
- **Related Evidence:**  
  - **Appeals Log:** `\\CO_AI_Act\05_Appeals\Appeals_Log.xlsx`  
  - Example case files showing intake, review notes, and final communications.[web:16][web:54][web:88][web:90][web:93][web:95]

---

## 6. Vendor Due Diligence & Contracts

For each vendor‑provided high‑risk AI system:

| System Name | Vendor | Due‑Diligence File | Contract / Addendum | Last Vendor Review |
|------------|--------|--------------------|---------------------|--------------------|
| {{SYSTEM_1}} | {{VENDOR_1}} | {{DD_FILE_1}} | {{CONTRACT_1}} | {{VENDOR_REVIEW_1}} |

- **Folder:** `\\CO_AI_Act\06_Vendors\{{VENDOR_NAME}}`  
- **Contents:** Vendor questionnaires, technical documentation, fairness/bias testing summaries, SB 24‑205 cooperation clauses, DPAs.[web:54][web:74][web:81][web:90][web:94]

---

## 7. Monitoring, Incidents, and Remediation

- **Monitoring Reports Folder:** `\\CO_AI_Act\07_Monitoring\Reports\`  
  - E.g., quarterly fairness / outcome reports per system.  
- **Incident Log:** `\\CO_AI_Act\07_Monitoring\Incidents_Log.xlsx`  
- **Remediation Records:** `\\CO_AI_Act\07_Monitoring\Remediation\{{SYSTEM_ID}}_Remediation_{{YEAR}}.docx`  

Each record should capture: incident description, affected system, groups impacted, root cause, actions taken, and closure date.[web:16][web:18][web:54][web:74][web:78][web:81][web:93][web:95]

---

## 8. Training & Awareness

- **AI Governance / Colorado AI Act Training Materials:** `\\CO_AI_Act\08_Training\CO_AI_Training_Slides_{{YEAR}}.pptx`  
- **Attendance Records:** `\\CO_AI_Act\08_Training\Attendance_{{YEAR}}.xlsx`  

Covers staff involved in designing, operating, or reviewing high‑risk AI systems.[web:54][web:74][web:81][web:93]

---

## 9. Retention & Archived Systems

- **Retired Systems Register:** `\\CO_AI_Act\09_Archive\Retired_Systems_Register.xlsx`  
  - Fields: System name, ID, retirement date, last decision date, retention end date (≥ 3 years after discontinuation), archive location.  
- **Archive Locations:** zipped / read‑only folders containing frozen documentation and logs for retired systems.[web:16][web:18][web:59][web:61]

---

## 10. Index Maintenance

- This index is reviewed and updated at least annually, and whenever:  
  - New high‑risk AI systems are added or removed.  
  - Key documents (policies, templates, contracts) are revised.  
  - Monitoring or incidents require new evidence types.  

**Last Index Review:** {{INDEX_REVIEW_DATE}}  
**Reviewed By:** {{INDEX_REVIEWER_NAME}}, {{INDEX_REVIEWER_ROLE}}
