# Law Profile

## Law Name
Colorado Artificial Intelligence Act (SB 24-205)

## Citation
Colorado Senate Bill 24-205 (2024)

## Status
Enacted

## Effective Date
February 1, 2026

## Regulatory Scope

Applies to developers and deployers of “high-risk artificial intelligence systems” used in consequential decision-making within Colorado.

Covers AI systems used in decisions involving:

- Employment
- Education
- Housing
- Financial services
- Health care
- Insurance
- Legal services
- Government services
- Essential services

Applies to both:

- Developers (entities creating high-risk AI systems)
- Deployers (entities using high-risk AI systems in consequential decisions)

## Core Obligations

Developers must:

- Implement risk management programs
- Conduct impact assessments
- Document training data and model design
- Provide documentation to deployers
- Maintain transparency disclosures

Deployers must:

- Conduct impact assessments
- Implement risk management policies
- Provide consumer notices
- Offer human review and appeal processes
- Maintain monitoring and documentation
- Report certain AI incidents

## Enforcement Authority

Colorado Attorney General

## Penalties

Enforced under the Colorado Consumer Protection Act.

Civil penalties may reach:
- Up to $20,000 per violation
- Each affected consumer may constitute a separate violation

No private right of action.

## Private Right of Action
No

## Tier Classification
Tier 1 – Flagship High-Risk AI Governance Law

## Revenue Priority
Very High

## Target Industries

- Employers using AI hiring tools
- Financial institutions using AI credit models
- Insurers using automated underwriting
- Healthcare entities using AI for eligibility decisions
- Housing providers using automated screening
- Enterprise AI vendors

## Strategic Positioning

This is the first comprehensive state-level high-risk AI governance regime in the United States.

It establishes structured risk management, documentation, transparency, and oversight obligations for both developers and deployers.

Position as enterprise AI governance compliance architecture.

## Internal Notes

Primary compliance focus areas:

1. High-Risk AI Inventory
2. Risk Management Program
3. Impact Assessment Framework
4. Consumer Notice & Transparency
5. Human Review & Appeals Workflow
6. Ongoing Monitoring & Incident Reporting
7. Enforcement Defense File

This is a cornerstone law in the AI compliance portfolio.