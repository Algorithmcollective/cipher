# Law Profile

## Law Name
Illinois Biometric Information Privacy Act (BIPA)

## Citation
740 ILCS 14/1 et seq.

## Status
Enacted

## Effective Date
October 3, 2008  
(Amendments affecting damages interpretation: 2023)

## Regulatory Scope

Applies to private entities that:

- Collect
- Capture
- Purchase
- Receive through trade
- Store
- Obtain biometric identifiers or biometric information

Applies regardless of company size.

## Biometric Identifiers Include

- Retina or iris scan
- Fingerprint
- Voiceprint
- Scan of hand or face geometry

Excludes:
- Photographs
- Writing samples
- Demographic data
- Biological samples used for medical testing

## Core Obligations

Private entities must:

1. Develop a publicly available written retention schedule and destruction policy
2. Provide written notice before collecting biometric data
3. Inform individuals of:
   - Purpose of collection
   - Length of retention
4. Obtain written informed consent
5. Prohibit sale or profit from biometric data
6. Implement reasonable data security measures
7. Restrict disclosure except under statutory exceptions

## Enforcement Authority

Private right of action  
Illinois Attorney General (limited enforcement authority)

## Penalties

Statutory damages:

- $1,000 per negligent violation
- $5,000 per reckless or intentional violation

Plus:
- Attorneys' fees
- Injunctive relief

Each scan may constitute a separate violation (subject to evolving interpretation).

Mass exposure risk is extremely high.

## Private Right of Action
Yes (primary enforcement mechanism)

## Tier Classification
Tier 1 – High Litigation Risk Biometric Law

## Revenue Priority
Very High

## Target Industries

- Employers using biometric time clocks
- Retail using facial recognition
- Security and surveillance providers
- Healthcare facilities using biometric access
- Financial institutions using biometric authentication
- AI facial recognition vendors

## Strategic Positioning

BIPA is the most aggressive biometric litigation statute in the United States.

Primary compliance driver:
Litigation risk mitigation.

Sell as:
Biometric Risk Containment & Class Action Prevention Program.

## Internal Notes

Primary compliance focus areas:

1. Biometric Inventory
2. Written Retention Policy
3. Notice & Consent Framework
4. Vendor Controls
5. Security Safeguards
6. Audit & Controls Verification
7. Litigation Defense Documentation

This is a cornerstone high-revenue compliance regime.