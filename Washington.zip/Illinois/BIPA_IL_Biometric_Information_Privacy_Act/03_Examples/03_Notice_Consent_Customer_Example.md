# Biometric Data Notice & Consent – CUSTOMER Identity Verification

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** NovaVerify Inc.  
**Use Case:** Customer Identity Verification (Selfie + ID Document Match)  

---

## 1. Biometric Data Notice

NovaVerify Inc. (“NovaVerify”) offers an online identity verification service. When you complete identity verification for an Illinois‑based account or transaction, we may collect and use **biometric data** related to your face.

Under Illinois law:

- “Biometric identifiers” include scans of face geometry.  
- “Biometric information” means information based on a biometric identifier that is used to identify an individual.

### What We Collect

For identity verification, NovaVerify may collect and use:

- **Biometric data type:** Face‑geometry data derived from your selfie image and from the photo on your government‑issued ID.  
- **How it is captured:**  
  - You take a selfie using your device camera.  
  - You capture an image of your government‑issued ID (such as a driver’s license or passport).  
- **Who is affected:**  
  - Customers who choose to complete identity verification for NovaVerify’s clients and who are located in, or verifying identity for, an Illinois account or transaction.

### Why We Collect It (Purpose)

We collect and use your biometric data solely to:

- Verify that the person in the selfie matches the person in the ID document;  
- Help prevent fraud and protect accounts and transactions handled by NovaVerify and its clients.

We do not use your biometric data for unrelated purposes such as advertising, general tracking, or sharing with data brokers.

### How Long We Keep It (Retention)

NovaVerify keeps your biometric data **only as long as necessary** to complete identity verification and support limited fraud‑prevention checks, and in any event, no longer than:

- The date on which the verification and related fraud checks are complete; **or**  
- Three (3) years after your last interaction with NovaVerify in connection with the relevant account or transaction,

whichever occurs first, unless a longer period is required by law.

After this period, NovaVerify permanently deletes your biometric data from its systems and requests that its biometric processing vendor(s) do the same, consistent with NovaVerify’s Biometric Data Privacy, Retention & Destruction Policy.

### How We Protect It

NovaVerify stores, transmits, and protects biometric data using a reasonable standard of care and in a manner that is the same as or more protective than the methods used to protect other confidential and sensitive information, such as authentication credentials and transaction details.

Protections include:

- Encryption of biometric templates at rest and in transit;  
- Strict access controls limited to personnel who need access to perform verification or maintain the system;  
- Vendor security and privacy requirements for biometric processing providers.

### Sharing and Sale

- NovaVerify does **not** sell, lease, trade, or otherwise profit from your biometric data.  
- NovaVerify may share your biometric data only:
  - With its biometric processing vendor(s), solely to perform identity verification and fraud prevention on NovaVerify’s behalf;  
  - With the business that requested the verification, in the form of verification results (e.g., pass/fail) and only as needed;  
  - As required by law, such as in response to a valid warrant, subpoena, or court order.

NovaVerify’s vendors are contractually prohibited from using your biometric data for their own purposes.

---

## 2. Consent / Written Release

By checking the box, clicking “I agree,” or otherwise electronically acknowledging this Notice, you:

1. Confirm that you have read and understood this **Biometric Data Notice & Consent – Customer Identity Verification**.  
2. Understand that NovaVerify and its service providers will collect, use, store, and disclose your biometric data for identity verification and fraud‑prevention purposes as described above.  
3. Understand how long your biometric data will be retained and that it will be deleted in accordance with NovaVerify’s Biometric Data Privacy, Retention & Destruction Policy.  
4. Authorize NovaVerify and its service providers to collect, use, store, and disclose your biometric data as described above and as permitted or required by law.

If you have any questions about this Notice or your biometric data, contact:  
- **Privacy Office:** privacy@novaverify.com or (312) 555‑0199.

---

### Customer Acknowledgment

I, _______________________________, acknowledge and agree to the collection, use, storage, and disclosure of my biometric data by NovaVerify Inc. as described above.

- Name: _______________________________  
- Signature (or electronic equivalent): _______________________________  
- Date: _______________________________  

---

**End of CUSTOMER Example**
