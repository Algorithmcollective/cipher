# Biometric Data Privacy, Retention & Destruction Policy – NovaRetail Inc.

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.[web:263][web:268][web:289]  
**Organization:** NovaRetail Inc.  
**Effective Date:** April 1, 2026  
**Approved By:** Sarah Kim, General Counsel  

---

## 1. Purpose

This Policy describes how NovaRetail Inc. (“NovaRetail”) collects, uses, safeguards, stores, retains, and destroys biometric identifiers and biometric information in compliance with applicable laws, including the Illinois Biometric Information Privacy Act (BIPA).[web:268][web:283][web:279][web:287]

---

## 2. Scope

This Policy applies to:

- Employees and contractors who use fingerprint time clocks in NovaRetail’s Illinois locations;  
- Individuals whose images are processed by NovaRetail’s pilot in‑store loss‑prevention analytics system in Illinois;  
- Vendors that process biometric data on NovaRetail’s behalf, including TimeTrack Co. (timekeeping) and SecureView Inc. (video analytics).[web:268][web:271][web:286]

---

## 3. Definitions

For purposes of this Policy:

- **Biometric identifier** means a fingerprint or scan of face geometry as used in NovaRetail’s systems.[web:263][web:268][web:281][web:284]  
- **Biometric information** means information based on a biometric identifier that is used to identify an individual, including fingerprint templates and face‑geometry data associated with identifiable employees or customers.[web:263][web:268][web:281]  

Collectively, these are referred to as **biometric data**.

Biometric identifiers do not include photographs or simple video footage without associated biometric analysis.[web:263][web:268][web:284]

---

## 4. Collection and Use of Biometric Data

NovaRetail uses biometric data for the following purposes:

1. **Employee Timekeeping (Fingerprint Time Clocks)**  
   - To verify the identity of employees clocking in and out of shifts at Illinois stores.  
   - Biometric data collected: fingerprint templates (not raw fingerprint images).  
   - Vendor: TimeTrack Co.

2. **Loss‑Prevention Analytics (Pilot)**  
   - To detect certain patterns of in‑store behavior and reduce theft at three pilot Illinois locations.  
   - Biometric data collected: face‑geometry‑based identifiers used by SecureView Inc. to track repeat appearances of individuals within a store.

Before collecting biometric data, NovaRetail:

- Provides a **written Biometric Notice & Consent** form to employees using time clocks, describing the purpose and retention period;  
- Posts enhanced **in‑store signage** in pilot locations to inform visitors that video analytics including biometric analysis may be used.[web:268][web:283][web:265][web:279]

No biometric data is collected from employees or customers without the required notice and consent, except where a specific legal exception applies.

---

## 5. Retention Schedule and Destruction Guidelines

Consistent with BIPA Section 15(a), NovaRetail retains biometric data **only until** the earliest of:[web:268][web:289][web:283]

- The date on which the initial purpose for collecting the biometric data has been satisfied; or  
- Three (3) years after the individual’s last interaction with NovaRetail.

**Employee Timekeeping (Fingerprints):**

- Retained while the employee is actively employed in a role that uses fingerprint time clocks.  
- Upon termination of employment or transfer to a non‑biometric role, biometric data is flagged for deletion.  
- In any case, biometric data is deleted no later than three years after the employee’s last interaction with NovaRetail.[web:277][web:270][web:282]

**Loss‑Prevention Analytics (Face Geometry):**

- Face‑geometry identifiers are retained only as long as necessary to perform in‑store analytics, and for no longer than one year after the individual’s last recorded presence in the store, and in no case beyond three years after the last interaction.[web:282][web:270][web:283]

**Destruction Process:**

- Biometric data is permanently deleted from NovaRetail systems and from vendor systems (TimeTrack and SecureView) via secure deletion procedures.  
- NovaRetail requires written confirmation from vendors that biometric data deletions have been completed.[web:280][web:279][web:283]

Absent a valid warrant, subpoena, or other legal obligation, NovaRetail complies with this retention and destruction schedule.[web:268][web:279][web:283]

---

## 6. No Sale or Profit from Biometric Data

NovaRetail does **not** sell, lease, trade, or otherwise profit from any individual’s biometric data.[web:263][web:251][web:285][web:286]

Vendor contracts prohibit TimeTrack Co. and SecureView Inc. from selling or profiting from biometric data they process on NovaRetail’s behalf.

---

## 7. Disclosure of Biometric Data

NovaRetail may disclose biometric data only:

- To the individual whose data is collected, or with that individual’s consent;  
- To vendors such as TimeTrack Co. and SecureView Inc. as needed to provide contracted services;  
- To comply with a valid warrant, subpoena, court order, or other lawful requirement.[web:268][web:271][web:286]

Vendor contracts require that biometric data is used solely to provide services to NovaRetail, and not for any other purpose.

---

## 8. Data Security

NovaRetail stores, transmits, and protects biometric data using a reasonable standard of care, and in a manner that is the same as or more protective than it uses to protect other confidential and sensitive information.[web:268][web:283][web:285][web:242]

Security measures include:

- Encryption of biometric templates at rest and in transit;  
- Role‑based access controls limiting who can access biometric data;  
- Logging of access to biometric data repositories;  
- Periodic security reviews of vendors handling biometric data.

---

## 9. Roles and Responsibilities

- **Chief Privacy Officer (CPO):**  
  - Owns this Policy, reviews it annually, and coordinates updates.  

- **HR (Illinois Stores):**  
  - Ensures employees receive and sign Biometric Notice & Consent forms.  
  - Coordinates off‑boarding processes that trigger biometric data deletion.

- **Loss Prevention & IT:**  
  - Manage the loss‑prevention analytics pilot and ensure data minimization.  

- **Vendors (TimeTrack Co. & SecureView Inc.):**  
  - Process biometric data only under NovaRetail’s instructions and consistent with this Policy and BIPA.

---

## 10. Policy Review and Updates

This Policy will be reviewed at least annually and updated as needed in response to:

- Changes in BIPA or other applicable laws;  
- Changes in NovaRetail’s use of biometric technologies;  
- Internal audits, incident reviews, or vendor assessments.

Material updates will be communicated to affected employees and, where appropriate, to customers.

---

**End of Example Policy**
