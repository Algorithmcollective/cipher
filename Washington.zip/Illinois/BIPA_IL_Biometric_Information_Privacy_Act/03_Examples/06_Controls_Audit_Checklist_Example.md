# BIPA Controls & Internal Audit Checklist – NovaRetail Inc. (Example)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** NovaRetail Inc.  
**Prepared By:** Jordan Ellis, Director of Compliance  
**Review Period:** Q2 2026  

---

## 2. Scope & Inventory

**2.1 Coverage**

- ☑ We have identified the following biometric use cases:
  - UC‑1: Employee fingerprint time clocks (Illinois stores).  
  - UC‑2: In‑store loss‑prevention analytics using face geometry (pilot, 3 Illinois stores).

- ☑ For each use case, we have documented:
  - Biometric type, purposes, data subjects, vendors, and storage locations.

**2.2 Changes Since Last Review**

- New: None.  
- Retired: No biometric systems retired this quarter.

---

## 3. Policy & Governance

**3.1 Written Policy**

- ☑ Public **Biometric Data Privacy, Retention & Destruction Policy** published on NovaRetail’s website and in employee handbook.  
- ☑ Policy includes retention schedule, destruction guidelines, no‑sale statement, and basic security commitments.[web:318][web:319][web:320][web:317]

**3.2 Ownership**

- ☑ Chief Privacy Officer (CPO) designated as BIPA owner and responsible for this quarterly review.

---

## 4. Notice & Consent

**4.1 Forms & Content**

- UC‑1 (Time clocks – employees):
  - ☑ Updated **Biometric Data Notice & Consent – Employee Timekeeping** rolled out in April 2026.  
  - ☑ Form explains purpose (timekeeping), retention, and includes explicit written release.[web:268][web:316][web:319][web:324]

- UC‑2 (Loss‑prevention analytics – customers):
  - ☑ Pilot stores now have enhanced signage stating that video analytics, including potential biometric analysis, may be used for security and loss‑prevention.  
  - ☑ NovaRetail’s privacy notice describes this pilot and how to contact Privacy Office with questions.

**4.2 Process & Records**

- ☑ For employees hired after April 1, 2026, signed consent forms are stored in the HRIS.  
- ☑ Legacy employees (approx. 150) have been re‑papered; 3 remaining consents are pending due to leave of absence.  
- ☑ A log of consents (date, form version) is maintained.

---

## 5. Retention & Destruction

**5.1 Retention Rules**

- ☑ UC‑1: Fingerprint data retained while employed in time‑clock roles and no longer than three years after termination.  
- ☑ UC‑2: Face geometry data retained for up to one year after last store visit and in no case more than three years after last interaction.

**5.2 Destruction Practices**

- ☑ HR triggers deletion requests for UC‑1 when employees are terminated or move to non‑biometric roles.  
- ☑ IT coordinates with TimeTrack Co. to confirm deletion; confirmations are stored in the vendor management system.  
- ☑ For UC‑2, SecureView has implemented rolling deletion, removing face‑geometry identifiers older than 12 months.

Evidence for this quarter:

- Deletion logs for 18 terminated employees; vendor confirmations received for all.[web:260][web:314][web:321]

---

## 6. Vendors & Contracts

- ☑ TimeTrack Co. and SecureView Inc. are the only vendors processing biometric data.  
- ☑ Contracts for both vendors:
  - Prohibit sale or profit from biometric data;  
  - Limit use to services for NovaRetail;  
  - Align retention/deletion with NovaRetail’s policy;  
  - Include minimum security standards and incident notification obligations.[web:260][web:311][web:321][web:310]  

- ☑ Vendor due‑diligence files (IL_BIPA_04) updated with March 2026 reviews.

---

## 7. Security Controls

- ☑ Biometric templates (UC‑1, UC‑2) are encrypted at rest and in transit.  
- ☑ Access to dashboards containing biometric data limited to specific HR, Loss Prevention, and IT admins.  
- ☑ Log review samples show no unauthorized access attempts this quarter.  
- ☑ Biometric data is explicitly included in incident response plans and tabletop exercises.[web:268][web:306][web:320][web:321]

---

## 8. Training & Awareness

- ☑ HR and Loss Prevention teams completed BIPA training in May 2026.  
- ☑ Training covers:
  - BIPA basics;  
  - Notice & consent requirements;  
  - Deletion triggers;  
  - How to respond to employee and customer questions.  

Training records (attendance logs, materials) are stored in the LMS.[web:315][web:318][web:320]

---

## 9. Issues Found and Remediation Plan

**Issues:**

1. Three legacy employees still have not signed updated BIPA consent forms due to leave or extended absence.  
2. Loss‑prevention signage could be more visible at one pilot store location.

**Remediation Actions:**

| Issue | Action | Owner | Target Date | Status |
|-------|--------|-------|------------|--------|
| Legacy consents outstanding | Obtain consent at next active shift or reassign to non‑biometric clock temporarily | HR Lead | June 30, 2026 | In progress |
| Signage visibility | Install additional signage at Store #IL‑03 entrance | Store Manager, IL‑03 | May 15, 2026 | Completed |

---

## 10. Review Sign‑Off

Reviewer: Sarah Kim, General Counsel  
Date of completion: June 5, 2026  

---

**End of Example**
