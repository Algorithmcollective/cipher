# Illinois BIPA – Scope & Risk Assessment Memo – NovaRetail Inc.

**Law:** Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Document Type:** Scope & Risk Assessment (Example)  
**Organization:** NovaRetail Inc.  
**Date:** January 31, 2026  
**Prepared By:** Jordan Ellis, Director of Compliance  

---

## 1. Purpose of This Memo

This memo evaluates how the Illinois Biometric Information Privacy Act (BIPA) applies to NovaRetail Inc., identifies systems that process biometric identifiers or biometric information for Illinois residents, and highlights key compliance risks and actions.

---

## 2. Overview of BIPA (Plain Language)

BIPA applies to private entities that obtain biometric identifiers or biometric information from individuals in Illinois.[web:263][web:268]

- NovaRetail’s relevant biometric types include:
  - Fingerprints (employee time clocks).  
  - Face geometry (AI‑based loss‑prevention analytics in Illinois stores).  

Under BIPA, NovaRetail must:

- Maintain a written, public **retention & destruction policy** for biometric data.[web:268][web:270]  
- Provide **written notice** and obtain **written consent** before collection, explaining the purpose and length of storage.[web:268][web:271][web:265]  
- Not sell or otherwise profit from biometric data.[web:263][web:251][web:264]  
- Use reasonable security protections.[web:268][web:271][web:242]  

BIPA allows individuals to sue for statutory damages per violation, which elevates litigation risk.[web:264][web:274]

---

## 3. Applicability to NovaRetail Inc.

### 3.1 Presence in Illinois

- NovaRetail operates 12 physical retail stores in Illinois.  
- NovaRetail employs approximately 220 employees in Illinois.  
- The company collects data from Illinois customers via loyalty programs and in‑store cameras.

Conclusion: **BIPA is in scope** for NovaRetail.

### 3.2 Use of Biometric Identifiers / Biometric Information

NovaRetail’s current biometric uses:

- **Use case UC‑1 – Employee Time Clocks (Illinois stores)**  
  - Fingerprint time clocks used for hourly associates to clock in/out.  
  - Vendor: TimeTrack Co. hosts biometric templates in its cloud.

- **Use case UC‑2 – In‑Store Loss‑Prevention Analytics (Pilot)**  
  - AI video analytics vendor uses cameras to detect “suspicious behavior” and flags individuals based partly on face geometry patterns.  
  - Pilot running in 3 Illinois stores.  

No voiceprints, retina/iris scans, or hand‑geometry systems are currently in use.

---

## 4. Data Flows and Vendors

| Use Case ID | System / Product | Biometric Type | Data Subjects | Storage Location(s) | Vendor(s) |
|------------|------------------|----------------|--------------|---------------------|----------|
| UC‑1 | TimeTrack Fingerprint Clock | Fingerprint (template) | Illinois store employees | TimeTrack US‑East data center (cloud) | TimeTrack Co. |
| UC‑2 | SecureView Analytics | Face geometry (derived) | Illinois store visitors and employees | SecureView cloud (US region) | SecureView Inc. |

---

## 5. Current BIPA Controls (Snapshot)

### 5.1 Public Policy & Retention Schedule

- NovaRetail does **not yet have** a standalone public Biometric Data Policy or retention schedule.  
- The employee handbook references “time clock data” but not BIPA specifically.

Status: **No / Partial** for both UC‑1 and UC‑2.

### 5.2 Notice & Written Consent

- **UC‑1 (Time clocks):**  
  - Onboarding packet includes a generic “time clock consent” form but does not explicitly reference biometric identifiers, the specific purpose, or retention period as required by BIPA.[web:268][web:271][web:265]  
  - Some long‑tenured employees signed older forms that may not meet BIPA standards.

- **UC‑2 (Loss‑prevention cameras):**  
  - In‑store signage says “Premises monitored by video surveillance” but does not disclose biometric analysis or its purposes.  
  - No individual written consent is obtained from customers.

Status: **Non‑compliant / unclear** for both UC‑1 and UC‑2.

### 5.3 No Sale / Profit

- NovaRetail does not sell or rent biometric data.  
- Contracts with TimeTrack and SecureView do not clearly prohibit vendors from profiting from biometric data.

Status: **Practice aligned, contracts need tightening.**[web:263][web:251][web:264]

### 5.4 Disclosure & Sharing

- UC‑1: TimeTrack has access as service provider; no other routine disclosures.  
- UC‑2: SecureView has access to video and analytics; no other sharing documented.  
- No formal policy describing allowable disclosures under BIPA (consent, transactions, law, or court orders).[web:268][web:271]

### 5.5 Security

- NovaRetail’s vendor security requirements are general (SOC 2, encryption at rest and in transit).  
- No explicit reference to biometric data or parity with other sensitive data.[web:268][web:271][web:242]

---

## 6. Risk Assessment

### 6.1 Legal & Litigation Risk

Key issues:

- No clear, public **BIPA retention & destruction policy**.[web:268][web:270][web:267]  
- Historical fingerprint collection (UC‑1) conducted without BIPA‑grade notice and consent.  
- Loss‑prevention analytics (UC‑2) may be using face geometry without any BIPA disclosures or consent.

Given BIPA’s private right of action and statutory damages, NovaRetail faces **elevated litigation risk**, particularly from current and former employees and from class‑style claims related to Store cameras.

**Overall BIPA risk level:** **High**

### 6.2 Operational & Reputational Risk

- Potential need to change time‑clock and camera vendors if they cannot meet BIPA requirements.  
- Negative publicity risk if customers learn that biometric analytics were deployed without clear notice.

---

## 7. Recommended Next Steps

**Priority 1 – Foundation (0–60 days)**

1. Engage outside counsel to confirm scope and review planned documents.  
2. Draft and publish a **Biometric Data Policy & Retention Schedule** that:
   - Covers both employee and customer biometric uses.  
   - Sets destruction at the earlier of purpose completion or 3 years after last interaction.[web:268][web:270][web:267]  

3. Replace current time‑clock forms with BIPA‑compliant **Notice & Consent** for UC‑1, re‑papering existing employees where needed.[web:268][web:271][web:255][web:269]  
4. Implement improved **in‑store signage** and/or alternatives for UC‑2 (or pause pilot in Illinois until compliance is confirmed).

**Priority 2 – Vendors & Controls (60–120 days)**

5. Amend contracts with TimeTrack and SecureView to:
   - Prohibit selling/profiting from biometric data.  
   - Require deletion on request and at end of retention period.  
   - Require BIPA‑level security and cooperation with audits.[web:252][web:242]  

6. Implement logging for biometric data deletion events.

**Priority 3 – Ongoing Governance (120+ days)**

7. Establish an annual BIPA self‑audit using the Controls & Audit Checklist.  
8. Train HR, IT, and Loss Prevention teams on BIPA basics and NovaRetail’s internal procedures.

**Owners & Target Dates**

| Action | Owner | Target Date |
|--------|-------|------------|
| Draft Biometric Data Policy & Retention Schedule | Compliance | March 15, 2026 |
| Roll out new time‑clock consent process | HR | April 1, 2026 |
| Review/renegotiate biometric vendor contracts | Legal | May 1, 2026 |
| Implement annual BIPA self‑audit | Compliance | July 1, 2026 |

---

**End of Example**
