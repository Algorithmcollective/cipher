# Biometric Data Notice & Consent – Employee Timekeeping

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.[web:263][web:268][web:289]  
**Organization:** NovaRetail Inc.  
**Use Case:** Employee Timekeeping (Fingerprint Time Clocks – Illinois Stores)  

---

## 1. Biometric Data Notice

NovaRetail Inc. (“NovaRetail”) uses fingerprint‑based time clocks at certain Illinois locations to verify employee identity when clocking in and out for work. These time clocks collect and use **biometric data**.

Under Illinois law:

- “Biometric identifiers” include fingerprints and scans of hand or face geometry.  
- “Biometric information” means information based on a biometric identifier that is used to identify an individual.[web:263][web:268][web:255][web:301]

### What We Collect

For timekeeping and payroll purposes, NovaRetail collects and uses:

- **Biometric data type:** Fingerprint template (a mathematical representation derived from your fingerprint, not a raw fingerprint image).  
- **How it is captured:** When you place your finger on the time clock scanner at the start and end of your shift.  
- **Who is affected:** Hourly employees and other workers who use fingerprint time clocks at NovaRetail’s Illinois stores.

### Why We Collect It (Purpose)

We collect and use your fingerprint template solely to:

- Verify your identity when you clock in and out;  
- Track your working hours accurately for payroll and scheduling.

We do not use this biometric data for any other purpose, such as background checks or performance monitoring.

### How Long We Keep It (Retention)

NovaRetail retains your biometric data **only as long as necessary** to fulfill the purposes above, and in any event, no longer than:

- The date your employment with NovaRetail ends; **or**  
- Three (3) years after your last interaction with NovaRetail (such as your last clock‑in),

whichever occurs first, unless a longer period is required by law.[web:268][web:270][web:297]

After this period, NovaRetail will permanently delete your biometric data from its systems and will request that its time‑clock vendor, TimeTrack Co., permanently delete your biometric data from their systems.[web:270][web:280][web:282]

### How We Protect It

NovaRetail stores, transmits, and protects biometric data using a reasonable standard of care, and in a manner that is the same as or more protective than the methods it uses to protect other confidential and sensitive information (such as Social Security numbers and payroll data).[web:268][web:283][web:301][web:242]

Measures include:

- Encryption of biometric templates at rest and in transit;  
- Limiting access to authorized HR, Payroll, and IT personnel;  
- Vendor security requirements for TimeTrack Co.

### Sharing and Sale

- NovaRetail does **not** sell, lease, trade, or otherwise profit from your biometric data.[web:263][web:251][web:292][web:301]  
- NovaRetail may share your biometric data only:
  - With TimeTrack Co., which operates the time‑clock system under contract with NovaRetail;  
  - As required by law, such as in response to a valid warrant, subpoena, or court order.

TimeTrack Co. is prohibited by contract from selling or using your biometric data for any purpose other than operating the time‑clock system for NovaRetail.

---

## 2. Consent / Written Release

By signing or electronically acknowledging this form, you:

1. Acknowledge that you have received and read this **Biometric Data Notice & Consent – Employee Timekeeping**;  
2. Understand that NovaRetail will collect, store, and use your fingerprint‑based biometric data for timekeeping and payroll purposes;  
3. Understand how long your biometric data will be retained and that it will be destroyed in accordance with NovaRetail’s Biometric Data Privacy, Retention & Destruction Policy;  
4. Authorize NovaRetail and TimeTrack Co. to collect, use, store, and disclose your biometric data as described above, and as permitted or required by law.[web:268][web:290][web:298][web:301]

If you have any questions, contact:  
- **Privacy & Compliance:** privacy@novaretail.com or (312) 555‑0100.

---

### Employee Signature

I, _______________________________, have read and understood this Biometric Data Notice & Consent and voluntarily agree to the collection, use, storage, and disclosure of my biometric data as described above.

- Employee Name: _______________________________  
- Employee Signature (or electronic equivalent): _______________________________  
- Date: _______________________________  

---

**End of Example**
