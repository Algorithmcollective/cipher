# Vendor Due Diligence & Contract Checklist – Biometric Data (Example)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** NovaRetail Inc.  
**Prepared By:** Jordan Ellis, Director of Compliance  
**Date:** March 10, 2026  

---

## 1. Purpose

This checklist documents NovaRetail’s assessment of TimeTrack Co., a vendor that provides fingerprint time clocks used by NovaRetail employees in Illinois.

---

## 2. Vendor & Use Case Overview

- **Vendor name:** TimeTrack Co.  
- **Service description:** Cloud‑hosted fingerprint time clocks for employee timekeeping and attendance.  
- **Biometric data processed:**
  - ☑ Fingerprints (stored as templates)  
  - ☐ Face geometry  
  - ☐ Voiceprints  
  - ☐ Retina / iris scans  
- **Data subjects:**
  - ☑ Employees  
  - ☐ Contractors  
  - ☐ Customers / users  

---

## 3. Legal & Policy Alignment (BIPA Basics)

**3.1 BIPA Awareness**

- ☑ TimeTrack acknowledges its role as a processor of biometric data and references BIPA specifically in its privacy documentation.  
- ☑ TimeTrack provided a copy of its Biometric Data Policy, which addresses notice, retention, and deletion expectations for its customers.

**3.2 No Sale / Profit**

- ☑ Master Service Agreement (MSA) Section 5.3 states that TimeTrack “will not sell, lease, trade, or otherwise profit from biometric identifiers or biometric information processed on behalf of Customer.”[web:263][web:303][web:309][web:311]

**3.3 Retention & Destruction**

- ☑ TimeTrack confirms it can support NovaRetail’s retention schedule (purpose‑based, and no longer than 3 years after last interaction).  
- ☑ MSA Section 6.4 requires TimeTrack to delete biometric data within 30 days of NovaRetail’s written request and upon termination of the services, subject to legal holds.[web:268][web:270][web:313]  

**3.4 Consent & Notice Support**

- ☑ TimeTrack’s documentation notes that customers (like NovaRetail) are responsible for obtaining BIPA‑compliant notice and consent from employees.  
- ☑ There is no direct data collection from employees by TimeTrack without NovaRetail’s involvement.

---

## 4. Security & Technical Controls

**4.1 Reasonable Security**

- ☑ TimeTrack represents that it uses a reasonable standard of care to protect biometric data and protects biometric templates at least as strongly as other sensitive data (including encryption and access controls).[web:268][web:306][web:311]  
- ☑ Provided summary of SOC 2 Type II report and high‑level security architecture.

**4.2 Technical Measures**

- ☑ Encryption of biometric data at rest (AES‑256).  
- ☑ Encryption in transit (TLS 1.2+).  
- ☑ Role‑based access control for admin portals.  
- ☑ Logging of administrator access to biometric data.  
- ☑ Annual penetration testing by a third‑party security firm.[web:260][web:306][web:310][web:308]

**4.3 Breach / Incident Handling**

- ☑ MSA Section 7.2 requires notification to NovaRetail “without undue delay” and within 72 hours of discovering a security incident involving biometric data.  
- ☑ Contract includes cooperation language and reimbursement for direct costs reasonably incurred responding to a breach caused by TimeTrack’s failure to maintain agreed security controls.[web:260][web:305][web:306][web:310]

---

## 5. Contract Clauses Checklist

| Clause | Required? | In Contract? | Location / Notes |
|--------|-----------|-------------|------------------|
| BIPA / biometric data definition & acknowledgement | Yes | ☑ Yes | DPA Exhibit A, “Definitions” |
| No sale / profit from biometric data | Yes | ☑ Yes | MSA §5.3 |
| Retention/destruction aligned with NovaRetail policy | Yes | ☑ Yes | DPA §4.2, MSA §6.4 |
| Use limited to providing services to NovaRetail | Yes | ☑ Yes | DPA §3.1 (“Purpose Limitation”) |
| Security standards (reasonable care, technical controls) | Yes | ☑ Yes | MSA §7, Security Addendum |
| Breach notification & cooperation | Yes | ☑ Yes | MSA §7.2 |
| Audit / assessment rights | Recommended | ☐ Partially | NovaRetail can request security summary reports; no formal onsite audit rights |
| Indemnification for vendor’s violations | Recommended | ☑ Yes | MSA §9.1 (data security indemnity) |

---

## 6. Risk Assessment & Decision

**Overall vendor BIPA risk level for this use case:**

- ☑ Low  
- ☐ Medium  
- ☐ High  

**Summary of key concerns:**

- No formal onsite audit rights, but SOC 2 reports and security summaries are acceptable for current risk level.  
- Deletion confirmation process should be tested during the next off‑boarding event.

**Decision:**

- ☑ Approved with conditions  

**Conditions:**

1. TimeTrack must provide written confirmation of deletion when NovaRetail requests deletion of biometric data for terminated employees.  
2. NovaRetail will revisit vendor security and contractual terms during the annual BIPA self‑audit.

**Approver:** Sarah Kim, General Counsel  
**Approval Date:** March 15, 2026  

---

**End of Example**
