# BIPA Discovery Script – Illinois Biometric Law

Purpose: Gather information needed to prepare BIPA compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Scope & Applicability

Say:
“I need to identify any systems that collect or analyze biometric information.”

Ask:

- Do you operate in Illinois or process data of Illinois residents
- List biometric use cases (time clocks, ID verification, face analytics, voice auth)
- Systems involved
- Vendors involved
- Biometric types collected
- Data subjects (employees, customers, visitors)

---

## 🧾 Deliverable: Data Flow & Inventory

Ask per use case:

- Capture method
- Storage location
- Access roles
- Transmission path
- Sharing
- Retention approach

---

## 🧾 Deliverable: Biometric Policy & Retention

Ask:

- Policy exists?
- Policy owner
- Approved use cases
- Retention period
- Destruction trigger
- Destruction method
- Public policy location

---

## 🧾 Deliverable: Notice & Consent

Ask:

- Notice provided before collection
- Written consent method
- Consent storage
- Purpose explained
- Retention explained
- Separate forms for employees vs customers
- Consent updates when practices change

---

## 🧾 Deliverable: Vendor Due Diligence

Ask:

- Vendors handling biometrics
- Contract prohibits sale/profit
- Retention alignment
- Security controls
- Deletion support
- Incident notification
- Audit rights

---

## 🧾 Deliverable: Controls & Internal Audit

Ask:

- Inventory completeness
- Consent logging method
- Deletion evidence
- Vendor review cadence
- Security controls used
- Training provided

---

## 🧾 Deliverable: Incident & Investigation

Ask:

- Incident definition
- Logging system
- Investigation roles
- Vendor coordination
- Notification decision process
- Remediation tracking

---

## ✅ Closing

Say:
“That gives us what we need to prepare your BIPA documentation.”