# BIPA Discovery Worksheet

---

## Scope

Illinois Presence:
Biometric Use Cases:
Systems:
Vendors:
Biometric Types:
Data Subjects:

---

## Data Flow

Capture:
Storage:
Access:
Transmission:
Sharing:
Retention:

---

## Policy

Policy Exists:
Owner:
Approved Uses:
Retention Period:
Destruction Trigger:
Destruction Method:
Public Location:

---

## Notice & Consent

Notice Provided:
Consent Method:
Consent Storage:
Purpose Explained:
Retention Explained:
Employee vs Customer Forms:
Update Process:

---

## Vendors

Vendor List:
No Sale Clause:
Retention Alignment:
Security Controls:
Deletion Support:
Incident Notification:
Audit Rights:

---

## Controls & Audit

Inventory Complete:
Consent Logs:
Deletion Evidence:
Vendor Review:
Security Controls:
Training:

---

## Incidents

Incident Definition:
Logging System:
Investigation Roles:
Vendor Coordination:
Notification Process:
Remediation Tracking:

---

## TBD

Item:
Owner:
Notes: