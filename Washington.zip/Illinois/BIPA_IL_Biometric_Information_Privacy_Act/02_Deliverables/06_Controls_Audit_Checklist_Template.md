# BIPA Controls & Internal Audit Checklist (TEMPLATE)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** {{ORG_NAME}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  
**Review Period:** {{PERIOD}}  

---

## 1. Purpose

This checklist is used for periodic internal reviews of {{ORG_NAME}}’s compliance with BIPA requirements, focusing on:

- Scope and inventory of biometric data;  
- Policies and notices;  
- Consent and record‑keeping;  
- Retention, destruction, and vendor management;  
- Security and incident handling.

It supports defensible, documented compliance efforts.[web:314][web:318][web:260][web:320]

---

## 2. Scope & Inventory

**2.1 Coverage**

- ☐ We have identified all systems and processes that collect or use biometric identifiers or biometric information (employees, contractors, customers).[web:260][web:318][web:321]  
- ☐ We have documented the type of biometric data, purposes, and locations for each use case.  

**2.2 Changes Since Last Review**

- ☐ New biometric use cases added? Describe: {{DETAILS}}  
- ☐ Any use cases retired or vendors off‑boarded? Describe: {{DETAILS}}  

---

## 3. Policy & Governance

**3.1 Written Policy**

- ☐ A publicly available **Biometric Data Privacy, Retention & Destruction Policy** exists and is up to date.[web:318][web:319][web:320][web:317]  
- ☐ The Policy includes:
  - Written retention schedule;  
  - Destruction guidelines;  
  - No‑sale / no‑profit statement;  
  - Basic data security commitments.[web:268][web:260][web:320]

**3.2 Ownership**

- ☐ A specific role (e.g., Privacy Officer / Compliance Lead) is responsible for BIPA compliance and this checklist.[web:318][web:320]

---

## 4. Notice & Consent

**4.1 Forms & Content**

For each biometric use case:

- ☐ We have BIPA‑aligned **Notice & Consent** forms (EMPLOYEE, CUSTOMER) that:
  - Inform individuals in writing that biometric data will be collected/stored/used;  
  - Explain the purpose;  
  - Explain the length of time for collection, storage, and use;  
  - Obtain written release/consent (including electronic consent where appropriate).[web:268][web:316][web:319][web:324]

**4.2 Process & Records**

- ☐ Consent is obtained **before** biometric data is collected for new users.[web:315][web:316][web:320]  
- ☐ We maintain records showing who has consented and when (e.g., logs or HRIS records).[web:316][web:318]  
- ☐ Processes exist to ensure consent is updated if purposes or retention practices change.

---

## 5. Retention & Destruction

**5.1 Retention Rules**

- ☐ Retention periods for biometric data follow the Policy and BIPA’s requirement to destroy data when:
  - The original purpose has been satisfied, **or**  
  - Three (3) years have passed since the individual’s last interaction,  
  whichever occurs first, unless legally required to retain longer.[web:268][web:270][web:319][web:323]

**5.2 Destruction Practices**

- ☐ There is a documented process for identifying biometric data that must be destroyed (e.g., upon termination, inactivity).  
- ☐ Destruction methods (secure deletion, physical destruction) are in place and tested.  
- ☐ We maintain evidence/logs that deletions occurred (where technically feasible).[web:260][web:314][web:321]

---

## 6. Vendors & Contracts

- ☐ All vendors that handle biometric data have been identified.  
- ☐ Vendor contracts:
  - Prohibit sale/profit from biometric data;  
  - Limit use to providing services to {{ORG_NAME}};  
  - Align retention and deletion with our Policy;  
  - Require appropriate security controls;  
  - Include incident notification and cooperation obligations.[web:260][web:311][web:321][web:310]  

- ☐ Vendor due‑diligence files are complete (see IL_BIPA_04).  

---

## 7. Security Controls

- ☐ Biometric data is protected with a reasonable standard of care and at least as protective as other sensitive data.[web:268][web:306][web:320]  
- ☐ Technical controls include (where applicable):
  - Encryption at rest and in transit;  
  - Access controls and least privilege;  
  - Audit logs for access and changes;  
  - Regular security testing and patching.[web:260][web:306][web:321]  

- ☐ Biometric data is integrated into the organization’s incident response and breach‑handling plans.[web:321][web:320]

---

## 8. Training & Awareness

- ☐ Employees who work with biometric systems receive training on:
  - BIPA basics;  
  - Notice & consent procedures;  
  - Handling and securing biometric data;  
  - Deletion processes.[web:315][web:318][web:320]  

- ☐ Training is refreshed periodically and documented.

---

## 9. Issues Found and Remediation Plan

For this review:

- **Issues identified:**  
  - {{ISSUE_1}}  
  - {{ISSUE_2}}  
  - {{ISSUE_3}}  

- **Remediation actions:**  

| Issue | Action | Owner | Target Date | Status |
|-------|--------|-------|------------|--------|
| {{ISSUE_1}} | {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} | {{STATUS_1}} |
| {{ISSUE_2}} | {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} | {{STATUS_2}} |

---

## 10. Review Sign‑Off

Reviewer: {{REVIEWER_NAME}}, {{ROLE}}  
Date of completion: {{REVIEW_DATE}}  

---

**End of TEMPLATE**
