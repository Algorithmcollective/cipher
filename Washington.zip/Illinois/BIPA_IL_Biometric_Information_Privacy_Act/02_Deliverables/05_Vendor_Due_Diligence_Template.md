# Vendor Due Diligence & Contract Checklist – Biometric Data (TEMPLATE)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** {{ORG_NAME}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  
**Date:** {{DATE}}  

---

## 1. Purpose

This checklist is used to evaluate and document whether vendors and service providers that process biometric data for {{ORG_NAME}} meet BIPA‑aligned requirements and {{ORG_NAME}}’s internal standards.

It should be completed during vendor selection and revisited periodically.

---

## 2. Vendor & Use Case Overview

- Vendor name: {{VENDOR_NAME}}  
- Service description: {{e.g., time clocks, ID verification, video analytics}}  
- Biometric data processed:
  - ☐ Fingerprints  
  - ☐ Face geometry  
  - ☐ Voiceprints  
  - ☐ Retina / iris scans  
  - ☐ Other: {{DETAILS}}  
- Data subjects:
  - ☐ Employees  
  - ☐ Contractors  
  - ☐ Customers / users  
  - ☐ Other: {{DETAILS}}  

---

## 3. Legal & Policy Alignment (BIPA Basics)

**3.1 BIPA Awareness**

- ☐ Vendor acknowledges that its services involve biometric data as defined by Illinois BIPA (even if vendor is not based in Illinois).[web:263][web:268][web:311]  
- ☐ Vendor provides a written statement or policy describing how it complies with biometric privacy laws.

**3.2 No Sale / Profit**

- ☐ Contract explicitly prohibits vendor from selling, leasing, trading, or otherwise profiting from biometric data.[web:263][web:303][web:309][web:311]  

**3.3 Retention & Destruction**

- ☐ Vendor can configure retention to match {{ORG_NAME}}’s BIPA policy (purpose‑based and/or ≤ 3 years after last interaction).[web:268][web:270][web:313]  
- ☐ Vendor commits to permanently delete biometric data:
  - On request from {{ORG_NAME}}, and  
  - At end of retention period or contract termination.[web:268][web:270][web:280][web:313]

**3.4 Consent & Notice Support**

- ☐ Vendor provides documentation of expected notices/consents its customers must obtain.  
- ☐ Vendor does not directly collect biometric data from {{ORG_NAME}}’s users without clear responsibilities for notice/consent in the contract.[web:268][web:251][web:311]

---

## 4. Security & Technical Controls

**4.1 Reasonable Security**

- ☐ Vendor represents that it uses a “reasonable standard of care” to protect biometric data, at least as protective as other sensitive data.[web:268][web:306][web:311]  
- ☐ Vendor has documented security policies and incident response procedures.

**4.2 Technical Measures (check if in place or required)**

- ☐ Encryption of biometric data at rest  
- ☐ Encryption of biometric data in transit  
- ☐ Access controls and least‑privilege permissions  
- ☐ Logging and monitoring of access to biometric repositories  
- ☐ Regular security testing (e.g., penetration tests, vulnerability scans)[web:260][web:306][web:310][web:308]

**4.3 Breach / Incident Handling**

- ☐ Contract requires prompt notification of any security incident involving biometric data.  
- ☐ Contract includes cooperation obligations and remediation support.  
- ☐ Contract addresses allocation of costs and indemnity for vendor‑caused incidents.[web:260][web:305][web:306][web:310]

---

## 5. Contract Clauses Checklist

For each item, indicate status and where it appears (section / exhibit).

| Clause | Required? | In Contract? | Location / Notes |
|--------|-----------|-------------|------------------|
| BIPA / biometric data definition & acknowledgement | Yes | ☐ Yes ☐ No | {{NOTES}} |
| No sale / profit from biometric data | Yes | ☐ Yes ☐ No | {{NOTES}} |
| Retention/destruction aligned with {{ORG_NAME}} policy | Yes | ☐ Yes ☐ No | {{NOTES}} |
| Use limited to providing services to {{ORG_NAME}} | Yes | ☐ Yes ☐ No | {{NOTES}} |
| Security standards (reasonable care, technical controls) | Yes | ☐ Yes ☐ No | {{NOTES}} |
| Breach notification & cooperation | Yes | ☐ Yes ☐ No | {{NOTES}} |
| Audit / assessment rights | Recommended | ☐ Yes ☐ No | {{NOTES}} |
| Indemnification for vendor’s violations | Recommended | ☐ Yes ☐ No | {{NOTES}} |

---

## 6. Risk Assessment & Decision

**Overall vendor BIPA risk level for this use case:**

- ☐ Low – Requirements largely met, minimal residual risk.  
- ☐ Medium – Some gaps covered by compensating controls or planned contract updates.  
- ☐ High – Significant gaps; remediation or alternative vendor recommended.

**Summary of key concerns:**

- {{CONCERN_1}}  
- {{CONCERN_2}}  
- {{CONCERN_3}}  

**Decision:**

- ☐ Approved (as‑is)  
- ☐ Approved with conditions (list conditions)  
- ☐ Not approved / alternative vendor recommended  

Conditions (if any):  
- {{CONDITION_1}}  
- {{CONDITION_2}}  

Approver: {{APPROVER_NAME}}, {{ROLE}}  
Date: {{APPROVAL_DATE}}  

---
**End of TEMPLATE**
