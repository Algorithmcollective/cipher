# Biometric Data Notice & Consent – CUSTOMER (MASTER TEMPLATE)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** {{ORG_NAME}}  
**Use Case:** {{e.g., Customer Identity Verification / In‑Store Analytics / KYC}}  

---

## 1. Biometric Data Notice

{{ORG_NAME}} may use certain technologies that collect and use **biometric identifiers** and **biometric information** (together, “biometric data”) related to you as a customer or user.

Under Illinois law:

- “Biometric identifiers” include retina or iris scans, fingerprints, voiceprints, and scans of hand or face geometry.  
- “Biometric information” means information based on a biometric identifier that is used to identify an individual.  

### What We Collect

For this use case, {{ORG_NAME}} may collect and use:

- Type of biometric data: {{FACE GEOMETRY / VOICEPRINT / FINGERPRINT / OTHER}}  
- How it is captured: {{e.g., selfie photo, video frame, voice sample, kiosk camera}}  
- Who is affected: {{customers completing identity verification / visitors in certain Illinois locations / users of a specific feature}}  

### Why We Collect It (Purpose)

We collect and use your biometric data only for the following purpose(s), for example:

- To verify your identity when you create an account or complete a high‑risk transaction;  
- To help prevent fraud and protect your account;  
- To support security and access‑control features you choose to use.

We do **not** use this biometric data for unrelated purposes such as marketing profiling or general tracking, unless we clearly tell you and obtain any additional required consent.

### How Long We Keep It (Retention)

We keep your biometric data **only as long as necessary** to fulfill the purposes listed above, and in any event, no longer than:

- Until the initial purpose for collecting the biometric data has been satisfied; **or**  
- Three (3) years after your last interaction with {{ORG_NAME}},

whichever occurs first, unless a longer period is required by law.

After this period, {{ORG_NAME}} will permanently destroy your biometric data and will request that relevant service providers do the same, consistent with our Biometric Data Privacy, Retention & Destruction Policy.

### How We Protect It

We store, transmit, and protect biometric data using a reasonable standard of care, and in a manner that is the same as or more protective than the methods we use to protect other confidential and sensitive information (for example, account credentials and financial information).

### Sharing and Sale

- {{ORG_NAME}} does **not** sell, lease, trade, or otherwise profit from your biometric data.  
- We may share your biometric data only:
  - With service providers who help us verify your identity or provide the feature you are using, under written contracts; or  
  - As required by law, such as in response to a valid warrant, subpoena, or court order.  

Our service providers are contractually required to protect your biometric data and may not use it for their own purposes.

---

## 2. Consent / Written Release

By signing, clicking “I agree,” or otherwise electronically acknowledging this form:

1. You confirm that you have read and understood this **Biometric Data Notice & Consent – Customer**.  
2. You understand that {{ORG_NAME}} and its service providers will collect, use, store, and disclose your biometric data for the purposes described above.  
3. You understand how long your biometric data will be retained and that it will be deleted in accordance with {{ORG_NAME}}’s Biometric Data Privacy, Retention & Destruction Policy.  
4. You authorize {{ORG_NAME}} and its service providers to collect, use, store, and disclose your biometric data as described in this Notice and as permitted or required by law.

If you have questions about this Notice or your biometric data, you may contact:  
- {{CONTACT_NAME}}, {{ROLE}} – {{CONTACT_EMAIL}}, {{CONTACT_PHONE}}.

---

### Customer Acknowledgment

I, {{CUSTOMER_NAME}}, acknowledge and agree to the collection, use, storage, and disclosure of my biometric data by {{ORG_NAME}} as described above.

- Name: _______________________________  
- Signature (or electronic equivalent): _______________________________  
- Date: _______________________________  

---

**End of CUSTOMER TEMPLATE**
