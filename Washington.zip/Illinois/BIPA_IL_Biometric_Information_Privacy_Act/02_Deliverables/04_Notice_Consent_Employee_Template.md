# Biometric Data Notice & Consent (MASTER TEMPLATE)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.[web:263][web:268][web:289]  
**Organization:** {{ORG_NAME}}  
**Use Case:** {{e.g., Employee Timekeeping / Customer Identity Verification}}  

---

## 1. Biometric Data Notice

{{ORG_NAME}} uses certain technologies that may collect and use **biometric identifiers** and **biometric information** (together, “biometric data”). Under Illinois law:[web:268][web:292][web:301]

- “Biometric identifiers” include retina or iris scans, fingerprints, voiceprints, and scans of hand or face geometry.  
- “Biometric information” means information based on a biometric identifier that is used to identify an individual.[web:263][web:268][web:255][web:301]

### What We Collect

For this specific use case, {{ORG_NAME}} may collect and use the following biometric data:

- Type of biometric data: {{FINGERPRINT / FACE GEOMETRY / VOICEPRINT / OTHER}}  
- How it is captured: {{e.g., fingerprint scanner, camera, microphone}}  
- Who is affected: {{employees in Illinois stores / customers using ID‑verification / etc.}}

### Why We Collect It (Purpose)

We collect and use biometric data **only** for the following purpose(s):

- {{e.g., to verify your identity for timekeeping and payroll purposes}}  
- {{e.g., to verify your identity when you access secure systems or locations}}  

We do not use biometric data for any other purposes without providing additional notice and obtaining any required consent.

### How Long We Keep It (Retention)

{{ORG_NAME}} keeps biometric data **only as long as necessary** to fulfill the purposes described above, and in any event, no longer than:

- Until the initial purpose for collection has been satisfied; **or**  
- Three (3) years after your last interaction with {{ORG_NAME}},

whichever occurs first, unless a longer period is required by law.[web:268][web:270][web:297]

After this period, biometric data will be permanently destroyed in accordance with {{ORG_NAME}}’s Biometric Data Privacy, Retention & Destruction Policy.[web:268][web:270][web:282][web:281]

### How We Protect It

{{ORG_NAME}} stores, transmits, and protects biometric data using a reasonable standard of care, and in a manner that is the same as or more protective than the methods it uses to protect other confidential and sensitive information.[web:268][web:283][web:301][web:242]

### Sharing and Sale

- {{ORG_NAME}} does **not** sell, lease, trade, or otherwise profit from biometric data.[web:263][web:251][web:292][web:301]  
- We may share biometric data only:
  - With vendors that help us provide the services described above (under written contracts), or  
  - As required by law, such as in response to a valid warrant, subpoena, or court order.[web:268][web:292][web:301]

---

## 2. Consent / Written Release

By signing or electronically acknowledging this form, you:

1. Acknowledge that you have received and read the **Biometric Data Notice** above;  
2. Understand that {{ORG_NAME}} will collect, use, and store your biometric data for the purposes described;  
3. Understand how long your biometric data will be retained and that it will be destroyed in accordance with {{ORG_NAME}}’s Biometric Data Privacy, Retention & Destruction Policy;  
4. Authorize {{ORG_NAME}} and its service providers to collect, use, store, and disclose your biometric data as described in this Notice, and as permitted or required by law.[web:268][web:290][web:298][web:301]

You may contact {{ORG_CONTACT_NAME}} at {{ORG_CONTACT_EMAIL}} or {{PHONE}} with questions about this Notice or your biometric data.

---

### Signature (for employees or other individuals)

I, {{INDIVIDUAL_NAME}}, have read and understood this Biometric Data Notice & Consent and voluntarily agree to the collection, use, storage, and disclosure of my biometric data as described above.

- Name: _______________________________  
- Signature (or electronic equivalent): _______________________________  
- Date: _______________________________  

---

**End of TEMPLATE**
