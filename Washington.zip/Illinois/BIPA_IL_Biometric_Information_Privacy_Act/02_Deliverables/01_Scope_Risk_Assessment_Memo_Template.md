# Illinois BIPA – Scope & Risk Assessment Memo (MASTER)

**Law:** Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Document Type:** Scope & Risk Assessment (Template)  
**Organization:** {{ORG_NAME}}  
**Date:** {{DATE}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  

---

## 1. Purpose of This Memo

This memo helps {{ORG_NAME}} determine:

- Whether the Illinois Biometric Information Privacy Act (BIPA) applies.  
- Which systems, products, or vendors involve biometric identifiers or biometric information.  
- Key compliance gaps and next steps.

It is not legal advice and should be reviewed by qualified counsel before being relied upon.

---

## 2. Overview of BIPA (Plain Language)

BIPA applies to **private entities** that collect, capture, purchase, receive, or otherwise obtain “biometric identifiers” or “biometric information” from individuals in Illinois.[web:263][web:268][web:271]

- **Biometric identifiers** include:  
  - Retina or iris scans  
  - Fingerprints  
  - Voiceprints  
  - Scans of hand or face geometry[web:263][web:268][web:271]  

- **Biometric information** means information based on a biometric identifier that is used to identify an individual.[web:263][web:268]

Key requirements include:

- Written **public policy** with a retention schedule and destruction guidelines.[web:268][web:270][web:267]  
- **Written notice and consent** before collecting biometric data, including purpose and length of storage.[web:268][web:271][web:265]  
- **No sale or profit** from biometric data.[web:263][web:251][web:264]  
- **Reasonable security** protections.[web:268][web:271][web:242]  

BIPA also includes a **private right of action** with statutory damages per violation.[web:264][web:274]

---

## 3. Applicability to {{ORG_NAME}}

### 3.1 Presence in Illinois

- Does {{ORG_NAME}} operate in Illinois (employees, facilities, customers, or users)?  
  - ☐ Yes  ☐ No  ☐ Unclear  
- Does {{ORG_NAME}} process data of individuals located in Illinois (even if {{ORG_NAME}} has no office there)?  
  - ☐ Yes  ☐ No  ☐ Unclear  

If either answer is “Yes” or “Unclear”, BIPA may apply.

### 3.2 Use of Biometric Identifiers / Biometric Information

For each listed use case, check all that apply:

- **Employee timekeeping / access control**  
  - ☐ Fingerprint / hand geometry time clocks  
  - ☐ Facial recognition for door / system access  
- **Identity verification / KYC**  
  - ☐ Face match (selfie vs. ID document)  
  - ☐ Voice biometrics for authentication  
- **AI / analytics using biometrics**  
  - ☐ Emotion / sentiment analysis from face video  
  - ☐ Gaze tracking, face geometry, or other biometric analysis  
- **Customer experiences**  
  - ☐ Face recognition at kiosks or in stores  
  - ☐ Voice profiling for call centers (voiceprints)  
- **Vendors handling biometrics on {{ORG_NAME}}’s behalf**  
  - ☐ Third‑party time clock vendor  
  - ☐ Identity verification provider  
  - ☐ Camera / analytics vendor (in‑store or in‑app)  

Provide a brief description of each identified use case:

- Use case UC‑1: {{DESCRIPTION}}  
- Use case UC‑2: {{DESCRIPTION}}  
- …

If no biometric identifiers or biometric information are used, document that conclusion and rationale.

---

## 4. Data Flows and Vendors

For each biometric use case identified:

| Use Case ID | System / Product | Biometric Type | Data Subjects (employees/customers) | Storage Location(s) | Vendor(s) Involved |
|------------|------------------|----------------|-------------------------------------|---------------------|--------------------|
| UC‑1 | {{SYSTEM_1}} | {{TYPE_1}} | {{SUBJECTS_1}} | {{LOCATIONS_1}} | {{VENDORS_1}} |
| UC‑2 | {{SYSTEM_2}} | {{TYPE_2}} | {{SUBJECTS_2}} | {{LOCATIONS_2}} | {{VENDORS_2}} |

---

## 5. Current BIPA Controls (Snapshot)

For each biometric use case, indicate whether the following are in place:

### 5.1 Public Policy & Retention Schedule

- Does {{ORG_NAME}} have a **written policy** (publicly available) with a retention schedule and destruction guidelines for biometric data?[web:268][web:270][web:267]  
  - ☐ Yes  ☐ No  ☐ Partial  

### 5.2 Notice & Written Consent

- Are individuals informed **in writing** that their biometric data is being collected?[web:268][web:271]  
- Are they informed of the **specific purpose and length of time** for which it will be stored and used?[web:268][web:271][web:265]  
- Is **written consent / release** obtained before collection?[web:268][web:271][web:255][web:269]  

For each use case UC‑X, summarize current practice:

- UC‑1: {{NOTICE_CONSENT_STATUS}}  
- UC‑2: {{NOTICE_CONSENT_STATUS}}  

### 5.3 No Sale / Profit

- Does {{ORG_NAME}} ever sell, lease, trade, or otherwise profit from biometric data?[web:263][web:251][web:264]  
  - ☐ Yes  ☐ No  ☐ Unclear  

### 5.4 Disclosure & Sharing

- Are disclosures limited to:  
  - The individual’s consent, or  
  - Transactions requested/authorized by the individual, or  
  - Required by law/warrant/subpoena?[web:268][web:271]  

### 5.5 Security

- Does {{ORG_NAME}} use reasonable standards of care to store, transmit, and protect biometric data, at least as protective as other confidential/sensitive data?[web:268][web:271][web:242]  

---

## 6. Risk Assessment

### 6.1 Legal & Litigation Risk

Consider:

- Any past or current BIPA claims or demand letters?  
- Any missing written policy or retention schedule?  
- Historical collection of biometrics without required notice/consent?

Summarize risk:

- **Current BIPA risk level for {{ORG_NAME}}:**  
  - ☐ Low  ☐ Medium  ☐ High  
  - Rationale: {{RATIONALE}}  

### 6.2 Operational & Reputational Risk

- Risk of enforcement or private lawsuits if gaps are not addressed.  
- Reputational harm if biometric practices are exposed as non‑compliant.

---

## 7. Recommended Next Steps

List prioritized actions, e.g.:

1. Confirm BIPA applicability and scope with legal counsel.  
2. Create or update **Biometric Data Policy & Retention Schedule** (Deliverable 2).  
3. Implement or update **Notice & Consent** processes and forms (Deliverable 3).  
4. Review and update contracts with biometric vendors (Deliverable 4).  
5. Implement annual BIPA self‑audit using the Controls & Audit Checklist (Deliverable 5).

Responsible owners and target dates:

| Action | Owner | Target Date |
|--------|-------|------------|
| {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} |
| {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} |

---

**End of Template**
