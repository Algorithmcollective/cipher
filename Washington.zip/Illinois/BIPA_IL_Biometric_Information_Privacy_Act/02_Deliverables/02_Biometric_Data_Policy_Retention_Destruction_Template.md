# Biometric Data Privacy, Retention & Destruction Policy (MASTER)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.[web:263][web:268][web:289]  
**Organization:** {{ORG_NAME}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Approved By:** {{APPROVER_NAME}}, {{TITLE}}  

---

## 1. Purpose

This Policy defines how {{ORG_NAME}} collects, uses, safeguards, stores, retains, and destroys biometric identifiers and biometric information in compliance with applicable laws, including the Illinois Biometric Information Privacy Act (BIPA).[web:268][web:283][web:279][web:287]

---

## 2. Scope

This Policy applies to:

- All biometric identifiers and biometric information of individuals whose data {{ORG_NAME}} collects or controls;  
- All business units that implement biometric technologies for employees, contractors, customers, or other individuals;  
- All vendors and service providers who process biometric data on behalf of {{ORG_NAME}}.[web:268][web:271][web:286]

---

## 3. Definitions

For purposes of this Policy:

- **Biometric identifier** means a retina or iris scan, fingerprint, voiceprint, or scan of hand or face geometry.[web:263][web:268][web:281][web:284]  
- **Biometric information** means any information, regardless of how it is captured, converted, stored, or shared, based on an individual’s biometric identifier that is used to identify an individual.[web:263][web:268][web:281]  
- **Biometric data** means biometric identifiers and biometric information collectively.

Biometric identifiers do **not** include, for example, writing samples, written signatures, photographs, demographic data, or physical descriptions.[web:263][web:268][web:284]

---

## 4. Collection and Use of Biometric Data

{{ORG_NAME}} may collect and use biometric data only for specific, limited purposes, such as:

- Timekeeping or access control for employees;  
- Identity verification for employees, contractors, or customers;  
- Other business purposes that have been evaluated and approved by {{DESIGNATED_ROLE}}.

Before collecting biometric data, {{ORG_NAME}} will:

1. Inform the individual in writing that biometric data is being collected or stored;  
2. Inform the individual in writing of the specific purpose and length of term for which the biometric data is being collected, stored, and used;  
3. Obtain a written release or consent from the individual or the individual’s legally authorized representative.[web:268][web:283][web:265][web:279]

No biometric data may be collected or used without this process, unless an applicable law provides a specific exception.

---

## 5. Retention Schedule and Destruction Guidelines

In accordance with BIPA Section 15(a):[web:268][web:289][web:283]

- {{ORG_NAME}} will retain biometric data **only until** the earliest of:  
  - The date on which the initial purpose for collecting or obtaining the biometric data has been satisfied; **or**  
  - Three (3) years after the individual’s last interaction with {{ORG_NAME}}.[web:268][web:270][web:282][web:286]

- Once the applicable retention period has expired, {{ORG_NAME}} will permanently destroy the biometric data in its possession, and will request that relevant vendors do the same, unless a valid warrant, subpoena, or other legal requirement prevents deletion.[web:268][web:279][web:280][web:283]

**Destruction methods** may include secure deletion of electronic data and destruction of physical media, consistent with industry practices for sensitive information.

{{ORG_NAME}} will comply with this retention schedule and destruction process absent a valid warrant, subpoena, or other lawful order requiring further retention.[web:268][web:283][web:279]

---

## 6. No Sale or Profit from Biometric Data

{{ORG_NAME}} will not sell, lease, trade, or otherwise profit from an individual’s biometric data.[web:263][web:251][web:285][web:286]

---

## 7. Disclosure of Biometric Data

{{ORG_NAME}} may disclose biometric data only:

- With the individual’s informed consent;  
- To a service provider or vendor as necessary to perform services requested or authorized by the individual;  
- As required by or permitted under applicable law, including in response to a valid warrant, subpoena, or court order.[web:268][web:271][web:286]

Any vendor receiving biometric data must agree in writing to comply with this Policy and applicable laws.

---

## 8. Data Security

{{ORG_NAME}} will store, transmit, and protect biometric data using a **reasonable standard of care**, and in a manner that is the same as or more protective than the methods used to protect other confidential and sensitive information.[web:268][web:283][web:285][web:242]

Security measures may include:

- Encryption at rest and in transit;  
- Access controls and least‑privilege permissions;  
- Monitoring and logging of access;  
- Vendor security assessments.

---

## 9. Roles and Responsibilities

- **{{DESIGNATED_ROLE}} (e.g., Privacy Officer / Compliance Lead):**  
  - Maintains this Policy and reviews it at least annually.  
  - Oversees implementation of retention/destruction practices.  

- **HR / Operations:**  
  - Ensures appropriate notice and consent processes for employees.  

- **IT / Security:**  
  - Implements technical controls to secure biometric data and support secure destruction.  

- **Vendors / Service Providers:**  
  - Process biometric data only as instructed by {{ORG_NAME}} and in compliance with this Policy and applicable law.

---

## 10. Policy Review and Updates

This Policy will be reviewed periodically and updated as needed to reflect:

- Changes in applicable laws and regulations;  
- Changes in {{ORG_NAME}}’s use of biometric technologies;  
- Lessons learned from internal audits, incidents, or vendor assessments.

Material changes will be communicated to affected stakeholders and, where required, to affected individuals.

---

**End of MASTER Policy**
