# Biometric Data Incident & Investigation Playbook (TEMPLATE)

**Law Reference:** Illinois Biometric Information Privacy Act (BIPA), 740 ILCS 14/1 et seq.  
**Organization:** {{ORG_NAME}}  
**Owner:** {{OWNER_NAME}}, {{ROLE}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  

---

## 1. Purpose & Scope

This Playbook describes how {{ORG_NAME}} identifies, investigates, and responds to actual or suspected security incidents or policy violations involving biometric data.

It supplements the organization’s general incident response plan by focusing on the heightened risks and obligations associated with biometric identifiers and biometric information.[web:325][web:326][web:327][web:321]

---

## 2. What Counts as a “Biometric Incident”

For this Playbook, a **biometric incident** includes:

- Unauthorized access to biometric identifiers or biometric information (e.g., fingerprints, face geometry, voiceprints);  
- Accidental exposure or loss of biometric data (e.g., misconfigured storage, lost device with biometric templates);  
- Use of biometric data **without required notice/consent**;  
- Retention of biometric data **beyond** the period allowed by {{ORG_NAME}}’s policy or BIPA;  
- Vendor failures that impact biometric data processed on {{ORG_NAME}}’s behalf.[web:327][web:321][web:331]

---

## 3. Roles & Responsibilities

- **Incident Response Lead (IR Lead):** Coordinates overall response, liaises with executive leadership.  
- **Privacy / Compliance Lead:** Evaluates BIPA implications, records incidents for legal documentation.  
- **Security Team:** Performs technical investigation, containment, and remediation.  
- **HR / Customer Support:** Coordinates communication with affected employees or customers, if needed.  
- **Legal Counsel:** Advises on notification obligations, litigation risk, and regulatory inquiries.[web:326][web:318][web:332]

Contact details for key roles are maintained in {{INCIDENT_CONTACT_LIST_LOCATION}}.

---

## 4. Incident Lifecycle

### 4.1 Detection & Initial Triage

When a potential biometric incident is detected (via alerts, reports, or vendor notifications):

1. **Log the incident** in the incident tracking system with initial details:  
   - Date/time detected, reporter, systems involved, brief description.  
2. **Classify** as a potential biometric incident if any biometric data may be involved.  
3. **Assign** an Incident ID and notify the IR Lead and Privacy / Compliance Lead.[web:325][web:326][web:331]

### 4.2 Containment

Based on severity:

- Isolate affected systems or accounts (e.g., disable access, revoke credentials).  
- Temporarily suspend biometric collection or processing in affected systems.  
- Coordinate with vendors to contain any ongoing exposure.[web:325][web:327]

---

## 5. Investigation Steps

### 5.1 Forensic Investigation

Security team (and vendors, if applicable) should:

- Determine **what happened**, **when**, and **how** (misconfiguration, compromised account, code bug, etc.).  
- Identify **which biometric data** was involved and **how much** (number of records, types, and data subjects).  
- Review relevant logs to track access, changes, and potential exfiltration.[web:326][web:331][web:321]

### 5.2 Legal & Policy Review

Privacy / Compliance Lead and Legal should:

- Confirm whether the incident implicates BIPA requirements (collection without consent, retention beyond limits, sale/profit issues, etc.).[web:327][web:316][web:335]  
- Compare incident facts to {{ORG_NAME}}’s Biometric Policy and retention schedule.  
- Evaluate whether the incident triggers any breach notification obligations under other laws (e.g., Illinois data breach law).

### 5.3 Management Review

For material incidents, executive leadership should be briefed on:

- Scope and impact of the incident;  
- Likely legal and reputational risk;  
- Proposed remediation plan.[web:326][web:318]

---

## 6. Notification & Communication

### 6.1 Individuals

In consultation with Legal, determine whether and how to notify affected individuals (employees or customers), considering:

- Whether biometric data was accessed or acquired by an unauthorized party;  
- Applicable data breach notification laws and contractual commitments;  
- The organization’s general incident response policy.[web:321][web:329][web:336]

If notification is required or appropriate:

- Provide clear, plain‑language description of what happened, what data was involved, and what steps are being taken.  
- Offer contact information and any support (e.g., help desk, FAQs).

### 6.2 Regulators / Other Parties

- Legal advises whether to notify regulators, law enforcement, or other authorities.  
- If a vendor is responsible, coordinate on consistent messaging and accountability.[web:326][web:330][web:336]

---

## 7. Remediation & Lessons Learned

Following containment and investigation:

- **Technical fixes:**  
  - Patch vulnerabilities, correct misconfigurations, strengthen access controls.  

- **Process fixes:**  
  - Update procedures for notice & consent, retention, deletion, and vendor oversight.  

- **Documentation:**  
  - Record root cause, impact, decisions, and follow‑up tasks in the incident report.[web:325][web:260][web:331]

Conduct a **post‑incident review** within {{X_DAYS}} of closure to confirm:

- All remediation tasks are completed;  
- Learnings are integrated into policies, training, and technical controls.

---

## 8. Record‑Keeping

For each biometric incident, maintain:

- Incident report (facts, timeline, scope);  
- Technical investigation findings;  
- Legal analysis (including BIPA considerations);  
- Notifications sent (if any);  
- Remediation actions and completion dates.[web:326][web:320][web:331]  

Records should be retained in accordance with {{ORG_NAME}}’s legal hold and retention requirements.

---

**End of TEMPLATE**
