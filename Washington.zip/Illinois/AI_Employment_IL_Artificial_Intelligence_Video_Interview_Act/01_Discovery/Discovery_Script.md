# Illinois AI in Employment Discovery Script

Purpose: Gather information needed to prepare Illinois AI hiring compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Scope & Applicability

Say:
“I need to understand how AI is used across your hiring and employment decisions.”

Ask:

- Do you hire for Illinois roles or recruit Illinois candidates
- HR systems used (ATS, interview platforms, assessments)
- AI tools used in recruitment, hiring, promotion, discipline, scheduling
- Vendors involved
- Which decisions AI influences

---

## 🧾 Deliverable: Video Interview AI (AIVIA)

Ask:

- Do applicants record video interviews
- AI analyzes videos?
- Tool/vendor
- Characteristics evaluated
- Human review involvement
- Consent process
- Notice timing
- Sharing limitations
- Deletion request process (30-day requirement)

---

## 🧾 Deliverable: Video Data Handling & Deletion

Ask:

- Storage systems
- Access roles
- Vendor storage
- Retention period
- Deletion workflow
- Deletion evidence
- Conflict with other retention laws
- Policy owner

---

## 🧾 Deliverable: Demographic Reporting & Impact Procedure

Ask:

- Does AI solely decide who gets in-person interviews
- Race/ethnicity collection method
- ATS linkage
- Outcome tracking (selected/not/hired)
- Annual reporting owner
- Internal adverse impact review

---

## 🧾 Deliverable: AI Tool Risk Assessment

For EACH AI hiring tool ask:

- Purpose
- Decisions influenced
- Inputs
- Outputs
- Sensitive/proxy features (ZIP code etc.)
- Vendor documentation
- Bias monitoring
- Human oversight
- Safeguards
- Risk rating
- Mitigation plan

---

## 🧾 Deliverable: Employer AI Hiring Policy

Ask:

- AI governance owner
- AI register exists
- Approval process
- Notice locations
- Prohibited uses
- Escalation process
- Training program
- Monitoring cadence

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Illinois AI hiring documentation.”