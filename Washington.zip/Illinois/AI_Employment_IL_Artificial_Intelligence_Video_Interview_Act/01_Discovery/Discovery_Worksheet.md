# Illinois AI in Employment Worksheet

---

## Scope

Illinois Hiring:
Systems:
AI Tools:
Vendors:
Decisions Influenced:

---

## Video Interview AI

Video Interviews Used:
AI Used:
Vendor:
Characteristics Evaluated:
Human Review:
Consent Process:
Notice Timing:
Sharing Limits:
Deletion Requests:

---

## Video Data Handling

Storage:
Access Roles:
Vendor Storage:
Retention:
Deletion Workflow:
Deletion Evidence:
Retention Conflicts:
Policy Owner:

---

## Demographic Reporting

AI Sole Screener:
Race/Ethnicity Collection:
ATS Linkage:
Outcome Tracking:
Reporting Owner:
Impact Review:

---

## Tool Risk Assessment

Tool:
Purpose:
Decisions:
Inputs:
Outputs:
Proxy Features:
Vendor Docs:
Bias Monitoring:
Human Oversight:
Safeguards:
Risk Level:
Mitigation:

---

## Employer Policy

Governance Owner:
AI Register:
Approval Process:
Notice Locations:
Prohibited Uses:
Escalation:
Training:
Monitoring:

---

## TBD

Item:
Owner:
Notes: