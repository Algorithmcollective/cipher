# Law Profile

## Law Name
Illinois Artificial Intelligence Video Interview Act

## Citation
820 ILCS 42/

## Status
Enacted

## Effective Date
January 1, 2020  
(Amendments expanding requirements effective January 1, 2022)

## Regulatory Scope

Applies to employers that:

- Ask applicants to record video interviews
- Use artificial intelligence to analyze video interviews
- Evaluate applicant fitness using AI-based facial analysis or assessment tools

Applies regardless of employer size if AI analysis is used.

## Core Obligations

Employers must:

1. Notify applicants before video interview that AI may be used
2. Explain how AI works and what characteristics it evaluates
3. Obtain applicant consent
4. Limit sharing of video interviews to persons whose expertise is necessary
5. Delete video interviews within 30 days upon applicant request
6. Report demographic data and AI usage metrics (for certain employers)

## Enforcement Authority

Illinois Department of Commerce & Economic Opportunity  
Illinois Attorney General

## Penalties

Civil penalties under state enforcement authority.  
Exposure increases when combined with discrimination claims.

No private statutory damages like BIPA, but high employment litigation crossover risk.

## Private Right of Action
No direct statutory private right of action  
(But exposure through discrimination and employment claims)

## Tier Classification
Tier 2 – Employment AI Transparency Law

## Revenue Priority
High (HR / Enterprise hiring vertical)

## Target Industries

- Large employers using AI hiring tools
- Staffing agencies
- Enterprise HR departments
- AI hiring software vendors
- Recruiting SaaS platforms

## Strategic Positioning

Position as:

AI Hiring Transparency & Bias Mitigation Compliance Program.

Primary risk driver:
Reputational risk + discrimination exposure + regulatory scrutiny.

## Internal Notes

Primary compliance focus areas:

1. AI Hiring Tool Inventory
2. Applicant Notice & Consent
3. Data Retention & Deletion Controls
4. Bias Risk Assessment
5. Impact Reporting
6. HR Governance Policy
7. Vendor Due Diligence

Strong cross-sell with:
- BIPA
- EEOC risk mitigation
- Colorado AI Act (employment sector)