# Illinois AI in Employment – Scope & Applicability Memo (TEMPLATE)

**Laws Covered:**  
- Artificial Intelligence Video Interview Act (AIVIA), 820 ILCS 42/1 et seq.[web:337][web:250][web:341]  
- Illinois Human Rights Act (IHRA) Amendments on AI in Employment (HB 3773 / Public Act 103‑0804).[web:243][web:339][web:342][web:345]  

**Organization:** {{ORG_NAME}}  
**Prepared By:** {{PREPARER_NAME}}, {{ROLE}}  
**Date:** {{DATE}}  

---

## 1. Purpose

This memo determines whether and how Illinois’ AI employment laws apply to {{ORG_NAME}}, and identifies systems, tools, and vendors that must be brought into scope for compliance work.

It is a scoping and planning document, not legal advice. Counsel should review before final decisions.

---

## 2. Summary of Illinois AI Employment Laws

### 2.1 Artificial Intelligence Video Interview Act (AIVIA)

AIVIA applies when an employer:[web:337][web:250][web:338][web:341]

- Asks job applicants to **record video interviews** for positions based in Illinois; **and**  
- Uses **artificial intelligence analysis** of those videos to evaluate applicants.

Key obligations:

- Notify applicants **before** the interview that AI will be used to analyze the video.[web:337][web:338][web:343]  
- Provide information about **how the AI works** in general and what characteristics it evaluates.[web:337][web:341]  
- Obtain **consent** before using AI to evaluate the video.[web:337][web:341]  
- Limit sharing of video interviews to persons whose expertise or technology is needed to evaluate the applicant.[web:337][web:338]  
- Upon applicant’s request, delete the video within 30 days and instruct any recipients to do the same, including backups.[web:337][web:343]  
- If the employer **relies solely** on AI analysis to decide who gets in‑person interviews for Illinois positions, it must collect and report race/ethnicity data on applicants and outcomes.[web:337]

### 2.2 IHRA AI Amendments (HB 3773 / AI in Employment Decisions)

Effective January 1, 2026, amendments to the Illinois Human Rights Act (IHRA) cover the use of AI in employment decisions.[web:243][web:339][web:344][web:345]

Key ideas:

- Employers are responsible for AI use in **recruitment, hiring, promotion, renewal, training selection, discharge, discipline, tenure, and terms/conditions of employment**.[web:339][web:342][web:237][web:345]  
- Employers must **notify** employees and applicants when AI is used in employment decisions.[web:339][web:342][web:237][web:346]  
- It is a civil rights violation to use AI in a way that **discriminates** based on protected classes (including using ZIP codes as a proxy).[web:243][web:344][web:345]  
- Employers should assess and document whether AI tools have discriminatory effects and maintain records of those assessments.[web:243][web:237][web:340]

---

## 3. Illinois Footprint

### 3.1 Positions & Locations

- Does {{ORG_NAME}} have **positions based in Illinois** (employees or roles physically located or assigned to Illinois)?  
  - ☐ Yes  ☐ No  ☐ Unclear  

- Does {{ORG_NAME}} recruit **Illinois candidates** or allow remote roles that may be filled by Illinois residents?  
  - ☐ Yes  ☐ No  ☐ Unclear  

Brief description:

> {{SUMMARY_OF_IL_POSITIONS_AND_REMOTE_RECRUITING}}

---

## 4. Use of AI in Hiring & Employment

### 4.1 Video Interview + AI (AIVIA Scope)

For each recruiting process, indicate:

- Do you request **recorded video interviews** from applicants for Illinois‑based roles?  
- Do you use **AI tools** to analyze those videos (e.g., scoring, ranking, extracting traits)?

| Process / Role Family | Illinois Role? | Video Interviews Used? | AI Used on Video? | Tool / Vendor |
|-----------------------|----------------|------------------------|-------------------|--------------|
| {{e.g., Sales Associate}} | {{Y/N}} | {{Y/N}} | {{Y/N}} | {{VENDOR/TOOL}} |
| {{e.g., Engineer}} | {{Y/N}} | {{Y/N}} | {{Y/N}} | {{VENDOR/TOOL}} |

If **Yes** to both “Video” and “AI Used” for any Illinois roles, AIVIA likely applies for those processes.

### 4.2 Other AI in Employment Decisions (IHRA Scope)

List all AI or algorithmic tools used in:

- Recruitment / sourcing (e.g., resume screening, candidate scoring).  
- Hiring (e.g., assessments, chatbots, automated ranking).  
- Promotion, performance evaluation, or compensation.  
- Discharge / discipline / scheduling decisions.

| Tool / Process | Vendor / Platform | Employment Decision Area | Illinois Employees/Candidates Affected? |
|----------------|-------------------|--------------------------|-----------------------------------------|
| {{TOOL_1}} | {{VENDOR_1}} | {{e.g., resume screening}} | {{Y/N}} |
| {{TOOL_2}} | {{VENDOR_2}} | {{e.g., performance rating}} | {{Y/N}} |

If **any** of these tools influence employment decisions for Illinois workers or applicants, the IHRA AI requirements are in scope.[web:243][web:339][web:237][web:340]

---

## 5. High‑Level Applicability Conclusion

### 5.1 AIVIA

- AIVIA applies to {{ORG_NAME}}?  
  - ☐ Yes – We use AI to analyze video interviews for Illinois‑based roles.  
  - ☐ No – We do not both: (a) collect video interviews AND (b) use AI on those videos for Illinois roles.  
  - ☐ Unclear – Need more information from recruiting / vendors.

### 5.2 IHRA AI Amendments

- IHRA AI provisions apply?  
  - ☐ Yes – We use AI for recruitment, hiring, promotion, or other employment decisions affecting Illinois employees/candidates.  
  - ☐ No – We do not use AI in employment decisions for Illinois.  
  - ☐ Unclear – Need more information from HR / managers.

Brief narrative:

> {{NARRATIVE_APPLICABILITY_SUMMARY}}

---

## 6. Initial Gap Snapshot

### 6.1 If AIVIA Applies

Check current status for video + AI processes:

- ☐ Applicants notified **before** the interview that AI will be used to analyze the video.[web:337][web:338][web:341]  
- ☐ Applicants provided with basic information about how the AI works and what characteristics it evaluates.[web:337][web:341]  
- ☐ Applicants’ **consent** obtained before AI analysis.[web:337][web:341]  
- ☐ Sharing of videos limited to people/tech necessary to evaluate applicants.[web:337][web:338]  
- ☐ Process in place to delete videos within 30 days of applicant’s request, including asking vendors to delete copies.[web:337][web:343]  
- ☐ Demographic (race/ethnicity) data collected and reported if AI is the **sole** screener for interviews.[web:337]

### 6.2 If IHRA AI Applies

- ☐ Employees and applicants are notified when AI is used in employment decisions that affect them.[web:339][web:342][web:237][web:346]  
- ☐ AI tools are assessed for potential discriminatory effects (e.g., adverse impact on protected groups) and those assessments are documented.[web:243][web:237][web:340]  
- ☐ Tools do not use zip code or similar data as proxies for protected characteristics.[web:243][web:344][web:345]  
- ☐ Vendor contracts address employer responsibility, cooperation, and data needed to run impact analyses.

---

## 7. Recommended Deliverables for {{ORG_NAME}}

Based on the analysis above, we recommend preparing the following Illinois AI employment documents:

- **If AIVIA applies:**
  1. Video Interview AI Notice & Consent (IL_EMP_AI_02).  
  2. Video Data Handling & Deletion Policy (IL_EMP_AI_03).  
  3. AI Demographic Reporting & Impact Procedure (IL_EMP_AI_04) – if AI is sole screener.

- **If IHRA AI applies:**
  4. AI Tool Risk Assessment Template & completed assessments (IL_EMP_AI_05).  
  5. Internal Employer AI in Hiring & Employment Policy (IL_EMP_AI_06).

List final scope:

> {{FINAL_SCOPE_NOTES}}

---

**End of TEMPLATE**
