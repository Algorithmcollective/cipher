# Employer Policy on AI in Hiring & Employment Decisions (TEMPLATE)

**Law Context:**  
- Illinois Human Rights Act (IHRA) AI amendments (HB 3773 / Public Act 103‑0804).[web:372][web:261][web:370][web:345]  
- Employers must:
  - Notify applicants and employees when AI is used for covered employment decisions;  
  - Not use AI in a way that has a discriminatory effect based on protected classes;  
  - Not use ZIP code as a proxy for protected classes.[web:372][web:339][web:373][web:379]  

**Organization:** {{ORG_NAME}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{ROLE}}  

---

## 1. Purpose & Scope

This Policy sets rules for {{ORG_NAME}}’s use of artificial intelligence (AI) in employment‑related decisions, including recruitment, hiring, promotion, and other covered areas, with a focus on Illinois requirements.[web:372][web:261][web:339][web:370]

It applies to:

- All AI and automated tools that influence or facilitate employment decisions;  
- All employees, hiring managers, HR personnel, and external vendors who deploy or manage such tools.

---

## 2. Definition of AI (for this Policy)

For purposes of this Policy, **AI** includes any machine‑based system that:

- Infers from inputs (data) how to generate outputs (predictions, classifications, recommendations, or decisions); and  
- Is used to influence or facilitate employment decisions (e.g., screening, scoring, ranking, recommendations).[web:372][web:373][web:379]

This includes generative AI, scoring models, and other algorithmic systems integrated into HR tools.

---

## 3. Covered Employment Decisions

This Policy covers AI used in connection with:[web:372][web:339][web:373][web:370]

- Recruitment and sourcing;  
- Hiring and selection;  
- Promotion and advancement;  
- Renewal of employment;  
- Selection for training or apprenticeship;  
- Discharge / termination;  
- Discipline;  
- Tenure;  
- Terms, privileges, or conditions of employment (e.g., pay, scheduling, access to opportunities).

---

## 4. Notice Requirements (Illinois Focus)

Whenever {{ORG_NAME}} uses AI to **influence or facilitate** a covered employment decision affecting an Illinois applicant or employee, {{ORG_NAME}} will provide notice that includes:[web:372][web:261][web:342][web:340]

- The fact that AI is used for that decision;  
- The name or type of AI tool, where practical;  
- The types of decisions it influences;  
- A high‑level description of the tool’s purpose and the data it uses;  
- A contact point for questions or concerns.

Notice may be provided via:

- Job postings and applicant portals;  
- Employee handbooks or internal policy hubs;  
- Email notifications or onboarding materials.

Business units must coordinate with HR / Legal before deploying or materially changing AI tools that affect Illinois workers or applicants.

---

## 5. Nondiscrimination & Prohibited Uses

### 5.1 No Discriminatory Effect

{{ORG_NAME}} must **not** use AI in a way that has the effect of subjecting applicants or employees to discrimination on the basis of any protected class under the IHRA (e.g., race, color, religion, sex, national origin, age, disability).[web:372][web:237][web:370][web:345]

Intent is not required; an objectively discriminatory impact may violate the law even if unintentional.

### 5.2 No ZIP Code as Proxy

{{ORG_NAME}} will not use **ZIP code** as a proxy for protected classes in AI systems used for employment decisions.[web:372][web:370][web:379][web:345]

Where feasible, {{ORG_NAME}} will also avoid other variables that clearly act as proxies for protected categories unless there is a strong, documented business necessity and mitigation is in place.

---

## 6. AI Governance & Approval

### 6.1 AI Register & Approval

- All AI tools used in employment decisions must be recorded in an **AI Register**, including:
  - Tool name and vendor;  
  - Purpose and covered decisions;  
  - Data inputs and key features;  
  - Populations affected (states/jurisdictions, roles).[web:372][web:374][web:375]

- New AI tools or new use cases must be reviewed and approved by:
  - HR / Talent Acquisition;  
  - Legal / Compliance;  
  - Security / Privacy (as appropriate).

### 6.2 Risk Assessments

For each AI tool that affects Illinois applicants or employees, {{ORG_NAME}} will perform and maintain an **AI Tool Risk & Bias Assessment** (see IL_EMP_AI_05), focusing on:

- Inputs, outputs, and potential proxies for protected classes;  
- Notice and transparency;  
- Evidence of bias or disparate impact;  
- Safeguards and governance.[web:372][web:237][web:340][web:371]

---

## 7. Human Oversight & Escalation

- AI tools are intended to assist decision‑makers, not replace them.  
- High‑stakes employment actions (e.g., termination, denial of promotion) must not be based solely on AI output without appropriate human review and context.[web:379][web:374][web:381]

Employees and applicants may:

- Ask for more information about how AI is used in decisions affecting them;  
- Raise concerns if they believe AI has caused an unfair or discriminatory outcome.

Concerns should be escalated to HR or the designated AI / Ethics contact, which will coordinate with Legal as needed.

---

## 8. Training & Awareness

{{ORG_NAME}} will provide training for:

- HR and recruiters who use AI tools;  
- Managers who rely on AI‑generated outputs;  
- Technical teams who build or integrate AI systems.

Training will cover:

- Illinois AI notice and nondiscrimination requirements;  
- Appropriate use of AI outputs;  
- How to spot and escalate potential bias or fairness issues.[web:237][web:374][web:381]

---

## 9. Monitoring, Audits & Updates

- AI tools affecting Illinois employment decisions will be **periodically reviewed** for potential disparate impact and compliance with this Policy.  
- Results of reviews and any remediation steps will be documented.[web:237][web:340][web:371]

This Policy will be updated when:

- Illinois issues final rules or guidance;  
- {{ORG_NAME}} significantly changes its AI tooling or employment practices;  
- Audits or incidents identify gaps.

---

**End of TEMPLATE**
