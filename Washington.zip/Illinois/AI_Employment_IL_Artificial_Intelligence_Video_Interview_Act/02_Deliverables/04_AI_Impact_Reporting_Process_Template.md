# AI Video Interview – Demographic Reporting & Impact Procedure (TEMPLATE)

**Law Reference:**  
- Artificial Intelligence Video Interview Act (AIVIA) reporting amendment (820 ILCS 42/).[web:350][web:236][web:369]  

**Organization:** {{ORG_NAME}}  
**Owner:** {{OWNER_NAME}}, {{ROLE}}  
**Effective Date:** {{EFFECTIVE_DATE}}  

---

## 1. Purpose

This Procedure explains how {{ORG_NAME}}:

- Collects and reports demographic data when AI video interview analysis is the **sole** factor in deciding who is selected for an in‑person interview for Illinois positions; and  
- Uses this data to check for potential adverse impact or racial bias in its AI‑enabled hiring process.[web:350][web:369][web:244]

---

## 2. When This Procedure Applies

This Procedure applies if **all** of the following are true for a given role:

1. Applicants record video interviews for positions **based in Illinois**;  
2. {{ORG_NAME}} uses **AI to analyze** those video interviews;  
3. The AI analysis is the **sole determinant** of whether an applicant is selected for an in‑person (or live) interview.[web:350][web:236][web:244]

If human review or other factors always play a material role in deciding who gets an in‑person interview, the statutory reporting requirement may not be triggered. Document that determination.

---

## 3. Data to Be Collected

Where this Procedure applies, {{ORG_NAME}} must collect the following **race and ethnicity** information for each hiring cycle impacted:[web:350][web:369]

1. Race and ethnicity of applicants who are **selected** for in‑person interviews after AI analysis.  
2. Race and ethnicity of applicants who are **not selected** for in‑person interviews after AI analysis.  
3. Race and ethnicity of applicants who are **hired** for the position.

Data should be collected in a manner consistent with applicable equal employment opportunity (EEO) standards (e.g., voluntary self‑identification, standard race/ethnicity categories) and stored separately from decision‑making personnel where feasible.

---

## 4. Collection Process

### 4.1 Self‑Identification

- As part of the application process, applicants are invited (but not required) to self‑identify their race and ethnicity using standard categories.  
- {{ORG_NAME}} clearly states that:
  - Providing this information is voluntary,  
  - It will not be used in individual hiring decisions, and  
  - It will be used for compliance and fairness monitoring.[web:350][web:244]

### 4.2 Data Linking

- Each applicant is assigned a unique ID in the ATS.  
- Race/ethnicity data is linked to the applicant ID for reporting and impact analysis, but **not** displayed to interviewers or AI tools.  
- Outcome fields recorded per applicant:
  - Whether they were selected for in‑person interview (Yes/No).  
  - Whether they were hired (Yes/No).

---

## 5. Annual Reporting to Illinois DCEO

### 5.1 Report Preparation

For each calendar year in which {{ORG_NAME}} relies solely on AI video‑interview analysis to decide who is selected for in‑person interviews for positions based in Illinois:

- Aggregate the data required by the amendment:[web:350][web:369][web:244]
  - Race and ethnicity of applicants who **are** selected for in‑person interviews.  
  - Race and ethnicity of applicants who **are not** selected for in‑person interviews.  
  - Race and ethnicity of applicants who **are hired**.

- Prepare the report in the format specified or accepted by the Illinois Department of Commerce and Economic Opportunity (DCEO), if guidance is available.[web:369][web:350]

### 5.2 Submission

- Submit the aggregate report to DCEO by **December 31** of each year in which this requirement is triggered.[web:350][web:369]  
- Retain copies of the submitted report and supporting data extracts per {{ORG_NAME}}’s records‑retention schedule.

---

## 6. Internal Impact Review (Adverse Impact Check)

Even where not explicitly mandated, {{ORG_NAME}} will perform a basic internal impact review on the AI video‑interview process:

- Compare selection rates for in‑person interviews and hire rates across race/ethnicity groups.  
- Flag patterns that suggest potential adverse impact or racial bias (e.g., significantly lower selection rates for certain groups).[web:237][web:368][web:370]

If potential disparities are observed:

- Escalate to Legal / Compliance and AI governance;  
- Evaluate the AI model, configuration, and surrounding process;  
- Consider mitigation steps (e.g., adjusting thresholds, adding human review, or changing the tool).

---

## 7. Roles & Responsibilities

- **Talent Acquisition / HR Analytics:**  
  - Collect demographic and outcome data in the ATS.  
  - Prepare annual DCEO reports.

- **Legal / Compliance:**  
  - Confirm when the “sole determinant” condition is met.  
  - Review DCEO submissions and adverse‑impact findings.  

- **AI / Data Science / Vendor Management:**  
  - Support analysis of potential bias and recommend model or process changes.

---

## 8. Documentation & Retention

{{ORG_NAME}} will maintain:

- Copies of DCEO reports and related correspondence;  
- Year‑over‑year trend data and internal impact analyses;  
- Records showing which roles and AI tools are in‑scope each year.[web:350][web:369][web:237]

Records will be retained in accordance with legal requirements and {{ORG_NAME}}’s retention policies.

---

**End of TEMPLATE**
