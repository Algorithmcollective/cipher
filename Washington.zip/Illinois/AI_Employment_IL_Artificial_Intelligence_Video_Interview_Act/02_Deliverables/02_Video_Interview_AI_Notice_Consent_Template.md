# Illinois AI Video Interview – Notice & Consent (TEMPLATE)

**Law Reference:** Artificial Intelligence Video Interview Act (AIVIA), 820 ILCS 42/1 et seq.[web:337][web:241][web:347][web:353]  
**Organization:** {{ORG_NAME}}  
**Applies To:** Applicants for {{ROLE_FAMILIES}} located in or applying for positions based in Illinois  

---

## 1. Notice: Use of AI in Video Interviews

{{ORG_NAME}} uses a video interview process for certain roles. For some positions, we may use **artificial intelligence (AI)** to help evaluate your video interview.

Before you record your video interview, please read the information below carefully.

### 1.1 Use of AI

For the roles listed above, {{ORG_NAME}}:

- Asks applicants to record a structured video interview; and  
- Uses an AI system to analyze the video interview and provide scores or insights that our recruiting team uses as part of the evaluation process.[web:337][web:241][web:349][web:351]

### 1.2 How the AI Works (High‑Level Explanation)

Our AI system, provided by {{VENDOR_NAME}} or operated internally, generally works as follows:[web:337][web:241][web:351][web:353]

- It analyzes your recorded responses to interview questions (e.g., speech content, timing, and other observable characteristics).  
- It may extract features such as:
  - Communication clarity (e.g., how clearly you explain your answers);  
  - Job‑relevant skills or experience (based on the content of your answers);  
  - Other role‑related attributes defined in advance (for example, customer‑focus, problem‑solving, or sales orientation).

The AI then produces a **score or ranking** that recruiters and hiring managers may use as **one factor** in deciding whether to move you forward in the hiring process. The AI does **not** make final hiring decisions on its own.

We do **not** design the system to evaluate protected characteristics such as race, ethnicity, sex, disability, religion, age, or national origin.[web:341][web:349]

### 1.3 What Characteristics the AI Uses

In general, the AI uses the following **job‑related characteristics** when evaluating your interview (examples):

- Quality and clarity of your verbal responses to role‑related questions;  
- Examples you provide of past experience and job‑relevant skills;  
- Alignment with competencies identified for the role (e.g., customer service, sales, analytical thinking).

The AI does **not** intentionally evaluate your physical appearance, accent, or other traits as stand‑alone criteria; however, any video‑based system may inadvertently be affected by such factors. {{ORG_NAME}} monitors AI tools to reduce risks of unfair bias.[web:341][web:349][web:351]

---

## 2. Confidentiality, Sharing, and Deletion

### 2.1 Who May See Your Video Interview

Your video interview may be viewed or processed only by:[web:337][web:241][web:347][web:355]

- Recruiters and hiring managers involved in evaluating your application;  
- Authorized personnel who support the video interview and AI systems (e.g., HR operations, IT);  
- Our AI service provider(s), such as {{VENDOR_NAME}}, solely to perform analysis on our behalf.

We will not share your video interview with other parties except as required by law (for example, in response to a valid subpoena or court order).

### 2.2 Your Right to Request Deletion

Under Illinois law, if you ask us to delete your video interview:

- {{ORG_NAME}} will delete your video interview within **30 days** after receiving your request; and  
- {{ORG_NAME}} will instruct anyone who received copies of your video interview (including our AI vendor) to delete their copies, including electronically generated backup copies.[web:337][web:236][web:351][web:355]

You can request deletion at any time by contacting {{CONTACT_EMAIL}} or {{PORTAL_LINK}}.

Please note: certain other laws may require us to retain some hiring‑related records for a period of time. In those cases, we will explain any limits on deletion.

---

## 3. Consent to AI Analysis

By checking the box or signing below, you:

1. Confirm that you have read and understood this **Illinois AI Video Interview – Notice & Consent**;  
2. Acknowledge that {{ORG_NAME}} may use AI to analyze your video interview and consider your suitability for the role described;[web:337][web:241][web:347][web:353]  
3. Understand, at a high level, how the AI works and what general types of characteristics it uses to evaluate applicants;  
4. Consent to the use of AI to analyze your video interview as described in this Notice;  
5. Understand that you may request deletion of your video interview and that {{ORG_NAME}} will delete the video and instruct others who have copies to delete theirs within 30 days of your request, subject to legal requirements.

If you **do not consent**, you may contact {{CONTACT_EMAIL}} to request an alternative, non‑AI interview process (if available). If no alternative is available, your application may not proceed using this process.

---

### Applicant Acknowledgment

I, {{APPLICANT_NAME}}, have read and understood this Notice & Consent and agree that {{ORG_NAME}} may use AI to analyze my video interview as described.

- Name: _______________________________  
- Signature (or electronic equivalent): _______________________________  
- Date: _______________________________  

---

**End of TEMPLATE**
