# AI Video Interview – Data Handling & Deletion Policy (TEMPLATE)

**Law Reference:** Artificial Intelligence Video Interview Act (AIVIA), 820 ILCS 42/1 et seq.[web:337][web:239][web:250][web:353]  
**Organization:** {{ORG_NAME}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Owner:** {{OWNER_NAME}}, {{ROLE}}  

---

## 1. Purpose

This Policy describes how {{ORG_NAME}}:

- Handles, stores, and shares video interviews that are analyzed by artificial intelligence (AI) for Illinois‑based roles; and  
- Responds to applicant requests to delete video interviews within 30 days, as required by AIVIA.[web:239][web:250][web:353][web:358]

It supplements {{ORG_NAME}}’s general privacy and records‑retention policies.

---

## 2. Scope

This Policy applies to:

- All **video interviews** submitted by applicants for positions **based in Illinois** where AI is used to analyze the video;[web:337][web:343][web:358]  
- All internal teams and external service providers involved in collecting, storing, analyzing, or accessing those videos.

---

## 3. Collection & Use

Video interviews covered by this Policy are collected and used to:

- Evaluate applicants’ suitability for specific roles;  
- Assist recruiters and hiring managers in making interview and hiring decisions.

AI systems may analyze the video to generate scores or insights that are used as **one factor** in the decision process; AI does not make final hiring decisions on its own.

---

## 4. Access & Sharing

### 4.1 Internal Access

Video interviews may only be accessed by:[web:337][web:250][web:347][web:355]

- Recruiters and hiring managers directly involved in evaluating the applicant;  
- HR operations staff who administer the hiring process;  
- IT / Security staff as needed to maintain systems or respond to incidents.

Access must follow least‑privilege principles.

### 4.2 External Sharing

{{ORG_NAME}} may share video interviews with:

- AI video‑interview service providers (e.g., {{VENDOR_NAME}}) solely to analyze interviews for {{ORG_NAME}};  
- Other third parties only as required by law (e.g., in response to a valid subpoena or court order).

Under AIVIA, {{ORG_NAME}} is prohibited from sharing applicant videos with anyone other than **persons whose expertise or technology is necessary to evaluate the applicant’s fitness for the position**.[web:337][web:250][web:353][web:358]

---

## 5. Storage, Retention & Security

### 5.1 Storage

Video interviews are stored:

- In {{SYSTEMS}}, with access controls and logging enabled;  
- By {{VENDOR_NAME}} under written agreements requiring appropriate security and compliance.

### 5.2 Retention

Unless deletion is requested sooner (see Section 6), {{ORG_NAME}} retains video interviews only as long as necessary to:

- Evaluate applicants and complete the hiring process for the relevant roles; and  
- Comply with applicable record‑retention laws and legal holds.

Retention and deletion must be coordinated with HR, Legal, and Records Management to manage any conflicts between AIVIA’s 30‑day deletion requirement and other legal obligations (e.g., EEOC/OFCCP retention rules).[web:347][web:356][web:351]

### 5.3 Security

Video interviews are protected using appropriate technical and organizational measures, including:

- Encryption in transit and at rest (where feasible);  
- Access controls with role‑based permissions;  
- Logging of access to video‑interview data.[web:347][web:247][web:325][web:336]

---

## 6. Applicant Deletion Requests

### 6.1 Right to Request Deletion

Applicants have the right under AIVIA to request that {{ORG_NAME}} delete their video interview(s).[web:239][web:343][web:353][web:360]

- Requests may be submitted via {{EMAIL_ADDRESS}}, {{WEB_PORTAL}}, or other documented channels.  
- Requests should include sufficient information to identify the applicant and the specific position.

### 6.2 Deletion Timeline

Upon receiving a valid deletion request:

- {{ORG_NAME}} will delete the applicant’s video interview(s) within **30 days** after receipt of the request; and  
- {{ORG_NAME}} will instruct any other persons who received copies of the applicant’s video interviews (including service providers) to also delete their copies, including electronically generated backup copies, as required by AIVIA.[web:239][web:236][web:337][web:351]

Any service provider or other recipient is expected to comply with these instructions.

### 6.3 Handling Conflicts with Other Laws

If another law requires {{ORG_NAME}} to retain hiring‑related records for a specific period (e.g., EEOC or OFCCP record‑retention rules), {{ORG_NAME}} will:

- Consult with Legal to determine how to reconcile those obligations with the AIVIA 30‑day requirement;[web:347][web:356]  
- Document the rationale for any deviations from standard deletion timelines;  
- Where possible, segregate AI video‑interview content from other records to facilitate compliant deletion.

---

## 7. Roles & Responsibilities

- **Talent Acquisition / HR:**  
  - Ensure applicants receive AIVIA notices and consent forms.  
  - Log and route deletion requests promptly.

- **IT / Systems Owners:**  
  - Implement technical controls to delete videos upon request within required timeframes.  
  - Maintain logs to verify deletion.

- **Vendors / Service Providers:**  
  - Delete video interviews upon {{ORG_NAME}}’s instruction and confirm completion.  
  - Restrict internal access to personnel required to evaluate the applicant.

- **Legal / Compliance:**  
  - Advise on conflicts with other legal retention duties.  
  - Review and update this Policy as laws evolve.

---

## 8. Review & Updates

This Policy will be reviewed at least annually and when:

- AIVIA or related regulations are amended;  
- {{ORG_NAME}} changes AI vendors or video‑interview processes;  
- Internal audits or incidents identify gaps in current practices.

Updates will be communicated to relevant teams and incorporated into contracts with service providers.

---

**End of TEMPLATE**
