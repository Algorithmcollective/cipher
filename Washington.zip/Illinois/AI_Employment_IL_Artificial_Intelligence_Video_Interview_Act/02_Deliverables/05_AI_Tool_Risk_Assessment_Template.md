# AI Tool Risk & Bias Assessment – Employment Decisions (TEMPLATE)

**Law Context:**  
- Illinois Human Rights Act (IHRA) AI amendments (HB 3773 / Public Act 103‑0804).  
- Employers must avoid using AI in a way that has a **discriminatory effect** based on protected classes or ZIP code as a proxy and must provide notice when AI is used in employment decisions.[web:372][web:344][web:261][web:374]  

**Organization:** {{ORG_NAME}}  
**Tool Name:** {{TOOL_NAME}}  
**Version / Model:** {{VERSION}}  
**Vendor / Owner:** {{VENDOR_NAME or INTERNAL}}  
**Assessment Date:** {{DATE}}  
**Assessor:** {{ASSESSOR_NAME}}, {{ROLE}}  

---

## 1. Tool Overview

- **Purpose / Function:**  
  > {{e.g., Resume screening, interview scoring, performance analytics}}

- **Employment Decisions Influenced:**  
  - ☐ Recruitment / sourcing  
  - ☐ Hiring / selection  
  - ☐ Promotion  
  - ☐ Renewal of employment  
  - ☐ Training / apprenticeship selection  
  - ☐ Discharge / termination  
  - ☐ Discipline / scheduling  
  - ☐ Other: {{DETAILS}}[web:372][web:344][web:373][web:374]

- **Illinois Populations Affected:**  
  - ☐ Illinois applicants  
  - ☐ Illinois employees  
  - ☐ Neither (tool not used for Illinois – document and stop here)

---

## 2. Inputs, Outputs & Features

### 2.1 Inputs

List all **data inputs** the tool uses:

- Structured data (e.g., education, tenure, performance ratings, location, ZIP code).  
- Unstructured data (e.g., free‑text responses, interview transcripts, video, audio).[web:372][web:377][web:345]

> {{INPUTS_DESCRIPTION}}

### 2.2 Outputs

- Type(s) of output:  
  - ☐ Score or rating  
  - ☐ Recommendation (e.g., “advance / reject”)  
  - ☐ Ranking of candidates  
  - ☐ Narrative explanation or summary  
  - ☐ Other: {{DETAILS}}

- How outputs influence employment decisions:  
  > {{e.g., used as a primary filter, advisory only, combined with human review}}

### 2.3 Potentially Sensitive Features

Indicate whether the tool uses, infers, or correlates with:

- ☐ Protected characteristics (race, color, religion, sex, national origin, age, disability, etc.) – direct or inferred.  
- ☐ ZIP code, neighborhood, or similar location data that may act as a proxy for protected classes.[web:372][web:344][web:374]  
- ☐ Other proxies (e.g., school, language, work history patterns strongly tied to protected traits).

If any are used, explain purpose and mitigation (e.g., removal, masking, or strict justification):

> {{SENSITIVE_FEATURES_NOTES}}

---

## 3. Notice & Transparency

- ☐ Employees and applicants are informed that this tool uses AI to influence or facilitate relevant employment decisions.[web:372][web:344][web:340][web:346]  
- ☐ Notice explains:
  - The tool’s name or type;  
  - The decisions it affects;  
  - Its general purpose;  
  - The types of data it uses or characteristics it evaluates;  
  - A contact point for questions or concerns.[web:372][web:344][web:346]

Describe how and where notice is provided (e.g., offer letters, privacy notices, internal policy, career site):

> {{NOTICE_DESCRIPTION}}

---

## 4. Bias & Impact Considerations

### 4.1 Vendor / Model Documentation

- ☐ Vendor (or internal team) provides documentation on:
  - Training data sources and limitations;  
  - Steps taken to reduce bias;  
  - Known limitations and appropriate uses.[web:371][web:377][web:345]

- ☐ Documentation reviewed by Legal / AI governance.

Key points:

> {{DOC_SUMMARY}}

### 4.2 Internal Impact Checks (High‑Level)

Even though Illinois law does not mandate formal bias audits, employers are expected to avoid discriminatory effects and may wish to conduct impact assessments.[web:237][web:371][web:340][web:346]

For the last {{PERIOD}} (e.g., 12 months):

- Have we compared selection/hire/promotions rates across protected groups for decisions where this tool is a key input?  
  - ☐ Yes  ☐ No (plan below)

If **Yes**, summarize:

- Any significant disparities identified?  
- Any correctives (e.g., threshold changes, human review, tool replacement)?

> {{IMPACT_ANALYSIS_SUMMARY}}

If **No**, describe plan:

> {{IMPACT_ANALYSIS_PLAN}}

---

## 5. Governance & Controls

- ☐ Tool is covered in {{ORG_NAME}}’s AI policy and register.  
- ☐ Use cases for this tool are clearly defined and approved (no “off‑label” use).[web:372][web:374][web:375][web:376]  
- ☐ There is a documented process for:
  - Approving new use cases;  
  - Periodic re‑evaluation;  
  - Responding to complaints or disputes about AI‑driven decisions.

- ☐ Human review is in place where appropriate (e.g., no fully automated termination decisions).  
- ☐ ZIP code and obvious proxies for protected classes are not used as selection criteria.[web:372][web:344][web:374]

Describe key safeguards:

> {{SAFEGUARDS_DESCRIPTION}}

---

## 6. Risk Assessment & Action Plan

**Overall risk level for discriminatory effect under Illinois law (subjective, based on available data):**

- ☐ Low – Narrow use, strong safeguards, no adverse indicators.  
- ☐ Medium – Some risk factors; monitoring and periodic checks required.  
- ☐ High – Significant concerns about potential discriminatory effects or proxy use.

**Key risks identified:**

- {{RISK_1}}  
- {{RISK_2}}  
- {{RISK_3}}  

**Planned mitigation actions:**

| Risk | Action | Owner | Target Date |
|------|--------|-------|------------|
| {{RISK_1}} | {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} |
| {{RISK_2}} | {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} |

---

## 7. Approval & Review

- Assessor Signature: ________________________  Date: ____________  
- Legal / Compliance Reviewer: _______________  Date: ____________  
- Next Review Due: {{NEXT_REVIEW_DATE}}  

---

**End of TEMPLATE**
