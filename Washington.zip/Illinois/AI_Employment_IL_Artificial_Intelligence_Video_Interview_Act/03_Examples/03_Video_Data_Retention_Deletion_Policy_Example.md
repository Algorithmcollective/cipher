# AI Video Interview – Data Handling & Deletion Policy – BrightPath Talent Inc. (Example)

**Law Reference:** Artificial Intelligence Video Interview Act (AIVIA), 820 ILCS 42/1 et seq.[web:337][web:239][web:250][web:353]  
**Organization:** BrightPath Talent Inc.  
**Effective Date:** March 1, 2026  
**Owner:** Maria Lopez, Director of Talent Acquisition  

---

## 1. Purpose

This Policy describes how BrightPath Talent Inc. (“BrightPath”) handles and deletes candidate video interviews that are analyzed by artificial intelligence (AI) for Sales Development Representative (SDR) and Account Executive (AE) roles based in Illinois.

It is intended to ensure compliance with the Illinois Artificial Intelligence Video Interview Act (AIVIA) and BrightPath’s broader privacy and security standards.[web:337][web:239][web:250][web:353]

---

## 2. Scope

This Policy applies to:

- Video interviews submitted by applicants for SDR and AE roles **based in Illinois**;  
- Video interviews recorded through the VidHire platform where AI is used to analyze candidate responses;  
- All BrightPath and VidHire personnel involved in collecting, storing, analyzing, or accessing these videos.

---

## 3. Collection & Use

BrightPath collects video interviews for Illinois SDR and AE roles using VidHire. These interviews are used to:

- Evaluate candidates’ communication skills, sales orientation, and other job‑related competencies;  
- Generate AI‑based scores (via VidHire) that are used alongside resumes, assessments, and recruiter judgment to determine which candidates move forward.

VidHire’s AI does **not** make final hiring decisions; BrightPath recruiters and hiring managers remain responsible for all hiring decisions.

---

## 4. Access & Sharing

### 4.1 Internal Access

Video interviews may be accessed only by:

- Recruiters assigned to SDR/AE hiring;  
- Hiring managers for the relevant role;  
- A limited number of HR operations and IT staff responsible for administering VidHire and troubleshooting issues.

Access is controlled via role‑based permissions in VidHire and our SSO platform.

### 4.2 External Sharing

BrightPath shares video interviews with:

- **VidHire**, as our AI video interview provider, solely to:
  - Host interviews;  
  - Analyze responses using its AI models;  
  - Provide scores and analytics back to BrightPath.

BrightPath does not otherwise share candidate video interviews with third parties, except when required by law (such as in response to a valid subpoena or court order).[web:337][web:250][web:347][web:355]

Under AIVIA, BrightPath must limit sharing to persons whose expertise or technology is necessary to evaluate the candidate; this includes VidHire and authorized BrightPath personnel.[web:337][web:250][web:353][web:358]

---

## 5. Storage, Retention & Security

### 5.1 Storage

Candidate video interviews are stored:

- In VidHire’s cloud platform (US region) under a data‑processing agreement with BrightPath;  
- With metadata (scores, timestamps) synced to BrightPath’s applicant‑tracking system (ATS) without raw video content.

### 5.2 Retention

By default:

- BrightPath retains video interviews in VidHire for up to **12 months** after the hiring process for a given role is completed, to:
  - Complete hiring and onboarding;  
  - Support limited internal quality review of interviews.

- Longer retention may be required by certain employment or anti‑discrimination laws and legal holds. Legal and HR coordinate on these requirements.[web:347][web:356][web:351]

### 5.3 Security

VidHire and BrightPath implement the following controls:

- Encryption of video files in transit (TLS) and at rest.  
- Authentication via BrightPath SSO for recruiter/hiring manager access.  
- Role‑based access limiting who can view interviews.  
- Logging of access and administrative actions related to video files.[web:347][web:247][web:325][web:336]

---

## 6. Applicant Deletion Requests

### 6.1 Right to Request Deletion

Candidates for Illinois SDR/AE roles may request that BrightPath delete their recorded video interview(s) at any time.

- Requests can be submitted to **privacy@brightpathtalent.com** or via the “Privacy Request” form on BrightPath’s careers site.  
- Requests must include the candidate’s full name, email address, and the role applied for.

### 6.2 Deletion Timeline & Process

When a valid deletion request is received:

1. **Log the request** in BrightPath’s privacy request tracker.  
2. Within 30 days:
   - BrightPath’s Talent Operations team deletes the candidate’s video interview(s) from VidHire (using admin tools);  
   - BrightPath instructs VidHire, in writing, to delete all copies, including any backups within its control;  
   - BrightPath confirms deletion in the privacy tracker.[web:239][web:236][web:337][web:351]

3. If the candidate’s video interview is still needed due to legal holds or retention laws, BrightPath:
   - Consults Legal to determine whether immediate deletion is possible;  
   - Documents any exceptions and notifies the candidate if deletion must be delayed.[web:347][web:356]

### 6.3 Conflicts with Other Laws

If there is an apparent conflict between AIVIA’s 30‑day deletion requirement and other requirements (e.g., EEOC retention of hiring records), Legal will:

- Determine whether the other legal obligation requires retaining the video;  
- Document the decision and legal justification;  
- Ensure deletion occurs as soon as legally permitted.[web:347][web:356][web:351]

---

## 7. Roles & Responsibilities

- **Talent Acquisition:**  
  - Ensures candidates receive AIVIA notices and consent forms.  
  - Coordinates with VidHire on access and deletion tasks.

- **Privacy / Compliance:**  
  - Monitors deletion requests and ensures deadlines are met.  
  - Reviews this Policy annually.

- **IT / Security:**  
  - Maintains SSO and access controls.  
  - Supports secure storage and logs for video‑interview data.

- **VidHire:**  
  - Provides tools and APIs to delete specific candidate interviews.  
  - Confirms deletion when requested by BrightPath, including backup copies.

---

## 8. Review & Updates

BrightPath reviews this Policy each year and when:

- AIVIA is updated;  
- BrightPath expands AI video interviews to other roles or vendors;  
- Internal audits or incidents reveal issues with retention or deletion processes.

Changes are communicated to Talent Acquisition, Legal, and IT, and reflected in vendor contracts as needed.

---

**End of Example Policy**
