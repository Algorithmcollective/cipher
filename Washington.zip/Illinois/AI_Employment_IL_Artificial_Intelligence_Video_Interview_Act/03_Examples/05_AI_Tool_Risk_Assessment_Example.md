# AI Tool Risk & Bias Assessment – ResumeRanker (Example)

**Law Context:**  
- Illinois Human Rights Act (IHRA) AI amendments (HB 3773 / Public Act 103‑0804).[web:372][web:344][web:261][web:374]  

**Organization:** BrightPath Talent Inc.  
**Tool Name:** ResumeRanker  
**Version / Model:** v2.3 (2026 model)  
**Vendor / Owner:** Internal ML team  
**Assessment Date:** February 20, 2026  
**Assessor:** Priya Shah, Head of People Analytics  

---

## 1. Tool Overview

- **Purpose / Function:**  
  ResumeRanker scores and ranks applicants based on resume content for corporate roles (sales, marketing, operations, and some engineering positions).

- **Employment Decisions Influenced:**  
  - ☑ Recruitment / sourcing  
  - ☑ Hiring / selection (early screening)  
  - ☐ Promotion  
  - ☐ Other areas

- **Illinois Populations Affected:**  
  - ☑ Illinois applicants (all corporate roles are open to Illinois residents)  
  - ☐ Illinois employees (tool not used post‑hire)

---

## 2. Inputs, Outputs & Features

### 2.1 Inputs

ResumeRanker uses:

- Education history, work experience, job titles, skills, certifications.  
- Keywords/phrases relevant to specific job families.  
- No direct demographic data (race, sex, age) is used as an input.[web:372][web:377][web:345]

### 2.2 Outputs

- Produces a **0–100 score** indicating estimated fit.  
- Generates a ranked list of candidates per role.  
- Recruiters currently:
  - Auto‑advance candidates above a configurable score threshold.  
  - Manually review mid‑score candidates.  
  - Rarely review candidates below the low‑score threshold.

### 2.3 Potentially Sensitive Features

Historically, v2.0 used ZIP code and college name as features.

- ZIP code was removed in 2025 due to risk of acting as a proxy for race and socioeconomic status.[web:372][web:344][web:374]  
- College name remains, but the model was retrained to minimize over‑weighting elite schools.

Current version v2.3 does **not** ingest ZIP code or other obvious proxy fields (e.g., neighborhood, citizenship status). Remaining risks are documented, and engineering monitors feature importance metrics.

---

## 3. Notice & Transparency

BrightPath has:

- Updated its **Careers Privacy Notice** and candidate FAQs to state that it uses AI tools, including ResumeRanker, to help screen and prioritize applicants;  
- Added a sentence to the application page:  
  “We may use automated tools to assist in reviewing applications; human recruiters make final decisions.”[web:372][web:344][web:340][web:346]

Planned enhancements:

- Name ResumeRanker explicitly and add a brief description of what it does and the types of data it uses.

---

## 4. Bias & Impact Considerations

### 4.1 Vendor / Model Documentation

Because ResumeRanker is internal, the ML team provided:

- Training data description: 2018–2024 historical hiring data, with some re‑balancing to avoid over‑fitting to historically favored schools and employers.  
- Fairness testing summary: impact analysis by gender and race (where data available) on past cohorts; adjustments made to reduce disparities.[web:371][web:377][web:345]

---

### 4.2 Internal Impact Checks (High‑Level)

For 2025 hires using ResumeRanker:

- People Analytics compared **advance‑to‑interview** and **hire** rates by self‑identified race and gender for roles where ResumeRanker scores were the primary filter.  
- Results:
  - Some variation across groups, but no group’s selection rate fell below 80% of the highest group’s rate.  
  - Hire‑rate differences were small and not consistently tied to ResumeRanker scores.

Planned 2026 updates:

- Re‑run impact analysis annually, with Illinois‑specific cuts and more granular race/ethnicity breakdowns.[web:237][web:371][web:340][web:346]

---

## 5. Governance & Controls

Key safeguards:

- ResumeRanker is listed in BrightPath’s AI register with defined use cases (resume pre‑screening only).  
- Recruiters receive guidance that:
  - Scores are **advisory** and must not be treated as the sole determinant of any employment decision;  
  - They should periodically spot‑check low‑score candidates.[web:372][web:374][web:375][web:376]

- ZIP code and similar proxies are blocked as inputs; engineering reviews new features for proxy risk.[web:372][web:344][web:374]  
- Any major model update requires:
  - Fairness testing;  
  - Review by People Analytics and Legal;  
  - Updated documentation in the AI register.

---

## 6. Risk Assessment & Action Plan

**Overall risk level:**  
- ☑ Medium – Tool operates at scale and shapes who is considered, but safeguards and early impact checks are in place.

**Key risks identified:**

1. Historical training data may encode past biases (e.g., preference for certain schools or employers).  
2. Recruiters may over‑rely on scores in practice, effectively making ResumeRanker a “gatekeeper” for interviews.  
3. Documentation and candidate‑facing notice could be more specific.

**Planned mitigation actions:**

| Risk | Action | Owner | Target Date |
|------|--------|-------|------------|
| 1 | Continue regular fairness testing with Illinois‑specific slices; adjust model if disparities emerge | ML Lead | Q3 2026 |
| 2 | Reinforce guidance in recruiter training; monitor use patterns and override rates | TA Director | Q2 2026 |
| 3 | Update Careers Privacy Notice and FAQ to describe ResumeRanker by name and function | Compliance | Q2 2026 |

---

## 7. Approval & Review

- Assessor: Priya Shah (signed)  Date: 2026‑02‑20  
- Legal / Compliance Reviewer: Sarah Kim (signed)  Date: 2026‑02‑25  
- Next review due: February 2027  

---

**End of Example Assessment**
