# Illinois AI Video Interview – Notice & Consent – Sales Roles (Example)

**Law Reference:** Artificial Intelligence Video Interview Act (AIVIA), 820 ILCS 42/1 et seq.[web:337][web:241][web:347][web:353]  
**Organization:** BrightPath Talent Inc.  
**Applies To:** Applicants for Sales Development Representative (SDR) and Account Executive (AE) roles based in Illinois  

---

## 1. Notice: Use of AI in Video Interviews

BrightPath Talent Inc. (“BrightPath”) uses a structured video interview as part of the hiring process for certain sales roles. For SDR and AE positions based in Illinois, we use **artificial intelligence (AI)** to help evaluate video interviews.

### 1.1 Use of AI

For these roles:

- You will be asked to record a video interview using our provider, **VidHire**.  
- VidHire’s AI system analyzes your recorded answers and provides a score to BrightPath recruiters, which they use as one factor in deciding whether to move you forward.[web:337][web:241][web:349][web:351]

### 1.2 How the AI Works (High‑Level Explanation)

At a high level:

- The AI analyzes the content of your responses to the interview questions (what you say), as well as certain aspects of how you speak (e.g., pacing, coherence).  
- The system compares your answers against patterns associated with successful performance in similar sales roles.  
- It then generates a score for each interview, which recruiters review along with your resume and other information.

The AI does **not** make hiring decisions on its own; BrightPath recruiters and hiring managers make all final hiring decisions.

We do not design the system to evaluate protected characteristics such as race, ethnicity, sex, religion, age, or disability.[web:341][web:349][web:351]

### 1.3 What Characteristics the AI Uses

The VidHire AI focuses on job‑related characteristics relevant to SDR and AE roles, including:

- Clarity in explaining product or value propositions;  
- Evidence of persistence and resilience (based on your past examples);  
- Customer orientation and communication style.

It does not intentionally score you based on your physical appearance or accent as independent criteria, although, like any video‑based system, performance may vary across different groups. BrightPath reviews the system periodically to monitor for unfair bias.[web:341][web:349][web:351]

---

## 2. Confidentiality, Sharing, and Deletion

### 2.1 Who May See Your Video Interview

Your video interview may be:

- Viewed by BrightPath recruiters and hiring managers involved in the SDR/AE hiring process;  
- Processed by VidHire’s AI system to generate scores and analytics;  
- Accessed by a limited number of BrightPath HR operations and IT staff who support the system.

We do not share your video interview with other external parties, except as required by law (for example, in response to a valid subpoena or court order).[web:337][web:241][web:347][web:355]

### 2.2 Your Right to Request Deletion

If you request that we delete your video interview:

- BrightPath will delete your video interview within **30 days** after receiving your request; and  
- BrightPath will instruct VidHire to delete all copies of your video interview, including any backup copies they maintain.[web:337][web:236][web:351][web:355]

To request deletion, email **privacy@brightpathtalent.com** with the subject line “Video Interview Deletion Request – Illinois” and include your full name and the position you applied for.

Please note that other laws may require us to retain some hiring‑related records for a certain period. If that prevents immediate deletion, we will explain the situation and confirm deletion when allowed.

---

## 3. Consent to AI Analysis

By clicking “I agree” in the VidHire platform or signing below, you:

1. Confirm that you have read and understood this **Illinois AI Video Interview – Notice & Consent – Sales Roles**;  
2. Acknowledge that BrightPath will use AI (through VidHire) to analyze your video interview and help evaluate your application for SDR/AE roles;[web:337][web:241][web:347][web:353]  
3. Understand, at a high level, how the AI works and what general types of characteristics it uses to evaluate applicants;  
4. Consent to the use of AI to analyze your video interview as described;  
5. Understand that you may request deletion of your video interview and that BrightPath will delete the video and instruct VidHire to delete their copies within 30 days of your request, subject to legal requirements.

If you do **not** consent to the use of AI for your video interview, please contact **recruiting@brightpathtalent.com** before recording your interview to discuss alternative arrangements (if available).

---

### Applicant Acknowledgment

I, _______________________________, have read and understood this Notice & Consent and agree that BrightPath Talent Inc. may use AI to analyze my video interview as described.

- Name: _______________________________  
- Signature (or electronic equivalent): _______________________________  
- Date: _______________________________  

---

**End of Example**
