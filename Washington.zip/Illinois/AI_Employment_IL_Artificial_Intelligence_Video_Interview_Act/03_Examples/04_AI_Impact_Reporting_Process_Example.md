# AI Video Interview – Demographic Reporting & Impact Procedure – BrightPath Talent Inc. (Example)

**Law Reference:**  
- Artificial Intelligence Video Interview Act (AIVIA) reporting amendment (820 ILCS 42/).[web:350][web:236][web:369]  

**Organization:** BrightPath Talent Inc.  
**Owner:** Jordan Ellis, Director of Compliance  
**Effective Date:** April 15, 2026  

---

## 1. Purpose

This Procedure explains how BrightPath Talent Inc. (“BrightPath”) collects and reports demographic data under AIVIA when VidHire’s AI video‑interview analysis is the **sole** determinant of which applicants are invited to in‑person interviews for Illinois Sales Development Representative (SDR) roles.

It also describes how BrightPath checks for potential racial bias in this process.[web:350][web:369][web:244]

---

## 2. When This Procedure Applies

This Procedure applies to:

- SDR roles based in Chicago, Illinois;  
- Hiring processes where:
  - Candidates record video interviews through VidHire, and  
  - VidHire’s AI score is used as the **sole filter** to decide who is invited to live interviews.

Account Executive roles are currently **not** in scope because human review of resumes and experience always plays a role in deciding who is interviewed.

---

## 3. Data to Be Collected

For each Illinois SDR hiring cycle, BrightPath collects:

1. Race and ethnicity of applicants **selected** for in‑person interviews after AI analysis.  
2. Race and ethnicity of applicants **not selected** for in‑person interviews after AI analysis.  
3. Race and ethnicity of applicants who are **hired** into SDR roles.[web:350][web:369]

This data is pulled from voluntary self‑identification fields in our Greenhouse ATS and linked to VidHire outcome data.

---

## 4. Collection Process

### 4.1 Self‑Identification

- On the BrightPath application form for SDR roles, candidates are asked to **voluntarily** self‑identify their race and ethnicity using standard EEO categories.  
- The form states that:
  - The information is voluntary and will not affect individual hiring decisions;  
  - It will be used for compliance reporting and fairness monitoring of AI tools.[web:350][web:244]

### 4.2 Data Linking

- Each candidate has a unique Greenhouse Candidate ID.  
- Race/ethnicity data is stored in a restricted analytics field.  
- After the VidHire process, we record:
  - Whether the candidate was invited to a live interview (Yes/No).  
  - Whether the candidate was ultimately hired (Yes/No).

BrightPath’s People Analytics team uses a report that joins Candidate ID, VidHire AI outcome, interview selection status, hire status, and race/ethnicity.

---

## 5. Annual Reporting to Illinois DCEO

### 5.1 Report Preparation

For any year in which the SDR process uses VidHire as the **sole screener** for in‑person interviews, BrightPath:

- Aggregates data for SDR roles as required by the statute:[web:350][web:369]
  - Counts by race/ethnicity for candidates who **are** selected for in‑person interviews.  
  - Counts by race/ethnicity for candidates who **are not** selected for in‑person interviews.  
  - Counts by race/ethnicity for candidates who **are hired**.

- Formats the data according to DCEO guidance or, if none is published, in a simple tabular format with totals and percentages.

### 5.2 Submission

- The Compliance team prepares the report in November and has it reviewed by Legal.  
- BrightPath submits the report to DCEO by **December 31** via the process specified on DCEO’s website (e.g., secure email or portal).[web:350][web:369]  
- A copy of the submitted report and the underlying data extract is stored in the “AIVIA Reports” folder in the Compliance repository.

---

## 6. Internal Impact Review (Adverse Impact Check)

Each year, BrightPath runs a basic adverse impact review for the Illinois SDR VidHire process:

- The People Analytics team:
  - Calculates interview selection rates and hire rates by race/ethnicity.  
  - Compares each group’s rate to the group with the highest rate (using a 4/5ths rule as a heuristic).  

- If any group’s selection or hire rate falls materially below this threshold, the team flags a potential disparity for review.[web:237][web:368][web:370]

For 2025 data (example):

- Analysis showed slightly lower interview selection rates for one minority group compared to others but still above the 4/5ths threshold.  
- Finding was documented, and the AI vendor is being asked to provide updated fairness documentation.

If future analyses show more significant disparities, BrightPath will consider:

- Adjusting AI thresholds;  
- Adding human review before rejecting candidates;  
- Changing tools or models.

---

## 7. Roles & Responsibilities

- **People Analytics:**  
  - Run annual SDR reports and impact analyses.  
  - Provide data to Compliance and Legal.

- **Compliance / Legal:**  
  - Determine whether the “sole determinant” condition is met each year.  
  - Review and approve DCEO submissions and any remedial recommendations.

- **Talent Acquisition:**  
  - Ensure VidHire remains configured so that AI scores are indeed the sole screener only where intended, and update processes if human review is added (which may change reporting obligations).

---

## 8. Documentation & Retention

BrightPath keeps:

- Annual DCEO AIVIA reports and confirmation of submission;  
- Year‑over‑year impact analysis summaries;  
- Internal emails and memos describing any corrective actions.

These records are retained for at least **four years** or longer if required by law or legal hold.[web:350][web:369][web:237]

---

**End of Example Procedure**
