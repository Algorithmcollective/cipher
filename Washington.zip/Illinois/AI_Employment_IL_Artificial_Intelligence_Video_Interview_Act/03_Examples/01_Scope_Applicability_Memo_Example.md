# Illinois AI in Employment – Scope & Applicability Memo – BrightPath Talent Inc.

**Laws Covered:**  
- Artificial Intelligence Video Interview Act (AIVIA), 820 ILCS 42/1 et seq.[web:337][web:250][web:341]  
- Illinois Human Rights Act (IHRA) Amendments on AI in Employment (HB 3773 / Public Act 103‑0804).[web:243][web:339][web:342][web:345]  

**Organization:** BrightPath Talent Inc.  
**Prepared By:** Alex Romero, Head of People Operations  
**Date:** February 10, 2026  

---

## 1. Purpose

This memo evaluates whether Illinois AI employment laws apply to BrightPath Talent Inc., and identifies which hiring and employment tools must be in scope for compliance work.

---

## 2. Summary of Illinois AI Employment Laws

BrightPath uses multiple AI tools in recruiting and hiring, including AI‑screened video interviews for some sales roles. Illinois has two relevant laws:

- **AIVIA** applies because BrightPath:  
  - Asks certain applicants to record structured video interviews; and  
  - Uses a third‑party AI tool to score those interviews for Illinois sales positions.[web:337][web:250][web:338][web:341]

- **IHRA AI amendments** apply because BrightPath uses AI‑based tools in recruitment and hiring decisions that affect Illinois applicants and employees.[web:243][web:339][web:342][web:237]

---

## 3. Illinois Footprint

- BrightPath maintains a regional office in Chicago and regularly hires for sales, customer success, and engineering roles in Illinois.  
- Many roles are “remote, US‑based” but may be filled by Illinois residents.

Conclusion: BrightPath has a meaningful Illinois footprint and Illinois applicants.

---

## 4. Use of AI in Hiring & Employment

### 4.1 Video Interview + AI (AIVIA Scope)

BrightPath uses **VidHire**, an AI‑based video interview platform, for some roles.

| Process / Role Family | Illinois Role? | Video Interviews Used? | AI Used on Video? | Tool / Vendor |
|-----------------------|----------------|------------------------|-------------------|--------------|
| Sales Development Reps (SDRs) | Yes | Yes | Yes | VidHire |
| Account Executives | Yes | Optional | Yes (if video used) | VidHire |
| Customer Support | No | No | No | N/A |

For SDR and AE roles based in Illinois, candidates are asked to complete a structured video interview. VidHire’s AI scores answers on communication skills and role fit, and BrightPath recruiters use those scores in deciding who advances.

Result: AIVIA is **in scope** for BrightPath’s SDR and AE hiring in Illinois.

### 4.2 Other AI in Employment Decisions (IHRA Scope)

BrightPath’s other AI tools affecting Illinois applicants/employees:

| Tool / Process | Vendor / Platform | Employment Decision Area | Illinois Employees/Candidates Affected? |
|----------------|-------------------|--------------------------|-----------------------------------------|
| ResumeRanker | In‑house model | Resume screening for all corporate roles | Yes |
| SkillAssess | Third‑party | Pre‑hire assessment scoring for engineering roles | Yes |
| Performance Insights | HR analytics vendor | Performance data dashboards (no direct automated decisions yet) | Yes, Illinois staff included |

Because these tools influence who is interviewed, advanced, and potentially hired, they fall within IHRA AI scope for Illinois.[web:243][web:339][web:237][web:340]

---

## 5. High‑Level Applicability Conclusion

### 5.1 AIVIA

- AIVIA applies to BrightPath because:  
  - BrightPath asks Illinois applicants to record video interviews; and  
  - BrightPath uses VidHire’s AI to analyze those videos as part of hiring decisions for Illinois‑based SDR and AE roles.[web:337][web:250][web:338][web:341]

### 5.2 IHRA AI Amendments

- IHRA AI provisions apply because BrightPath uses AI in:
  - Recruitment (ResumeRanker, VidHire).  
  - Hiring decisions (SkillAssess scores).  
  - Performance analytics (Performance Insights), which could influence future promotions or terminations.[web:243][web:339][web:342][web:345]

---

## 6. Initial Gap Snapshot

### 6.1 AIVIA Gaps

Current state for VidHire‑based hiring:

- Notice:  
  - Applicants are told that “automated tools” may be used to “help evaluate applications,” but BrightPath does **not** explicitly state that AI will analyze the video interview or how it works in general.[web:337][web:338][web:341]

- Explanation of AI:  
  - VidHire’s documentation explains evaluation factors, but BrightPath has not summarized this clearly for candidates.[web:337][web:341]

- Consent:  
  - Candidates click “Continue” before recording; explicit AI‑specific consent language is not clearly separated.

- Sharing & Deletion:  
  - Videos are shared with BrightPath recruiters and VidHire only.  
  - There is **no documented process** to delete a candidate’s video within 30 days of a deletion request, nor to ensure VidHire deletes copies.[web:337][web:343]

- Demographic reporting:  
  - For SDRs, BrightPath uses VidHire scores as the **sole filter** for who is invited to live interviews. BrightPath is **not yet collecting race/ethnicity data and reporting it to the state** as required.[web:337]

### 6.2 IHRA AI Gaps

- Notice:  
  - Employees and applicants are not explicitly informed when ResumeRanker, VidHire, or SkillAssess are used in employment decisions.[web:339][web:342][web:237][web:346]

- Bias / impact assessment:  
  - BrightPath has not yet performed a formal adverse impact analysis of its AI tools for Illinois candidates or employees.[web:243][web:237][web:340]

- Use of ZIP code:  
  - ResumeRanker initially used ZIP code as a feature; engineering removed it in 2025, but this is not documented.[web:243][web:344][web:345]

---

## 7. Recommended Deliverables for BrightPath

Given the analysis above, BrightPath should implement the following Illinois AI employment documents:

1. **IL_EMP_AI_02_VideoInterview_Notice_Consent_TEMPLATE**  
   - AIVIA‑aligned notice and consent for VidHire video interviews.

2. **IL_EMP_AI_03_VideoData_Handling_Deletion_POLICY_TEMPLATE**  
   - Policy for who can access video interviews, how long they are kept, and deletion within 30 days of candidate request (including instructions to VidHire).[web:337][web:343]

3. **IL_EMP_AI_04_AI_Impact_Reporting_Procedure_TEMPLATE**  
   - Procedure for:
     - Collecting race/ethnicity data for SDR (and any other) roles where AI is the sole screener;  
     - Reporting required demographic data to the state;  
     - Running basic adverse impact checks.

4. **IL_EMP_AI_05_AI_Tool_Risk_Assessment_TEMPLATE**  
   - Formal assessments for:
     - ResumeRanker  
     - VidHire (beyond AIVIA)  
     - SkillAssess  
     - Performance Insights (if used in decisions).[web:243][web:237][web:340]

5. **IL_EMP_AI_06_Employer_AI_Hiring_Policy_TEMPLATE**  
   - Internal policy that:
     - Requires notice when AI is used in employment decisions;  
     - Prohibits using ZIP code as a proxy for protected classes;  
     - Mandates periodic impact assessments and documentation.

**Scope Summary:**

> AIVIA applies to BrightPath’s VidHire‑based video interview process for SDR and AE roles in Illinois. IHRA AI amendments apply to all current AI tools used for recruitment and hiring affecting Illinois applicants and employees. BrightPath should treat Illinois as a “regulated AI hiring jurisdiction” similar to NYC and Colorado and implement the deliverables listed above in Q1–Q2 2026.

---

**End of Example**
