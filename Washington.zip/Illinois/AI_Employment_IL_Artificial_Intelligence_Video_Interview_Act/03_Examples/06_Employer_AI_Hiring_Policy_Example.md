# Employer Policy on AI in Hiring & Employment Decisions – BrightPath Talent Inc. (Example)

**Law Context:**  
- Illinois Human Rights Act (IHRA) AI amendments (HB 3773 / Public Act 103‑0804).[web:372][web:261][web:370][web:345]  

**Organization:** BrightPath Talent Inc.  
**Effective Date:** June 1, 2026  
**Owner:** Sarah Kim, General Counsel  

---

## 1. Purpose & Scope

This Policy sets rules for BrightPath Talent Inc. (“BrightPath”) when using artificial intelligence (AI) in employment‑related decisions. It is designed to meet Illinois requirements and reinforce BrightPath’s nondiscrimination commitments.

It applies to all AI‑enabled tools used in recruitment, hiring, promotion, and other covered employment decisions that may affect Illinois applicants or employees.[web:372][web:261][web:339][web:370]

---

## 2. Definition of AI (for this Policy)

For this Policy, AI includes:

- Machine‑based systems that generate predictions, scores, recommendations, or decisions about candidates or employees;  
- Tools that use statistical models or machine learning to screen resumes, analyze interviews, or assist with performance analytics.

Examples at BrightPath:

- ResumeRanker (internal resume‑scoring model).  
- VidHire (AI video‑interview scoring).  
- SkillAssess (third‑party assessment tool).

[web:372][web:373][web:379]

---

## 3. Covered Employment Decisions

BrightPath may use AI in connection with:

- Recruitment and sourcing (ResumeRanker).  
- Hiring and selection (ResumeRanker, VidHire, SkillAssess).  
- Performance and promotion analytics (Performance Insights dashboards – advisory only).  

Any future use of AI in discharge, discipline, or scheduling must be reviewed and approved under this Policy.[web:372][web:339][web:373][web:370]

---

## 4. Notice Requirements (Illinois Focus)

For roles and employees in Illinois, BrightPath will:

- Inform applicants, via its Careers Privacy Notice and role‑specific notices, when AI is used to assist in resume screening (ResumeRanker), video‑interview scoring (VidHire), or assessment scoring (SkillAssess).[web:372][web:261][web:342][web:340]  
- Inform employees, via internal policy and onboarding materials, when AI‑driven analytics (e.g., Performance Insights) are used in performance or promotion discussions.  

Notices will:

- Identify the tool (by name or type);  
- Describe the decisions it influences;  
- Explain, at a high level, the data used;  
- Provide a contact (Privacy@brightpathtalent.com) for questions.

---

## 5. Nondiscrimination & Prohibited Uses

### 5.1 No Discriminatory Effect

BrightPath will not use AI in a way that has the effect of discriminating against applicants or employees based on protected characteristics under Illinois law.[web:372][web:237][web:370][web:345]

To support this:

- BrightPath conducts periodic impact analyses on its AI tools, including Illinois‑specific slices where data allows.  
- If evidence suggests a tool creates or amplifies inequitable outcomes, BrightPath will investigate and may adjust, replace, or discontinue the tool.

### 5.2 No ZIP Code as Proxy

BrightPath does not use ZIP code or neighborhood data as features in ResumeRanker, VidHire, or SkillAssess scoring.[web:372][web:370][web:379][web:345]

If any future tool requests ZIP code or similar proxy fields for employment decisions, the request must be rejected or escalated to Legal and People Analytics for review and documented justification.

---

## 6. AI Governance & Approval

### 6.1 AI Register & Approval

BrightPath maintains an **AI Tool Register** listing:

- Tool name / vendor;  
- Purpose and covered decisions;  
- Employment stages where it is used;  
- Populations affected (including whether Illinois is in scope).[web:372][web:374][web:375]

Current entries include:

- ResumeRanker – Internal resume‑screening model.  
- VidHire – AI video‑interview scoring tool.  
- SkillAssess – Skills assessment for engineering roles.  
- Performance Insights – Analytics dashboards (no automated decisions).

New tools or major changes require:

- Review by People Analytics, Legal, Security, and HR leadership;  
- Completion of an AI Tool Risk & Bias Assessment (IL_EMP_AI_05).

---

## 7. Human Oversight & Escalation

BrightPath’s principle is that **humans remain accountable** for employment decisions:

- AI scores and recommendations are advisory; managers must not rely solely on AI to make final hiring, promotion, or termination decisions.  
- Any employee or applicant who believes an AI‑assisted decision was inaccurate or unfair may contact HR or the Privacy Office.[web:379][web:374][web:381]

Escalation process:

- HR logs the concern and consults with People Analytics and Legal to review the decision and underlying AI outputs.  
- If appropriate, BrightPath may reconsider the decision or provide additional explanation.

---

## 8. Training & Awareness

BrightPath provides annual training to:

- Recruiters and hiring managers using ResumeRanker, VidHire, or SkillAssess;  
- Managers who consume AI‑driven analytics for performance or promotion.[web:237][web:374][web:381]

Training topics:

- Overview of Illinois AI requirements (notice, nondiscrimination, ZIP‑code restriction).  
- Proper interpretation of AI scores and the importance of human judgment.  
- How to recognize and report potential bias or anomalous AI behavior.

---

## 9. Monitoring, Audits & Updates

BrightPath will:

- Review AI tools affecting Illinois decisions at least annually for potential disparate impact, focusing on roles where AI screens at scale.  
- Document findings and remediation steps, and maintain them for audit purposes.[web:237][web:340][web:371]

This Policy will be updated when:

- Illinois issues final rules or additional guidance;  
- BrightPath deploys new AI tools into employment decisions;  
- Internal reviews or incidents reveal gaps.

---

**End of Example Policy**
