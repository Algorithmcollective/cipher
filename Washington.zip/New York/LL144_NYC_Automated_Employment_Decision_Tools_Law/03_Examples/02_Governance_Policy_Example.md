# Automated Employment Decision Tool (AEDT) Governance Policy  
_New York City Local Law 144_

**Company:** Metro Talent Solutions LLC  
**Effective Date:** 01/01/2026  
**Policy Owner:** Sarah Martinez, Director of Talent Acquisition  
**Last Reviewed:** 01/01/2026

---

## 1. Purpose

This policy establishes how Metro Talent Solutions LLC governs the use of Automated Employment Decision Tools (AEDTs) in hiring decisions, including compliance with New York City Local Law 144 (LL 144). It defines ownership, approval, review, and documentation requirements so that AEDTs are used in a controlled, transparent, and compliant way.

---

## 2. Scope

This policy applies to:

- All AEDTs used in **hiring decisions** for roles based in New York City.  
- All departments that select, configure, or use AEDTs in the hiring process (Talent Acquisition, HR, Operations, IT).  
- All third‑party vendors providing AEDTs to Metro Talent Solutions LLC.

---

## 3. Roles and Responsibilities

**AEDT Governance Owner – Sarah Martinez, Director of Talent Acquisition**  
- Owns this policy and the AEDT inventory.  
- Approves the addition, removal, or material change of any AEDT used for NYC roles.  
- Ensures bias audits are obtained and reviewed at least annually.  

**Talent Acquisition / HR**  
- Identifies when AEDTs are used in the hiring process.  
- Ensures candidates receive required LL 144 notices and opt‑out options.  
- Implements mitigation steps agreed upon after bias audits.  

**Legal / Compliance (General Counsel’s Office)**  
- Reviews AEDT contracts and vendor terms for LL 144 obligations.  
- Reviews bias audit reports and advises on legal risk and mitigation.  

**IT / Systems Owners**  
- Supports integration and configuration of AEDTs (SmartRecruit ATS, HireVue, Indeed Skills Tests).  
- Ensures data used by AEDTs is securely managed and available for audits.

---

## 4. AEDT Inventory and Approval

- All AEDTs used in NYC hiring decisions are documented in the **Metro Talent AEDT Inventory & Classification** file.  
- Before any new AEDT is put into production for NYC roles, the Governance Owner must:  
  - Confirm whether the tool qualifies as an AEDT and “substantially assists” decisions.  
  - Ensure a plan is in place for an independent bias audit before or within the required timeframe.  
  - Confirm candidate notice and opt‑out procedures are configured for the affected roles.

No business unit may deploy or materially change an AEDT for NYC roles without approval from the Governance Owner and Legal/Compliance.

---

## 5. Bias Audits and Public Summaries

For each in-scope AEDT (SmartRecruit ATS, HireVue Assessment, Indeed Skills Tests):

- An **independent bias audit** must be obtained at least **once every year**.  
- The Governance Owner is responsible for:  
  - Coordinating with FairMetrics Analytics, Inc. and the vendors to provide necessary data.  
  - Reviewing audit findings with Legal/Compliance and Talent Acquisition.  
  - Ensuring the **Bias Audit Summary for AEDTs** page on the Metro Talent website is updated after each audit.

If an audit identifies potential disparate impact (e.g., impact ratios below commonly used thresholds), the Governance Owner, Legal, and HR must document and implement appropriate mitigation steps (e.g., tool configuration changes, additional human review, process adjustments).

---

## 6. Candidate Notices and Alternative Processes

For each NYC role where an AEDT is used:

- Candidates receive an **AEDT Notice Email** at least **10 business days** before the tool is applied, using the approved LL 144 notice template.  
- The notice describes:  
  - The job qualifications and characteristics that the AEDT evaluates.  
  - How to request an **alternative, non-automated process** via aedt-alternative@metrotalentsolutions.com or (212) 555‑0147.

The Governance Owner and HR ensure that:

- An **opt‑out / alternative process** workflow exists for each AEDT.  
- Requests are tracked in the AEDT Opt-Out Log and handled according to the Opt-Out Policy.

---

## 7. Vendor Due Diligence

Before engaging or renewing an AEDT vendor for NYC roles:

- Legal/Compliance and the Governance Owner:  
  - Review the vendor’s LL 144 compliance support and bias-audit experience.  
  - Obtain technical documentation describing how the AEDT works and what data it uses.  
  - Include contract language requiring cooperation with bias audits and timely provision of data.

Vendor due-diligence records are stored in the **AEDT Compliance Evidence File**.

---

## 8. Documentation and Evidence

The Governance Owner maintains a centralized **AEDT Compliance Evidence File** containing:

- Current AEDT Inventory & Classification document.  
- Latest independent bias audit reports and the public website summary.  
- Candidate notice templates and proof of delivery from SmartRecruit ATS.  
- Opt‑out / alternative process procedures and sample request records.  
- Vendor due‑diligence questionnaires and relevant contract clauses.  
- This policy and related procedures.

---

## 9. Review and Updates

- This policy is reviewed at least **annually** and when:  
  - A new AEDT is added or an existing AEDT is materially changed.  
  - LL 144 or related regulations are updated.  
  - Significant findings from a bias audit require policy changes.

Updates must be approved by the AEDT Governance Owner and Legal/Compliance.
