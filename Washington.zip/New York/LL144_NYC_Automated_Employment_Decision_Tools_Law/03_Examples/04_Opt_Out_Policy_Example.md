**Company:** Metro Talent Solutions LLC  
**Policy Name:** AEDT Opt‑Out & Alternative Process Policy  
**Effective Date:** 01/01/2026  
**Policy Owner:** Sarah Martinez, Director of Talent Acquisition  
**Last Reviewed:** 01/01/2026

---

### 1. Purpose

This policy explains how Metro Talent Solutions LLC handles candidate requests **not** to be evaluated by an Automated Employment Decision Tool (AEDT) and how we provide an **alternative, non‑automated process** for NYC roles, as required by New York City Local Law 144.

---

### 2. Scope

This policy applies to:

- All NYC‑based positions where an AEDT is used in hiring decisions (administrative, professional, clerical, customer service, and management roles).  
- All candidates who receive an LL 144 AEDT notice and request an alternative process.  
- HR, Talent Acquisition, and any staff involved in reviewing applications.

---

### 3. How candidates can opt out

Candidates may request an alternative, non‑automated process by contacting:

- **Email:** aedt‑alternative@metrotalentsolutions.com  
- **Phone:** (212) 555‑0147  

Each request must include:

- Candidate’s full name  
- Email address used to apply  
- Job title and/or requisition ID  

---

### 4. Internal workflow (step‑by‑step)

When an opt‑out request is received:

1. **Log the request**  
   - Record it in the **Metro Talent AEDT Opt‑Out Log** with:  
     - Date/time received  
     - Candidate name and role  
     - Channel (email/phone)  
     - Staff member handling it  
     - Current status (Open / In Progress / Completed)

2. **Acknowledge within 2 business days**  
   - Send a confirmation email explaining:  
     - That SmartRecruit ATS, HireVue, and Indeed Skills Tests will **not** be used for this candidate, and  
     - What the alternative review process and timeline will be (manual review within 10 business days).

3. **Disable AEDT for that candidate**  
   - In **SmartRecruit ATS**, remove the candidate from any automated screening, scoring, or ranking workflow and mark the profile:  
     - “LL 144 AEDT opt‑out – manual process only.”  
   - Ensure the candidate is excluded from HireVue and Indeed Skills Tests invites for that requisition.

4. **Run the alternative process**  
   - A recruiter and, where appropriate, the hiring manager conduct **manual human review** of the candidate’s resume, application, and any written responses.  
   - They apply the same job‑related criteria normally used by the AEDTs (experience, skills, location, basic qualifications) without automated scoring.  
   - If needed, they schedule a phone or video interview that does **not** use automated scoring.

5. **Document the decision**  
   - Record in SmartRecruit ATS:  
     - Names/titles of reviewers.  
     - Criteria used in the manual evaluation.  
     - Final outcome (advance / decline) and decision date.  
   - Note that the decision was made via the LL 144 alternative process.

6. **Close the request in the Opt‑Out Log**  
   - Update status to **Completed**, with completion date and the initials of the final reviewer.

---

### 5. Responsibilities

- **Opt‑Out Coordinator (Talent Operations Specialist):**  
  - Monitors aedt‑alternative@metrotalentsolutions.com and the opt‑out phone line.  
  - Maintains the Metro Talent AEDT Opt‑Out Log.  
  - Ensures acknowledgements are sent within 2 business days and manual reviews are completed within 10 business days.

- **Recruiters / Hiring Managers:**  
  - Follow the manual review steps when notified of an opt‑out.  
  - Do not use SmartRecruit ATS automated scoring, HireVue assessments, or Indeed Skills Tests for opt‑out candidates.

- **Compliance / Legal:**  
  - Periodically reviews the AEDT Opt‑Out Log and sample cases to confirm the process is followed.

---

### 6. Recordkeeping

The following are retained in the **AEDT Compliance Evidence File**:

- This Opt‑Out & Alternative Process Policy and workflow.  
- The Metro Talent AEDT Opt‑Out Log (with access restricted to HR/Compliance).  
- Sample acknowledgement emails and manual review notes for selected cases.

**Retention period:** At least 3 years from the date of the hiring decision, or longer if required by law.
