# NYC Local Law 144 – Compliance Evidence File Checklist (Example)

**Company:** Metro Talent Solutions LLC  
**Owner:** Sarah Martinez, Director of Talent Acquisition  
**Last Updated:** 01/01/2026  

> This example shows how a mid‑size staffing firm using Greenhouse, HireVue, and Codility might complete the checklist.

---

## 1. Governance & Scope

- [x] **AEDT Inventory & Classification Register**  
      - Location: GDrive > Compliance > LL144 > 01-Inventory  
      - Description: Master spreadsheet listing Greenhouse auto‑screen rules, HireVue video interview scoring, and Codility coding assessments; flags which use cases are “AEDT – In Scope (NYC).”[web:86][web:93]

- [x] **AEDT Governance Policy**  
      - Location: GDrive > Compliance > LL144 > 02-Policies  
      - Description: Approved “AI & AEDT Use Policy” signed by CHRO and GC; defines responsibilities for TA Ops, Legal, and InfoSec; includes LL144 requirements summary.[web:86][web:101]

- [ ] **Change Log for AEDTs**  
      - Location: GDrive > Compliance > LL144 > 01-Inventory > Change-Log  
      - Description: To be created – will track when new models/configs are added (e.g., new Codility score thresholds for NYC engineering roles).[web:99]

---

## 2. Bias Audits & Results

- [x] **Independent Bias Audit Reports – Full Versions**  
      - Location: GDrive > Compliance > LL144 > 03-Bias-Audits  
      - Description: Full BABL AI reports for HireVue and Codility, plus vendor‑provided Ashby bias audit used as a reference.[web:94][web:96]

- [x] **Bias Audit Public Summaries (Website Copies)**  
      - Location: GDrive > Compliance > LL144 > 04-Public-Site-Captures  
      - Description: PDF printouts of the “NYC Local Law 144 Bias Audit Summary” page from metrotalentsolutions.com/careers/aedt‑transparency.[web:98][web:41]

- [x] **Evidence of Publication Timing**  
      - Location: GDrive > Compliance > LL144 > 04-Public-Site-Captures > Timestamps  
      - Description: Dated screenshots from the CMS and Wayback‑style snapshots showing annual refresh of summaries.[web:41][web:100]

- [x] **Auditor Engagement Documents**  
      - Location: GDrive > Compliance > LL144 > 03-Bias-Audits > Engagements  
      - Description: Signed SOWs with BABL AI and an independence attestation referencing NYC LL144 scope.[web:94][web:93]

---

## 3. Candidate Notice & Disclosures

- [x] **Standard Candidate Notice Language (10‑Day Notice)**  
      - Location: GDrive > Compliance > LL144 > 05-Notices  
      - Description: Final text embedded in Greenhouse confirmation emails and job postings explaining AEDT use, characteristics assessed, and accommodation contact.[web:93][web:101]

- [x] **Evidence of Notice Delivery**  
      - Location: GDrive > Compliance > LL144 > 05-Notices > Evidence  
      - Description:  
        - Sample Greenhouse job posting for “NYC Sales Development Rep” with LL144 notice section.  
        - PDF of application confirmation email template with AEDT notice.  
        - Screenshot of HireVue invitation email including reference to AEDT scoring for NYC roles.[web:42][web:41]

- [x] **Data Source & Use Disclosure Template**  
      - Location: GDrive > Compliance > LL144 > 06-Disclosures  
      - Description: Standard candidate response explaining data sources for HireVue and Codility (resume, application responses, tests, and video answers).[web:93]

- [x] **Candidate Requests & Responses Log**  
      - Location: GDrive > Compliance > LL144 > 06-Disclosures > Requests-Log  
      - Description: Export from Zendesk tagged “LL144” with 11 candidate requests in 2025 and response timestamps.[web:41][web:86]

---

## 4. Alternative Process / Opt‑Out

- [x] **Alternative Process Policy**  
      - Location: GDrive > Compliance > LL144 > 07-Alt-Process  
      - Description: Policy allowing NYC candidates to opt out of HireVue and Codility, with manual recruiter review of resume and live interview as alternative.[web:93][web:86]

- [x] **Operational Workflow / SOP**  
      - Location: GDrive > Compliance > LL144 > 07-Alt-Process > SOP  
      - Description: Flowchart and checklist in Lucidchart exported to PDF showing steps for handling an opt‑out request within 3 business days.[web:99][web:101]

- [x] **Training Materials for Recruiters**  
      - Location: GDrive > Compliance > LL144 > 08-Training  
      - Description: 20‑minute LMS module “Using AEDTs for NYC Roles” plus job aids on what to say when a candidate asks about the AEDT.[web:86][web:92]

- [ ] **Sample Completed Opt‑Out Cases**  
      - Location: GDrive > Compliance > LL144 > 07-Alt-Process > Evidence  
      - Description: In progress – will collect at least 3 redacted cases from 2026 once volume is sufficient.[web:41]

---

## 5. Data Management & Retention

- [x] **AEDT Data Retention & Deletion Standard**  
      - Location: GDrive > Compliance > LL144 > 09-Data  
      - Description: Annex to global data retention schedule defining 3‑year retention for AEDT scoring logs used in audits.[web:86][web:91]

- [x] **Data Extract Specifications for Bias Audits**  
      - Location: GDrive > Compliance > LL144 > 03-Bias-Audits > Data-Specs  
      - Description: Excel data dictionaries given to BABL AI for HireVue and Codility datasets, including required protected‑class fields and outcome labels.[web:94][web:102]

- [ ] **Evidence of Secure Data Transfer to Auditors**  
      - Location: GDrive > Compliance > LL144 > 03-Bias-Audits > Data-Transfers  
      - Description: To be populated for next audit; plan is to store redacted SFTP logs and tickets.[web:94]

---

## 6. Vendor Management

- [x] **Vendor Due Diligence Questionnaire – Completed**  
      - Location: GDrive > Compliance > LL144 > 10-Vendors > DDQ  
      - Description: Completed LL144‑focused DDQs from HireVue, Codility, and Greenhouse describing model purpose, inputs, and controls.[web:96][web:63]

- [x] **Contractual LL144 Clauses**  
      - Location: GDrive > Compliance > LL144 > 10-Vendors > Contracts  
      - Description: 2025 contract amendments requiring vendors to support annual bias audits, provide documentation, and maintain audit‑ready logs.[web:91][web:63]

- [ ] **Vendor‑Provided Bias Audit Materials (If Any)**  
      - Location: GDrive > Compliance > LL144 > 10-Vendors > Vendor-Audits  
      - Description: Currently only HireVue’s own LL144 audit summary stored; Codility and Greenhouse still pending.[web:95][web:102]

---

## 7. Annual Review & Monitoring

- [x] **Annual LL144 Compliance Review Checklist**  
      - Location: GDrive > Compliance > LL144 > 11-Annual-Review  
      - Description: Completed 2025 checklist confirming fresh bias audits, notice text review, and website updates for all NYC‑relevant tools.[web:86][web:41]

- [ ] **Monitoring & Issue Log**  
      - Location: GDrive > Compliance > LL144 > 11-Annual-Review > Monitoring  
      - Description: To be formalized; currently issues are tracked informally in TA Ops Jira.[web:99]

- [x] **Regulatory & Guidance Tracker**  
      - Location: GDrive > Compliance > LL144 > 12-Regulatory-Tracker  
      - Description: OneNote tab logging DCWP FAQ updates, OSC enforcement report notes, and law‑firm alerts with dates and owners.[web:41][web:101]

---

## 8. Quick Status Summary (for Internal Use)

| Area                          | Owner              | Last Reviewed | Status | Notes                                                |
|-------------------------------|--------------------|---------------|--------|------------------------------------------------------|
| Inventory & Governance        | Sarah Martinez     | 01/01/2026    | Green  | Change log still being formalized.                  |
| Bias Audits & Publication     | External Auditor   | 10/15/2025    | Green  | Next audits scheduled for Q3 2026.                  |
| Candidate Notice & Disclosures| TA Operations Lead | 12/01/2025    | Green  | Notice copy aligned with latest DCWP FAQ.           |
| Alternative Process           | NYC Recruiting Lead| 11/20/2025    | Amber  | Need redacted opt‑out case examples for evidence.   |
| Data & Retention              | Privacy Counsel    | 09/30/2025    | Green  | Data retention annex approved by Legal.             |
| Vendors                       | Procurement Lead   | 08/10/2025    | Amber  | Awaiting Codility and Greenhouse audit summaries.   |
| Annual Review & Monitoring    | Compliance Manager | 01/01/2026    | Amber  | Monitoring log process to be finalized in Q2 2026.  |
