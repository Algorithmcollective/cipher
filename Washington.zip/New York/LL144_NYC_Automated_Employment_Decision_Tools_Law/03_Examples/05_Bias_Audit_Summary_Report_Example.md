# Bias Audit Summary for Automated Employment Decision Tools (AEDTs)

Metro Talent Solutions LLC uses certain Automated Employment Decision Tools (AEDTs) to assist with hiring decisions for roles based in New York City. This summary is provided to comply with New York City Local Law 144 and related rules. It reflects the results of the most recent independent bias audit for each AEDT.

---

## 1. General Information

- **Company:** Metro Talent Solutions LLC  
- **Audit Date:** 01/10/2026  
- **Auditor:** FairMetrics Analytics, Inc. (independent third-party auditor)  
- **Audit Period Covered:** 01/01/2025–12/31/2025  
- **Scope:** AEDTs used for hiring decisions for NYC-based roles

---

## 2. AEDTs Covered in This Audit

| AEDT Name           | Vendor             | Use Case / Role Type                           | Decision Stage              | In Use for NYC Roles? (Y/N) |
|---------------------|--------------------|------------------------------------------------|-----------------------------|-----------------------------|
| SmartRecruit ATS    | SmartRecruit, Inc. | Administrative & Professional roles            | Initial resume screening    | Y                           |
| HireVue Assessment  | HireVue            | Customer Service & Management roles            | Video assessment stage      | Y                           |
| Indeed Skills Tests | Indeed             | Clerical & Support roles                       | Pre-offer skills assessment | Y                           |

---

## 3. Bias Audit Methodology (High-Level)

The independent auditor evaluated whether the AEDTs' use has a disproportionate impact on candidates in protected categories defined by Local Law 144. The analysis included:

- **Protected categories analyzed:**  
  - Sex (male, female, other/not specified)  
  - Race/ethnicity (as self-reported by candidates where available)

- **Metrics assessed:**  
  - Selection/advancement rates by group at each AEDT stage  
  - Impact ratios comparing each group's selection rate to the group with the highest selection rate

- **Data sources:**  
  - Historical applicant and hiring data exported from Metro Talent Solutions LLC's applicant tracking and assessment systems for the period 01/01/2025–12/31/2025

---

## 4. Summary of Results

For each AEDT, the auditor calculated selection rates and impact ratios for the protected categories listed above.

- **Overall finding:**  
  - For SmartRecruit ATS, HireVue Assessment, and Indeed Skills Tests, no group's impact ratio fell below 0.80 (80%) when compared to the highest-selected group, based on the data analyzed for the audit period.  
  - Some differences in selection rates between groups were observed, but they did not meet the commonly used threshold for adverse impact.

Metro Talent Solutions LLC is continuing to monitor AEDT performance over time and will review future bias audit results with the auditor and vendors to identify and address any emerging disparities.

---

## 5. AEDT Usage and Candidate Rights

- AEDTs are used **together with human review**, not as the sole basis for hiring decisions. Recruiters and hiring managers make final decisions after reviewing AEDT outputs.  
- Candidates applying for NYC-based roles are notified in advance when an AEDT will be used in the hiring process and may request an alternative, non-automated evaluation process.  
- Candidates may request additional information about:  
  - The type of data collected and analyzed by the AEDTs, and  
  - How that data is used in the evaluation process.

Requests can be sent to:  
- **Email:** compliance@metrotalentsolutions.com

---

## 6. Audit Frequency

The AEDTs covered by this summary are subject to an **independent bias audit at least once every year**, and this public summary will be updated after each new audit is completed.

- **Date of next scheduled audit:** On or before 01/10/2027