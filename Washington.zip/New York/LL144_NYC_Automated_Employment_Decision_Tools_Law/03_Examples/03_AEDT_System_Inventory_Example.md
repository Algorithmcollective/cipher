# AEDT Inventory & Classification – Local Law 144

**Company:** Metro Talent Solutions LLC  
**Prepared by:** Ben Schulz / Algorithm Collective  
**Date:** 01/29/2026

---

## 1. Purpose

This document identifies all Automated Employment Decision Tools (AEDTs) used by Metro Talent Solutions LLC and classifies whether each tool is in scope for New York City Local Law 144 (LL 144).

---

## 2. Definitions (Plain English)

- **AEDT:** Any tool that uses machine learning, statistical modeling, data analytics, or AI to help make employment decisions (screening, ranking, scoring, or recommending candidates).  
- **Substantially assists:** The tool's output meaningfully influences whether someone is moved forward, rejected, or ranked for a job (not just a minor convenience).

---

## 3. AEDT Inventory Table

| # | Tool / System Name | Vendor / Platform | Business Use Case | Stage in Hiring Process | What the Tool Does | Used for NYC Roles? (Y/N) | Does It "Substantially Assist" Decisions? (Y/N) | In Scope of LL 144? (Y/N) | Notes / Evidence |
|---|--------------------|-------------------|-------------------|-------------------------|--------------------|---------------------------|-----------------------------------------------|---------------------------|------------------|
| 1 | SmartRecruit ATS | SmartRecruit, Inc. | Resume screening for administrative and professional roles | Initial screening | Automatically scores and ranks resumes based on keywords, skills, years of experience, and education level | Y | Y | Y | System filters top 20% of applicants for recruiter review. Vendor confirmed ML-based ranking in documentation. |
| 2 | HireVue Video Assessment | HireVue | Video interviews for customer service and management roles | Post-application assessment | Analyzes candidate video responses for communication skills, enthusiasm, and cultural fit using AI | Y | Y | Y | Tool generates a "candidate readiness score" (0-100) that recruiters use to shortlist candidates. Used for 80% of management hires. |
| 3 | Indeed Skills Tests | Indeed | Skills and aptitude testing for clerical roles | Pre-offer assessment | Auto-scores typing speed, Excel proficiency, and customer service scenarios | Y | Y | Y | Test results automatically filter candidates into "qualified" vs "not qualified" categories before recruiter contact. |
| 4 | Calendly Scheduling | Calendly | Interview scheduling | Scheduling | Allows candidates to self-schedule interviews based on recruiter availability | Y | N | N | Pure scheduling tool—does not evaluate, score, or rank candidates. No decision assistance. |
| 5 | LinkedIn Recruiter | LinkedIn | Candidate sourcing and outreach | Sourcing | Search and contact potential candidates based on profiles and keywords | Y | N | N | Recruiter manually selects and contacts candidates. Tool does not auto-rank or recommend specific candidates for specific roles. |

---

## 4. Classification Logic

For each tool above, classify LL 144 scope using these questions:

1. **Is the tool used for NYC-based roles or candidates?**  
   - If **No**, mark "In Scope of LL 144?" as **N** (but keep listed for visibility).  

2. **Does the tool score, rank, or automatically filter candidates or employees?**  
   - If **No** (e.g., pure scheduling tool), usually **not** in scope.  

3. **Does the tool's output substantially assist in making hiring or promotional decisions** (e.g., passing/failing, auto-advance, rank order)?  
   - If **Yes**, likely **in scope** and needs a bias audit + notices.

You can summarize decisions in a short note column for each tool (for audit defense).

---

## 5. Summary of In-Scope AEDTs

**In-scope AEDTs (require LL 144 compliance):**

- **SmartRecruit ATS** – AI-powered resume screening and ranking system used for all administrative and professional NYC roles  
- **HireVue Video Assessment** – Video interview AI analysis tool that scores candidates on behavioral and communication traits  
- **Indeed Skills Tests** – Automated skills testing platform that filters candidates into qualified/not qualified categories

**Out-of-scope AEDTs (monitored but no LL 144 bias audit required):**

- **Calendly Scheduling** – Scheduling tool only; does not evaluate or rank candidates  
- **LinkedIn Recruiter** – Sourcing tool with manual recruiter selection; no automated candidate scoring or ranking

---

## 6. Ownership and Review

- **AEDT Inventory Owner:** Sarah Martinez, Director of Talent Acquisition  
- **Review Frequency:** At least annually, and whenever:  
  - A new hiring tool is added  
  - An existing tool is materially updated  
  - The company expands or changes NYC hiring practices  

---

**Document Version:** 1.0  
**Last Updated:** 01/29/2026  
**Next Review Date:** 01/29/2027