**Company:** Metro Talent Solutions LLC  
**Document Name:** AEDT Data Source & Use Disclosure (Candidate Request Example)  
**Effective Date:** 01/01/2026  
**Owner:** Sarah Martinez, Director of Talent Acquisition

---

### When to use this

This is an example response for a candidate applying to an **Administrative Assistant** role in New York City, where Metro Talent Solutions LLC uses SmartRecruit ATS, HireVue, and Indeed Skills Tests as AEDTs.

---

### Subject line (email)

Information About Data Used in Our Automated Employment Decision Tools – Administrative Assistant at Metro Talent Solutions

---

### Email body

Dear Jessica Thompson,

Thank you for your request for more information about the data used in the automated tools that assist with hiring for the **Administrative Assistant** position at **Metro Talent Solutions LLC**.

Below is a summary of the **data sources** and **types of data** used by our Automated Employment Decision Tools (AEDTs), as well as how that data is used in our hiring process for NYC‑based roles.

---

#### 1. Data sources used by the AEDTs

For this position, our AEDTs may use data from the following sources:

- **Your application materials** submitted directly to Metro Talent Solutions LLC, including:  
  - Your resume / CV  
  - Your online application form responses in SmartRecruit ATS  
  - Any cover letter you chose to provide

- **Job‑related screening questions and assessments**, such as:  
  - Your answers to application and knockout questions (e.g., years of experience, software proficiency, work authorization)  
  - Scores from job‑related skills assessments delivered through Indeed Skills Tests (e.g., typing, Microsoft Office)

- **Internal hiring system data**, such as:  
  - The date and time your application was submitted  
  - The specific role and location you applied for  
  - Recruiter disposition codes (for example, “phone screen completed,” “interview scheduled”)

- **Video interview responses** recorded through HireVue (if you complete a video interview), limited to the content of your responses to the interview questions for this role.

We do **not** use personal social media accounts, personal web search history, or unrelated third‑party consumer data in the AEDTs for this position.

---

#### 2. Types of data analyzed

Depending on the specific tool and stage, the AEDTs may analyze some or all of the following **job‑related information**:

- Your years and type of administrative and office experience  
- Your experience with Microsoft Office (Word, Excel, Outlook) and similar tools  
- Your education, certifications, or relevant training  
- Skills listed on your resume or application (for example, typing, data entry, customer service)  
- Your responses to job‑related screening questions in the application  
- Scores from skills tests (such as typing speed and accuracy, basic Excel or office skills)

For certain assessments, the tools may also use:

- Number of correct answers and errors on skills tests  
- Time taken to complete the test or exercise

If you complete a HireVue video interview, the platform analyzes your recorded responses to evaluate job‑related communication and behavioral indicators, such as clarity of responses and customer service orientation, based on the configuration for this role.

---

#### 3. How the AEDTs use this data

The AEDTs use the data described above to:

- Determine whether you meet the **minimum qualifications** for the Administrative Assistant role (for example, required years of experience and basic software skills).  
- Compare your skills and experience to the **requirements** listed in the job posting.  
- Produce a **score or recommendation** that helps our recruiters identify candidates who may be a good fit to move forward to interviews.

These outputs are used **together with human review**, not as the sole basis for hiring decisions. Recruiters and hiring managers review AEDT results, your resume, your application, and any interview notes before making final decisions about interviews or offers.

---

If you have any additional questions about the data used or how it is processed in connection with this role, you can reply to this email or contact us at:

- **Email:** privacy@metrotalentsolutions.com

Sincerely,  
**Sarah Martinez**  
**Director of Talent Acquisition**  
**Metro Talent Solutions LLC**  
**smartinez@metrotalentsolutions.com**  
**(212) 555‑0100**
