# NYC Local Law 144 – AEDT Vendor Due Diligence & Contract Addendum (Example)

**Company:** Metro Talent Solutions LLC  
**Owner:** Legal & Procurement – AEDT Program  
**Last Updated:** 01/01/2026  

> Example of a completed LL 144 vendor pack for a staffing firm using Greenhouse (ATS rules), HireVue (video interviews), and Codility (skills tests).[web:42][web:86]

---

## Part A – Vendor Due Diligence Questionnaire (Completed Example)

### A1. Tool Overview & Use Case

**Vendor:** HireVue  
**Product:** HireVue Interview Insights (NYC configuration)  

1. AEDT(s) covered  
   - Structured video interview platform with automated scoring for customer service, sales, and SDR roles in NYC.  
   - Uses a standardized question set configured for Metro Talent Solutions’ “NYC Frontline” hiring stream.[web:95][web:98]

2. Purpose in hiring/promotion  
   - Provides ranked recommendations and pass/fail bands for candidates after initial recruiter screen.  
   - Substantially assists decisions on which candidates advance to live interviews for NYC roles, but final decisions involve human review.[web:42][web:107]

3. Typical clients and use cases  
   - High‑volume hiring in customer service, sales, and call center roles.  
   - For Metro, used only after basic resume screen, not for internal promotions or low‑volume executive searches.[web:116]

---

### A2. Data Inputs, Outputs, and Logic

4. Data sources used for Metro implementation  
   - Candidate video responses recorded in HireVue (content and limited metadata such as duration).  
   - Basic application data imported from Greenhouse (role, location, candidate ID).  
   - No social media, web‑scraped data, or external consumer data.[web:93][web:92]

5. Outputs used for decision‑making  
   - Overall fit score (0–100) plus categorical rating (Advance / Consider / Do Not Advance).  
   - Recruiter dashboard shows ranked candidate list with scores and recommended next action.[web:95]

6. High‑level model description  
   - Vendor describes use of supervised machine‑learning models trained on labeled interview responses, combined with validated psychometric scales.  
   - Metro uses the “standard customer service” NYC‑approved configuration; no custom training on Metro’s own labels yet.[web:95][web:105]

---

### A3. Bias Audit & LL 144 Support

7. Independent bias audit status  
   - HireVue has undergone an independent bias audit meeting NYC LL 144 requirements, covering the Interview Insights product for declared demographic data.  
   - Metro retains the full audit report and public summary in its LL 144 folder; scope includes customer service roles and U.S. applicant pool.[web:95][web:98]

8. Support for Metro‑specific audits  
   - Vendor provides CSV exports with candidate scores, final outcome (advance / no‑advance), and available demographic fields for defined time windows.  
   - Vendor allows Metro to map demographic groups consistent with DCWP FAQ and auditor guidance.[web:104][web:109]

9. Cooperation commitments  
   - Vendor confirms it will provide data and documentation reasonably required by Metro’s auditor, including configuration details and change logs for NYC use cases.[web:86][web:105]

---

### A4. Logging, Explainability, and Transparency

10. Logging  
    - For each interview, HireVue logs candidate identifier, role, timestamp, model version, score, rating band, and recruiter action (if taken within the platform).[web:92][web:95]

11. Explanations  
    - Provides category‑level explanations (e.g., “customer orientation,” “problem solving”) plus guidance for recruiters on how to interpret scores.  
    - Does not expose full feature‑attribution explanations to Metro but provides documentation describing key feature groups.[web:110]

12. Configuration verification  
    - Vendor issues configuration IDs for each major setup; Metro’s NYC configuration is labeled “NYC-CS-STD‑2025,” referenced in the bias audit documentation.[web:104][web:105]

---

### A5. Security, Privacy, and Data Retention

13. Retention defaults  
    - Default retention of video and logs is 2 years; Metro has contracted for 3‑year retention of scoring logs to support audits.[web:86][web:91]

14. Data protection  
    - Vendor states compliance with SOC 2 Type II and appropriate data protection laws for hosted regions, plus DPA addendum for GDPR where applicable.[web:92]

15. Sub‑processors  
    - Uses a U.S. cloud provider and a content‑delivery network as sub‑processors; full list accessible on vendor trust center.[web:92][web:115]

---

### A6. Governance, Testing, and Change Management

16. Fairness/bias testing cadence  
    - Internal fairness checks run at least annually and before major model updates; LL 144‑specific audits are planned to align with NYC annual expectations.[web:104][web:109]

17. Model change management  
    - Vendor sends release notes for material changes and flags if an update may impact prior LL 144 audits; Metro’s NYC configuration is governed by a controlled change process.[web:106][web:112]

18. Responsible AI policies  
    - Vendor provides a public “Responsible AI” statement and internal governance outline; Metro stores PDFs in its LL 144 vendor file.[web:114]

---

## Part B – Contract / Addendum Clauses (Filled for Metro)

Below is how Metro’s legal team adapted the clause concepts for HireVue.

### B1. Bias Audit Cooperation

Metro’s contract includes:  

- A clause requiring HireVue to provide historical logs and configuration information for NYC roles upon request, at no extra license fee.  
- A commitment to cooperate with Metro’s chosen independent auditor within commercially reasonable efforts.[web:86][web:92]

### B2. Configuration and Change Notifications

- Configuration ID “NYC-CS-STD‑2025” is hard‑coded into the order form and referenced in the LL 144 exhibit to keep the audited configuration stable.  
- HireVue must provide 45 days’ notice before changes that affect scoring for NYC roles, and Metro may pause use in NYC pending audit if needed.[web:104][web:106]

### B3. Logging and Retention

- Contract sets a 3‑year minimum retention for NYC scoring logs, extendable on request, stored in a format accessible for external audits.  
- Metro has a right to quarterly exports of NYC interview logs to its own data warehouse.[web:92][web:91]

### B4. Representations & Sub‑Processors

- HireVue represents that Interview Insights can support independent LL 144 audits based on logs and documentation it provides.  
- Sub‑processors used for storage/processing must agree to equivalent cooperation and retention obligations for NYC logs.[web:92][web:115]

---

## Part C – Metro’s Internal LL 144 Vendor Snapshot

| Vendor / Tool         | Use Case (NYC)                         | Independent Audit in Last 12 Months? | Provides Logs for Audit? | LL144 Clauses Executed? | Notes                                                   |
|-----------------------|----------------------------------------|--------------------------------------|--------------------------|-------------------------|---------------------------------------------------------|
| Greenhouse – Rules    | Initial auto‑screen / knock‑out rules  | Not yet (Metro‑specific only)        | Yes                      | Yes                     | Rules simple; Metro planning internal pre‑screen review.|
| HireVue – Interview   | Video interview scoring for CSR & SDR  | Yes (vendor‑level + Metro scope)     | Yes                      | Yes                     | Primary LL 144 focus area.                              |
| Codility – Skills Test| Coding tests for NYC engineering roles | Vendor audit available               | Yes                      | In progress             | Contract amendment targeted for Q2 2026.                |[web:96][web:105]

