# New York City Local Law 144 – Independent Bias Audit Report

**Report Title:** Bias Audit for HireVue Interview Insights Used by Metro Talent Solutions LLC  
**Prepared For (Employer):** Metro Talent Solutions LLC  
**Prepared By (Independent Auditor):** BABL AI, Inc. (Example)  
**Date of Report:** 06/15/2026  
**Audit Period (Data Window):** 01/01/2025 – 12/31/2025  
**Jurisdiction:** New York City, NY – Local Law 144 of 2021 (AEDTs)[web:42][web:86]

---

## 1. Executive Summary

### 1.1 Purpose of the Audit

This independent bias audit was conducted to evaluate whether the **HireVue Interview Insights** AEDT, as implemented by Metro Talent Solutions LLC (“Metro”), exhibits disparate impact by sex and race/ethnicity for candidates applying to New York City customer service and sales development representative (SDR) roles, as required by NYC Local Law 144.[web:86][web:124]

### 1.2 High-Level Conclusions

Using 2025 hiring data for NYC CSR and SDR roles, the AEDT’s **selection decisions** (advance vs. do not advance based on HireVue score thresholds) did **not** show impact ratios below 0.80 for any sex or race/ethnicity group with sufficient sample size (≥2% of the population).[web:94][web:110]  
A small number of intersectional groups (e.g., specific sex x race combinations) had low sample sizes; their results are reported but interpreted with caution.[web:109][web:123]

### 1.3 AEDT and Use Cases in Scope

The audit covers **HireVue Interview Insights** used to score structured, pre‑recorded video interviews for external applicants to NYC **Customer Service Representative** and **Sales Development Representative** roles.[web:95][web:122]  
The AEDT substantially assists Metro’s decision on whether a candidate is advanced from video interview to live recruiter/manager interview for these NYC roles.[web:42][web:116]

---

## 2. Description of the AEDT and Employer Use

### 2.1 AEDT Overview

HireVue Interview Insights is a video interview platform that records candidate responses to a standardized set of questions and generates an overall **fit score (0–100)** and categorical recommendation (Advance / Consider / Do Not Advance).[web:95][web:110]  
The underlying model uses supervised machine‑learning techniques and job‑related feature groups identified through prior validation studies (as described in vendor documentation).[web:95]

### 2.2 Employer Implementation

Metro uses HireVue for NYC CSR/SDR roles only, with:  

- A fixed NYC configuration ID: **NYC-CS-STD‑2025**  
- Standard question set focusing on customer orientation, communication, and problem solving  
- A decision threshold: candidates with a HireVue category of **“Advance”** or **“Consider”** are typically progressed, while **“Do Not Advance”** candidates are not advanced absent an alternative process request[web:95][web:105]

### 2.3 Decisions Substantially Assisted or Replaced

The AEDT’s scores and categories substantially assist Metro’s decision to **advance or not advance** candidates from the recorded video interview stage to live human interviews for NYC CSR and SDR roles.[web:42][web:116]  
Final hiring decisions (offers) remain human‑made, taking into account interviews and other information not evaluated by the AEDT.[web:110]

---

## 3. Data Used for the Audit

### 3.1 Data Source and Extraction

Data were extracted from:  

- **HireVue**: interview scores, categories, timestamps, and candidate IDs  
- **Greenhouse ATS**: role, NYC location flag, final disposition (advanced vs not advanced), and self‑identified demographics[web:94][web:124]

The audit covers interviews conducted between **01/01/2025 and 12/31/2025** for external candidates to NYC CSR and SDR roles.

### 3.2 Population and Sampling

- Total candidates with completed HireVue interviews and known NYC CSR/SDR designation: **4,200**  
- No sampling was performed; the full in‑scope population was used for the audit.[web:94][web:122]  
- Candidates whose applications were incomplete or whose video recordings failed quality checks were excluded (3.1% of initial pool).

### 3.3 Demographic Categories and Groups

Metro collects voluntary, self‑identified demographics in Greenhouse:[web:123][web:109]  

- **Sex**: Female, Male, Non‑binary, Prefer not to say  
- **Race/Ethnicity** (collapsed for audit):  
  - White  
  - Black or African American  
  - Hispanic or Latino  
  - Asian  
  - Two or More Races  
  - Other / Not Listed  
  - Prefer not to say  

Intersectional groups are defined by sex x race/ethnicity for individuals who provided both identifiers.[web:110][web:123]  
Overall, **18%** of candidates did not provide sex and/or race/ethnicity and are reported as “Unknown.”

### 3.4 Handling of Small Groups and Test Data

Groups representing **<2%** of the total population (for either a single sex or single race/ethnicity category) are labeled as “small‑N” in the tables.[web:110][web:109]  
Their selection rates are disclosed, but impact ratios for those groups are interpreted cautiously and not used as primary indicators of systemic disparate impact.[web:124]  
No synthetic or test data were used; only Metro’s 2025 live production data were included.

---

## 4. Methodology

### 4.1 Outcome Definitions

The **outcome** analyzed is whether a candidate was **“selected”** by the AEDT to advance, defined as:  

- HireVue categorical recommendation of **Advance** or **Consider**, and  
- Candidate being moved forward in Greenhouse to a live interview stage (consistent with Metro’s standard practice).[web:110][web:123]

Candidates with **“Do Not Advance”** recommendations who were not moved forward are treated as **not selected**.

### 4.2 Metrics for Disparate Impact

For each demographic and intersectional group, we calculated:[web:110][web:94]  

- **Selection rate** = selected candidates / total candidates in group  
- **Impact ratio** = group selection rate / highest group selection rate (reference group)  

We computed these metrics separately for:  

- Sex  
- Race/ethnicity  
- Intersectional sex x race/ethnicity

### 4.3 Statistical Techniques

The audit used:[web:94][web:125]  

- Point estimates of selection rates and impact ratios  
- 95% confidence intervals for selection rates (Wilson intervals)  
- Flags for groups with impact ratios below **0.80** as a cautionary threshold, consistent with LL 144 commentary and four‑fifths rule practices[web:110][web:109]

No further hypothesis testing (e.g., chi‑square) was performed due to varying group sizes and focus on practical impact.

### 4.4 Assumptions and Limitations

- The audit assumes candidates self‑identify sex and race/ethnicity accurately where reported.  
- Approximately 18% “Unknown” demographics may mask some disparities; Metro is encouraged to improve voluntary self‑identification rates.[web:109][web:88]  
- Results apply only to Metro’s specific configuration of HireVue for NYC CSR/SDR roles during the 2025 period.

---

## 5. Results – Tables and Findings

### 5.1 Summary Table – Sex

**Overall N (with known sex):** 3,444 (82% of 4,200 total)  

| Sex Group | N Candidates | Selected (N) | Selection Rate | Impact Ratio vs Reference | Notes |
|----------|-------------:|-------------:|---------------:|--------------------------:|-------|
| Female   | 1,900        | 950          | 50.0%          | 1.00                      | Reference group (highest rate) |
| Male     | 1,450        | 700          | 48.3%          | 0.97                      | –     |
| Non‑binary | 94         | 45           | 47.9%          | 0.96                      | Small‑N but ≥2% threshold not met globally; interpret with caution. |

No sex group with adequate sample size exhibited an impact ratio below **0.80**.[web:94][web:110]

### 5.2 Summary Table – Race/Ethnicity

**Overall N (with known race/ethnicity):** 3,360  

| Race/Ethnicity            | N Candidates | Selected (N) | Selection Rate | Impact Ratio vs Reference | Notes |
|---------------------------|-------------:|-------------:|---------------:|--------------------------:|-------|
| White                     | 1,400        | 735          | 52.5%          | 1.00                      | Reference group (highest rate) |
| Black or African American | 780          | 380          | 48.7%          | 0.93                      | –     |
| Hispanic or Latino        | 620          | 305          | 49.2%          | 0.94                      | –     |
| Asian                     | 380          | 180          | 47.4%          | 0.90                      | –     |
| Two or More Races         | 120          | 58           | 48.3%          | 0.92                      | Small‑N; still above 2% of population. |
| Other / Not Listed        | 60           | 27           | 45.0%          | 0.86                      | Small‑N group. |

No race/ethnicity group’s impact ratio fell below **0.80**.[web:94][web:123]

### 5.3 Intersectional Analysis (Sex x Race/Ethnicity)

Intersectional analysis was performed for groups with at least **50** candidates.[web:110][web:123]  

Example subset of table:

| Sex x Race/Ethnicity             | N Candidates | Selection Rate | Impact Ratio vs Reference | Notes |
|----------------------------------|-------------:|---------------:|--------------------------:|-------|
| Female – White                   | 900          | 53.0%          | 1.00                      | Reference intersectional group |
| Female – Black or African American | 400       | 50.0%          | 0.94                      | –     |
| Female – Hispanic or Latino      | 320          | 50.0%          | 0.94                      | –     |
| Male – White                     | 500          | 51.0%          | 0.96                      | –     |
| Male – Black or African American | 350          | 47.0%          | 0.89                      | –     |
| Male – Hispanic or Latino        | 260          | 47.3%          | 0.89                      | –     |

No intersectional group meeting the minimum sample size threshold showed an impact ratio below 0.80.[web:94][web:122]

### 5.4 Findings by Category

- **Sex:** Selection rates for Female, Male, and Non‑binary candidates were within approximately 2 percentage points of each other, with impact ratios between 0.96 and 1.00.[web:94]  
- **Race/Ethnicity:** All major race/ethnicity groups had impact ratios between 0.86 and 1.00; the lowest, “Other / Not Listed,” had small sample size but remained above the 0.80 threshold.[web:123]  
- **Intersectional:** No large intersectional group showed impact ratios suggesting pronounced disparate impact, though several smaller groups warrant continued monitoring.[web:110][web:109]

---

## 6. Conclusions and Recommendations

### 6.1 Conclusions with Respect to LL 144 Criteria

Based on the data and methods described, this report constitutes an **independent bias audit** of Metro’s use of HireVue Interview Insights for NYC CSR/SDR hiring under Local Law 144.[web:42][web:124]  
For the audited period, no sex, race/ethnicity, or intersectional group with sufficient sample size exhibited an impact ratio below 0.80, and no pattern of substantial adverse impact was identified.[web:94][web:123]

### 6.2 Recommendations to Employer (Non‑Binding)

- Maintain annual re‑audits, particularly if Metro changes question sets, score thresholds, or roles included in the HireVue configuration.[web:104][web:118]  
- Improve voluntary demographic self‑identification to reduce the “Unknown” category, which will strengthen future audits.[web:109][web:88]  
- Continue to offer and document alternative processes for candidates who opt out of the AEDT, ensuring transparency and accessibility in NYC.[web:42][web:86]

---

## 7. Information Required for Public Summary (For Metro’s Website)

The following may be used by Metro in the required public summary under LL 144.[web:124][web:123]

- **AEDT Name and Vendor:** HireVue Interview Insights, HireVue Inc.  
- **Employer / Employment Agency:** Metro Talent Solutions LLC  
- **Date Employer First Used AEDT in NYC:** 07/01/2024  
- **Date of This Bias Audit:** 06/15/2026  
- **Data Source(s):**  
  - HireVue interview logs and scores (01/01/2025 – 12/31/2025)  
  - Greenhouse ATS candidate records and demographic data for NYC CSR/SDR roles in the same period[web:94][web:122]  
- **Number of Candidates/Employees Assessed:** 4,200 total; 3,444 with known sex; 3,360 with known race/ethnicity  
- **Summary of Selection/Impact Ratios:**  
  - No sex or race/ethnicity group with sufficient sample size had an impact ratio below 0.80.  
- **Number of Individuals with Unknown Sex and Race/Ethnicity:**  
  - Sex Unknown: 756  
  - Race/Ethnicity Unknown: 840[web:110][web:123]

---

## 8. Auditor Independence and Qualifications

### 8.1 Independence Statement

BABL AI, Inc. affirms that it is independent from Metro Talent Solutions LLC and HireVue Inc. for purposes of this audit: it does not own or operate the AEDT and does not make or control any employment decisions resulting from its use.[web:88][web:94]

### 8.2 Auditor Qualifications

BABL AI specializes in algorithmic bias audits and has conducted multiple audits under NYC Local Law 144 for AEDTs in hiring contexts, applying documented methodologies consistent with industry and regulatory expectations.[web:105][web:125]

### 8.3 Signatures

**Lead Auditor:** ___________________________  
**Title:** _________________________________  
**Date:** 06/15/2026  

**End of Report**
