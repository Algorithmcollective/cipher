# NYC Local Law 144 – Annual Re‑Audit & Review Schedule (Example)

**Company:** Metro Talent Solutions LLC  
**Owner:** Sarah Martinez, Director of Talent Acquisition & Compliance Lead  
**Cycle Covered:** 2026  

> This example shows how Metro Talent Solutions plans and tracks its annual LL 144 bias audits and compliance reviews for AEDTs used in NYC hiring.[web:41][web:86]

---

## 1. Annual Timeline Overview – Metro's 2026 Cycle

- **January–February 2026:**  
  - ✅ **Completed 01/15/2026:** Refreshed AEDT inventory (Greenhouse auto-rules, HireVue, Codility); confirmed all three remain in scope for NYC SDR, CSR, and engineering roles.[web:50][web:116]  
  - ✅ **Completed 01/20/2026:** Engaged BABL AI as independent auditor for all three tools; signed SOWs and set data delivery deadlines.[web:104][web:114]  
  - Decision: Continue using all three AEDTs for 2026 NYC hiring with no major configuration changes planned.

- **March–May 2026:**  
  - **Target 03/15/2026:** TA Ops and Data team pull candidate/score datasets from Greenhouse, HireVue, and Codility for Q4 2025 audit window.  
  - **Target 04/01/2026:** Transmit data to BABL AI via secure SFTP; store transfer logs in LL 144 folder.[web:104]  
  - **Target 05/01–05/15/2026:** Review preliminary audit results and address any auditor questions.  
  - **Target 05/20/2026:** Finalize any required mitigations if impact ratios show adverse impact (e.g., adjust score thresholds, expand alternative process communications).

- **June 2026:**  
  - **Target 06/15/2026:** Receive final bias audit reports for all three AEDTs from BABL AI.[web:86][web:105]  
  - **Target 06/20/2026:** Legal drafts updated bias audit summaries for Metro website based on final reports.  
  - **Target 06/25/2026:** Sarah M. reviews candidate notice templates against latest DCWP FAQ (no changes expected from 2025 version).[web:42][web:119]

- **July–August 2026:**  
  - **Target 07/10/2026:** Publish updated bias audit summaries on metrotalentsolutions.com/careers/aedt-transparency; capture dated screenshots for evidence file.[web:41][web:110]  
  - **Target 07/20/2026:** Update internal AEDT governance policy to reference 2026 audit dates and distribution dates.  
  - **Target 08/01/2026:** Refresh recruiter LMS module "Using AEDTs for NYC Roles" with 2026 audit references and any new alternative process examples.[web:114][web:92]

- **September–October 2026:**  
  - **Target 09/15/2026:** Run internal LL 144 compliance review (see checklist below); assign owners for any gaps.  
  - **Target 10/01/2026:** Complete remediation of any gaps identified in compliance review (e.g., missing vendor DDQ updates, missing alt-process case examples).

- **November–December 2026:**  
  - **Target 11/15/2026:** Decide on 2027 AEDT changes (e.g., evaluate new ATS auto-scoring features, decide whether to pilot new assessment tools).  
  - **Target 12/01/2026:** If new AEDTs planned, initiate vendor DDQ and LL 144 contract review process.[web:45][web:92]  
  - **Target 12/20/2026:** Close out 2026 LL 144 compliance year; file annual sign-off and prepare for 2027 audits starting in January.

---

## 2. Tool‑By‑Tool Annual Audit Planner – Metro 2026

| AEDT / Vendor & Tool              | NYC Use Case                     | Last Audit Completion | Latest Date to Re‑Audit | Auditor  | Status (as of 01/29/2026)        | Notes                                                                 |
|-----------------------------------|----------------------------------|-----------------------|-------------------------|----------|----------------------------------|-----------------------------------------------------------------------|
| Greenhouse – Auto-Screen Rules    | Resume knockout, NYC SDR roles   | 06/10/2025            | 06/10/2026              | BABL AI  | Planned (SOW signed 01/20/2026)  | Simple rules; planning minimal audit scope for this tool.           |
| HireVue – Interview Insights      | Video interview scoring, CSR/SDR | 06/15/2025            | 06/15/2026              | BABL AI  | Planned (SOW signed 01/20/2026)  | Primary LL 144 focus area; expecting detailed impact ratio analysis. |
| Codility – Skills Assessment      | Coding tests, NYC engineers      | 07/01/2025            | 07/01/2026              | BABL AI  | Planned (SOW signed 01/20/2026)  | Contract addendum with Codility finalized Q1 2026 for log access.    |[web:41][web:104]

---

## 3. Annual LL 144 Review Checklist – Metro 2026 (As of 01/29/2026)

### 3.1 Inventory & Scope

- [x] **Completed 01/15/2026:** AEDT inventory reviewed and updated. Three tools remain in scope (Greenhouse, HireVue, Codility).[web:50][web:116]  
- [ ] **Ongoing:** Any new tools added to inventory with LL 144 review before go-live (none planned for H1 2026).  
- [ ] **Ongoing:** Any retired tools documented (none retired in 2025 or planned for 2026).

### 3.2 Bias Audits

- [ ] **Target 06/15/2026:** Each in-scope AEDT has independent bias audit within 12 months of current use.[web:41][web:86]  
- [x] **Completed 01/20/2026:** SOWs signed with BABL AI for all three tools; data prep timeline set for March 2026.[web:50][web:105]  
- [ ] **Target 05/20/2026:** Follow-up actions documented if impact ratios show potential adverse impact (mitigations, config changes).[web:104][web:118]

### 3.3 Public Website & Notices

- [ ] **Target 07/10/2026:** Website bias audit summaries updated for each AEDT with audit date, distribution date, and summary table.[web:41][web:110]  
- [ ] **Target 07/12/2026:** Dated screenshots/PDFs taken and stored in GDrive > Compliance > LL144 > 04-Public-Site-Captures.[web:41]  
- [x] **Completed 06/25/2025 (last year); re-review target 06/25/2026:** Candidate notice templates reviewed against DCWP FAQ (no material changes expected for 2026).[web:42][web:119]  
- [x] **Confirmed current:** Notices clearly state AEDT use, characteristics evaluated, data types/sources, retention, and alternative process contact (privacy@metrotalentsolutions.com).[web:86][web:114]

### 3.4 Vendor & Data Management

- [x] **Completed 01/10/2026:** Vendor DDQs current for HireVue and Greenhouse; Codility DDQ update in progress (target completion 02/15/2026).[web:92][web:63]  
- [x] **Completed Q4 2025:** LL 144 contract clauses executed with HireVue and Greenhouse; Codility addendum signed 01/05/2026.  
- [x] **Confirmed 01/15/2026:** Data retention settings verified: 3-year retention for scoring logs across all three tools (enough for audit history).[web:86][web:91]  
- [ ] **Target 04/05/2026:** Evidence of secure data transfers to BABL AI retained (SFTP logs, Zendesk tickets).[web:104]

### 3.5 Training & Governance

- [ ] **Target 08/01/2026:** Recruiter LMS module "Using AEDTs for NYC Roles" refreshed to reflect 2026 audit dates and any new alternative process examples.[web:114][web:92]  
- [x] **Completed 12/15/2025 (last year); re-review target 07/20/2026:** Internal AEDT governance policy reviewed (no changes needed for 2026 unless audit findings require updates).  
- [ ] **Target 09/15/2026:** Review candidate complaints/questions from 2026 and incorporate feedback into training and notice improvements.[web:41]

---

## 4. Internal Roles & RACI – Metro 2026

| Activity                                | Compliance (Sarah M.) | Legal (External GC) | TA Ops (Jessica R.) | IT / Data (Mark T.) | Vendor Mgr (Procurement) |
|----------------------------------------|-----------------------|---------------------|---------------------|---------------------|--------------------------|
| Maintain AEDT inventory                | **R**                 | C                   | **A**               | C                   | C                        |
| Engage independent bias auditor        | **A**                 | **R**               | C                   | C                   | C                        |
| Prepare and send data to auditor       | C                     | C                   | **R**               | **R**               | C                        |
| Draft & publish website summaries      | C                     | **R**               | **A**               | C                   | C                        |
| Refresh notices & candidate templates  | C                     | **R**               | **A**               | C                   | C                        |
| Update vendor DDQs & contract clauses  | C                     | **A**               | C                   | C                   | **R**                    |
| Run annual LL 144 review checklist     | **A**                 | C                   | **R**               | C                   | C                        |

**Legend:** **R** = Responsible (does the work), **A** = Accountable (final sign-off), **C** = Consulted.[web:50][web:110]

---

## 5. Annual Sign‑Off – Metro 2026

**LL 144 Annual Review Completed By:**  
- Name: ___________________________ (to be signed 12/20/2026)  
- Role: ___________________________  
- Date: ___________________________  

**Comments / Known Gaps for Next Cycle (Updated 01/29/2026):**  
- Codility vendor DDQ update still in progress; target completion 02/15/2026.  
- Need to collect at least 3 redacted opt-out/alternative process case examples during 2026 for evidence file (currently only 1 on file from 2025).  
- Consider piloting new AEDT for 2027 (e.g., Indeed Skills Tests for administrative roles); if pursued, build in LL 144 review and audit timeline before NYC go-live.
