# Candidate Notification EXAMPLE – Local Law 144 (AEDT Use)

**Format:** Email or ATS message  
**Example for:** Metro Talent Solutions LLC – Administrative Assistant role

---

**Subject:** Notice of Automated Employment Decision Tool Use – Administrative Assistant at Metro Talent Solutions

Dear Jessica Thompson,

Thank you for your interest in the **Administrative Assistant** position at **Metro Talent Solutions LLC**.

As part of our hiring process for this role, we use an **Automated Employment Decision Tool (AEDT)** to help evaluate applications. This tool uses data and algorithms to assist our recruiters in reviewing candidates.

## What this tool does

For this position, the AEDT will be used to:

- **Evaluate:** Your resume, application information, and responses to screening questions  
- **Focus on:** Years of administrative experience, proficiency with Microsoft Office applications (Word, Excel, Outlook), typing speed, customer service skills, and organizational abilities

The AEDT's results will be used **along with human review** to help decide which candidates move forward in the hiring process.

## Your options (alternative process)

If you **do not want your application to be evaluated by this AEDT**, you may request an **alternative, non-automated process**.

To request an alternative process, please contact:

- **Email:** aedt-alternative@metrotalentsolutions.com  
- **Phone:** (212) 555-0147  

Please include your **full name**, **email address**, and the **job title** you applied for in your request.

We will confirm and explain the alternative process and timeline after we receive your request.

## Data and privacy

The tool uses information that you provide in your application and any related assessments, as well as limited job‑related data from our systems. If you would like more information about the data used or how it is processed, you can contact us at:

- **Email:** privacy@metrotalentsolutions.com

---

If you have any questions about this notice or our hiring process, please let us know.

Sincerely,  
**Sarah Martinez**  
**Director of Talent Acquisition**  
**Metro Talent Solutions LLC**  
**smartinez@metrotalentsolutions.com**  
**(212) 555-0100**

---

**Compliance Notes (Internal - Do Not Send to Candidate):**

- This notice must be sent **at least 10 business days before the AEDT is used** to evaluate the candidate.
- Delivery method should be timestamped (e.g., via email or ATS notification with sent date/time).
- Keep a copy of the notice and confirmation of delivery in the compliance evidence file for this role.
- Ensure alternative process contacts are monitored and requests are responded to promptly.

**Delivery record for this example:**
- Sent via: ATS automated notification
- Date sent: 01/15/2026
- Date AEDT screening begins: 01/29/2026 (14 business days after notice)
- Confirmation: Email delivery receipt saved in candidate file