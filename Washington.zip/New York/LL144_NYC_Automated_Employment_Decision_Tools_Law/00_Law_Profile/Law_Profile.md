# Law Profile

## Law Name
New York City Local Law 144 of 2021 – Automated Employment Decision Tools (AEDT)

## Citation
NYC Administrative Code § 20-870 et seq.

## Status
Enacted

## Effective Date
July 5, 2023 (Enforcement began)

## Regulatory Scope

Applies to employers and employment agencies that use automated employment decision tools (AEDTs) to:

- Screen candidates
- Evaluate employees for promotion

Applies when the position is located in New York City or the candidate resides in NYC.

## Definition of AEDT

A computational process derived from machine learning, statistical modeling, data analytics, or artificial intelligence that:

- Issues simplified outputs (score, classification, recommendation)
- Is used to substantially assist or replace discretionary decision-making

## Core Obligations

Employers must:

1. Conduct an independent bias audit before use
2. Conduct annual re-audits
3. Publish bias audit summary results publicly
4. Provide notice to candidates at least 10 business days before use
5. Disclose job qualifications and characteristics assessed
6. Provide data source disclosure
7. Offer alternative selection process upon request

## Enforcement Authority

NYC Department of Consumer and Worker Protection (DCWP)

## Penalties

Civil penalties:

- $500–$1,500 per violation
- Each day of non-compliance may constitute a separate violation

## Private Right of Action
No direct private right under LL144  
(But discrimination claims may arise separately)

## Tier Classification
Tier 1 – Municipal AI Employment Governance Law

## Revenue Priority
Very High (HR + AI Hiring Tools)

## Target Industries

- Large employers hiring in NYC
- Staffing firms
- AI hiring vendors
- Recruiting SaaS providers
- Enterprise HR platforms

## Strategic Positioning

Position as:

Automated Hiring Bias Audit & Transparency Compliance Program.

Primary risk drivers:

- Public audit disclosures
- Media exposure
- Regulatory penalties
- Discrimination crossover exposure

## Internal Notes

Primary compliance focus areas:

1. AEDT Identification & Inventory
2. Independent Bias Audit Procurement
3. Candidate Notice & Transparency
4. Vendor Governance
5. Annual Re-Audit Scheduling
6. Public Disclosure Management
7. Enforcement Defense File