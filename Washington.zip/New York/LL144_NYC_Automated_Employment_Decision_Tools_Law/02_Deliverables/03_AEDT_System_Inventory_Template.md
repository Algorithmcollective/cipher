# AEDT Inventory & Classification – Local Law 144

**Company:** [Client Company Name]  
**Prepared by:** [Your Name / Algorithm Collective]  
**Date:** [MM/DD/YYYY]

---

## 1. Purpose

This document identifies all Automated Employment Decision Tools (AEDTs) used by [Client Company Name] and classifies whether each tool is in scope for New York City Local Law 144 (LL 144).

---

## 2. Definitions (Plain English)

- **AEDT:** Any tool that uses machine learning, statistical modeling, data analytics, or AI to help make employment decisions (screening, ranking, scoring, or recommending candidates).  
- **Substantially assists:** The tool's output meaningfully influences whether someone is moved forward, rejected, or ranked for a job (not just a minor convenience).

---

## 3. AEDT Inventory Table

| # | Tool / System Name | Vendor / Platform | Business Use Case | Stage in Hiring Process | What the Tool Does | Used for NYC Roles? (Y/N) | Does It "Substantially Assist" Decisions? (Y/N) | In Scope of LL 144? (Y/N) | Notes / Evidence |
|---|--------------------|-------------------|-------------------|-------------------------|--------------------|---------------------------|-----------------------------------------------|---------------------------|------------------|
| 1 | [e.g., ATS Resume Screener] | [Vendor name] | Resume screening for [roles] | Initial screening | Scores / filters resumes based on keywords, experience, etc. | [Y/N] | [Y/N] | [Y/N] | [How you determined scope] |
| 2 | [e.g., Video Interview Analyzer] | [Vendor name] | Video interviews for [roles] | Post-application assessment | Analyzes video to rate candidates on traits/behaviors | [Y/N] | [Y/N] | [Y/N] | [Notes] |
| 3 | [e.g., Online Assessment Tool] | [Vendor name] | Skills / personality testing | Pre-offer assessment | Scores tests and recommends pass/fail or ranking | [Y/N] | [Y/N] | [Y/N] | [Notes] |
| 4 | [Add more rows as needed] | | | | | | | | |

---

## 4. Classification Logic

For each tool above, classify LL 144 scope using these questions:

1. **Is the tool used for NYC-based roles or candidates?**  
   - If **No**, mark "In Scope of LL 144?" as **N** (but keep listed for visibility).  

2. **Does the tool score, rank, or automatically filter candidates or employees?**  
   - If **No** (e.g., pure scheduling tool), usually **not** in scope.  

3. **Does the tool's output substantially assist in making hiring or promotional decisions** (e.g., passing/failing, auto-advance, rank order)?  
   - If **Yes**, likely **in scope** and needs a bias audit + notices.

You can summarize decisions in a short note column for each tool (for audit defense).

---

## 5. Summary of In-Scope AEDTs

**In-scope AEDTs (require LL 144 compliance):**

- [Tool 1 name] – [Short description]  
- [Tool 2 name] – [Short description]

**Out-of-scope AEDTs (monitored but no LL 144 bias audit required):**

- [Tool name] – [Reason (e.g., not used for NYC roles, does not screen/rank candidates, etc.)]

---

## 6. Ownership and Review

- **AEDT Inventory Owner:** [Name, Title – e.g., Head of HR / Compliance]  
- **Review Frequency:** At least annually, and whenever:  
  - A new hiring tool is added  
  - An existing tool is materially updated  
  - The company expands or changes NYC hiring practices  

---

**Document Version:** 1.0  
**Last Updated:** [MM/DD/YYYY]  
**Next Review Date:** [MM/DD/YYYY]