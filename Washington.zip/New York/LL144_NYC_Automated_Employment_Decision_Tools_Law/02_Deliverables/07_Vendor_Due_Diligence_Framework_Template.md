# NYC Local Law 144 – AEDT Vendor Due Diligence & Contract Addendum

**Company:** [Company Name]  
**Owner:** [Legal / Procurement / Compliance]  
**Last Updated:** [MM/DD/YYYY]

> Purpose: Use this package when onboarding or renewing any vendor that provides an Automated Employment Decision Tool (AEDT) used for NYC hiring or promotions.[web:42][web:86]

---

## Part A – Vendor Due Diligence Questionnaire (LL 144 Focus)

Send this section as a questionnaire to each AEDT vendor. Clarify that responses are contractually incorporated and must be kept accurate.[web:45][web:92]

### A1. Tool Overview & Use Case

1. Identify the AEDT(s) covered in this response.  
   - Product name(s):  
   - Version(s) / model(s):  
   - Modules in scope (e.g., resume screening, video interview scoring, coding tests).

2. Describe the primary **purpose** of the tool in the hiring/promotions process.  
   - What decision(s) does the tool substantially assist or replace (e.g., screening, ranking, interview recommendation)?[web:42][web:116]

3. List the **typical clients and use cases** (e.g., volume hiring, tech roles, campus recruiting), including any configurations specific to NYC or U.S. clients.

---

### A2. Data Inputs, Outputs, and Logic

4. List all **data sources** the AEDT uses for our implementation (check all that apply and describe):  
   - Resume / CV text  
   - Application form data  
   - Assessment/test results (describe)  
   - Video or audio recordings (describe)  
   - Internal HRIS or ATS fields (describe)  
   - Third‑party data (describe).[web:93][web:92]

5. Describe the **outputs** used for decision‑making.  
   - Scores, rankings, pass/fail flags, recommendation labels, etc.  
   - Explain how these outputs are presented to recruiters/hiring managers.[web:116]

6. Provide a **high‑level description** of the model or algorithmic approach (e.g., gradient boosting, neural network, rules‑based, heuristic scoring) and whether models are:  
   - Global for all clients,  
   - Client‑specific, or  
   - Per‑role/per‑industry models.

---

### A3. Bias Audit & LL 144 Support

7. Has the AEDT been the subject of an **independent bias audit** that meets NYC Local Law 144 requirements within the last 12 months?  
   - If yes, attach:  
     - Full bias audit report and public summary;  
     - Scope details (jobs, locations, time period, data used).[web:86][web:105]  
   - If not, describe what support you provide to customers to obtain an independent audit.[web:45]

8. Describe how your product supports **per‑client or per‑use‑case** bias audits.  
   - What data extracts can you provide (fields, formats, time windows)?  
   - How do you handle protected‑class data (actual vs inferred vs “unknown”)?[web:104][web:109]

9. Confirm whether your organization will:  
   - Provide data and documentation reasonably required by an independent auditor.  
   - Cooperate with annual re‑audits and changes in legal guidance.[web:86][web:92]

---

### A4. Logging, Explainability, and Transparency

10. What **logs** do you maintain for each evaluation?  
    - Input data snapshot per candidate  
    - Model version / configuration  
    - Scores or outputs  
    - Timestamp and user ID.[web:92]

11. Can you provide **case‑level explanations** or feature contributions for decisions (e.g., why a candidate received a particular score)?  
    - If yes, describe the format and limitations.  
    - If no, describe how you support overall transparency and documentation.[web:110]

12. How can clients verify that the **live configuration** used in production matches the configuration that was bias‑audited (e.g., configuration hashes, “audit profile” IDs)?[web:104]

---

### A5. Security, Privacy, and Data Retention (AEDT‑Relevant)

13. Describe your **data retention** defaults for AEDT input data, outputs, and logs, including options for client‑specific retention aligned with LL 144 audit history needs.[web:86][web:91]

14. Confirm compliance with relevant **data protection laws** for the jurisdictions where data is processed (e.g., GDPR, CCPA/CPRA) and attach your privacy and security summaries.[web:92][web:115]

15. Do you transfer AEDT data to **sub‑processors**?  
    - List sub‑processors and their roles.  
    - Confirm they are subject to equivalent contractual and security obligations.

---

### A6. Governance, Testing, and Change Management

16. How frequently do you perform **fairness/bias testing** on your AEDT outside of NYC LL 144 audits (e.g., prior to major releases, quarterly monitoring)?[web:104][web:109]

17. Describe your **model change management** process:  
    - How are significant changes identified?  
    - How are clients notified about changes that may affect prior LL 144 audits (e.g., new model version, re‑training)?[web:106][web:112]

18. Provide links or copies of your **responsible AI** or model risk management policies, if available.

---

## Part B – Contract / Addendum Clauses (LL 144 Support)

Use or adapt the sample clauses below with your legal team. These clauses do not transfer statutory obligations from employer to vendor but ensure the vendor supports compliance.[web:45][web:91]

### B1. Cooperation with Independent Bias Audits

> **Bias Audit Cooperation.** Vendor shall, at no additional cost other than reasonable out‑of‑pocket expenses, provide Customer and Customer’s designated independent auditor with timely access to information, documentation, and data extracts reasonably necessary to conduct any bias audits of the AEDT as required by New York City Local Law 144 or similar laws. Vendor shall not unreasonably withhold, condition, or delay such cooperation.[web:86][web:92]

> **Scope of Data.** Such cooperation shall include provision of historical AEDT output logs, configuration information, and other technical documentation sufficient to identify selection rates and impact ratios for the demographic groups specified by applicable law, to the extent such data is available to Vendor.[web:104][web:110]

---

### B2. Configuration Consistency and Change Notifications

> **Configuration Reliance.** Vendor shall document the AEDT configuration(s) used by Customer and, upon request, confirm whether a specific configuration matches the configuration that has been subject to an independent bias audit. Vendor will maintain configuration identifiers or equivalent documentation for this purpose.[web:104][web:105]

> **Material Changes.** Vendor shall provide at least [30] days’ prior written notice before implementing any material change to the AEDT that is reasonably likely to affect the validity of prior bias audits or materially alter model behavior (including but not limited to new model versions, significant re‑training, or changes to scoring scales). At Customer’s request, the parties will confer regarding any need for a new or updated bias audit.[web:106][web:116]

---

### B3. Logging, Access, and Retention

> **Logging.** Vendor shall maintain logs for AEDT evaluations performed for Customer, including timestamps, model or ruleset identifiers, and outputs for each evaluated candidate or employee, for at least [X] years or such other period mutually agreed in writing, to support legal compliance and audit obligations.[web:92]

> **Access to Logs.** Upon reasonable request, Vendor shall provide Customer with access to such logs in a commonly used electronic format, subject to appropriate data protection safeguards and technical limitations.[web:86][web:115]

> **Retention Alignment.** Vendor’s retention and deletion of AEDT‑related data shall be consistent with Customer’s written instructions, to the extent commercially reasonable and technically feasible.[web:91]

---

### B4. Representations and Warranties (AEDT Compliance Support)

> **Compliance Support.** Vendor represents that, as of the Effective Date, the AEDT is designed to be capable of supporting compliance with New York City Local Law 144, including by enabling independent bias audits based on AEDT outputs and providing the documentation described in this Agreement. Vendor does not assume Customer’s legal obligations under such laws, but will not knowingly design the AEDT in a manner that renders such compliance impossible.[web:45][web:92]

> **Accuracy of Disclosures.** Vendor represents that all material information provided in response to Customer’s AEDT due diligence questionnaire is accurate and complete in all material respects as of the date provided, and will promptly notify Customer of any material changes.[web:111][web:117]

---

### B5. Sub‑Processors and Third Parties

> **Sub‑Processor Transparency.** Vendor shall disclose to Customer all sub‑processors that process AEDT input or output data on Customer’s behalf and shall ensure such sub‑processors are bound by written obligations that are no less protective than those set out in this Agreement.[web:92][web:115]

> **Flow‑Down of Obligations.** Vendor shall ensure that sub‑processors reasonably cooperate with Customer’s bias audits and related legal obligations to the extent such sub‑processors hold relevant AEDT data or logs.[web:92]

---

### B6. Termination and Transition

> **Termination for Non‑Cooperation.** Customer may terminate the AEDT portion of the Agreement upon [30] days’ written notice if Vendor materially fails to comply with its obligations under this Section [LL144/AEDT] and does not cure such failure within such period, where such failure materially impairs Customer’s ability to comply with applicable AEDT laws.[web:91][web:112]

> **Transition Assistance.** Upon termination or expiration of the AEDT services, Vendor shall provide reasonable transition assistance, including export of AEDT‑related logs and configuration documentation, to support Customer’s ongoing audit, recordkeeping, and regulatory obligations.[web:45][web:92]

---

## Part C – Internal Tracking Table (Which Vendors Are LL 144‑Ready?)

Keep this table in your vendor file so you can see at a glance which AEDT vendors are ready for LL 144.

| Vendor / Tool        | Use Case (NYC)                | Independent Audit in Last 12 Months? | Provides Logs for Audit? | LL144 Clauses Executed? | Notes |
|----------------------|-------------------------------|--------------------------------------|--------------------------|-------------------------|-------|
| [Vendor A – Tool X]  | Resume screening for NYC SDRs | Yes / No                             | Yes / No                 | Yes / No                |       |
| [Vendor B – Tool Y]  | Video interview scoring       | Yes / No                             | Yes / No                 | Yes / No                |       |
| [Vendor C – Tool Z]  | Tech skills testing           | Yes / No                             | Yes / No                 | Yes / No                |       |

