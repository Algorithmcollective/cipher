**Company:** [Company Name]  
**Document Name:** AEDT Data Source & Use Disclosure (Candidate Request Template)  
**Effective Date:** [MM/DD/YYYY]  
**Owner:** [Name, Title]

---

### When to use this

Use this template to respond when a candidate for a New York City role asks:

- What data the Automated Employment Decision Tool (AEDT) uses, and  
- How that data is used in the hiring process.

---

### Subject line (email)

Information About Data Used in Our Automated Employment Decision Tool – [Job Title] at [Company Name]

---

### Email body

Dear [Candidate Name],

Thank you for your request for more information about the data used in the automated tools that assist with hiring for the **[Job Title]** position at **[Company Name]**.

Below is a summary of the **data sources** and **types of data** used by our Automated Employment Decision Tool (AEDT), as well as how that data is used in our hiring process for NYC‑based roles.

---

#### 1. Data sources used by the AEDT

For this position, the AEDT may use data from the following sources:

- **Your application materials** submitted directly to [Company Name], including:  
  - Resume / CV  
  - Online application form responses  
  - Cover letter (if provided)

- **Job‑related screening questions and assessments**, such as:  
  - Answers to application or knockout questions  
  - Skills or knowledge assessments related to the role  
  - Job‑related tests (e.g., typing or software skills)

- **Internal hiring system data**, such as:  
  - Application timestamps  
  - Role / location applied for  
  - Recruiter disposition codes (e.g., “interview scheduled,” “offer extended”)

[Optional – include if applicable]  
- **Video interview responses** recorded through our interview platform, limited to the content of your responses for this role.

We do **not** use personal social media accounts, personal web search history, or unrelated third‑party consumer data in the AEDT for this role.

---

#### 2. Types of data analyzed

Depending on the specific AEDT and role, the tool may analyze some or all of the following **job‑related information**:

- Years and type of work experience  
- Education, certifications, and training  
- Skills listed on your resume or application (e.g., software tools, languages)  
- Responses to job‑related screening questions  
- Scores from job‑related skills or knowledge tests  
- Role‑related availability (e.g., shift, location, work authorization)

For some assessments (such as typing tests or task‑based exercises), the tool may also use:

- Number of correct responses and errors  
- Time taken to complete the task

---

#### 3. How the AEDT uses this data

The AEDT uses the data described above to:

- Identify whether you meet the **minimum qualifications** for the role.  
- Compare your skills and experience against the **requirements** listed in the job posting.  
- Produce a **score, rating, or recommendation** that helps recruiters decide which candidates move forward for further review.

These outputs are used **together with human review**, not as the sole basis for hiring decisions. Recruiters and hiring managers review AEDT results and your application materials before making final decisions about interviews or offers.

---

If you have any additional questions about the data used or how it is processed in connection with this role, you can reply to this email or contact us at:

- **Email:** [Data/Privacy Contact Email]

Sincerely,  
**[Name]**  
**[Title]**  
**[Company Name]**  
**[Contact Email]**  
**[Phone Number]**
