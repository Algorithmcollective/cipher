# Bias Audit Summary for Automated Employment Decision Tools (AEDTs)

[Company Name] uses certain Automated Employment Decision Tools (AEDTs) to assist with hiring and promotion decisions for roles based in New York City. This summary is provided to comply with New York City Local Law 144 and related rules. It reflects the results of the most recent independent bias audit for each AEDT.

---

## 1. General Information

- **Company:** [Company Name]  
- **Audit Date:** [MM/DD/YYYY]  
- **Auditor:** [Independent Auditor Name / Firm]  
- **Audit Period Covered:** [e.g., 01/01/2025–06/30/2025]  
- **Scope:** AEDTs used for [hiring / promotion] decisions for NYC-based roles

---

## 2. AEDTs Covered in This Audit

| AEDT Name | Vendor | Use Case / Role Type | Decision Stage | In Use for NYC Roles? (Y/N) |
|----------|--------|----------------------|----------------|-----------------------------|
| [Tool 1 name] | [Vendor] | [e.g., Administrative & Professional roles] | [e.g., Initial resume screening] | Y |
| [Tool 2 name] | [Vendor] | [e.g., Customer Service & Management roles] | [e.g., Video assessment stage] | Y |

---

## 3. Bias Audit Methodology (High-Level)

The independent auditor evaluated whether the AEDT's use has a disproportionate impact on candidates in protected categories defined by Local Law 144. The analysis included:

- **Protected categories analyzed:**  
  - Sex (e.g., male, female, other/not specified)  
  - Race/ethnicity (as reported by candidates, where available)

- **Metrics assessed:**  
  - Selection (or advancement) rates by group  
  - Impact ratios comparing each group's selection rate to the most-favored group

- **Data sources:**  
  - Historical applicant and hiring data from [Company Name] systems for the period listed above

---

## 4. Summary of Results

For each AEDT, the auditor calculated selection rates and impact ratios for the protected categories.

- **Overall finding:**  
  - [Example: "For the AEDTs covered in this audit, no group's impact ratio fell below 0.80 when compared to the highest-selected group, based on the data analyzed."]  
  - or  
  - [Example: "For one or more AEDTs, the auditor identified groups with impact ratios below 0.80 when compared to the highest-selected group. The company is reviewing these findings and taking appropriate mitigation steps."]

Where potential disparities were identified, [Company Name] is working with the auditor and the AEDT vendor to evaluate and, where appropriate, mitigate those disparities.

---

## 5. AEDT Usage and Candidate Rights

- AEDTs are used **along with human review**, not as the sole basis for hiring or promotion decisions.  
- Candidates applying for NYC-based roles are notified in advance when an AEDT will be used in the hiring process and may request an alternative, non-automated process.  
- Candidates may request additional information about:  
  - The type of data collected and analyzed by the AEDT, and  
  - How that data is used in the evaluation process.

Requests can be sent to:  
- **Email:** [Compliance / Privacy Contact Email]

---

## 6. Audit Frequency

The AEDTs covered by this summary are subject to an **independent bias audit at least once every year**, and this public summary will be updated after each new audit is completed.

- **Date of next scheduled audit:** [MM/DD/YYYY or "On or before MM/DD/YYYY"]