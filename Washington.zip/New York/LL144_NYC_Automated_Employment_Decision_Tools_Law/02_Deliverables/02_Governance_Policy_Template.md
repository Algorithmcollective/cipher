# Automated Employment Decision Tool (AEDT) Governance Policy  
_New York City Local Law 144_

**Company:** [Company Name]  
**Effective Date:** [MM/DD/YYYY]  
**Policy Owner:** [Name, Title – e.g., Director of Talent Acquisition / Compliance]  
**Last Reviewed:** [MM/DD/YYYY]

---

## 1. Purpose

This policy establishes how [Company Name] governs the use of Automated Employment Decision Tools (AEDTs) in hiring and promotion decisions, including compliance with New York City Local Law 144 (LL 144). It defines ownership, approval, review, and documentation requirements so that AEDTs are used in a controlled, transparent, and compliant way.

---

## 2. Scope

This policy applies to:

- All AEDTs used in **hiring or promotion decisions** for roles based in New York City.  
- All departments that select, configure, or use AEDTs in the hiring process (e.g., HR, Talent Acquisition, IT, business units).  
- All third‑party vendors providing AEDTs to [Company Name].

---

## 3. Roles and Responsibilities

**AEDT Governance Owner** – [Name / Role]  
- Owns this policy and the AEDT inventory.  
- Approves the addition, removal, or material change of any AEDT used for NYC roles.  
- Ensures bias audits are obtained and reviewed at least annually.  

**Talent Acquisition / HR**  
- Identifies when AEDTs are used in the hiring process.  
- Ensures candidates receive required LL 144 notices and opt‑out options.  
- Implements any mitigation steps agreed upon after bias audits.  

**Legal / Compliance**  
- Reviews AEDT contracts and vendor terms for LL 144 obligations.  
- Reviews bias audit reports and advises on legal risk and mitigation.  

**IT / Systems Owners**  
- Supports integration and configuration of AEDTs.  
- Ensures data used by AEDTs is securely managed and available for audits.

---

## 4. AEDT Inventory and Approval

- All AEDTs used in NYC hiring or promotion decisions must be documented in the **AEDT Inventory & Classification** file.  
- Before any new AEDT is put into production for NYC roles, the Governance Owner must:  
  - Confirm whether the tool qualifies as an AEDT and “substantially assists” decisions.  
  - Ensure a plan is in place for an independent bias audit before use or within the required timeframe.  
  - Confirm candidate notice and opt‑out procedures are configured.

No business unit may deploy or materially change an AEDT for NYC roles without approval from the Governance Owner and Legal/Compliance.

---

## 5. Bias Audits and Public Summaries

For each in-scope AEDT:

- An **independent bias audit** must be obtained at least **once every year**.  
- The Governance Owner is responsible for:  
  - Coordinating with the auditor and vendors to provide necessary data.  
  - Reviewing audit findings with Legal/Compliance and Talent Acquisition.  
  - Ensuring a **public bias-audit summary** page is updated on the company website after each audit.

If an audit identifies potential disparate impact (e.g., impact ratios below commonly used thresholds), the Governance Owner, Legal, and HR must document and implement appropriate mitigation steps.

---

## 6. Candidate Notices and Alternative Processes

For each NYC role where an AEDT is used:

- Candidates must receive **advance written notice** describing AEDT use, at least **10 business days** before the tool is applied.  
- The notice must:  
  - Describe the job qualifications and characteristics that the AEDT will evaluate.  
  - Inform candidates how to request an **alternative, non-automated process**.  

The Governance Owner and HR must ensure:

- A documented **opt‑out / alternative process** exists for each AEDT.  
- Requests are tracked and handled according to the separate Opt‑Out Policy.  

---

## 7. Vendor Due Diligence

Before engaging an AEDT vendor for NYC roles, Legal/Compliance and the Governance Owner must:

- Review the vendor’s LL 144 compliance support, including bias-audit capabilities.  
- Obtain and review technical documentation describing how the AEDT works and what data it uses.  
- Include appropriate **contract language** requiring cooperation with bias audits and provision of necessary data.

Vendor due-diligence records must be kept in the **Compliance Evidence File**.

---

## 8. Documentation and Evidence

The Governance Owner must maintain a centralized **AEDT Compliance Evidence File** containing, at minimum:

- Current AEDT Inventory & Classification document.  
- Latest independent bias audit reports and website summaries.  
- Candidate notice templates and proof of delivery (e.g., ATS logs).  
- Opt‑out / alternative process procedures and sample records.  
- Vendor due‑diligence questionnaires and relevant contract clauses.  
- This policy and any related procedures.

---

## 9. Review and Updates

- This policy will be reviewed at least **annually** or when:  
  - A new AEDT is added or an existing AEDT is materially changed.  
  - LL 144 or related regulations are updated.  
  - Significant findings from a bias audit require policy changes.

Updates must be approved by the AEDT Governance Owner and Legal/Compliance.
