**Company:** [Company Name]  
**Policy Name:** AEDT Opt‑Out & Alternative Process Policy  
**Effective Date:** [MM/DD/YYYY]  
**Policy Owner:** [Name, Title]  
**Last Reviewed:** [MM/DD/YYYY]

---

### 1. Purpose

This policy explains how [Company Name] handles candidate requests **not** to be evaluated by an Automated Employment Decision Tool (AEDT) and how we provide an **alternative, non‑automated process** for NYC roles, as required by New York City Local Law 144.

---

### 2. Scope

This policy applies to:

- All NYC‑based positions where an AEDT is used in hiring decisions.  
- All candidates who receive an LL 144 AEDT notice and request an alternative process.  
- HR, Talent Acquisition, and any staff involved in reviewing applications.

---

### 3. How candidates can opt out

Candidates may request an alternative, non‑automated process by contacting:

- **Email:** [aedt‑alternative@company.com]  
- **Phone:** [Opt‑Out Phone Number]

Each request must include:

- Candidate’s full name  
- Email address used to apply  
- Job title and/or requisition ID  

---

### 4. Internal workflow (step‑by‑step)

When an opt‑out request is received:

1. **Log the request**  
   - Record it in the **AEDT Opt‑Out Log** with:  
     - Date/time received  
     - Candidate name and role  
     - Channel (email/phone)  
     - Staff member handling it  
     - Current status (Open / In Progress / Completed)

2. **Acknowledge within [X] business days** (e.g., 2 business days)  
   - Send a confirmation email explaining:  
     - That the AEDT will not be used for this candidate, and  
     - What the alternative review process and timeline will be.

3. **Disable AEDT for that candidate**  
   - In the ATS or tool, remove the candidate from any automated screening, scoring, or ranking workflow.  
   - Add a note in the candidate record: “LL 144 AEDT opt‑out – manual process only.”

4. **Run the alternative process**  
   - Conduct **manual human review** of the candidate’s materials, using the same job‑related criteria the AEDT would have used (experience, skills, etc.).  
   - Optionally substitute an interview or manual assessment that does **not** rely on the AEDT.

5. **Document the decision**  
   - Record:  
     - Who reviewed the candidate (names/titles).  
     - What criteria were applied.  
     - Final outcome (advance / decline) and decision date.  
   - Keep this with the candidate’s record for audit purposes.

6. **Close the request in the Opt‑Out Log**  
   - Mark as Completed with date and reviewer initials.

---

### 5. Responsibilities

- **Opt‑Out Coordinator (HR/Talent Ops):**  
  - Monitors the opt‑out email inbox and phone line.  
  - Maintains the AEDT Opt‑Out Log.  
  - Ensures acknowledgements and manual reviews happen on time.

- **Recruiters / Hiring Managers:**  
  - Follow the manual review steps when notified of an opt‑out.  
  - Do not use AEDTs for those candidates.

- **Compliance / Legal:**  
  - Periodically reviews opt‑out records to confirm the process is followed.

---

### 6. Recordkeeping

The following must be retained in the **AEDT Compliance Evidence File**:

- This Opt‑Out & Alternative Process Policy and workflow.  
- The AEDT Opt‑Out Log (with entries limited or anonymized as appropriate).  
- Sample acknowledgement emails and manual review notes.

**Retention period:** [e.g., at least 3 years] from the date of the hiring decision, or longer if required by law.
