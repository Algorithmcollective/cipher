# NYC Local Law 144 – Annual Re‑Audit & Review Schedule

**Company:** [Company Name]  
**Owner:** [Compliance / TA Ops / Legal]  
**Cycle Covered:** [Year] (e.g., 2026)  

> Purpose: Make sure every AEDT in scope has a fresh independent bias audit within 12 months, a current public summary online, and aligned notices, policies, and vendor docs.[web:41][web:86]

---

## 1. Annual Timeline Overview

Use this as your standard yearly rhythm. Adjust months to your fiscal/calendar year.

- **January–February:**  
  - Confirm list of AEDTs in scope for NYC roles (inventory refresh).[web:50][web:116]  
  - Decide which tools will continue, be paused, or be retired.  
  - Lock in independent auditor(s) and agree on data cuts and timelines.[web:104][web:114]

- **March–May:**  
  - Pull data extracts and transmit to auditor(s).  
  - Respond to auditor questions and validate preliminary results.[web:104]  
  - Plan mitigations if early results show adverse impact for any group.

- **June:**  
  - Finalize independent bias audit reports for each AEDT.[web:86][web:105]  
  - Draft updated website bias‑audit summaries (per AEDT).  
  - Validate candidate notice language against latest guidance.[web:42][web:119]

- **July–August:**  
  - Publish updated bias audit summaries on careers website, clearly labeled with audit dates and distribution dates.[web:41][web:110]  
  - Refresh internal policies and recruiter training content.  
  - Capture dated screenshots / PDFs for the audit file.[web:41]

- **September–October:**  
  - Conduct an internal LL 144 compliance review (mini‑audit): inventory, notices, website, vendor status, and documentation.[web:50][web:92]  
  - Log issues, assign owners, and set remediation deadlines.

- **November–December:**  
  - Decide on tool changes (new AEDTs, decommissioning, major reconfigs) for next year.  
  - Align vendor contracts and DDQs to support the next audit cycle.[web:45][web:92]  
  - Update the LL 144 Evidence File checklist and close the year.

---

## 2. Tool‑By‑Tool Annual Audit Planner

Track each AEDT separately to avoid missing the 12‑month window.

| AEDT / Vendor & Tool | NYC Use Case (Role/Stage)         | Last Audit Completion Date | Latest Date to Re‑Audit (12 Months) | Auditor          | Status (Planned / In Progress / Complete) | Notes |
|----------------------|-----------------------------------|----------------------------|--------------------------------------|------------------|-------------------------------------------|-------|
| [Vendor A – Tool X]  | Resume screen, NYC SDR roles      | [MM/DD/YYYY]              | [MM/DD/YYYY]                         | [Auditor Name]   | [Status]                                  |       |
| [Vendor B – Tool Y]  | Video interview, NYC CSR roles    | [MM/DD/YYYY]              | [MM/DD/YYYY]                         | [Auditor Name]   | [Status]                                  |       |
| [Vendor C – Tool Z]  | Coding test, NYC engineers        | [MM/DD/YYYY]              | [MM/DD/YYYY]                         | [Auditor Name]   | [Status]                                  |       |[web:41][web:104]

---

## 3. Annual LL 144 Review Checklist

Complete this once per year and store it in your LL 144 Evidence File.

### 3.1 Inventory & Scope

- [ ] AEDT inventory reviewed and updated (all tools, use cases, NYC‑in‑scope flags).[web:50][web:116]  
- [ ] Any new tools added to inventory with LL 144 review before go‑live.  
- [ ] Any retired tools documented with end‑of‑use date and last audit date.

### 3.2 Bias Audits

- [ ] Each in‑scope AEDT has an independent bias audit **within the last 12 months** of current use.[web:41][web:86]  
- [ ] Full audit reports stored in LL 144 folder, organized by tool and year.[web:50]  
- [ ] Follow‑up actions documented where impact ratios show potential adverse impact (e.g., mitigations, configuration changes).[web:104][web:118]

### 3.3 Public Website & Notices

- [ ] Website bias audit summaries updated for each AEDT with:  
  - Audit date,  
  - Distribution date,  
  - Summary table of impact ratios and data scope.[web:41][web:110]  
- [ ] Dated screenshots/PDFs taken and stored.  
- [ ] Candidate notice templates (job postings, ATS emails, portal text) reviewed against latest DCWP FAQ and law‑firm guidance.[web:42][web:119]  
- [ ] Notices still clearly state: AEDT use, characteristics evaluated, data types/sources, data retention, and alternative process contact.[web:86][web:114]

### 3.4 Vendor & Data Management

- [ ] Vendor DDQs updated where tools or models have changed.[web:92][web:63]  
- [ ] LL 144 contract clauses executed or refreshed with all AEDT vendors.  
- [ ] Data retention and logging settings confirmed (enough history for audits, no premature deletion).[web:86][web:91]  
- [ ] Evidence of secure data transfers to auditors retained (SFTP logs, tickets).[web:104]

### 3.5 Training & Governance

- [ ] Recruiter and hiring manager training refreshed to reflect any changes in AEDT use or notices.[web:114][web:92]  
- [ ] Internal AEDT governance policy reviewed and updated if needed.  
- [ ] Complaints and candidate questions from the year reviewed and used as input to improvements.[web:41]

---

## 4. Internal Roles & RACI Snapshot

Clarify who owns what for the annual cycle.

| Activity                                | Compliance | Legal | TA Ops | IT / Data | Vendor Mgr |
|----------------------------------------|-----------|-------|--------|-----------|-----------|
| Maintain AEDT inventory                | R         | C     | A      | C         | C         |
| Engage independent bias auditor        | A         | R     | C      | C         | C         |
| Prepare and send data to auditor       | C         | C     | R      | R         | C         |
| Draft & publish website summaries      | C         | R     | A      | C         | C         |
| Refresh notices & candidate templates  | C         | R     | A      | C         | C         |
| Update vendor DDQs & contract clauses  | C         | A     | C      | C         | R         |
| Run annual LL 144 review checklist     | A         | C     | R      | C         | C         |

Legend: **R** = Responsible, **A** = Accountable, **C** = Consulted.[web:50][web:110]

---

## 5. Annual Sign‑Off

**LL 144 Annual Review Completed By:**  
- Name: ___________________________  
- Role: ___________________________  
- Date: ___________________________  

**Comments / Known Gaps for Next Cycle:**  
- _______________________________________________________  
- _______________________________________________________  
- _______________________________________________________  
