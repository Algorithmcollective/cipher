# Candidate Notification Template – Local Law 144 (AEDT Use)

**Format:** Email or ATS message  
**Recommended subject line:** Notice about automated tools in your application process

---

**Subject:** Notice of Automated Employment Decision Tool Use – [Job Title] at [Company Name]

Dear [Candidate Name],

Thank you for your interest in the **[Job Title]** position at **[Company Name]**.

As part of our hiring process for this role, we use an **Automated Employment Decision Tool (AEDT)** to help evaluate applications. This tool uses data and algorithms to assist our recruiters in reviewing candidates.

## What this tool does

For this position, the AEDT will be used to:

- **Evaluate:** [e.g., your resume and application information]  
- **Focus on:** [e.g., years of experience, relevant skills, education, responses to screening questions, assessment scores]

The AEDT's results will be used **along with human review** to help decide which candidates move forward in the hiring process.

## Your options (alternative process)

If you **do not want your application to be evaluated by this AEDT**, you may request an **alternative, non-automated process**.

To request an alternative process, please contact:

- **Email:** [Alternative Process Email Address]  
- **Phone:** [Phone Number]  

Please include your **full name**, **email address**, and the **job title** you applied for in your request.

We will confirm and explain the alternative process and timeline after we receive your request.

## Data and privacy

The tool uses information that you provide in your application and any related assessments, as well as limited job‑related data from our systems. If you would like more information about the data used or how it is processed, you can contact us at:

- **Email:** [Data/Privacy Contact Email]

---

If you have any questions about this notice or our hiring process, please let us know.

Sincerely,  
**[Name]**  
**[Title]**  
**[Company Name]**  
**[Contact Email]**  
**[Phone Number]**

---

**Compliance Notes (Internal - Do Not Send to Candidate):**

- This notice must be sent **at least 10 business days before the AEDT is used** to evaluate the candidate.
- Delivery method should be timestamped (e.g., via email or ATS notification with sent date/time).
- Keep a copy of the notice and confirmation of delivery in the compliance evidence file for this role.
- Ensure alternative process contacts are monitored and requests are responded to promptly.