# New York City Local Law 144 – Independent Bias Audit Report (Skeleton)

**Report Title:** Bias Audit for [AEDT Name] Used by [Employer]  
**Prepared For (Employer):** [Employer / Employment Agency Name]  
**Prepared By (Independent Auditor):** [Auditor Name, Firm]  
**Date of Report:** [MM/DD/YYYY]  
**Audit Period (Data Window):** [e.g., 01/01/2025 – 12/31/2025]  
**Jurisdiction:** New York City, NY – Local Law 144 of 2021 (AEDTs)[web:42][web:86]

> This skeleton mirrors the structure auditors are using under LL 144: scope, methodology, datasets, selection/impact metrics, and conclusions.[web:94][web:122]

---

## 1. Executive Summary

1.1 **Purpose of the Audit**  
- Brief description of why the audit was performed (LL 144 requirement, annual re‑audit, new AEDT configuration, etc.).[web:86][web:104]

1.2 **High-Level Conclusions**  
- Summary of whether disparate impact was observed for any sex, race/ethnicity, or intersectional group.  
- Any notable limitations (e.g., small sample sizes, high “unknown” demographic rates).[web:110][web:123]

1.3 **AEDT and Use Cases in Scope**  
- Tool/vendor name, module(s) audited.  
- Employer use cases: roles, locations (NYC), and stages where AEDT substantially assists or replaces employment decisions.[web:42][web:124]

---

## 2. Description of the AEDT and Employer Use

2.1 **AEDT Overview**  
- Functional description (e.g., resume screening model, interview scoring system, coding assessment scoring).[web:50][web:116]  
- Type of outputs: scores, rankings, pass/fail flags, recommendations.

2.2 **Employer Implementation**  
- How the AEDT is configured for this employer (global vs client-specific model, relevant settings).  
- Where in the process it is used (pre‑screen, shortlisting, interview selection, promotion decisions).[web:104]

2.3 **Decision(s) Substantially Assisted or Replaced**  
- Clear statement of which employment decisions the AEDT informs, in line with LL 144 definitions (screening, ranking, etc.).[web:42][web:104]

---

## 3. Data Used for the Audit

3.1 **Data Source and Extraction**  
- Systems used (ATS, assessment platform, etc.).  
- Time period covered and justification.[web:124][web:123]

3.2 **Population and Sampling**  
- Number of individuals assessed by the AEDT in the audit window.  
- Criteria for inclusion/exclusion (e.g., NYC roles only, specific job families).[web:110][web:123]

3.3 **Demographic Categories and Groups**  
- Sex categories included.  
- Race/ethnicity categories included.  
- Intersectional categories of sex x race/ethnicity, as required by LL 144.[web:123][web:109]  
- Number and proportion of individuals with **unknown** demographics, by category.[web:110][web:124]

3.4 **Handling of Small Groups and Test Data**  
- Any demographic groups excluded because they represent <2% of the data, with counts and scoring/selection rates still disclosed.[web:110][web:109]  
- Whether historical or test data was used, and why (e.g., no historical data yet for a new AEDT).[web:124]

---

## 4. Methodology

4.1 **Outcome Definitions**  
- What “selection” or “scoring” means for this AEDT (e.g., score ≥ threshold, moved to next stage, recommended for interview).[web:110][web:123]

4.2 **Metrics for Disparate Impact**  
- Selection rate calculations for each group.  
- Impact ratios for each group relative to the highest‑scoring or reference group, as required by LL 144 rules.[web:110][web:94]

4.3 **Statistical Techniques**  
- Any additional statistical tests used (e.g., confidence intervals, significance tests, bootstrapping).  
- Handling of sparse data and intersectional analysis.[web:94][web:125]

4.4 **Assumptions and Limitations**  
- Data quality issues, missing data handling, potential biases in the underlying applicant pool.  
- Any constraints that may affect interpretation of results.[web:109][web:88]

---

## 5. Results – Tables and Findings

5.1 **Summary Table – Overall Selection and Impact Ratios**

For each sex, race/ethnicity, and intersectional group, provide:

- N (number of individuals assessed)  
- Selection or scoring rate  
- Impact ratio vs reference group  

Example structure:

| Group                            | N Applicants | Selection Rate | Impact Ratio vs Reference | Notes (e.g., <2% group, excluded from primary impact analysis) |
|----------------------------------|-------------:|---------------:|--------------------------:|-----------------------------------------------------------------|
| Reference Group (e.g., Group A)  | [N]          | [Rate]         | 1.00                      | Reference group                                                 |
| Group B                          | [N]          | [Rate]         | [IR]                      |                                                                 |
| Group C                          | [N]          | [Rate]         | [IR]                      | Group <2%? Yes/No                                              |[web:94][web:123]

5.2 **Intersectional Analysis**

- Provide separate tables or an appendix showing impact ratios for intersectional categories (e.g., sex x race/ethnicity) as required by LL 144.[web:123][web:110]  
- Flag any intersectional groups with particularly high or low impact ratios.

5.3 **Findings by Category**

- Narrative summary of key findings: any groups with notably lower impact ratios, any patterns across roles or stages.  
- Note which findings may warrant further investigation by the employer (even if law does not require corrective action).[web:109][web:50]

---

## 6. Conclusions and Recommendations

6.1 **Conclusions with Respect to LL 144 Criteria**

- Statement that the audit constitutes an independent bias audit under LL 144, with scope and methods aligned to NYC rules.[web:42][web:124]  
- Summary of whether any groups exhibit substantially lower impact ratios, and where the employer should exercise caution (e.g., in conjunction with Title VII / NYC HRL obligations).[web:109][web:123]

6.2 **Recommendations to Employer (Non‑Binding)**

- Suggestions for monitoring, configuration changes, or additional testing to address observed disparities.  
- Any recommendations regarding data collection practices (e.g., encouraging voluntary self‑identification to reduce “unknown” rates).[web:94][web:118]

---

## 7. Information Required for Public Summary (Employer Use)

This section can be copied by the employer into the required *public* bias‑audit summary.[web:124][web:123]

- **AEDT Name and Vendor:** [Text]  
- **Employer / Agency:** [Text]  
- **Date Employer First Used AEDT:** [MM/DD/YYYY]  
- **Date of This Bias Audit:** [MM/DD/YYYY]  
- **Data Source(s):** [Systems and time windows used]  
- **Number of Candidates/Employees Assessed:** [Total N]  
- **Selection/Scoring Rates and Impact Ratios:**  
  - Reference to attached table or summary of key metrics.  
- **Number of Individuals with Unknown Sex and Race/Ethnicity:** [Counts by category].[web:123][web:124]

---

## 8. Auditor Independence and Qualifications

8.1 **Independence Statement**

- Confirmation that the auditor is independent from the employer and AEDT vendor, and has no conflicts of interest under LL 144 rules.[web:88][web:94]

8.2 **Auditor Qualifications**

- Brief description of auditor’s experience, credentials, and methodology frameworks (e.g., ForHumanity criteria, internal standards).[web:88][web:125]

8.3 **Signatures**

- Name, title, and signature of lead auditor.  
- Date of signature.

---

**End of Report**
