# NYC Local Law 144 – Compliance Evidence File Checklist

**Company:** [Company Name]  
**Owner:** [Compliance / Legal / HR Owner]  
**Last Updated:** [MM/DD/YYYY]

> Purpose: This checklist shows what evidence you keep on file to demonstrate compliance with NYC Local Law 144 (AEDTs) if DCWP, OSC, or a plaintiff’s attorney asks for documentation.

---

## 1. Governance & Scope

- [ ] **AEDT Inventory & Classification Register**  
      - Location: [e.g., GDrive > Compliance > LL144 > 01-Inventory]  
      - Description: List of all tools, their use cases, in-scope vs out-of-scope for LL 144.[web:50][web:86]

- [ ] **AEDT Governance Policy**  
      - Location: [e.g., GDrive > Compliance > LL144 > 02-Policies]  
      - Description: Approved policy describing roles, responsibilities, approvals, monitoring, and decommissioning for AEDTs.[web:86][web:91]

- [ ] **Change Log for AEDTs**  
      - Location: [e.g., GDrive > Compliance > LL144 > 01-Inventory]  
      - Description: Log of new tools added, tools retired, major configuration changes, and date of LL144 review.[web:50][web:90]

---

## 2. Bias Audits & Results

- [ ] **Independent Bias Audit Reports – Full Versions**  
      - Location: [e.g., GDrive > Compliance > LL144 > 03-Bias-Audits]  
      - Description: Full reports from the independent auditor for each AEDT used for NYC candidates/employees, showing disparate impact calculations by sex and race/ethnicity.[web:50][web:86]

- [ ] **Bias Audit Public Summaries (Website Copies)**  
      - Location: [e.g., GDrive > Compliance > LL144 > 04-Public-Site-Captures]  
      - Description: PDF/HTML copies or screenshots of what is posted on the public website (URL, text, tables, last updated date).[web:41][web:45]

- [ ] **Evidence of Publication Timing**  
      - Location: [e.g., GDrive > Compliance > LL144 > 04-Public-Site-Captures]  
      - Description: Dated screenshots or CMS logs showing the audit summary was posted and refreshed at least every 12 months.[web:41][web:86]

- [ ] **Auditor Engagement Documents**  
      - Location: [e.g., GDrive > Compliance > LL144 > 03-Bias-Audits > Engagements]  
      - Description: SOWs, engagement letters, and independence statements for each third‑party auditor.[web:50][web:59]

---

## 3. Candidate Notice & Disclosures

- [ ] **Standard Candidate Notice Language (10‑Day Notice)**  
      - Location: [e.g., GDrive > Compliance > LL144 > 05-Notices]  
      - Description: Final templates used in job postings, email confirmations, or portals to notify candidates that an AEDT will be used and what it evaluates.[web:41][web:86]

- [ ] **Evidence of Notice Delivery**  
      - Location: [e.g., GDrive > Compliance > LL144 > 05-Notices > Evidence]  
      - Description:  
        - Example job postings showing the notice text.  
        - Sample application confirmation emails including the notice.  
        - ATS configuration screenshots showing notice placement and logic.[web:41][web:91]

- [ ] **Data Source & Use Disclosure Template**  
      - Location: [e.g., GDrive > Compliance > LL144 > 06-Disclosures]  
      - Description: Standard response template explaining data sources, data types, and AEDT usage for candidate requests.[web:86][web:93]

- [ ] **Candidate Requests & Responses Log**  
      - Location: [e.g., GDrive > Compliance > LL144 > 06-Disclosures > Requests-Log]  
      - Description: Log or ticketing export of candidate requests for data source information or accommodations and your responses (date, channel, responder).[web:91]

---

## 4. Alternative Process / Opt‑Out

- [ ] **Alternative Process Policy**  
      - Location: [e.g., GDrive > Compliance > LL144 > 07-Alt-Process]  
      - Description: Policy describing how candidates can request an alternative selection process or accommodation instead of the AEDT.[web:86][web:93]

- [ ] **Operational Workflow / SOP**  
      - Location: [e.g., GDrive > Compliance > LL144 > 07-Alt-Process]  
      - Description: SOPs or playbooks for recruiters and coordinators on how to process opt‑out requests, timeframes, and documentation.[web:91]

- [ ] **Training Materials for Recruiters**  
      - Location: [e.g., GDrive > Compliance > LL144 > 08-Training]  
      - Description: PPTs, LMS modules, or one‑pager guides on AEDT usage, candidate notice, and alternative process handling.[web:50][web:92]

- [ ] **Sample Completed Opt‑Out Cases**  
      - Location: [e.g., GDrive > Compliance > LL144 > 07-Alt-Process > Evidence]  
      - Description: Redacted examples showing how opt‑out or accommodation requests were handled end‑to‑end.[web:91]

---

## 5. Data Management & Retention

- [ ] **AEDT Data Retention & Deletion Standard**  
      - Location: [e.g., GDrive > Compliance > LL144 > 09-Data]  
      - Description: Document describing how long you retain AEDT‑related data, including logs used for bias audits, and how deletion is handled.[web:86][web:91]

- [ ] **Data Extract Specifications for Bias Audits**  
      - Location: [e.g., GDrive > Compliance > LL144 > 03-Bias-Audits > Data-Specs]  
      - Description: Specs or data dictionaries given to auditors describing fields, time windows, and filters used for the audit.[web:50][web:59]

- [ ] **Evidence of Secure Data Transfer to Auditors**  
      - Location: [e.g., GDrive > Compliance > LL144 > 03-Bias-Audits > Data-Transfers]  
      - Description: Redacted file transfer logs or tickets showing secure delivery of datasets to the independent auditor.[web:50]

---

## 6. Vendor Management

- [ ] **Vendor Due Diligence Questionnaire – Completed**  
      - Location: [e.g., GDrive > Compliance > LL144 > 10-Vendors > DDQ]  
      - Description: Completed questionnaires from each AEDT vendor covering model purpose, inputs, outputs, controls, and LL144 support.[web:63][web:92]

- [ ] **Contractual LL144 Clauses**  
      - Location: [e.g., GDrive > Compliance > LL144 > 10-Vendors > Contracts]  
      - Description: Contract language on cooperation with bias audits, data access, logging, and notice obligations.[web:63][web:91]

- [ ] **Vendor‑Provided Bias Audit Materials (If Any)**  
      - Location: [e.g., GDrive > Compliance > LL144 > 10-Vendors > Vendor-Audits]  
      - Description: Vendor audit summaries, validation reports, or model documentation used as inputs to your independent audit.[web:50][web:63]

---

## 7. Annual Review & Monitoring

- [ ] **Annual LL144 Compliance Review Checklist**  
      - Location: [e.g., GDrive > Compliance > LL144 > 11-Annual-Review]  
      - Description: Completed yearly checklist confirming that all required audits, notices, website updates, and trainings were performed.[web:86][web:92]

- [ ] **Monitoring & Issue Log**  
      - Location: [e.g., GDrive > Compliance > LL144 > 11-Annual-Review > Monitoring]  
      - Description: Log of detected issues (e.g., audit findings, complaints, tool misconfiguration) and documented remediation steps.[web:90][web:91]

- [ ] **Regulatory & Guidance Tracker**  
      - Location: [e.g., GDrive > Compliance > LL144 > 12-Regulatory-Tracker]  
      - Description: Notes on updates from DCWP, NYC OSC, or courts, and how your program was adjusted.[web:42][web:41]

---

## 8. Quick Status Summary (for Internal Use)

Use this mini‑table during internal reviews.

| Area                          | Owner          | Last Reviewed | Status (Green/Amber/Red) | Notes |
|-------------------------------|----------------|---------------|--------------------------|-------|
| Inventory & Governance        | [Name]         | [Date]        | [ ]                      |       |
| Bias Audits & Publication     | [Name]         | [Date]        | [ ]                      |       |
| Candidate Notice & Disclosures| [Name]         | [Date]        | [ ]                      |       |
| Alternative Process           | [Name]         | [Date]        | [ ]                      |       |
| Data & Retention              | [Name]         | [Date]        | [ ]                      |       |
| Vendors                       | [Name]         | [Date]        | [ ]                      |       |
| Annual Review & Monitoring    | [Name]         | [Date]        | [ ]                      |       |
