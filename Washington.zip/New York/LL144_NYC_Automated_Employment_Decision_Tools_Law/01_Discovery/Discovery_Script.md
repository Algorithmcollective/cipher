# LL144 Discovery Call Script (Deliverable-Based)

Purpose: Gather all information required to complete NYC Local Law 144 documentation.

Instruction for caller:
- Ask questions exactly as written
- Write answers into worksheet/templates
- If unknown → mark **TBD**

---

## 🧾 Deliverable: Company Headers (Used Across All Documents)

Say:
“To start, I’ll capture the core company details used across the documentation.”

Ask:

- Legal company name  
- Hiring entity name (if different)  
- Compliance / Legal contact (name + title)  
- Talent acquisition lead  
- IT / systems owner  
- Candidate questions email  
- Candidate questions phone  

---

## 🧾 Deliverable: AEDT Inventory & Classification

Say:
“Now let’s identify any tools that help screen, score, rank, or recommend candidates.”

For each tool ask:

- Tool name  
- Vendor  
- What the tool does (one sentence)  
- Hiring stage where it is used  
- Roles used for NYC  
- Does it screen, rank, recommend, or filter?  
- Date first used  
- Any recent major changes  

---

## 🧾 Deliverable: Data Source & Use Disclosure

Say:
“I want to understand what information the tool looks at.”

Ask:

- Resume fields analyzed  
- Application form data used  
- Assessments or tests used  
- Video or audio data used  
- ATS or HRIS data used  
- Any third-party data used  

Then ask:

“In plain English, what characteristics is the tool evaluating?”

---

## 🧾 Deliverable: Candidate Notice

Say:
“I want to capture what candidates are told about the tool.”

Ask:

- When AEDT notice is sent  
- How notice is delivered (ATS, email, portal, job posting)  
- Job qualifications or characteristics described in the notice  
- Data/privacy contact email  

---

## 🧾 Deliverable: Opt-Out & Alternative Process Policy

Say:
“Now I need to understand how candidates can request a manual process.”

Ask:

- Opt-out email  
- Opt-out phone  
- Who monitors requests  
- Response timeframe  
- Steps taken to disable AEDT for that candidate  
- Describe the manual alternative review process  
- Is an opt-out log maintained?  

---

## 🧾 Deliverable: AEDT Governance Policy

Say:
“I’m going to capture ownership and oversight for these tools.”

Ask:

- AEDT governance owner  
- Who approves new tools  
- Who reviews bias audits  
- Who coordinates vendors  
- Who handles mitigation steps  
- How often tools are reviewed  

---

## 🧾 Deliverable: Vendor Due Diligence & Contract Addendum

Say:
“I need a few details about vendor capabilities.”

Ask:

- Product modules used  
- Model/version if known  
- Data inputs vendor requires  
- Outputs produced  
- Does vendor support bias audits  
- Can vendor provide data extracts  
- Does vendor provide logs  
- Does vendor notify before model changes  
- Will vendor cooperate with audits  
- Any sub-processors known  

---

## 🧾 Deliverable: Independent Bias Audit Report

Say:
“To support the required bias audit…”

Ask:

- Has an independent bias audit been completed  
- Auditor name  
- Audit date  
- Audit period / data window  
- Number of candidates evaluated (estimate ok)  
- Definition of “selection” used  
- Any disparities identified  
- Any limitations noted  

---

## 🧾 Deliverable: Bias Audit Public Summary

Ask:

- AEDT names included in summary  
- Roles covered  
- High-level findings  
- Mitigation steps taken  
- Next scheduled audit date  

---

## 🧾 Deliverable: Annual Re-Audit & Review Schedule

Ask:

- Current audit cycle timing  
- Planned auditor  
- Planned data extraction owner  
- Who publishes website summary  
- Who runs annual review checklist  
- Any upcoming tool changes  

---

## 🧾 Deliverable: Compliance Evidence File

Say:
“Finally, I need to understand where documentation is stored.”

Ask:

- Where AEDT documents are stored  
- Inventory file location  
- Bias audit reports stored  
- Website summary screenshots stored  
- Notice delivery evidence stored  
- Opt-out log stored  
- Vendor questionnaires stored  
- Audit datasets stored  
- Tool change log exists  

---

## ✅ Closing Script

Say:

“That’s everything needed to prepare your Local Law 144 documentation. Anything marked TBD we’ll follow up on with your vendor or internal teams.”