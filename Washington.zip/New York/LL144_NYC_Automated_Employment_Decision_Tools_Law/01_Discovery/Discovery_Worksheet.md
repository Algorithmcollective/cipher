# LL144 Discovery Worksheet (Answer Capture)

Instruction:
- Complete during discovery call
- If unknown → write **TBD**
- Repeat tool sections for each AEDT

---

## 🧾 Company Headers (All Documents)

Legal Company Name:  
Hiring Entity (if different):  
Compliance / Legal Contact (Name + Title):  
Talent Acquisition Lead:  
IT / Systems Owner:  
Candidate Questions Email:  
Candidate Questions Phone:  

---

## 🧾 AEDT Inventory & Classification

### Tool #1

Tool Name:  
Vendor:  
What the Tool Does (1 sentence):  
Hiring Stage Used:  
NYC Roles Using Tool:  
Does it Screen / Rank / Recommend / Filter?:  
Date First Used:  
Recent Major Changes:  

### Tool #2

Tool Name:  
Vendor:  
What the Tool Does (1 sentence):  
Hiring Stage Used:  
NYC Roles Using Tool:  
Does it Screen / Rank / Recommend / Filter?:  
Date First Used:  
Recent Major Changes:  

(Add more as needed)

---

## 🧾 Data Source & Use Disclosure

### Tool Name:

Resume Fields Analyzed:  
Application Form Data Used:  
Assessments / Tests Used:  
Video / Audio Data Used:  
ATS / HRIS Data Used:  
Third-Party Data Used:  

Characteristics Evaluated (Plain English):  

---

## 🧾 Candidate Notice

When Notice Is Sent:  
Delivery Method (ATS / Email / Portal / Posting):  
Job Qualifications or Characteristics Listed:  
Data / Privacy Contact Email:  

---

## 🧾 Opt-Out & Alternative Process Policy

Opt-Out Email:  
Opt-Out Phone:  
Who Monitors Requests:  
Response Timeframe:  
Steps to Disable AEDT for Candidate:  
Manual Alternative Review Description:  
Opt-Out Log Maintained? (Y/N):  

---

## 🧾 AEDT Governance Policy

AEDT Governance Owner:  
Who Approves New Tools:  
Who Reviews Bias Audits:  
Who Coordinates Vendors:  
Who Handles Mitigation Steps:  
Tool Review Frequency:  

---

## 🧾 Vendor Due Diligence & Contract

Tool Name:  
Product Modules Used:  
Model / Version (if known):  
Vendor Data Inputs Required:  
Outputs Produced:  
Vendor Supports Bias Audits? (Y/N):  
Vendor Provides Data Extracts? (Y/N):  
Vendor Provides Logs? (Y/N):  
Vendor Notifies Before Model Changes? (Y/N):  
Vendor Cooperates With Audits? (Y/N):  
Sub-Processors Known:  

---

## 🧾 Independent Bias Audit

Audit Completed? (Y/N):  
Auditor Name:  
Audit Date:  
Audit Period / Data Window:  
Estimated Candidates Evaluated:  
Definition of “Selection” Used:  
Disparities Identified:  
Limitations Noted:  

---

## 🧾 Bias Audit Public Summary

AEDT Names Included:  
Roles Covered:  
High-Level Findings:  
Mitigation Steps Taken:  
Next Scheduled Audit Date:  

---

## 🧾 Annual Re-Audit & Review Schedule

Current Audit Cycle Timing:  
Planned Auditor:  
Data Extraction Owner:  
Website Summary Owner:  
Annual Review Owner:  
Upcoming Tool Changes:  

---

## 🧾 Compliance Evidence File

Document Storage Location:  
Inventory File Location:  
Bias Audit Reports Stored Location:  
Website Summary Evidence Stored:  
Notice Delivery Evidence Stored:  
Opt-Out Log Stored Location:  
Vendor Questionnaires Stored:  
Audit Datasets Stored:  
Tool Change Log Exists? (Y/N):  

---

## ✅ TBD / Follow-Ups

Item:  
Owner:  
Notes:  

Item:  
Owner:  
Notes:  

Item:  
Owner:  
Notes:  