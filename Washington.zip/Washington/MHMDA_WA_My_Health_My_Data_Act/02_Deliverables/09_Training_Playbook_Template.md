# Washington My Health My Data Act — Training & Awareness Playbook (MASTER TEMPLATE)

**Document Title:** MHMD Training & Awareness Playbook for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This playbook establishes {{CLIENT_NAME}}'s training program to ensure all employees, contractors, and processors who handle consumer health data understand their obligations under MHMD. While the Act does not explicitly mandate training, a documented training program is critical evidence of "reasonable" compliance and good faith — especially given the private right of action and treble damages.

---

## 1. Training Program Overview

### 1.1 Objectives

- Ensure all personnel who collect, process, share, or access consumer health data understand MHMD requirements.  
- Reduce the risk of accidental violations that could trigger private lawsuits or AG enforcement.  
- Create a documented compliance culture that demonstrates good faith in the event of an audit, investigation, or litigation.  
- Establish clear escalation paths so personnel know who to contact when a question or incident arises.

### 1.2 Training Tiers

| Tier | Audience | Content Depth | Frequency | Duration |
|:----:|----------|:-------------:|:---------:|:--------:|
| Tier 1 — Awareness | All employees (company‑wide) | High‑level overview of MHMD, what consumer health data is, why it matters, basic dos/don'ts | At hire + annually | {{DURATION_T1}} (e.g., 30 min) |
| Tier 2 — Operational | Teams that handle consumer health data (product, engineering, data, customer support, marketing) | Detailed obligations: consent rules, consumer rights workflows, deletion procedures, sharing restrictions, geofence prohibition | At hire + annually + when role changes | {{DURATION_T2}} (e.g., 60 min) |
| Tier 3 — Specialist | Privacy/compliance team, legal, security | Deep‑dive: enforcement risk, private right of action, sale authorization management, incident response, AG interaction, policy drafting | At hire + semi‑annually | {{DURATION_T3}} (e.g., 90 min) |

---

## 2. Tier 1 — Company‑Wide Awareness Training

### 2.1 Learning Objectives

By the end of this module, all employees will be able to:

- Define "consumer health data" under MHMD and recognize that it is much broader than traditional medical records.  
- Explain why MHMD matters to {{CLIENT_NAME}} (private right of action, treble damages, AG enforcement).  
- Identify the basic consumer rights (access, delete, withdraw consent).  
- Know who to contact with questions or concerns ({{PRIVACY_CONTACT}}).  
- Recognize a potential consumer health data incident and know the escalation path.

### 2.2 Module Outline

| # | Topic | Key Points | Duration |
|:-:|-------|-----------|:--------:|
| 1 | What is MHMD? | Washington state law protecting consumer health data; effective March 31, 2024; applies to {{CLIENT_NAME}} as a regulated entity | {{MIN}} min |
| 2 | What is "consumer health data"? | Personal info linked to a consumer identifying past/present/future health status; includes conditions, medications, vital signs, biometrics, reproductive health, gender‑affirming care, precise location near health facilities, **and inferred/derived data** | {{MIN}} min |
| 3 | Who is a "consumer"? | WA residents + anyone whose health data is collected in WA; does not include employees acting in employment context | {{MIN}} min |
| 4 | Why does this matter? | Private right of action — any consumer can sue; treble damages up to $25,000; attorneys' fees; AG can seek $7,500 per violation; class action risk | {{MIN}} min |
| 5 | Basic dos and don'ts | Do: follow consent procedures, honor deletion requests, escalate questions. Don't: access health data without a business need, share data without approval, ignore a consumer request | {{MIN}} min |
| 6 | Who to contact | {{PRIVACY_CONTACT}} for questions; {{LEGAL_CONTACT}} for legal issues; escalation path for incidents | {{MIN}} min |
| 7 | Quiz / acknowledgment | Short quiz (pass/fail) + signed acknowledgment of completion | {{MIN}} min |

---

## 3. Tier 2 — Operational Training

### 3.1 Learning Objectives

By the end of this module, operational team members will be able to:

- Apply the MHMD consent framework: when collection consent, sharing consent, and sale authorization are required.  
- Process consumer rights requests correctly (access, delete, withdraw consent, appeal) within the 45‑day timeline.  
- Follow the deletion workflow including downstream notification to processors and third parties.  
- Recognize prohibited geofencing scenarios.  
- Handle consumer health data in accordance with the published privacy policy.

### 3.2 Module Outline

| # | Topic | Key Points | Duration |
|:-:|-------|-----------|:--------:|
| 1 | Consent deep‑dive | Three separate consent layers (collect, share, sell); opt‑in only; no dark patterns; cannot bundle with ToS; consent before collection | {{MIN}} min |
| 2 | Consumer rights workflow | How to receive, authenticate, and process access/deletion/withdrawal/appeal requests; 45‑day deadlines; extension rules; free up to 2x/year | {{MIN}} min |
| 3 | Deletion procedures | Full deletion from production + backups (6 months for archives); downstream notification to all affiliates, processors, third parties; confirmation tracking | {{MIN}} min |
| 4 | Privacy policy compliance | What's in {{CLIENT_NAME}}'s health data privacy policy; cannot collect/share beyond what's disclosed; must update policy before new data uses | {{MIN}} min |
| 5 | Sharing and sale rules | Sharing requires separate consent; sale requires signed authorization with 9 elements; 6‑year retention; 1‑year expiration | {{MIN}} min |
| 6 | Geofence prohibition | No geofencing within 2,000 ft of health care facilities for tracking, data collection, or health‑related notifications; applies to SDKs and ad partners too | {{MIN}} min |
| 7 | Data security responsibilities | Access only what you need; report suspicious access; follow RBAC; no unauthorized exports or copies | {{MIN}} min |
| 8 | Scenario exercises | Role‑specific scenarios (see Section 3.3) | {{MIN}} min |
| 9 | Quiz / acknowledgment | Scenario‑based quiz + signed acknowledgment | {{MIN}} min |

### 3.3 Role‑Specific Scenarios

| Scenario | Target Role(s) | Key Learning Point |
|----------|---------------|-------------------|
| A consumer emails asking "what health data do you have on me?" | Customer Support | This is a Right to Confirm & Access request — log it, authenticate, escalate to Privacy Ops, 45‑day clock starts on receipt |
| A consumer calls and says "delete everything you have about me" | Customer Support | Right to Delete — log the request, do not ask why, authenticate, escalate to Privacy Ops for full deletion workflow |
| Product team wants to add a new symptom tracker feature | Product / Engineering | Cannot collect new health data categories without updating the privacy policy and obtaining new consumer consent first |
| Marketing wants to use health data to create targeted ad segments | Marketing | Sharing consumer health data with ad partners requires separate sharing consent; check if current consent covers this use |
| An engineer needs to export health data for a bug investigation | Engineering | Access only the minimum data needed; do not copy to personal devices; log the access; delete the export when done |
| A user sets a "Workout Zone" geofence near a hospital | Product / Engineering | Check proximity to health care facilities; if within 2,000 ft, the zone should be blocked per geofence policy |
| {{CLIENT_NAME}} wants to sell anonymized health trends to a new research partner | Legal / Compliance | Need new sale authorization signed by each consumer; cannot use existing collection or sharing consent; new purchaser info required |

---

## 4. Tier 3 — Specialist Training

### 4.1 Learning Objectives

By the end of this module, privacy/compliance/legal specialists will be able to:

- Conduct a full MHMD scope assessment for new products or data practices.  
- Draft and review consent forms, sale authorizations, and processor contracts for MHMD compliance.  
- Manage AG inquiries and respond to private lawsuits or demand letters.  
- Lead incident response for consumer health data breaches.  
- Advise business teams on MHMD compliance for new initiatives.

### 4.2 Module Outline

| # | Topic | Key Points | Duration |
|:-:|-------|-----------|:--------:|
| 1 | MHMD legal deep‑dive | Full statutory walk‑through: RCW 19.373.010–.100; definitions, obligations, exemptions, enforcement | {{MIN}} min |
| 2 | Enforcement landscape | Private right of action mechanics; treble damages; attorneys' fees; class action trends; BIPA litigation parallels; AG enforcement patterns | {{MIN}} min |
| 3 | Exemptions analysis | HIPAA, GLBA, FCRA, FERPA, 42 CFR Part 2, security incident exception; how to document and defend exemption claims | {{MIN}} min |
| 4 | Consent and authorization drafting | How to draft compliant consent prompts and sale authorizations; common drafting errors; deceptive design pitfalls | {{MIN}} min |
| 5 | Processor contract review | Key clauses in MHMD processor addendum; processor‑becomes‑regulated‑entity risk; sub‑processor controls | {{MIN}} min |
| 6 | Incident response leadership | Leading the response for health data breaches; consumer notification; AG notification; litigation hold; PR coordination | {{MIN}} min |
| 7 | Emerging trends and amendments | Monitoring for MHMD amendments; other state health data laws (Nevada SB 370, Connecticut, etc.); federal developments | {{MIN}} min |
| 8 | Tabletop exercise | Simulated scenario: class action demand letter alleging MHMD violations from geofence SDK; walk through response steps | {{MIN}} min |

---

## 5. Training Delivery and Logistics

### 5.1 Delivery Methods

| Method | Used For | Platform |
|--------|---------|----------|
| Online self‑paced module | Tier 1 (all employees) | {{LMS_PLATFORM}} (e.g., KnowBe4, Lessonly, internal LMS) |
| Live virtual workshop | Tier 2 (operational teams) | {{WORKSHOP_PLATFORM}} (e.g., Zoom, Teams) |
| In‑person or live virtual deep‑dive | Tier 3 (specialists) | {{SPECIALIST_PLATFORM}} (e.g., in‑person workshop, Zoom with breakout rooms) |

### 5.2 Training Schedule

| Training | Audience | Initial Delivery | Recurring Schedule |
|----------|---------|:----------------:|:------------------:|
| Tier 1 — Awareness | All employees | {{INITIAL_DATE_T1}} | At hire + annually ({{ANNUAL_MONTH}}) |
| Tier 2 — Operational | Product, Engineering, Data, Support, Marketing | {{INITIAL_DATE_T2}} | At hire + annually + role change |
| Tier 3 — Specialist | Privacy, Legal, Security | {{INITIAL_DATE_T3}} | At hire + semi‑annually ({{SEMI_MONTHS}}) |

### 5.3 New Hire Onboarding

- All new hires complete Tier 1 within **{{ONBOARD_DAYS_T1}}** days of start date.  
- New hires in operational roles complete Tier 2 within **{{ONBOARD_DAYS_T2}}** days of start date.  
- New hires in privacy/legal/security roles complete Tier 3 within **{{ONBOARD_DAYS_T3}}** days of start date.

---

## 6. Assessment and Acknowledgment

### 6.1 Assessment Requirements

| Tier | Assessment Type | Passing Score | Remediation for Failure |
|:----:|----------------|:-------------:|------------------------|
| Tier 1 | Multiple‑choice quiz ({{QUIZ_COUNT_T1}} questions) | {{PASS_SCORE_T1}}% | Retake module + retake quiz within 7 days |
| Tier 2 | Scenario‑based quiz ({{QUIZ_COUNT_T2}} questions) | {{PASS_SCORE_T2}}% | Retake module + 1:1 review with {{PRIVACY_CONTACT}} |
| Tier 3 | Tabletop exercise participation + written reflection | Participation required | Follow‑up session with {{LEGAL_CONTACT}} |

### 6.2 Acknowledgment

All participants must sign (physically or electronically) an acknowledgment confirming:  
- They completed the training.  
- They understand their obligations under MHMD.  
- They know who to contact with questions ({{PRIVACY_CONTACT}}).  
- They understand that violations may result in disciplinary action.

---

## 7. Record‑Keeping

| Record | Retention Period |
|--------|:---------------:|
| Training completion records (name, date, tier, score) | {{RETENTION}} |
| Signed acknowledgments | {{RETENTION}} |
| Training materials (module content, slides, quizzes) | {{RETENTION}} |
| Remediation records | {{RETENTION}} |

---

## 8. Roles & Responsibilities

| Role | Responsibilities |
|------|-----------------|
| {{TRAINING_OWNER}} | Owns training program; develops content; schedules sessions; tracks completion |
| {{PRIVACY_CONTACT}} | Reviews content for accuracy; leads Tier 2 workshops; handles remediation |
| {{LEGAL_CONTACT}} | Reviews content for legal accuracy; leads Tier 3 deep‑dives; updates for legal changes |
| {{HR_CONTACT}} | Integrates training into onboarding; tracks completion in HR system; escalates non‑completion |
| People Managers | Ensure team members complete training by deadlines; support remediation |

---

## 9. Program Review

- This playbook is reviewed and updated at least **annually** or when:  
  - MHMD is amended.  
  - {{CLIENT_NAME}} launches new products or data practices involving consumer health data.  
  - A significant incident, enforcement action, or litigation occurs.  
  - Training assessment results indicate knowledge gaps.

---

**End of Template**
