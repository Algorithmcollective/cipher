# Washington My Health My Data Act — Consent & Authorization Framework (MASTER TEMPLATE)

**Document Title:** MHMD Consent & Authorization Framework for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Sections:** RCW 19.373.030 (Collection & Sharing Consent) and RCW 19.373.070 (Valid Authorization to Sell)  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This framework provides {{CLIENT_NAME}} with three separate consent/authorization instruments required under MHMD:  
> - **Part A:** Consent to Collect consumer health data  
> - **Part B:** Consent to Share consumer health data (must be separate and distinct from collection consent)  
> - **Part C:** Valid Authorization to Sell consumer health data (must be a standalone signed document with all 9 statutory elements)  
>  
> Each part must be presented **independently** — they cannot be bundled together or buried in general terms of use.

---

## MHMD Consent Rules — Quick Reference

Before using the templates below, review these MHMD‑specific consent rules:

| Rule | Statutory Basis | What It Means |
|------|----------------|---------------|
| Consent must be a "clear affirmative act" | RCW 19.373.010(6)(a) | Opt‑in only. Pre‑checked boxes, implied consent, or passive acceptance do not count. |
| Consent must be freely given, specific, informed, voluntary, and unambiguous | RCW 19.373.010(6)(a) | Each consent must name the specific data categories, purposes, and recipients. |
| Cannot be obtained via general terms of use | RCW 19.373.010(6)(b)(i) | Health data consent must be a standalone prompt — not buried in a broad ToS or privacy policy acceptance. |
| Hovering, muting, pausing, or closing content ≠ consent | RCW 19.373.010(6)(b)(ii) | No "consent by scrolling" or "consent by dismissing a banner." |
| Cannot use deceptive designs | RCW 19.373.010(6)(b)(iii) | No dark patterns, misleading button labels, or manipulative UI flows. |
| Collection consent and sharing consent must be separate | RCW 19.373.030(1)(a)–(b) | Two distinct consent moments — even if presented on the same screen, each must be a separate affirmative action. |
| Sale requires a signed valid authorization (not just consent) | RCW 19.373.070 | A formal document with 9 required elements, consumer signature, and 1‑year expiration. Separate from collection and sharing consent. |
| Consumer can withdraw consent at any time | RCW 19.373.040(1)(b) | Must provide a clear, easy mechanism for withdrawal. |
| Consent must be obtained **prior to** collection or sharing | RCW 19.373.030(1)(c) | No retroactive consent. Data cannot be collected or shared before consent is obtained. |

---

## Part A — Consent to Collect Consumer Health Data

> **Statutory basis:** RCW 19.373.030(1)(a) — A regulated entity may not collect any consumer health data except with consent from the consumer for such collection for a specified purpose, or to the extent necessary to provide a product or service the consumer has requested.

### Template: Collection Consent Prompt

---

**{{CLIENT_NAME}} — Consent to Collect Your Health Data**

We would like to collect the following categories of health data from you:

**Categories of health data to be collected:**  
- {{COLLECTION_CATEGORY_1}}  
- {{COLLECTION_CATEGORY_2}}  
- {{COLLECTION_CATEGORY_3}}  
- {{COLLECTION_CATEGORY_4}}  

**Purpose of collection (how the data will be used):**  
- {{COLLECTION_PURPOSE_1}}  
- {{COLLECTION_PURPOSE_2}}  
- {{COLLECTION_PURPOSE_3}}  

**How to withdraw consent:**  
You may withdraw your consent to collection at any time by {{WITHDRAWAL_METHOD}}.

☐ **I agree** — I consent to the collection of the health data categories listed above for the purposes described. I understand this consent is voluntary, I am not required to consent to receive goods or services, and I may withdraw consent at any time.

☐ **I do not agree** — I do not consent to the collection of my health data.

---

### Implementation Notes

- This prompt must appear **before** any consumer health data is collected.  
- The checkbox (or equivalent affirmative action) must be **unchecked by default**.  
- This consent must be **separate** from any sharing consent or sale authorization.  
- If {{CLIENT_NAME}} collects some health data that is **necessary to provide a requested product or service**, that specific data does not require consent — but document which data falls under this exception and why.  
- Store a timestamped record of each consumer's consent (date, time, IP, version of consent text, consumer identifier).

---

## Part B — Consent to Share Consumer Health Data

> **Statutory basis:** RCW 19.373.030(1)(b) — A regulated entity may not share any consumer health data except with consent from the consumer for such sharing that is **separate and distinct** from the consent obtained to collect consumer health data, or to the extent necessary to provide a requested product or service.

### Template: Sharing Consent Prompt

---

**{{CLIENT_NAME}} — Consent to Share Your Health Data**

We would like to share certain categories of your health data with the following entities:

**Categories of health data to be shared:**  
- {{SHARING_CATEGORY_1}}  
- {{SHARING_CATEGORY_2}}  
- {{SHARING_CATEGORY_3}}  

**Entities we will share your data with:**  
- {{SHARING_RECIPIENT_1}} — {{SHARING_RECIPIENT_1_PURPOSE}}  
- {{SHARING_RECIPIENT_2}} — {{SHARING_RECIPIENT_2_PURPOSE}}  

**Purpose of sharing (specific ways the data will be used):**  
- {{SHARING_PURPOSE_1}}  
- {{SHARING_PURPOSE_2}}  

**How to withdraw consent:**  
You may withdraw your consent to sharing at any time by {{WITHDRAWAL_METHOD}}.

☐ **I agree** — I consent to the sharing of the health data categories listed above with the entities and for the purposes described. I understand this consent is voluntary, I am not required to consent to receive goods or services, and I may withdraw consent at any time.

☐ **I do not agree** — I do not consent to the sharing of my health data.

---

### Implementation Notes

- This prompt must be **separate and distinct** from the collection consent in Part A.  
- It may appear on the same screen as Part A, but must require its own independent affirmative action (separate checkbox, separate button).  
- The consent must be obtained **prior to** any sharing.  
- If sharing is **necessary to provide a requested product or service** (e.g., sending data to a clinic the consumer selected), that specific sharing does not require consent — but document the exception.

---

## Part C — Valid Authorization to Sell Consumer Health Data

> **Statutory basis:** RCW 19.373.070 — It is unlawful to sell or offer to sell consumer health data without first obtaining valid authorization from the consumer. The authorization must be a standalone signed document with all 9 required elements.

### Template: Valid Authorization to Sell

---

**VALID AUTHORIZATION TO SELL CONSUMER HEALTH DATA**

This authorization is provided pursuant to the Washington My Health My Data Act, RCW 19.373.070. Please read carefully before signing.

**(a) Specific consumer health data to be sold:**  
{{SALE_DATA_DESCRIPTION}}

**(b) Seller — name and contact information:**  
Name: {{CLIENT_NAME}}  
Address: {{CLIENT_ADDRESS}}  
Email: {{CLIENT_EMAIL}}  
Phone: {{CLIENT_PHONE}}

**(c) Purchaser — name and contact information:**  
Name: {{PURCHASER_NAME}}  
Address: {{PURCHASER_ADDRESS}}  
Email: {{PURCHASER_EMAIL}}  
Phone: {{PURCHASER_PHONE}}

**(d) Purpose of the sale:**  
{{SALE_PURPOSE_DESCRIPTION}}  
How data will be gathered: {{HOW_DATA_GATHERED}}  
How data will be used by the purchaser: {{HOW_PURCHASER_WILL_USE}}

**(e) Non‑conditioning statement:**  
The provision of goods or services by {{CLIENT_NAME}} may not be conditioned on you signing this authorization. You are not required to sign this authorization to use {{CLIENT_NAME}}'s products or services.

**(f) Right to revoke:**  
You have the right to revoke this authorization at any time. To revoke, {{REVOCATION_METHOD}} (e.g., email {{CLIENT_EMAIL}} with the subject line "Revoke Sale Authorization," or submit a revocation at {{PORTAL_URL}}).

**(g) Redisclosure warning:**  
The consumer health data sold pursuant to this authorization may be subject to redisclosure by the purchaser and may no longer be protected by the Washington My Health My Data Act.

**(h) Expiration date:**  
This authorization expires on **{{EXPIRATION_DATE}}** (no more than 1 year from the date of signature below).

**(i) Consumer signature and date:**

Signature: ___________________________________  
Printed Name: ___________________________________  
Date: ___________________________________

---

### Implementation Notes

- This authorization must be a **standalone document** — it cannot be combined with other documents (compound authorizations are invalid per RCW 19.373.070(3)(d)).  
- All 9 elements (a) through (i) above are **required**. Missing any element makes the authorization invalid.  
- The authorization is invalid if:  
  - The expiration date has passed.  
  - Any required element is missing.  
  - The consumer has revoked it.  
  - It has been combined with other documents.  
  - Goods or services are conditioned on signing.  
- A **copy of the signed authorization must be provided to the consumer**.  
- Both the seller and purchaser must **retain a copy for 6 years** from the date of signature or the date when it was last in effect, whichever is later.  
- For digital signatures, use a method that satisfies Washington's Uniform Electronic Transactions Act (RCW 1.80) — e.g., DocuSign, Adobe Sign, or equivalent.

---

## Consent Record‑Keeping Requirements

For all three consent/authorization types, {{CLIENT_NAME}} must maintain records including:

| Record Element | Part A (Collect) | Part B (Share) | Part C (Sell) |
|---------------|:----------------:|:--------------:|:-------------:|
| Consumer identifier | ✓ | ✓ | ✓ |
| Timestamp of consent/signature | ✓ | ✓ | ✓ |
| Version of consent text shown | ✓ | ✓ | ✓ |
| Categories of data covered | ✓ | ✓ | ✓ |
| Purposes disclosed | ✓ | ✓ | ✓ |
| Recipients disclosed | — | ✓ | ✓ |
| Signed copy provided to consumer | — | — | ✓ |
| Seller + purchaser retain copy for 6 years | — | — | ✓ |
| Expiration date (max 1 year) | — | — | ✓ |
| Withdrawal/revocation record | ✓ | ✓ | ✓ |

---

**End of Template**
