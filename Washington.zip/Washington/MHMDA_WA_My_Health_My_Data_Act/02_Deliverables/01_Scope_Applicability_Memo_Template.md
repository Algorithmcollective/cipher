# Washington My Health My Data Act — Scope & Applicability Memo (MASTER TEMPLATE)

**Report Title:** Washington My Health My Data Act (MHMD) Scope & Applicability Memo for {{CLIENT_NAME}}  
**Prepared For (Client):** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date of Analysis:** {{REPORT_DATE}}  
**Jurisdiction(s):** Washington State  
**Applicable Law(s):** Washington My Health My Data Act (RCW Chapter 19.373)  

> **Purpose:** This memo documents whether {{CLIENT_NAME}} qualifies as a "regulated entity" (or "small business") under the Washington My Health My Data Act and identifies which consumer health data collection, sharing, and processing activities are in scope for compliance.

---

## 1. Executive Summary

### 1.1 Conclusion

- Summary statement on regulated entity status, for example:  
  - "{{CLIENT_NAME}} **is / is not** a regulated entity under the Washington My Health My Data Act as of {{REPORT_DATE}}."
- Brief description of the consumer health data activities determined to be in scope, if any.

### 1.2 Key Factors Considered

- Whether {{CLIENT_NAME}} conducts business in Washington or produces/provides products or services targeted to consumers in Washington.  
- Whether {{CLIENT_NAME}} alone or jointly determines the purpose and means of collecting, processing, sharing, or selling consumer health data.  
- Whether any data collected meets the broad MHMD definition of "consumer health data" (personal information linked or reasonably linkable to a consumer that identifies past, present, or future physical or mental health status, including inferred and derived data).  
- Whether {{CLIENT_NAME}} meets the "small business" thresholds (fewer than 100,000 consumers/year, or <50% revenue from health data and <25,000 consumers).

### 1.3 Recommended Next Steps

- High‑level next steps (e.g., draft consumer health data privacy policy, implement consent mechanisms, establish deletion request workflow, execute processor contracts, review geofence practices).

---

## 2. Client Profile

### 2.1 Business Overview

- Description of {{CLIENT_NAME}}'s primary business activities.  
- Key products and services, especially those involving health‑related, wellness, fitness, location, or biometric data.

### 2.2 Health Data Touchpoints

- List and brief description of products, features, or services that may collect, process, share, or sell consumer health data, including:  
  - {{TOUCHPOINT_1}} — {{SHORT_DESCRIPTION_1}}  
  - {{TOUCHPOINT_2}} — {{SHORT_DESCRIPTION_2}}  
- Primary user/customer base:  
  - Consumer / enterprise / mixed.  
- Data collection channels:  
  - Website, mobile app, wearable device, in‑store/kiosk, API, third‑party integrations, etc.  
- Types of health‑related data potentially collected:  
  - Direct (e.g., health conditions, medications, reproductive info, biometric scans).  
  - Inferred/derived (e.g., location‑based health inferences, purchase‑based wellness inferences, algorithmic health scoring).

---

## 3. Regulated Entity Test

> **Objective:** Assess whether {{CLIENT_NAME}} meets the statutory definition of a "regulated entity" under RCW 19.373.010(23).

### 3.1 Conducts Business in Washington or Targets Washington Consumers

- Description of whether {{CLIENT_NAME}}:  
  - Is incorporated, headquartered, or has offices in Washington.  
  - Sells goods or services to Washington residents.  
  - Operates websites, apps, or platforms accessible to Washington consumers.  
  - Actively markets or targets Washington consumers.  
- Note any geo‑blocking or restrictions for Washington users.

**Assessment:** {{NARRATIVE_ASSESSMENT_WA_NEXUS}}

### 3.2 Determines Purpose and Means of Collecting / Processing / Sharing / Selling Consumer Health Data

- Description of whether {{CLIENT_NAME}} alone or jointly with others decides:  
  - What consumer health data to collect.  
  - How consumer health data is processed.  
  - Whether and with whom consumer health data is shared or sold.  
- Indicate if {{CLIENT_NAME}} acts as a controller (regulated entity) vs. a processor acting only on behalf of another entity.

**Assessment:** {{NARRATIVE_ASSESSMENT_CONTROLLER}}

### 3.3 Consumer Health Data Collected — Scope and Categories

- Identify all data that may meet the MHMD definition of "consumer health data" (RCW 19.373.010(8)), including but not limited to:

| Category | Statutory Reference | Collected? (Y/N) | Source / Method | Notes |
|----------|-------------------|:-----------------:|-----------------|-------|
| Individual health conditions, treatment, diseases, diagnosis | 19.373.010(8)(b)(i) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Social, psychological, behavioral, medical interventions | 19.373.010(8)(b)(ii) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Health‑related surgeries or procedures | 19.373.010(8)(b)(iii) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Use or purchase of prescribed medication | 19.373.010(8)(b)(iv) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Bodily functions, vital signs, symptoms, measurements | 19.373.010(8)(b)(v) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Diagnoses, diagnostic testing, treatment, medication | 19.373.010(8)(b)(vi) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Gender‑affirming care information | 19.373.010(8)(b)(vii) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Reproductive or sexual health information | 19.373.010(8)(b)(viii) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Biometric data | 19.373.010(8)(b)(ix) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Genetic data | 19.373.010(8)(b)(x) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Precise location info indicating health service attempt | 19.373.010(8)(b)(xi) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Data identifying consumer seeking health care services | 19.373.010(8)(b)(xii) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |
| Inferred / derived health data from non‑health info (algorithms, ML, proxies) | 19.373.010(8)(b)(xiii) | {{Y_N}} | {{SOURCE}} | {{NOTES}} |

**Assessment:** {{NARRATIVE_ASSESSMENT_HEALTH_DATA}}

### 3.4 Small Business Threshold Check

| Threshold | Metric | Client Value | Meets Small Business? |
|-----------|--------|:------------:|:---------------------:|
| Fewer than 100,000 consumers whose health data is collected, processed, sold, or shared per calendar year | Consumer count | {{CONSUMER_COUNT}} | {{Y_N}} |
| <50% gross revenue from health data AND <25,000 consumers | Revenue % + consumer count | {{REVENUE_PCT}} / {{CONSUMER_COUNT_ALT}} | {{Y_N}} |

**Assessment:** {{NARRATIVE_ASSESSMENT_SMALL_BIZ}}

> **Note:** Small businesses have the same obligations as regulated entities but had a later compliance deadline (June 30, 2024 vs. March 31, 2024). All obligations now apply to both.

### 3.5 Overall Regulated Entity Determination

- Synthesis of Sections 3.1–3.4, leading to a clear conclusion:  
  - "Based on the available information, {{CLIENT_NAME}} **is / is not** a regulated entity (or small business) under the Washington My Health My Data Act as of {{REPORT_DATE}}."  
- Note any assumptions, data gaps, or uncertainties.

---

## 4. Exemptions Analysis

> **Objective:** Determine whether any of {{CLIENT_NAME}}'s data activities fall under the MHMD exemptions (RCW 19.373.100).

### 4.1 HIPAA / Covered Entity Exemption

- Is {{CLIENT_NAME}} or any relevant division a HIPAA covered entity or business associate?  
- Does any consumer health data qualify as protected health information (PHI) under HIPAA?  
- If yes, that specific data is exempt — but non‑PHI health data collected by the same entity is still in scope.

### 4.2 Other Federal Exemptions

- Gramm‑Leach‑Bliley Act (financial data)  
- Fair Credit Reporting Act  
- FERPA (education records)  
- 42 C.F.R. Part 2 (substance abuse treatment records)  
- Human subjects research under 45 C.F.R. Part 46

### 4.3 Security Incident / Fraud Exception

- Does {{CLIENT_NAME}} process any consumer health data solely to prevent, detect, or respond to security incidents, identity theft, fraud, or illegal activity?  
- If yes, document the specific processing and note it is exempt under RCW 19.373.100(3), but {{CLIENT_NAME}} bears the burden of demonstrating the exemption applies.

**Exemption Summary:**

| Data Set / Activity | Claimed Exemption | Statutory Basis | Exempt? (Y/N) | Notes |
|---------------------|-------------------|-----------------|:--------------:|-------|
| {{DATA_SET_1}} | {{EXEMPTION_1}} | {{STATUTE_1}} | {{Y_N}} | {{NOTES}} |
| {{DATA_SET_2}} | {{EXEMPTION_2}} | {{STATUTE_2}} | {{Y_N}} | {{NOTES}} |

---

## 5. Data Flow & Third‑Party Mapping

> **Objective:** Map how consumer health data flows into, through, and out of {{CLIENT_NAME}} to support privacy policy drafting and consent design.

### 5.1 Data Collection Sources

- Direct from consumers (app, website, forms, devices).  
- Third‑party sources (data brokers, partners, ad networks, SDKs).  
- Inferred/derived from non‑health data (algorithms, location tracking, purchase patterns).

### 5.2 Internal Processing

- Systems and databases where consumer health data is stored or processed.  
- Business units and employees with access.  
- Purposes for processing (service delivery, analytics, marketing, product improvement, etc.).

### 5.3 Sharing & Sale Map

| Recipient | Relationship (Affiliate / Processor / Third Party) | Data Categories Shared | Purpose | Consent Required? | Sale Authorization Required? |
|-----------|-----------------------------------------------------|------------------------|---------|:-----------------:|:---------------------------:|
| {{RECIPIENT_1}} | {{RELATIONSHIP_1}} | {{CATEGORIES_1}} | {{PURPOSE_1}} | {{Y_N}} | {{Y_N}} |
| {{RECIPIENT_2}} | {{RELATIONSHIP_2}} | {{CATEGORIES_2}} | {{PURPOSE_2}} | {{Y_N}} | {{Y_N}} |

> **Key MHMD note:** Sharing requires separate, distinct consent from collection consent (RCW 19.373.030(1)(b)). Selling requires a separate valid written authorization document with specific required elements (RCW 19.373.070).

---

## 6. Geofence Risk Assessment

> **Objective:** Assess whether {{CLIENT_NAME}} uses or could use geofencing technology near health care facilities, which is prohibited under RCW 19.373.080.

- Does {{CLIENT_NAME}} use geofencing technology (GPS, cell tower, Wi‑Fi, RFID, etc.) in any product, service, or marketing activity?  
- If yes, are any geofences located within 2,000 feet of a facility that provides in‑person health care services?  
- Is any geofence used to identify/track consumers seeking health care, collect consumer health data, or send health‑related notifications/ads?

**Assessment:** {{NARRATIVE_GEOFENCE}}

---

## 7. Enforcement Risk Summary

### 7.1 Attorney General Enforcement

- Violations are treated as violations of the Washington Consumer Protection Act (RCW 19.86).  
- The AG can seek civil penalties of up to **$7,500 per violation**.

### 7.2 Private Right of Action

- **Any** MHMD violation may trigger a private lawsuit — the Act does not limit which provisions are actionable.  
- Consumers may recover:  
  - Actual damages (which may be **trebled up to $25,000**).  
  - Costs and reasonable attorneys' fees if successful.  
  - Injunctive relief.  
- Class action risk is significant given the broad "consumer" definition (Washington residents + any individual whose data is collected in Washington).

### 7.3 Risk Rating

| Risk Factor | Rating (Low / Medium / High) | Notes |
|-------------|:----------------------------:|-------|
| Volume of consumer health data collected | {{RATING}} | {{NOTES}} |
| Third‑party sharing / sale activity | {{RATING}} | {{NOTES}} |
| Geofence usage near health facilities | {{RATING}} | {{NOTES}} |
| Current consent mechanism maturity | {{RATING}} | {{NOTES}} |
| Private right of action exposure | {{RATING}} | {{NOTES}} |
| Overall enforcement risk | {{RATING}} | {{NOTES}} |

---

## 8. Monitoring & Re‑Assessment Plan

### 8.1 Metrics to Monitor

- Consumer count (Washington residents + individuals whose data is collected in WA).  
- Volume and categories of consumer health data collected, shared, and sold.  
- New products, features, or data collection practices involving health‑related data.  
- Changes to third‑party/processor relationships.  
- Proximity of any geofencing activities to health care facilities.

### 8.2 Thresholds & Triggers

- Any new product or feature that collects data meeting the MHMD health data definition.  
- Change in business model that introduces health data sale activity.  
- Expansion of geofencing programs.  
- Receipt of a consumer rights request, AG inquiry, or private lawsuit.

### 8.3 Roles and Responsibilities

- **Privacy / Compliance Lead:** {{COMPLIANCE_LEAD}} — responsible for maintaining the MHMD compliance program and re‑running this scope memo.  
- **Product / Engineering Owner(s):** {{PRODUCT_OWNERS}} — responsible for flagging new or changed data collection practices.  
- **Legal Contact:** {{LEGAL_CONTACT}} — responsible for coordinating with outside counsel on enforcement risk and consumer requests.

### 8.4 Re‑Assessment Cadence

- Recommended cadence for rerunning this scope memo:  
  - **Annually** (standard), or  
  - **Quarterly** (if health data practices are changing rapidly or litigation risk is elevated).

---

## 9. Recommendations & Next Steps

### 9.1 If {{CLIENT_NAME}} Is a Regulated Entity

- Proceed to implement:  
  - **Deliverable 2:** Consumer Health Data Privacy Policy (RCW 19.373.020).  
  - **Deliverable 3:** Consent & Authorization Framework (collection consent, sharing consent, sale authorization).  
  - **Deliverable 4:** Consumer Rights Request & Deletion Workflow (confirm, access, delete, withdraw consent, appeal).  
  - **Deliverable 5:** Processor Contract Addendum (binding instructions, deletion obligations, technical assistance).  
  - **Deliverable 6:** Data Security Practices Checklist (access controls, administrative/technical/physical safeguards).  
  - **Deliverable 7:** Geofence Compliance Assessment & Policy.  
  - **Deliverable 8:** Valid Authorization to Sell Template (if selling consumer health data).  
  - **Deliverable 9:** Training & Awareness Playbook for staff handling consumer health data.  
  - **Deliverable 10:** Audit & Monitoring Checklist / Annual Review Plan.

### 9.2 If {{CLIENT_NAME}} Is Not a Regulated Entity

- Maintain this memo as formal documentation of the scope assessment.  
- Implement the monitoring and trigger plan defined in Section 8.  
- Re‑evaluate scope when:  
  - Any new product or data practice introduces consumer health data, or  
  - Business expansion brings Washington consumers into scope.

---

## 10. Applicable Law Reference

| Section | Title | Key Obligation |
|---------|-------|---------------|
| RCW 19.373.010 | Definitions | Defines "consumer health data," "regulated entity," "small business," "consent," "sell," "share," "processor," etc. |
| RCW 19.373.020 | Consumer health data privacy policy | Must maintain and publish a health data privacy policy on homepage; cannot collect/share beyond what's disclosed without new consent. |
| RCW 19.373.030 | Collection or sharing of consumer health data | Requires opt‑in consent for collection and separate consent for sharing; consent must be specific, informed, voluntary. |
| RCW 19.373.040 | Consumer rights and requests | Right to confirm, access, delete, withdraw consent; 45‑day response window; appeal process required. |
| RCW 19.373.050 | Data security practices | Restrict access; implement reasonable administrative, technical, and physical safeguards. |
| RCW 19.373.060 | Processors | Binding contract required; processor limited to contracted instructions; processor becomes regulated entity if it exceeds scope. |
| RCW 19.373.070 | Valid authorization to sell | Sale requires separate signed written authorization with specific elements; 6‑year retention; 1‑year expiration. |
| RCW 19.373.080 | Geofence restrictions | Unlawful to geofence within 2,000 ft of health care facility to track, collect data, or send ads. |
| RCW 19.373.090 | Consumer protection act enforcement | Violations = WA CPA violations; AG enforcement + private right of action. |
| RCW 19.373.100 | Exemptions | HIPAA PHI, GLBA, FCRA, FERPA, 42 CFR Part 2, security incident use, etc. |

---

**End of Template**
