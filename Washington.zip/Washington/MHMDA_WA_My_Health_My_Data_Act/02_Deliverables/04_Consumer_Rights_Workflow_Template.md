# Washington My Health My Data Act — Consumer Rights Request & Deletion Workflow (MASTER TEMPLATE)

**Document Title:** MHMD Consumer Rights Request & Deletion Workflow for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.040 — Consumer Rights and Requests  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This document establishes {{CLIENT_NAME}}'s internal workflow for receiving, authenticating, processing, and responding to consumer rights requests under MHMD. It covers the right to confirm/access, right to delete, right to withdraw consent, the appeal process, and downstream notification obligations.

---

## 1. Consumer Rights Overview

| Right | Statutory Basis | Description | Response Deadline |
|-------|----------------|-------------|:-----------------:|
| Right to Confirm & Access | RCW 19.373.040(1)(a) | Consumer can confirm whether health data is being collected, shared, or sold; access that data; and receive a list of all third parties/affiliates with contact info | 45 days (+ 45‑day extension if needed) |
| Right to Withdraw Consent | RCW 19.373.040(1)(b) | Consumer can withdraw consent to collection and sharing at any time | 45 days |
| Right to Delete | RCW 19.373.040(1)(c) | Consumer can request deletion of all consumer health data from all systems including archives/backups; entity must notify all downstream recipients | 45 days (backup deletion up to 6 months) |
| Right to Appeal | RCW 19.373.040(1)(h) | Consumer can appeal any refusal; entity must respond in writing within 45 days; if denied, must provide AG complaint mechanism | 45 days |

---

## 2. Request Intake Channels

> **Requirement:** {{CLIENT_NAME}} must establish secure and reliable methods for consumers to submit requests, taking into account how consumers normally interact with the business (RCW 19.373.040(1)(d)).

| Channel | Details | Responsible Team |
|---------|---------|:----------------:|
| Email | {{PRIVACY_EMAIL}} | {{INTAKE_TEAM}} |
| Online Portal | {{PORTAL_URL}} | {{INTAKE_TEAM}} |
| Phone | {{PHONE_NUMBER}} | {{INTAKE_TEAM}} |
| In‑App (if applicable) | {{IN_APP_PATH}} (e.g., Settings > Privacy > My Rights) | {{INTAKE_TEAM}} |

> **Note:** {{CLIENT_NAME}} may not require a consumer to create a new account to exercise rights, but may require use of an existing account (RCW 19.373.040(1)(d)).

---

## 3. Authentication Procedure

> **Requirement:** {{CLIENT_NAME}} must authenticate consumer identity using commercially reasonable efforts before processing a request (RCW 19.373.040(1)(e)).

### 3.1 Authentication Steps

| Step | Action | Owner |
|:----:|--------|:-----:|
| 1 | Receive request and log in tracking system with timestamp | {{INTAKE_TEAM}} |
| 2 | Send acknowledgment to consumer within {{ACK_DAYS}} business days confirming receipt | {{INTAKE_TEAM}} |
| 3 | Verify consumer identity using {{AUTH_METHOD_1}} (e.g., account login verification, email confirmation link, government ID match) | {{AUTH_TEAM}} |
| 4 | If identity cannot be verified, request additional information from consumer — document the request and consumer's response | {{AUTH_TEAM}} |
| 5 | If identity still cannot be verified using commercially reasonable efforts, {{CLIENT_NAME}} is not required to comply — notify consumer of the reason | {{AUTH_TEAM}} |

### 3.2 Authentication Methods by Channel

| Channel | Primary Authentication | Fallback Authentication |
|---------|----------------------|------------------------|
| Online Portal | {{PORTAL_AUTH}} (e.g., account login + email verification code) | {{PORTAL_FALLBACK}} |
| Email | {{EMAIL_AUTH}} (e.g., reply from registered email + last 4 of phone) | {{EMAIL_FALLBACK}} |
| Phone | {{PHONE_AUTH}} (e.g., account PIN + registered email confirmation) | {{PHONE_FALLBACK}} |
| In‑App | {{APP_AUTH}} (e.g., biometric/PIN unlock within authenticated session) | {{APP_FALLBACK}} |

---

## 4. Request Processing Workflows

### 4.1 Right to Confirm & Access

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Authenticate consumer (Section 3) | {{AUTH_TEAM}} | Promptly |
| 2 | Query all systems for consumer health data: {{SYSTEMS_LIST}} | {{DATA_TEAM}} | Day 1–15 |
| 3 | Compile data package including: all consumer health data held; list of all third parties and affiliates who received the data; active email or online contact mechanism for each third party/affiliate | {{DATA_TEAM}} | Day 15–30 |
| 4 | Review data package for completeness and accuracy | {{COMPLIANCE_LEAD}} | Day 30–40 |
| 5 | Deliver data package to consumer in a secure, accessible format | {{INTAKE_TEAM}} | By Day 45 |

> **Key MHMD detail:** The access response must include a list of **all third parties and affiliates** with whom data was shared or sold, plus an **active email address or other online mechanism** the consumer can use to contact each one (RCW 19.373.040(1)(a)).

### 4.2 Right to Withdraw Consent

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Authenticate consumer (Section 3) | {{AUTH_TEAM}} | Promptly |
| 2 | Identify which consents the consumer wishes to withdraw (collection, sharing, or both) | {{INTAKE_TEAM}} | Day 1–5 |
| 3 | Update consent records to reflect withdrawal; timestamp the change | {{DATA_TEAM}} | Day 5–15 |
| 4 | Cease collection and/or sharing of consumer health data as applicable | {{PRODUCT_TEAM}} / {{DATA_TEAM}} | Day 5–15 |
| 5 | Notify consumer confirming consent withdrawal and any impact on services | {{INTAKE_TEAM}} | By Day 45 |

> **Note:** Withdrawal of consent does not require deletion of previously collected data — that is a separate right. If the consumer also wants deletion, process under Section 4.3.

### 4.3 Right to Delete

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Authenticate consumer (Section 3) | {{AUTH_TEAM}} | Promptly |
| 2 | Identify all consumer health data across all systems: production databases, analytics platforms, data warehouses, ML training sets, logs | {{DATA_TEAM}} | Day 1–10 |
| 3 | Delete consumer health data from all production systems | {{DATA_TEAM}} | Day 10–25 |
| 4 | Initiate deletion from archived and backup systems | {{DATA_TEAM}} / {{IT_TEAM}} | Day 10–25 (completion up to 6 months per RCW 19.373.040(1)(c)(iii)) |
| 5 | Notify all downstream recipients — affiliates, processors, contractors, and third parties — of the deletion request | {{COMPLIANCE_LEAD}} | Day 10–20 |
| 6 | Confirm downstream recipients have honored the deletion request | {{COMPLIANCE_LEAD}} | Day 20–40 |
| 7 | Send confirmation to consumer that deletion is complete (note backup timeline if applicable) | {{INTAKE_TEAM}} | By Day 45 |

**Downstream Notification Template:**

> Subject: Consumer Health Data Deletion Request — {{CLIENT_NAME}} / MHMD  
>  
> To: {{RECIPIENT_NAME}}  
>  
> Pursuant to the Washington My Health My Data Act (RCW 19.373.040(1)(c)), we are notifying you that a consumer has exercised their right to delete their consumer health data. You have previously received this consumer's data from {{CLIENT_NAME}}.  
>  
> **Action required:** Please delete all consumer health data associated with the following identifier: {{CONSUMER_IDENTIFIER}} from your records, including archived and backup systems, and confirm completion to {{COMPLIANCE_EMAIL}} within {{DOWNSTREAM_DEADLINE}} days.  
>  
> Consumer reference number: {{REQUEST_ID}}  
> Date of request: {{REQUEST_DATE}}

### 4.4 Right to Appeal

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Consumer submits appeal after receiving a refusal or adverse decision | Consumer | Reasonable time after decision |
| 2 | Log appeal in tracking system with link to original request | {{INTAKE_TEAM}} | Day 1 |
| 3 | Review original request, refusal rationale, and any new information from consumer | {{COMPLIANCE_LEAD}} | Day 1–20 |
| 4 | Make appeal decision (uphold original decision or reverse) | {{COMPLIANCE_LEAD}} / {{LEGAL_CONTACT}} | Day 20–35 |
| 5 | Inform consumer **in writing** of the appeal decision with explanation of reasons | {{INTAKE_TEAM}} | By Day 45 |
| 6 | If appeal is denied, provide consumer with an online mechanism or other method to contact the Washington State Attorney General to submit a complaint | {{INTAKE_TEAM}} | Included in Day 45 response |

**Appeal Denial — Required AG Referral Language:**

> If you are not satisfied with the outcome of your appeal, you may submit a complaint to the Washington State Attorney General:  
> - Online: {{AG_COMPLAINT_URL}} (e.g., www.atg.wa.gov/file-complaint)  
> - Phone: {{AG_PHONE}}  
> - Mail: {{AG_ADDRESS}}

---

## 5. Timelines & Extensions

| Event | Deadline | Notes |
|-------|:--------:|-------|
| Acknowledge receipt of request | {{ACK_DAYS}} business days | Internal best practice (not statutory) |
| Respond to request | **45 days** from receipt | Statutory deadline |
| Extension (if reasonably necessary) | **+45 days** (90 days total) | Must notify consumer of extension + reason within initial 45 days |
| Backup/archive deletion | **Up to 6 months** from authenticating deletion request | Statutory allowance for archived/backup systems |
| Respond to appeal | **45 days** from receipt of appeal | Statutory deadline |

---

## 6. Fees & Frequency Limits

- Requests are **free of charge** up to **twice annually** per consumer.  
- If requests are **manifestly unfounded, excessive, or repetitive**, {{CLIENT_NAME}} may:  
  - Charge a **reasonable fee** to cover administrative costs, **or**  
  - **Decline to act** on the request.  
- {{CLIENT_NAME}} bears the burden of demonstrating that a request is manifestly unfounded, excessive, or repetitive.

---

## 7. Non‑Discrimination

{{CLIENT_NAME}} may not unlawfully discriminate against a consumer for exercising any rights under MHMD (RCW 19.373.030(1)(d)). This means:  
- No denial of goods or services.  
- No different pricing or service levels.  
- No retaliation.

---

## 8. Record‑Keeping

For every consumer rights request, {{CLIENT_NAME}} must maintain:

| Record | Retention Period |
|--------|:---------------:|
| Request received (date, channel, type, consumer identifier) | {{RETENTION_PERIOD}} |
| Authentication records | {{RETENTION_PERIOD}} |
| Actions taken (search, deletion, notifications sent) | {{RETENTION_PERIOD}} |
| Response sent to consumer (date, content) | {{RETENTION_PERIOD}} |
| Downstream notification confirmations | {{RETENTION_PERIOD}} |
| Appeal records (if any) | {{RETENTION_PERIOD}} |

---

## 9. Roles & Responsibilities

| Role | Name / Title | Responsibilities |
|------|-------------|-----------------|
| Intake & Acknowledgment | {{INTAKE_TEAM}} | Receive requests, log, acknowledge, deliver responses |
| Authentication | {{AUTH_TEAM}} | Verify consumer identity |
| Data Search & Deletion | {{DATA_TEAM}} | Locate and delete consumer health data across all systems |
| Downstream Notification | {{COMPLIANCE_LEAD}} | Notify affiliates, processors, third parties; confirm deletion |
| Appeal Review | {{COMPLIANCE_LEAD}} / {{LEGAL_CONTACT}} | Review and decide appeals |
| Escalation | {{LEGAL_CONTACT}} | Handle AG inquiries, litigation, complex requests |

---

## 10. Escalation Triggers

Immediately escalate to {{LEGAL_CONTACT}} if:

- A request references the Washington Attorney General or threatens legal action.  
- A request involves data that was sold (implicates RCW 19.373.070 authorization records).  
- A request involves reproductive health, gender‑affirming care, or other sensitive categories.  
- A request cannot be authenticated and the consumer is persistent or adversarial.  
- Multiple requests are received from the same consumer or a law firm representing multiple consumers (potential class action signal).  
- A downstream recipient refuses or fails to confirm deletion.

---

**End of Template**
