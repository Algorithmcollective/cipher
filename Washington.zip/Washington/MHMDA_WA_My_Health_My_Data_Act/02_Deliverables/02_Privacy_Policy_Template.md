# Washington My Health My Data Act — Consumer Health Data Privacy Policy (MASTER TEMPLATE)

**Document Title:** Consumer Health Data Privacy Policy for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.020 — Consumer Health Data Privacy Policy  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This template provides {{CLIENT_NAME}} with a compliant consumer health data privacy policy that meets all disclosure requirements under RCW 19.373.020. This policy must be published as a separate, standalone document with a prominent link on {{CLIENT_NAME}}'s homepage and on every page where consumer health data is collected.

---

## Instructions for Use

1. Fill in all {{PLACEHOLDER}} fields with client‑specific information.  
2. This policy must be **separate and distinct** from {{CLIENT_NAME}}'s general privacy policy — MHMD requires a dedicated consumer health data privacy policy.  
3. The policy link must be **prominently published** on the homepage (website landing page) and, for apps, on the platform/download page and within the app settings or "about" page.  
4. {{CLIENT_NAME}} may **not** collect, use, or share additional categories of consumer health data or use data for additional purposes not disclosed in this policy without first updating the policy **and** obtaining consumer affirmative consent.  
5. It is a violation of MHMD to contract with a processor to process consumer health data in a manner inconsistent with this policy.

---

## Consumer Health Data Privacy Policy

**Effective Date:** {{EFFECTIVE_DATE}}  
**Last Updated:** {{LAST_UPDATED_DATE}}  

{{CLIENT_NAME}} ("we," "us," "our") respects the privacy of your health data. This Consumer Health Data Privacy Policy explains how we collect, use, share, and protect consumer health data as defined under the Washington My Health My Data Act (RCW Chapter 19.373).

This policy applies to:  
- Washington residents, and  
- Any individual whose consumer health data is collected in Washington.

This policy is **separate from** our general Privacy Policy and applies specifically to consumer health data as defined by Washington law.

---

### 1. Categories of Consumer Health Data We Collect

> **Statutory requirement:** RCW 19.373.020(1)(a)(i) — Disclose the categories of consumer health data collected and the purpose for which the data is collected, including how the data will be used.

| Category of Consumer Health Data | Purpose of Collection | How the Data Will Be Used |
|---------------------------------|----------------------|--------------------------|
| {{CATEGORY_1}} | {{PURPOSE_1}} | {{USE_1}} |
| {{CATEGORY_2}} | {{PURPOSE_2}} | {{USE_2}} |
| {{CATEGORY_3}} | {{PURPOSE_3}} | {{USE_3}} |
| {{CATEGORY_4}} | {{PURPOSE_4}} | {{USE_4}} |
| {{CATEGORY_5}} | {{PURPOSE_5}} | {{USE_5}} |

> **Note:** We will not collect, use, or share categories of consumer health data not listed in this policy without first disclosing the additional categories and obtaining your affirmative consent.

---

### 2. Sources of Consumer Health Data

> **Statutory requirement:** RCW 19.373.020(1)(a)(ii) — Disclose the categories of sources from which the consumer health data is collected.

We collect consumer health data from the following sources:

- {{SOURCE_1}} — {{SOURCE_DESCRIPTION_1}}  
- {{SOURCE_2}} — {{SOURCE_DESCRIPTION_2}}  
- {{SOURCE_3}} — {{SOURCE_DESCRIPTION_3}}  
- {{SOURCE_4}} — {{SOURCE_DESCRIPTION_4}}  

---

### 3. Categories of Consumer Health Data We Share

> **Statutory requirement:** RCW 19.373.020(1)(a)(iii) — Disclose the categories of consumer health data that is shared.

We may share the following categories of consumer health data:

| Category of Data Shared | Purpose of Sharing |
|------------------------|-------------------|
| {{SHARED_CATEGORY_1}} | {{SHARED_PURPOSE_1}} |
| {{SHARED_CATEGORY_2}} | {{SHARED_PURPOSE_2}} |
| {{SHARED_CATEGORY_3}} | {{SHARED_PURPOSE_3}} |

> **Note:** We will not share consumer health data for purposes not disclosed in this policy without first disclosing the additional purposes and obtaining your affirmative consent. Sharing requires separate consent from the consent we obtain to collect your data.

---

### 4. Third Parties and Affiliates We Share Data With

> **Statutory requirement:** RCW 19.373.020(1)(a)(iv) — Provide a list of the categories of third parties and specific affiliates with whom the regulated entity shares consumer health data.

| Recipient Name or Category | Relationship (Affiliate / Processor / Third Party) | Categories of Data Shared | Purpose |
|----------------------------|-----------------------------------------------------|--------------------------|---------|
| {{RECIPIENT_1}} | {{RELATIONSHIP_1}} | {{DATA_SHARED_1}} | {{PURPOSE_1}} |
| {{RECIPIENT_2}} | {{RELATIONSHIP_2}} | {{DATA_SHARED_2}} | {{PURPOSE_2}} |
| {{RECIPIENT_3}} | {{RELATIONSHIP_3}} | {{DATA_SHARED_3}} | {{PURPOSE_3}} |

> **MHMD requirement:** Unlike most state privacy laws, MHMD requires disclosure of **specific affiliates** (by name), not just categories. All affiliates that receive consumer health data must be listed here.

---

### 5. Your Rights Under the Washington My Health My Data Act

> **Statutory requirement:** RCW 19.373.020(1)(a)(v) — Disclose how a consumer can exercise the rights provided in RCW 19.373.040.

Under the Washington My Health My Data Act, you have the following rights regarding your consumer health data:

**Right to Confirm and Access**  
You have the right to confirm whether we are collecting, sharing, or selling your consumer health data and to access that data, including a list of all third parties and affiliates with whom we have shared or sold your data and an active email address or other online mechanism to contact those third parties.

**Right to Withdraw Consent**  
You have the right to withdraw your consent to our collection and sharing of your consumer health data at any time.

**Right to Delete**  
You have the right to request deletion of your consumer health data from our records. Upon receiving your request, we will:  
- Delete your consumer health data from our records, including archived and backup systems (backup deletion may take up to 6 months).  
- Notify all affiliates, processors, contractors, and third parties with whom we shared your data, who must also honor the deletion request.

**How to Exercise Your Rights**  
You may submit a request to exercise any of these rights by:  
- {{REQUEST_METHOD_1}} (e.g., emailing {{PRIVACY_EMAIL}})  
- {{REQUEST_METHOD_2}} (e.g., submitting a request through {{PORTAL_URL}})  
- {{REQUEST_METHOD_3}} (e.g., calling {{PHONE_NUMBER}})  

We will respond to your request within **45 days**. If we need additional time, we will inform you of a one‑time 45‑day extension and the reason for it within the initial 45‑day period.

We will authenticate your identity using commercially reasonable means before processing your request. You will not be required to create a new account to exercise your rights, but you may be asked to use an existing account.

Requests are free of charge up to twice per year. If requests are manifestly unfounded, excessive, or repetitive, we may charge a reasonable fee or decline to act.

**Right to Appeal**  
If we decline your request, you may appeal by {{APPEAL_METHOD}}. We will respond to your appeal in writing within 45 days. If the appeal is denied, we will provide you with information on how to submit a complaint to the Washington State Attorney General.

**Non‑Discrimination**  
We will not discriminate against you for exercising your rights under MHMD.

---

### 6. Sale of Consumer Health Data

We {{DO_OR_DO_NOT}} sell consumer health data.

{{IF_SELL_SECTION_START}}  
If we sell your consumer health data, we will first obtain your valid, signed authorization as required by RCW 19.373.070. This authorization will be separate from any other consent and will include:  
- The specific data to be sold  
- The identity of the purchaser  
- The purpose of the sale  
- Your right to revoke the authorization at any time  
- An expiration date (no more than 1 year from signing)  

A copy of the signed authorization will be provided to you and retained for 6 years.  
{{IF_SELL_SECTION_END}}

---

### 7. Data Security

We maintain administrative, technical, and physical data security practices that satisfy reasonable standards of care within our industry to protect the confidentiality, integrity, and accessibility of your consumer health data. Access to consumer health data is restricted to employees, processors, and contractors for whom access is necessary.

---

### 8. Geofencing

We do not use geofencing technology within 2,000 feet of any facility that provides in‑person health care services to identify or track consumers, collect consumer health data, or send health‑related notifications or advertisements, as prohibited by RCW 19.373.080.

{{IF_GEOFENCE_EXCEPTION}}  
{{DESCRIBE_ANY_GEOFENCE_USAGE_AND_COMPLIANCE_MEASURES}}  
{{/IF_GEOFENCE_EXCEPTION}}

---

### 9. Changes to This Policy

We may update this Consumer Health Data Privacy Policy from time to time. If we make material changes, we will {{NOTIFICATION_METHOD}} (e.g., post an updated version on our website, notify you via email, provide in‑app notice). The "Last Updated" date at the top of this policy will be revised accordingly.

If we wish to collect, use, or share additional categories of consumer health data or use your data for additional purposes not described in this policy, we will update this policy **and** obtain your affirmative consent before doing so.

---

### 10. Contact Us

If you have questions about this Consumer Health Data Privacy Policy or wish to exercise your rights, please contact us at:

**{{CLIENT_NAME}}**  
Attn: {{PRIVACY_CONTACT_TITLE}}  
{{MAILING_ADDRESS}}  
Email: {{PRIVACY_EMAIL}}  
Phone: {{PHONE_NUMBER}}  
Online: {{PORTAL_URL}}  

---

**End of Template**
