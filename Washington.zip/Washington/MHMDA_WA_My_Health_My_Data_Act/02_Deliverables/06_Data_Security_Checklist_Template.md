# Washington My Health My Data Act — Data Security Practices Checklist (MASTER TEMPLATE)

**Document Title:** MHMD Data Security Practices Checklist for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.050 — Data Security Practices  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This checklist documents {{CLIENT_NAME}}'s compliance with the two core data security obligations under RCW 19.373.050:  
> **(1)** Restrict access to consumer health data to only those employees, processors, and contractors for whom access is necessary.  
> **(2)** Establish, implement, and maintain administrative, technical, and physical data security practices that satisfy a reasonable standard of care within {{CLIENT_NAME}}'s industry.

---

## Instructions for Use

1. Complete each section by filling in {{PLACEHOLDERS}} and marking each control as ✅ Implemented, 🔲 Planned, or ❌ Gap.  
2. For any ❌ Gap item, document a remediation plan with owner and target date in the Remediation Tracker (Section 8).  
3. Review and update this checklist at least **annually** or whenever there is a material change to systems, personnel, or data practices.  
4. Retain completed checklists for at least **6 years** as compliance evidence.

---

## 1. Access Restriction Controls

> **Statutory requirement:** RCW 19.373.050(1)(a) — Restrict access to consumer health data to only those employees, processors, and contractors for whom access is necessary to further the purposes for which the consumer provided consent or to provide a requested product or service.

### 1.1 Role‑Based Access Control (RBAC)

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Consumer health data systems have role‑based access controls implemented | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Access roles are defined and documented for each system containing consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Each role's access is limited to the minimum data necessary for its function | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Access roles are reviewed and updated at least {{REVIEW_FREQUENCY}} (e.g., quarterly, semi‑annually) | {{STATUS}} | {{OWNER}} | {{NOTES}} |

### 1.2 Personnel Access Inventory

| System / Database | Contains Consumer Health Data? | Authorized Roles | Number of Users with Access | Last Access Review Date |
|-------------------|:-----------------------------:|-------------------|:---------------------------:|:----------------------:|
| {{SYSTEM_1}} | Y | {{ROLES_1}} | {{COUNT_1}} | {{DATE_1}} |
| {{SYSTEM_2}} | Y | {{ROLES_2}} | {{COUNT_2}} | {{DATE_2}} |
| {{SYSTEM_3}} | Y | {{ROLES_3}} | {{COUNT_3}} | {{DATE_3}} |
| {{SYSTEM_4}} | Y | {{ROLES_4}} | {{COUNT_4}} | {{DATE_4}} |

### 1.3 Processor and Contractor Access

| Processor / Contractor | Consumer Health Data Accessed | Purpose | Access Method | Contract Addendum Executed? (Y/N) |
|------------------------|------------------------------|---------|---------------|:---------------------------------:|
| {{PROCESSOR_1}} | {{DATA_1}} | {{PURPOSE_1}} | {{METHOD_1}} | {{Y_N}} |
| {{PROCESSOR_2}} | {{DATA_2}} | {{PURPOSE_2}} | {{METHOD_2}} | {{Y_N}} |

### 1.4 Access Provisioning & De‑Provisioning

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| New employee/contractor access requires written approval from {{APPROVAL_AUTHORITY}} | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Access is provisioned based on documented role requirements, not individual requests | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Access is revoked within {{DEPROVISIONING_HOURS}} hours of employment/contract termination | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Access changes are logged with timestamp, approver, and reason | {{STATUS}} | {{OWNER}} | {{NOTES}} |

---

## 2. Administrative Security Practices

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Written information security policy exists and covers consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Security policy is reviewed and updated at least annually | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Designated privacy/security officer responsible for consumer health data protection | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Employee security awareness training conducted at hire and at least annually thereafter | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Training includes MHMD‑specific obligations (consumer health data handling, consent, deletion) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Background checks conducted for personnel with access to consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Confidentiality agreements signed by all personnel with access to consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Incident response plan exists and includes consumer health data breach scenarios | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Incident response plan is tested at least annually (tabletop exercise or simulation) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Vendor/processor risk assessments conducted before granting access to consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |

---

## 3. Technical Security Practices

### 3.1 Encryption

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Consumer health data encrypted at rest using {{ENCRYPTION_STANDARD}} (e.g., AES‑256) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Consumer health data encrypted in transit using {{TRANSIT_STANDARD}} (e.g., TLS 1.2+) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Encryption keys managed using {{KEY_MANAGEMENT}} (e.g., AWS KMS, Azure Key Vault, HSM) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Key rotation schedule: {{KEY_ROTATION_FREQUENCY}} | {{STATUS}} | {{OWNER}} | {{NOTES}} |

### 3.2 Network Security

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Firewalls configured to restrict access to consumer health data systems | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Network segmentation isolates consumer health data from non‑sensitive systems | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Intrusion detection / prevention system (IDS/IPS) deployed | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| VPN or zero‑trust network access required for remote access to health data systems | {{STATUS}} | {{OWNER}} | {{NOTES}} |

### 3.3 Application Security

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Secure software development lifecycle (SDLC) followed for applications handling consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Input validation and output encoding implemented to prevent injection attacks | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Application‑level authentication (e.g., MFA) required for access to consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Regular vulnerability scanning of applications and infrastructure (frequency: {{SCAN_FREQUENCY}}) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Penetration testing conducted at least annually by {{PEN_TEST_PROVIDER}} | {{STATUS}} | {{OWNER}} | {{NOTES}} |

### 3.4 Logging and Monitoring

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Access to consumer health data is logged (who, what, when) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Logs are retained for at least {{LOG_RETENTION}} (e.g., 12 months, 6 years) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Logs are reviewed for anomalies at least {{LOG_REVIEW_FREQUENCY}} | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Automated alerting for suspicious access patterns or bulk data exports | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Logs are tamper‑protected (immutable storage or write‑once) | {{STATUS}} | {{OWNER}} | {{NOTES}} |

---

## 4. Physical Security Practices

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Physical access to servers/data centers restricted to authorized personnel | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Visitor access logged and escorted in areas containing consumer health data systems | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Workstations with access to consumer health data are in secure areas or have screen locks | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Removable media (USB, external drives) policies restrict use with consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Secure disposal of hardware/media that contained consumer health data (shredding, degaussing, certified destruction) | {{STATUS}} | {{OWNER}} | {{NOTES}} |

---

## 5. Data Retention and Disposal

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Data retention policy exists and specifies retention periods for consumer health data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Consumer health data is not retained longer than necessary for the purpose disclosed to the consumer | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Automated deletion or archival processes enforce retention limits | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Sale authorization records retained for at least 6 years per RCW 19.373.070(5) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Deletion processes verified (spot checks, audit trails) | {{STATUS}} | {{OWNER}} | {{NOTES}} |

---

## 6. Incident Response — Consumer Health Data

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Incident response plan specifically addresses consumer health data breaches | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Incident classification criteria include MHMD‑regulated data | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Response team identified with MHMD‑specific roles (privacy lead, legal, comms) | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Notification procedures include: consumers affected, WA Attorney General (if required), processors/third parties | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Post‑incident review and remediation documented | {{STATUS}} | {{OWNER}} | {{NOTES}} |
| Tabletop exercise or simulation conducted at least annually | {{STATUS}} | {{OWNER}} | {{NOTES}} |

---

## 7. Industry Standard of Care Benchmark

> **Statutory requirement:** RCW 19.373.050(1)(b) — Security practices must "at a minimum, satisfy reasonable standard of care within the regulated entity's industry."

| Benchmark / Framework | Adopted? | Certification / Evidence | Notes |
|-----------------------|:--------:|--------------------------|-------|
| NIST Cybersecurity Framework (CSF) | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |
| SOC 2 Type II | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |
| ISO 27001 | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |
| HIPAA Security Rule (if applicable) | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |
| CIS Controls | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |
| OWASP Top 10 (application security) | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |
| Other: {{FRAMEWORK}} | {{Y_N}} | {{EVIDENCE}} | {{NOTES}} |

> **Guidance:** MHMD does not prescribe a specific framework, but adopting a recognized industry framework strengthens the "reasonable standard of care" defense. Document which framework(s) {{CLIENT_NAME}} follows and maintain current certifications or assessment reports.

---

## 8. Remediation Tracker

| Item # | Control Gap Identified | Risk Level | Remediation Action | Owner | Target Date | Status |
|:------:|----------------------|:----------:|-------------------|:-----:|:-----------:|:------:|
| 1 | {{GAP_1}} | {{RISK_1}} | {{ACTION_1}} | {{OWNER_1}} | {{DATE_1}} | {{STATUS_1}} |
| 2 | {{GAP_2}} | {{RISK_2}} | {{ACTION_2}} | {{OWNER_2}} | {{DATE_2}} | {{STATUS_2}} |
| 3 | {{GAP_3}} | {{RISK_3}} | {{ACTION_3}} | {{OWNER_3}} | {{DATE_3}} | {{STATUS_3}} |

---

## 9. Review and Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Completed By | {{PREPARER_NAME}} | _______________ | _______________ |
| Reviewed By | {{REVIEWER_NAME}} | _______________ | _______________ |
| Approved By | {{APPROVER_NAME}} | _______________ | _______________ |

**Next Review Date:** {{NEXT_REVIEW_DATE}}

---

**End of Template**
