# Washington My Health My Data Act — Compliance Audit Checklist & Evidence Register (MASTER TEMPLATE)

**Document Title:** MHMD Compliance Audit Checklist & Evidence Register for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  
**Audit Period:** {{AUDIT_START_DATE}} to {{AUDIT_END_DATE}}  

> **Purpose:** This is the master audit instrument that ties together all 9 preceding deliverables into a single compliance verification document. It maps every MHMD statutory requirement to a specific deliverable, evidence artifact, and compliance status — creating a defensible, auditor‑ready record. Use this checklist for internal audits, third‑party compliance assessments, or as the foundation for responding to an AG inquiry or litigation discovery request.

---

## Instructions for Use

1. Complete this checklist at least **annually** or upon any material change to data practices.  
2. For each requirement, mark status as: ✅ Compliant | ⚠️ Partial | ❌ Non‑Compliant | N/A.  
3. Link each requirement to the specific deliverable and evidence artifact that demonstrates compliance.  
4. For any ⚠️ or ❌ item, create a remediation entry in the Remediation Tracker (Section 9).  
5. Have the checklist reviewed and signed by {{COMPLIANCE_LEAD}} and {{LEGAL_CONTACT}}.  
6. Retain completed checklists for at least **6 years**.

---

## 1. Scope & Applicability (RCW 19.373.010, .005)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 1.1 | Determined whether {{CLIENT_NAME}} is a "regulated entity" (conducts business in WA or produces products/services targeted to WA consumers AND collects, processes, or shares consumer health data) | 19.373.010(24) | WA_01 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 1.2 | Identified all categories of "consumer health data" collected (13 statutory categories + inferred/derived) | 19.373.010(8) | WA_01 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 1.3 | Identified all "consumers" affected (WA residents + data collected in WA) | 19.373.010(7) | WA_01 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 1.4 | Assessed and documented all applicable exemptions (HIPAA, GLBA, FCRA, FERPA, etc.) | 19.373.005 | WA_01 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 1.5 | Mapped all data flows (collection, processing, sharing, sale) involving consumer health data | WA_01 | WA_01 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 2. Consumer Health Data Privacy Policy (RCW 19.373.020)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 2.1 | Published a **separate and distinct** consumer health data privacy policy (not part of general privacy policy) | 19.373.020(1) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.2 | Policy prominently linked on homepage | 19.373.020(1) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.3 | Policy prominently linked on app store/download page and within app settings (if app) | 19.373.020(1) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.4 | Discloses categories of health data collected + purpose + how used | 19.373.020(1)(a)(i) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.5 | Discloses categories of sources from which data is collected | 19.373.020(1)(a)(ii) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.6 | Discloses categories of health data shared | 19.373.020(1)(a)(iii) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.7 | Lists categories of third parties AND **specific affiliates by name** | 19.373.020(1)(a)(iv) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.8 | Discloses how consumers can exercise their rights under RCW 19.373.040 | 19.373.020(1)(a)(v) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.9 | No collection, use, or sharing beyond what is disclosed without updating policy + obtaining new consent | 19.373.020(2) | WA_02 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 2.10 | No processor contracts inconsistent with the published policy | 19.373.020(3) | WA_02, WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 3. Consent Framework (RCW 19.373.030)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 3.1 | Collection consent obtained **prior to** collecting consumer health data | 19.373.030(1)(a) | WA_03 Part A | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.2 | Collection consent is for a **specified purpose** | 19.373.030(1)(a) | WA_03 Part A | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.3 | Sharing consent obtained **prior to** sharing consumer health data | 19.373.030(1)(b) | WA_03 Part B | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.4 | Sharing consent is **separate and distinct** from collection consent | 19.373.030(1)(b) | WA_03 Part B | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.5 | Consent is a "clear affirmative act" — opt‑in, not opt‑out | 19.373.010(6)(a) | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.6 | Consent is freely given, specific, informed, voluntary, and unambiguous | 19.373.010(6)(a) | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.7 | Consent is NOT obtained via general terms of use | 19.373.010(6)(b)(i) | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.8 | No deceptive designs (dark patterns) used to obtain consent | 19.373.010(6)(b)(iii) | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.9 | Hovering, muting, pausing, or closing content does not constitute consent | 19.373.010(6)(b)(ii) | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.10 | No unlawful discrimination against consumers who decline consent | 19.373.030(1)(d) | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 3.11 | Consent records maintained (timestamp, version, consumer ID, categories, purposes) | Best practice | WA_03 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 4. Consumer Rights (RCW 19.373.040)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 4.1 | Right to confirm and access: consumer can confirm collection/sharing/sale and access data + full third‑party list with contact info | 19.373.040(1)(a) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.2 | Right to withdraw consent at any time | 19.373.040(1)(b) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.3 | Right to delete from all systems including backups (up to 6 months for archives) | 19.373.040(1)(c) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.4 | Downstream deletion notification sent to all affiliates, processors, contractors, third parties | 19.373.040(1)(c)(ii) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.5 | Requests methods account for how consumers normally interact with the business | 19.373.040(1)(d) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.6 | Consumer not required to create new account to exercise rights | 19.373.040(1)(d) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.7 | Identity authenticated using commercially reasonable efforts | 19.373.040(1)(e) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.8 | Response within 45 days (one‑time 45‑day extension with notice + reason) | 19.373.040(1)(f) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.9 | Free of charge up to 2x/year; reasonable fee only if manifestly unfounded/excessive/repetitive | 19.373.040(1)(g) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 4.10 | Appeal process established; written response within 45 days; AG referral if denied | 19.373.040(1)(h) | WA_04 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 5. Data Security (RCW 19.373.050)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 5.1 | Access to consumer health data restricted to employees/processors/contractors for whom access is necessary | 19.373.050(1)(a) | WA_06 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 5.2 | Administrative, technical, and physical security practices implemented at reasonable industry standard | 19.373.050(1)(b) | WA_06 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 5.3 | RBAC implemented and documented | Best practice | WA_06 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 5.4 | Encryption at rest and in transit | Best practice | WA_06 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 5.5 | Incident response plan covers consumer health data | Best practice | WA_06 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 5.6 | Industry framework adopted and documented (NIST CSF, SOC 2, ISO 27001, etc.) | Best practice | WA_06 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 6. Processor Contracts (RCW 19.373.060)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 6.1 | Binding contract with every processor that processes consumer health data | 19.373.060(1) | WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 6.2 | Contract sets forth clear processing instructions | 19.373.060(1)(a) | WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 6.3 | Contract limits processor's actions to what is instructed | 19.373.060(1)(b) | WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 6.4 | Processor understands that exceeding scope makes it a regulated entity | 19.373.060(1)(c) | WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 6.5 | Processor required to assist with consumer deletion requests | Best practice | WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 6.6 | Sub‑processor controls in place (written consent, flow‑down obligations) | Best practice | WA_05 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 7. Sale of Consumer Health Data (RCW 19.373.070)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 7.1 | Valid authorization obtained before any sale | 19.373.070(1) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.2 | Authorization contains all 9 required elements (a)–(i) | 19.373.070(2) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.3 | Authorization is a standalone document (not combined with other docs) | 19.373.070(3)(d) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.4 | Goods/services not conditioned on signing | 19.373.070(3)(e) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.5 | Expiration date is no more than 1 year from signature | 19.373.070(2)(h) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.6 | Copy provided to consumer | 19.373.070(4) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.7 | Seller retains signed authorization for 6 years | 19.373.070(5) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.8 | Purchaser retains signed authorization for 6 years | 19.373.070(5) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.9 | Revocation mechanism available and functional | 19.373.070(2)(f) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 7.10 | No sale under expired, revoked, or invalid authorization | 19.373.070(3) | WA_08 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 8. Geofence Prohibition (RCW 19.373.080)

| # | Requirement | Statutory Ref | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:------------:|:-----------:|-------------------|:------:|-------|
| 8.1 | No geofence within 2,000 ft of health care facilities for identifying/tracking consumers | 19.373.080(1) | WA_07 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 8.2 | No geofence within 2,000 ft of health care facilities for collecting consumer health data | 19.373.080(2) | WA_07 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 8.3 | No geofence within 2,000 ft of health care facilities for sending health‑related notifications/ads | 19.373.080(3) | WA_07 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 8.4 | Third‑party SDKs and ad partners audited for geofence compliance | Best practice | WA_07 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 8.5 | Pre‑deployment proximity review process established | Best practice | WA_07 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 9. Training & Awareness

| # | Requirement | Deliverable | Evidence Artifact | Status | Notes |
|:-:|-------------|:-----------:|-------------------|:------:|-------|
| 9.1 | Company‑wide MHMD awareness training completed | WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 9.2 | Operational training for data‑handling teams completed | WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 9.3 | Specialist training for privacy/legal/security completed | WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 9.4 | Training acknowledgments signed and retained | WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 9.5 | Training program reviewed within last 12 months | WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 10. Enforcement Readiness

| # | Readiness Item | Deliverable | Evidence Artifact | Status | Notes |
|:-:|---------------|:-----------:|-------------------|:------:|-------|
| 10.1 | AG inquiry response plan documented | WA_04, WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 10.2 | Litigation hold procedures for health data | WA_09 | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 10.3 | Insurance coverage reviewed for MHMD claims (cyber, E&O, D&O) | Best practice | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 10.4 | Outside counsel identified for MHMD litigation | Best practice | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |
| 10.5 | Document retention policy covers all MHMD records (6‑year minimum) | Best practice | {{EVIDENCE}} | {{STATUS}} | {{NOTES}} |

---

## 11. Remediation Tracker

| # | Checklist Item # | Gap Description | Risk Level | Remediation Action | Owner | Target Date | Status |
|:-:|:---------------:|----------------|:----------:|-------------------|:-----:|:-----------:|:------:|
| 1 | {{ITEM}} | {{GAP}} | {{RISK}} | {{ACTION}} | {{OWNER}} | {{DATE}} | {{STATUS}} |
| 2 | {{ITEM}} | {{GAP}} | {{RISK}} | {{ACTION}} | {{OWNER}} | {{DATE}} | {{STATUS}} |
| 3 | {{ITEM}} | {{GAP}} | {{RISK}} | {{ACTION}} | {{OWNER}} | {{DATE}} | {{STATUS}} |

---

## 12. Audit Sign‑Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Audit Conducted By | {{AUDITOR_NAME}}, {{AUDITOR_TITLE}} | _______________ | _______________ |
| Reviewed By | {{REVIEWER_NAME}}, {{REVIEWER_TITLE}} | _______________ | _______________ |
| Approved By | {{APPROVER_NAME}}, {{APPROVER_TITLE}} | _______________ | _______________ |

**Next Scheduled Audit:** {{NEXT_AUDIT_DATE}}

---

## Appendix — Deliverable Cross‑Reference

| Deliverable # | Title | Statutory Section(s) | File Name |
|:-------------:|-------|---------------------|-----------|
| WA_01 | Scope & Applicability Memo | 19.373.010, .005 | {{FILENAME_01}} |
| WA_02 | Consumer Health Data Privacy Policy | 19.373.020 | {{FILENAME_02}} |
| WA_03 | Consent & Authorization Framework | 19.373.030, .070 | {{FILENAME_03}} |
| WA_04 | Consumer Rights Request & Deletion Workflow | 19.373.040 | {{FILENAME_04}} |
| WA_05 | Processor Contract Addendum | 19.373.060 | {{FILENAME_05}} |
| WA_06 | Data Security Practices Checklist | 19.373.050 | {{FILENAME_06}} |
| WA_07 | Geofence Compliance Assessment & Policy | 19.373.080 | {{FILENAME_07}} |
| WA_08 | Valid Authorization to Sell | 19.373.070 | {{FILENAME_08}} |
| WA_09 | Training & Awareness Playbook | Best practice | {{FILENAME_09}} |
| WA_10 | Compliance Audit Checklist & Evidence Register | All sections | {{FILENAME_10}} |

---

**End of Template**
