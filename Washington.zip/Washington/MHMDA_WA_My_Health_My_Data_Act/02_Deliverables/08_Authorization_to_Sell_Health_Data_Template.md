# Washington My Health My Data Act — Valid Authorization to Sell Consumer Health Data (MASTER TEMPLATE)

**Document Title:** MHMD Valid Authorization to Sell Consumer Health Data for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.070 — Valid Authorization to Sell  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This template provides {{CLIENT_NAME}} with a compliant "valid authorization to sell" document that meets all 9 required elements under RCW 19.373.070. This authorization must be used **every time** {{CLIENT_NAME}} sells or offers to sell consumer health data. It is separate and distinct from collection consent (Deliverable 3, Part A) and sharing consent (Deliverable 3, Part B).

---

## When This Document Is Required

- Any time {{CLIENT_NAME}} exchanges consumer health data for **monetary or other valuable consideration** (RCW 19.373.010(26)).  
- "Sale" does **not** include: (1) transfers as part of a merger/acquisition/bankruptcy, or (2) transfers to a processor consistent with the disclosed purpose.  
- If {{CLIENT_NAME}} does not sell consumer health data, this deliverable should be retained as a "break glass" template in case the business model changes.

---

## Validity Rules — RCW 19.373.070(3)

An authorization is **invalid** if any of the following are true:

| Defect | Statutory Basis | What to Watch For |
|--------|----------------|-------------------|
| Expiration date has passed | 19.373.070(3)(a) | Track expiration dates; re‑authorize before expiration if sale is ongoing |
| Missing any of the 9 required elements | 19.373.070(3)(b) | Use this template exactly — do not remove or skip any section |
| Consumer has revoked the authorization | 19.373.070(3)(c) | Check revocation records before each data export |
| Combined with other documents (compound authorization) | 19.373.070(3)(d) | This must be a **standalone** document — never bundle with ToS, privacy policy, consent forms, or any other agreement |
| Goods/services conditioned on signing | 19.373.070(3)(e) | Consumer must be able to use all products/services without signing this |

---

## Retention Requirements

| Requirement | Details |
|-------------|---------|
| **Copy to consumer** | A copy of the signed authorization must be provided to the consumer (RCW 19.373.070(4)) |
| **Seller retention** | {{CLIENT_NAME}} must retain the signed authorization for **6 years** from the date of signature or the date when it was last in effect, whichever is later (RCW 19.373.070(5)) |
| **Purchaser retention** | The purchaser must also retain the signed authorization for **6 years** under the same terms (RCW 19.373.070(5)) |

---

## VALID AUTHORIZATION TO SELL CONSUMER HEALTH DATA

> This is a standalone legal document. Do not combine with any other agreement, consent form, or terms of service.

---

### AUTHORIZATION TO SELL CONSUMER HEALTH DATA  
Pursuant to the Washington My Health My Data Act (RCW 19.373.070)

Please read this authorization carefully before signing. This document authorizes the sale of your consumer health data as described below.

---

**(a) Specific Consumer Health Data to Be Sold**

The following categories of your consumer health data will be sold:

{{SALE_DATA_DESCRIPTION}}

_Examples of what to include: "De‑identified vital sign trend data (heart rate averages, sleep duration patterns)," "Wellness risk score distributions," "Medication category adherence rates," etc. Be specific — do not use vague language like "health data" or "all data."_

---

**(b) Seller — Name and Contact Information**

| | |
|--|--|
| **Name:** | {{CLIENT_NAME}} |
| **Address:** | {{CLIENT_ADDRESS}} |
| **Email:** | {{CLIENT_EMAIL}} |
| **Phone:** | {{CLIENT_PHONE}} |

---

**(c) Purchaser — Name and Contact Information**

| | |
|--|--|
| **Name:** | {{PURCHASER_NAME}} |
| **Address:** | {{PURCHASER_ADDRESS}} |
| **Email:** | {{PURCHASER_EMAIL}} |
| **Phone:** | {{PURCHASER_PHONE}} |

---

**(d) Purpose of the Sale**

**Why this data is being sold:**  
{{SALE_PURPOSE}}

**How the data will be gathered by the seller:**  
{{HOW_GATHERED}}

**How the data will be used by the purchaser:**  
{{HOW_USED_BY_PURCHASER}}

---

**(e) Non‑Conditioning Statement**

The provision of goods or services by {{CLIENT_NAME}} may **not** be conditioned on you signing this authorization. You are not required to sign this authorization to use {{CLIENT_NAME}}'s products or services. All features and services remain fully available to you regardless of whether you sign this authorization.

---

**(f) Right to Revoke**

You have the right to revoke this authorization **at any time**. To revoke this authorization:

- {{REVOCATION_METHOD_1}} (e.g., Email {{CLIENT_EMAIL}} with the subject line "Revoke Sale Authorization")  
- {{REVOCATION_METHOD_2}} (e.g., Submit a revocation at {{PORTAL_URL}})  
- {{REVOCATION_METHOD_3}} (e.g., Call {{CLIENT_PHONE}})  

Upon revocation:  
- Your data will be excluded from all future sales to the purchaser identified above.  
- Data already sold prior to your revocation may not be retrievable from the purchaser.  
- Revocation does not affect the lawfulness of any sale that occurred before the revocation.

---

**(g) Redisclosure Warning**

**IMPORTANT:** The consumer health data sold pursuant to this authorization **may be subject to redisclosure** by the purchaser identified above and **may no longer be protected** by the Washington My Health My Data Act once sold.

---

**(h) Expiration Date**

This authorization expires on: **{{EXPIRATION_DATE}}**

This date is no more than **one (1) year** from the date of the consumer's signature below. After this date, this authorization is no longer valid and no further sales may be made under it. If the sale relationship is ongoing, a new authorization must be obtained.

---

**(i) Consumer Signature and Date**

By signing below, I acknowledge that I have read and understood this authorization, including my right to revoke it at any time and the redisclosure warning above.

| | |
|--|--|
| **Signature:** | ___________________________________________ |
| **Printed Name:** | ___________________________________________ |
| **Date:** | ___________________________________________ |

---

## Post‑Execution Checklist (Internal Use)

After the consumer signs this authorization, {{CLIENT_NAME}} must:

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Provide a copy of the signed authorization to the consumer | {{INTAKE_TEAM}} | Immediately upon signing |
| 2 | Store the signed authorization in the compliance vault | {{COMPLIANCE_LEAD}} | Within 24 hours |
| 3 | Provide a copy of the signed authorization to the purchaser ({{PURCHASER_NAME}}) | {{COMPLIANCE_LEAD}} | Within 5 business days |
| 4 | Confirm purchaser acknowledges receipt and 6‑year retention obligation | {{COMPLIANCE_LEAD}} | Within 10 business days |
| 5 | Set calendar reminder for expiration date ({{EXPIRATION_DATE}}) | {{COMPLIANCE_LEAD}} | Within 24 hours |
| 6 | Set calendar reminder for renewal outreach (30 days before expiration) | {{COMPLIANCE_LEAD}} | Within 24 hours |
| 7 | Log in authorization tracking register: consumer ID, signing date, purchaser, expiration date, revocation status | {{COMPLIANCE_LEAD}} | Within 24 hours |

---

## Authorization Tracking Register (Template)

| Auth ID | Consumer ID | Consumer Name | Signing Date | Purchaser | Data Categories | Expiration Date | Revoked? | Revocation Date | Copy to Consumer? | Copy to Purchaser? | Vault Location |
|---------|------------|--------------|:------------:|-----------|----------------|:--------------:|:--------:|:--------------:|:-----------------:|:------------------:|---------------|
| {{ID_1}} | {{CID_1}} | {{NAME_1}} | {{DATE_1}} | {{PURCH_1}} | {{CATS_1}} | {{EXP_1}} | {{Y_N}} | {{REV_DATE_1}} | {{Y_N}} | {{Y_N}} | {{LOC_1}} |
| {{ID_2}} | {{CID_2}} | {{NAME_2}} | {{DATE_2}} | {{PURCH_2}} | {{CATS_2}} | {{EXP_2}} | {{Y_N}} | {{REV_DATE_2}} | {{Y_N}} | {{Y_N}} | {{LOC_2}} |

---

**End of Template**
