# Washington My Health My Data Act — Geofence Compliance Assessment & Policy (MASTER TEMPLATE)

**Document Title:** MHMD Geofence Compliance Assessment & Policy for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.080 — Geofence Restrictions  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This document assesses {{CLIENT_NAME}}'s use of geofencing and location‑based technology for compliance with RCW 19.373.080 and establishes a standing policy to prevent violations. Unlike other MHMD provisions that apply only to "regulated entities," the geofence prohibition applies to **any person** — meaning it covers {{CLIENT_NAME}}, its processors, contractors, advertising partners, and any other entity acting on its behalf.

---

## The Law — RCW 19.373.080 (Full Text)

> It is unlawful for **any person** to implement a geofence around an entity that provides in‑person health care services where such geofence is used to:  
> (1) Identify or track consumers seeking health care services;  
> (2) Collect consumer health data from consumers; or  
> (3) Send notifications, messages, or advertisements to consumers related to their consumer health data or health care services.

---

## Key Definitions

| Term | Definition (RCW 19.373.010) | Compliance Implication |
|------|---------------------------|----------------------|
| **Geofence** | Technology that uses GPS coordinates, cell tower connectivity, cellular data, RFID, Wi‑Fi data, and/or any other form of spatial or location detection to establish a virtual boundary around a specific physical location, or to locate a consumer within a virtual boundary. A "geofence" means a virtual boundary that is **2,000 feet or less** from the perimeter of the physical location. | Any virtual boundary ≤2,000 ft from a health care facility triggers this section. |
| **Health care services** | Any service provided to assess, measure, improve, or learn about a person's mental or physical health, including: health conditions, interventions, surgeries, medication, vital signs, diagnostics, reproductive health, gender‑affirming care. | Extremely broad — covers hospitals, clinics, pharmacies, therapy offices, reproductive health centers, dentists, chiropractors, mental health practices, etc. |
| **Any person** | Natural persons, corporations, trusts, unincorporated associations, and partnerships. Does not include government agencies or tribal nations. | No exemption for processors or contractors — everyone in the chain is liable. |

---

## Part 1 — Geofence Technology Inventory

> **Objective:** Identify all location‑based technologies used by {{CLIENT_NAME}} that could constitute a "geofence" under MHMD.

### 1.1 Location Technology Inventory

| # | Technology / Feature | Type (GPS / Wi‑Fi / Cell / RFID / Bluetooth / Other) | Product or Service | Purpose | Creates Virtual Boundary? (Y/N) | Radius / Range |
|:-:|---------------------|------------------------------------------------------|-------------------|---------|:-------------------------------:|:--------------:|
| 1 | {{TECH_1}} | {{TYPE_1}} | {{PRODUCT_1}} | {{PURPOSE_1}} | {{Y_N}} | {{RADIUS_1}} |
| 2 | {{TECH_2}} | {{TYPE_2}} | {{PRODUCT_2}} | {{PURPOSE_2}} | {{Y_N}} | {{RADIUS_2}} |
| 3 | {{TECH_3}} | {{TYPE_3}} | {{PRODUCT_3}} | {{PURPOSE_3}} | {{Y_N}} | {{RADIUS_3}} |
| 4 | {{TECH_4}} | {{TYPE_4}} | {{PRODUCT_4}} | {{PURPOSE_4}} | {{Y_N}} | {{RADIUS_4}} |

### 1.2 Third‑Party / Partner Location Technologies

| # | Partner / Vendor | Technology Used | Deployed in {{CLIENT_NAME}} Products? | Purpose | Creates Virtual Boundary? |
|:-:|-----------------|----------------|:-------------------------------------:|---------|:-------------------------:|
| 1 | {{PARTNER_1}} | {{PARTNER_TECH_1}} | {{Y_N}} | {{PURPOSE_1}} | {{Y_N}} |
| 2 | {{PARTNER_2}} | {{PARTNER_TECH_2}} | {{Y_N}} | {{PURPOSE_2}} | {{Y_N}} |

> **Note:** SDKs embedded in {{CLIENT_NAME}}'s app by advertising partners, analytics providers, or data brokers may implement geofencing without {{CLIENT_NAME}}'s direct knowledge. A full SDK audit is recommended.

---

## Part 2 — Health Care Facility Proximity Analysis

> **Objective:** For each geofence or location‑based feature identified in Part 1, assess whether it operates within 2,000 feet of a health care facility.

### 2.1 Proximity Assessment

| # | Technology / Feature | Geofence Location(s) | Within 2,000 ft of Health Care Facility? | Facility Type | Risk Level |
|:-:|---------------------|---------------------|:----------------------------------------:|---------------|:----------:|
| 1 | {{TECH_1}} | {{LOCATION_1}} | {{Y_N_UNKNOWN}} | {{FACILITY_TYPE_1}} | {{RISK}} |
| 2 | {{TECH_2}} | {{LOCATION_2}} | {{Y_N_UNKNOWN}} | {{FACILITY_TYPE_2}} | {{RISK}} |

### 2.2 Assessment Methodology

- How was proximity determined?  
  - {{METHODOLOGY}} (e.g., GIS mapping of geofence coordinates against health care facility database, manual review of geofence configurations, third‑party audit)  
- Data source for health care facility locations:  
  - {{DATA_SOURCE}} (e.g., Washington State DOH facility registry, CMS provider database, Google Places API health care category, manual identification)  
- Frequency of re‑assessment:  
  - {{REASSESSMENT_FREQUENCY}} (e.g., quarterly, before each new geofence deployment)

---

## Part 3 — Prohibited Use Assessment

> **Objective:** For each geofence within 2,000 feet of a health care facility, assess whether it is used for any of the three prohibited purposes.

### 3.1 Prohibited Purpose Checklist

For each geofence identified as within 2,000 feet of a health care facility:

| Prohibited Purpose | Statutory Basis | Is This Geofence Used for This Purpose? (Y/N) | Evidence / Explanation |
|-------------------|----------------|:----------------------------------------------:|----------------------|
| Identify or track consumers seeking health care services | RCW 19.373.080(1) | {{Y_N}} | {{EXPLANATION}} |
| Collect consumer health data from consumers | RCW 19.373.080(2) | {{Y_N}} | {{EXPLANATION}} |
| Send notifications, messages, or advertisements related to consumer health data or health care services | RCW 19.373.080(3) | {{Y_N}} | {{EXPLANATION}} |

### 3.2 Overall Geofence Compliance Determination

| Geofence / Feature | Within 2,000 ft? | Used for Prohibited Purpose? | Compliant? | Required Action |
|--------------------|:-----------------:|:----------------------------:|:----------:|----------------|
| {{TECH_1}} | {{Y_N}} | {{Y_N}} | {{Y_N}} | {{ACTION}} |
| {{TECH_2}} | {{Y_N}} | {{Y_N}} | {{Y_N}} | {{ACTION}} |

---

## Part 4 — Geofence Compliance Policy

> **Objective:** Establish a standing policy to prevent MHMD geofence violations going forward.

### 4.1 Policy Statement

{{CLIENT_NAME}} prohibits the use of geofencing technology within 2,000 feet of any entity that provides in‑person health care services for the purpose of:  
- Identifying or tracking consumers seeking health care services;  
- Collecting consumer health data from consumers; or  
- Sending notifications, messages, or advertisements to consumers related to their consumer health data or health care services.

This prohibition applies to {{CLIENT_NAME}}, its employees, processors, contractors, advertising partners, and any other person acting on {{CLIENT_NAME}}'s behalf.

### 4.2 Pre‑Deployment Review Requirement

Before deploying any new geofence or location‑based feature, {{CLIENT_NAME}} must complete the following:

| Step | Action | Owner |
|:----:|--------|:-----:|
| 1 | Document the geofence parameters (coordinates, radius, technology type, purpose) | {{PRODUCT_TEAM}} |
| 2 | Run proximity check against health care facility database to confirm no facility within 2,000 feet | {{COMPLIANCE_LEAD}} |
| 3 | Confirm the geofence is not used for any of the three prohibited purposes | {{COMPLIANCE_LEAD}} |
| 4 | If proximity or purpose concern exists, escalate to {{LEGAL_CONTACT}} for review before deployment | {{LEGAL_CONTACT}} |
| 5 | Document approval or denial in geofence compliance log | {{COMPLIANCE_LEAD}} |

### 4.3 Third‑Party and SDK Controls

- All advertising partners, SDK providers, and data brokers that deploy location‑based technology within {{CLIENT_NAME}}'s products must:  
  - Certify in writing that they do not implement geofences within 2,000 feet of health care facilities for prohibited purposes.  
  - Include MHMD geofence compliance language in their contract or addendum with {{CLIENT_NAME}}.  
  - Submit to periodic audits or questionnaires regarding their geofence practices.

### 4.4 Ongoing Monitoring

| Activity | Frequency | Owner |
|----------|:---------:|:-----:|
| Re‑run proximity analysis for all active geofences | {{FREQUENCY}} (e.g., quarterly) | {{COMPLIANCE_LEAD}} |
| Audit third‑party SDK geofence behavior | {{FREQUENCY}} (e.g., semi‑annually) | {{PRODUCT_TEAM}} + {{COMPLIANCE_LEAD}} |
| Review new health care facility openings near existing geofence locations | {{FREQUENCY}} (e.g., quarterly) | {{COMPLIANCE_LEAD}} |
| Update health care facility database | {{FREQUENCY}} (e.g., quarterly) | {{DATA_TEAM}} |

### 4.5 Violation Response

If a geofence is discovered to be in violation of RCW 19.373.080:

| Step | Action | Owner | Timeline |
|:----:|--------|:-----:|:--------:|
| 1 | Immediately disable the geofence | {{PRODUCT_TEAM}} / {{IT_TEAM}} | Within 24 hours |
| 2 | Notify {{LEGAL_CONTACT}} | {{COMPLIANCE_LEAD}} | Within 24 hours |
| 3 | Assess scope: how long was the geofence active? How many consumers affected? What data was collected/sent? | {{COMPLIANCE_LEAD}} + {{DATA_TEAM}} | Within 72 hours |
| 4 | Document the incident and remediation in the geofence compliance log | {{COMPLIANCE_LEAD}} | Within 1 week |
| 5 | If consumer health data was collected, assess whether consumer notification or deletion is required | {{LEGAL_CONTACT}} | Within 1 week |
| 6 | Implement preventive controls to avoid recurrence | {{PRODUCT_TEAM}} + {{COMPLIANCE_LEAD}} | Within 30 days |

---

## Part 5 — Enforcement Risk

| Enforcement Mechanism | Details |
|----------------------|---------|
| Attorney General | Violations are WA CPA violations; civil penalties up to $7,500 per violation |
| Private Right of Action | Any consumer can sue; actual damages trebled up to $25,000; attorneys' fees recoverable |
| Class Action Risk | Geofencing near popular health facilities (hospitals, pharmacies) could affect thousands of consumers simultaneously |
| Reputational Risk | Geofencing near reproductive health or gender‑affirming care facilities carries extreme reputational and media risk |

> **Note:** The geofence prohibition has **no exemptions**. Unlike other MHMD provisions, there is no "necessary to provide a requested service" exception, no HIPAA carve‑out, and no small business delay. It applies immediately to any person.

---

## Part 6 — Record‑Keeping

| Record | Retention Period |
|--------|:---------------:|
| Geofence technology inventory (Part 1) | {{RETENTION}} |
| Proximity analysis results (Part 2) | {{RETENTION}} |
| Prohibited use assessments (Part 3) | {{RETENTION}} |
| Pre‑deployment review logs (Section 4.2) | {{RETENTION}} |
| Third‑party geofence certifications (Section 4.3) | {{RETENTION}} |
| Violation incident reports (Section 4.5) | {{RETENTION}} |

---

**End of Template**
