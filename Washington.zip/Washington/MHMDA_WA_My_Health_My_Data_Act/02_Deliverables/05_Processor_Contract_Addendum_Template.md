# Washington My Health My Data Act — Processor Contract Addendum (MASTER TEMPLATE)

**Document Title:** MHMD Processor Contract Addendum for {{CLIENT_NAME}}  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.060 — Processors  
**Organization:** {{CLIENT_NAME}}  
**Prepared By:** {{CONSULTANT_NAME}}, {{FIRM_NAME}}  
**Date:** {{REPORT_DATE}}  
**Version:** {{VERSION_NUMBER}}  

> **Purpose:** This addendum is designed to be attached to {{CLIENT_NAME}}'s existing service agreements with any processor that processes consumer health data on {{CLIENT_NAME}}'s behalf. RCW 19.373.060 requires a **binding contract** that sets forth processing instructions and limits the processor's actions. If a processor exceeds the scope of this contract, it becomes a regulated entity itself and is subject to all MHMD obligations.

---

## Instructions for Use

1. Execute this addendum with **every** vendor, service provider, or contractor that processes consumer health data on {{CLIENT_NAME}}'s behalf.  
2. This addendum supplements (does not replace) the existing Master Service Agreement (MSA) or similar agreement between the parties.  
3. In case of conflict between this addendum and the underlying agreement, this addendum controls with respect to consumer health data.  
4. Both parties should have legal counsel review before execution.  
5. Retain executed copies for at least **6 years** (aligned with MHMD sale authorization retention and general best practice).

---

## MHMD PROCESSOR CONTRACT ADDENDUM

**Addendum Effective Date:** {{ADDENDUM_EFFECTIVE_DATE}}

**Between:**

**Regulated Entity ("Controller"):**  
{{CLIENT_NAME}}  
{{CLIENT_ADDRESS}}  
Contact: {{CLIENT_CONTACT_NAME}}, {{CLIENT_CONTACT_TITLE}}  
Email: {{CLIENT_CONTACT_EMAIL}}

**Processor ("Processor"):**  
{{PROCESSOR_NAME}}  
{{PROCESSOR_ADDRESS}}  
Contact: {{PROCESSOR_CONTACT_NAME}}, {{PROCESSOR_CONTACT_TITLE}}  
Email: {{PROCESSOR_CONTACT_EMAIL}}

**Underlying Agreement:** {{UNDERLYING_AGREEMENT_NAME}} dated {{UNDERLYING_AGREEMENT_DATE}} ("Agreement")

---

### 1. Definitions

For purposes of this Addendum, capitalized terms have the meanings given to them in the Washington My Health My Data Act (RCW Chapter 19.373) unless otherwise defined herein.

- **"Consumer Health Data"** has the meaning set forth in RCW 19.373.010(8).  
- **"Consumer"** has the meaning set forth in RCW 19.373.010(7).  
- **"Process" or "Processing"** has the meaning set forth in RCW 19.373.010(20).  
- **"MHMD"** means the Washington My Health My Data Act, RCW Chapter 19.373, as amended.

---

### 2. Scope of Processing

Processor shall process Consumer Health Data **only** as described in this Section and in accordance with Controller's documented instructions.

**(a) Categories of Consumer Health Data processed:**  
- {{DATA_CATEGORY_1}}  
- {{DATA_CATEGORY_2}}  
- {{DATA_CATEGORY_3}}  

**(b) Purpose(s) of processing:**  
- {{PROCESSING_PURPOSE_1}}  
- {{PROCESSING_PURPOSE_2}}  

**(c) Duration of processing:**  
Processing shall continue for the term of the underlying Agreement unless terminated earlier pursuant to Section 10 of this Addendum.

**(d) Nature of processing operations:**  
- {{PROCESSING_OPERATIONS}} (e.g., storage, computation, transmission, analytics, email delivery, backup)

---

### 3. Processing Instructions and Limitations

**(a)** Processor shall process Consumer Health Data **only** in a manner that is consistent with the binding instructions set forth in this Addendum and any subsequent written instructions provided by Controller.

**(b)** Processor shall **not**:  
- Process Consumer Health Data for any purpose other than those specified in Section 2(b).  
- Sell Consumer Health Data.  
- Share Consumer Health Data with any third party, affiliate, or sub‑processor except as expressly authorized in writing by Controller.  
- Combine Consumer Health Data with data obtained from other sources or other Controller clients unless expressly instructed by Controller.  
- Use Consumer Health Data for Processor's own business purposes, including product development, analytics, advertising, or profiling.

**(c)** If Processor believes an instruction from Controller violates MHMD or other applicable law, Processor shall promptly notify Controller in writing before acting on the instruction.

> **MHMD Warning:** If Processor fails to adhere to Controller's instructions or processes Consumer Health Data outside the scope of this Addendum, Processor shall be considered a **regulated entity** with respect to such data and shall be subject to **all requirements of MHMD**, including the private right of action (RCW 19.373.060(1)(c)).

---

### 4. Technical and Organizational Measures

Processor shall implement and maintain appropriate technical and organizational measures to:

**(a)** Assist Controller in fulfilling its obligations under MHMD, including but not limited to:  
- Responding to consumer rights requests (access, deletion, consent withdrawal) pursuant to RCW 19.373.040.  
- Maintaining the confidentiality, integrity, and accessibility of Consumer Health Data pursuant to RCW 19.373.050.  
- Ensuring Consumer Health Data is processed in a manner consistent with Controller's consumer health data privacy policy pursuant to RCW 19.373.020.

**(b)** Implement data security practices that, at a minimum, satisfy reasonable standards of care within Processor's industry, including:  
- {{SECURITY_MEASURE_1}} (e.g., encryption at rest and in transit)  
- {{SECURITY_MEASURE_2}} (e.g., role‑based access controls)  
- {{SECURITY_MEASURE_3}} (e.g., regular security assessments/penetration testing)  
- {{SECURITY_MEASURE_4}} (e.g., employee security training)  
- {{SECURITY_MEASURE_5}} (e.g., incident detection and response capabilities)

**(c)** Restrict access to Consumer Health Data to only those Processor personnel for whom access is necessary to perform the processing described in Section 2.

---

### 5. Consumer Rights Assistance — Deletion Obligations

**(a)** Upon notification from Controller that a consumer has exercised their right to delete Consumer Health Data under RCW 19.373.040(1)(c), Processor shall:  
- Delete all Consumer Health Data associated with the identified consumer from Processor's records, including all parts of Processor's network.  
- Delete Consumer Health Data from archived or backup systems. If such data is stored on archived or backup systems, deletion may be delayed up to **six (6) months** from the date of Controller's notification.  
- Confirm completion of deletion to Controller in writing within **{{DELETION_CONFIRMATION_DAYS}}** business days (or within 6 months for archived/backup systems).

**(b)** Upon notification from Controller that a consumer has exercised their right to withdraw consent or right to access, Processor shall reasonably assist Controller in fulfilling the request within the timelines required by MHMD.

---

### 6. Sub‑Processors

**(a)** Processor shall not engage any sub‑processor to process Consumer Health Data without Controller's prior **written consent**.

**(b)** If Controller grants consent, Processor shall:  
- Enter into a written agreement with the sub‑processor that imposes obligations no less protective than those in this Addendum.  
- Remain fully liable to Controller for the acts and omissions of the sub‑processor.  
- Provide Controller with a current list of sub‑processors upon request.

**(c)** Current authorized sub‑processors:

| Sub‑Processor Name | Processing Activity | Location |
|--------------------|-------------------|----------|
| {{SUBPROCESSOR_1}} | {{ACTIVITY_1}} | {{LOCATION_1}} |
| {{SUBPROCESSOR_2}} | {{ACTIVITY_2}} | {{LOCATION_2}} |

---

### 7. Confidentiality

Processor shall ensure that all personnel authorized to process Consumer Health Data are bound by written confidentiality obligations or are under an appropriate statutory obligation of confidentiality.

---

### 8. Audits and Inspections

**(a)** Processor shall make available to Controller all information reasonably necessary to demonstrate compliance with this Addendum and MHMD.

**(b)** Processor shall allow and contribute to audits, including inspections, conducted by Controller or a third‑party auditor designated by Controller, upon **{{AUDIT_NOTICE_DAYS}}** days' written notice. Audits shall be conducted during normal business hours and shall not unreasonably interfere with Processor's operations.

**(c)** Processor shall promptly remediate any non‑compliance identified during an audit.

---

### 9. Data Breach Notification

Processor shall notify Controller without undue delay, and in no event later than **{{BREACH_NOTIFICATION_HOURS}}** hours, after becoming aware of any:  
- Unauthorized access to, disclosure of, or loss of Consumer Health Data.  
- Security incident that may compromise the confidentiality, integrity, or availability of Consumer Health Data.  
- Any request, inquiry, or complaint from a consumer, regulator, or the Washington Attorney General relating to Consumer Health Data processed under this Addendum.

Processor shall cooperate fully with Controller in investigating, remediating, and responding to any such incident.

---

### 10. Term and Termination

**(a)** This Addendum shall remain in effect for the duration of the underlying Agreement.

**(b)** Upon termination or expiration of the underlying Agreement, or upon Controller's written request, Processor shall:  
- Cease all processing of Consumer Health Data.  
- Delete all Consumer Health Data from Processor's systems (including backups, within 6 months) unless retention is required by applicable law.  
- Certify deletion in writing to Controller within **{{TERMINATION_DELETION_DAYS}}** days.

---

### 11. Liability and Indemnification

**(a)** If Processor's failure to comply with this Addendum or MHMD results in Controller being subject to enforcement action, private lawsuit, fines, penalties, damages, or costs, Processor shall indemnify and hold harmless Controller for all such losses to the extent caused by Processor's breach.

**(b)** Nothing in the underlying Agreement shall limit Processor's liability for breaches of this Addendum or violations of MHMD.

---

### 12. Governing Law

This Addendum shall be governed by the laws of the State of Washington. The parties acknowledge that MHMD violations are enforceable under the Washington Consumer Protection Act (RCW 19.86) and through a private right of action.

---

### 13. Order of Precedence

In the event of a conflict between this Addendum and the underlying Agreement, this Addendum shall control with respect to the processing of Consumer Health Data.

---

### 14. Signatures

**Controller — {{CLIENT_NAME}}**

Signature: ___________________________________  
Name: {{CLIENT_SIGNATORY_NAME}}  
Title: {{CLIENT_SIGNATORY_TITLE}}  
Date: ___________________________________

**Processor — {{PROCESSOR_NAME}}**

Signature: ___________________________________  
Name: {{PROCESSOR_SIGNATORY_NAME}}  
Title: {{PROCESSOR_SIGNATORY_TITLE}}  
Date: ___________________________________

---

**End of Template**
