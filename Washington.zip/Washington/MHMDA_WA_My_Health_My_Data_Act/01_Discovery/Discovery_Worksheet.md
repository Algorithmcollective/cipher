# Washington My Health My Data Act Discovery Worksheet

---

## Scope & Applicability

Washington Operations:
Health Data Activities:
Inferred Health Data:
Annual Consumer Count:
Revenue % Health Data:
Exemptions Applicable:
Prior WA Issues:

---

## Consumer Health Data Privacy Policy

Health Data Categories:
Data Sources:
Collection Purposes:
Shared Categories:
Affiliate Names:
Third Parties:
Separate Policy:
Homepage Link:
App Placement:
Last Update:

---

## Consent & Authorization

Collection Consent Mechanism:
Sharing Consent Separate:
Bundled With ToS:
Consent Logging:
Withdrawal Method:
Data Sold:
Standalone Authorization:
Expiration Tracking:
Revocation Workflow:

---

## Consumer Rights Workflow

Intake Channels:
Authentication Method:
Tracking System:
45-Day Monitoring:
Deletion Process:
Backup Deletion:
Downstream Notice:
Appeal Process:
Extension Procedure:

---

## Processor Contracts

Processors List:
MSA In Place:
MHMD Addendum:
Secondary Use Restricted:
Sale Prohibited:
Subprocessor Controls:
Deletion Assistance:
Security Obligations:

---

## Data Security Practices

RBAC Implemented:
Access Review Frequency:
Encryption At Rest:
Encryption In Transit:
Key Management:
Incident Response Plan:
Testing Cadence:
Vendor Assessments:
Security Training:
Access Deprovisioning:

---

## Geofence Compliance

Location Technologies:
Geofences Deployed:
Radius:
Health Facility Proximity:
Ad SDK Location Use:
Location Data Sold:
GIS Audit Conducted:
Policy Exists:

---

## Authorization to Sell

Health Data Sold:
Standalone Authorization Used:
9 Elements Included:
Signature Captured:
Expiration Tracked:
Copy Provided:
Six-Year Retention:
Revocation Check:

---

## Training & Awareness

Tiered Training:
Annual Refresh:
Operational Training:
Consent Training:
Rights Training:
Geofence Training:
Incident Escalation:
Training Logs:

---

## Compliance Audit

Annual Audit:
Evidence Repository:
Remediation Tracker:
Executive Sign-Off:
Six-Year Retention:
Litigation Binder:
Version Control:
Change Management:

---

## TBD

Item:
Owner:
Notes: