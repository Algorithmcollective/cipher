# Washington My Health My Data Act Discovery Script

Purpose: Gather information needed to prepare Washington My Health My Data Act compliance documentation.

If unknown → mark TBD

---

## 🧾 Deliverable: Scope & Applicability Memo

Say:
“I need to determine whether you qualify as a regulated entity under Washington’s My Health My Data Act and what consumer health data activities are in scope.”

Ask:

- Do you conduct business in Washington?
- Do you market or target Washington residents?
- Do you collect data from Washington residents?
- What products or services involve health-related data?
- Do you infer health status from non-health data?
- Approximate number of consumers whose health data is processed annually?
- Percentage of revenue derived from health-related data?
- Any HIPAA-covered operations?
- Any GLBA, FCRA, FERPA, or other federal exemptions applicable?
- Any prior Washington complaints, inquiries, or litigation?

---

## 🧾 Deliverable: Consumer Health Data Privacy Policy

Say:
“I need to understand exactly what health data you collect, how it is used, and how it is shared.”

Ask:

- Categories of consumer health data collected
- Sources of that data
- Purposes of collection
- Categories of data shared
- Names of specific affiliates receiving data
- Third-party categories receiving data
- Whether policy is separate from general privacy policy
- Homepage link placement
- App placement (if applicable)
- Last policy update date

---

## 🧾 Deliverable: Consent & Authorization Framework

Say:
“I need to confirm how you obtain valid consent for collection, sharing, and any sale of consumer health data.”

Ask:

- Collection consent mechanism (opt-in?)
- Sharing consent separate from collection?
- Are consents bundled with Terms of Service?
- Do you log timestamps and consent versions?
- How can users withdraw consent?
- Do you sell consumer health data?
- If yes, do you use a standalone signed authorization?
- Authorization expiration tracking?
- Revocation workflow?

---

## 🧾 Deliverable: Consumer Rights & Deletion Workflow

Say:
“I need to understand how consumer rights requests are received, authenticated, and fulfilled.”

Ask:

- Intake channels (email, portal, phone, in-app)
- Authentication method
- Response tracking system
- 45-day deadline monitoring?
- Deletion from production systems?
- Backup deletion timeline?
- Downstream deletion notification process?
- Appeal process documented?
- Extension notification procedure?

---

## 🧾 Deliverable: Processor Contract Addendum

Say:
“I need to confirm all vendors processing consumer health data are contractually restricted.”

Ask:

- List of processors handling consumer health data
- Existing MSA in place?
- MHMD addendum executed?
- Do contracts restrict secondary use?
- Are processors prohibited from selling data?
- Subprocessor controls?
- Deletion assistance clause included?
- Security obligations defined?

---

## 🧾 Deliverable: Data Security Practices Checklist

Say:
“I need to verify technical and organizational safeguards for consumer health data.”

Ask:

- Role-based access controls implemented?
- Access review frequency?
- Encryption at rest and in transit?
- Key management system?
- Incident response plan exists?
- Incident testing cadence?
- Vendor security assessments performed?
- Employee security training completed?
- Access deprovisioning timeline?

---

## 🧾 Deliverable: Geofence Compliance Assessment & Policy

Say:
“I need to determine whether any geofencing activity occurs within 2,000 feet of health care facilities.”

Ask:

- Use of GPS, Wi-Fi, cell, RFID location tracking?
- Any geofence features deployed?
- Radius configuration for geofences?
- Any geofences near clinics, hospitals, pharmacies?
- Advertising SDKs using location triggers?
- Location data sold or shared?
- GIS proximity audit conducted?
- Policy restricting prohibited uses?

---

## 🧾 Deliverable: Valid Authorization to Sell Consumer Health Data

Say:
“I need to confirm whether any consumer health data is sold and whether a valid authorization is used.”

Ask:

- Is health data exchanged for monetary or valuable consideration?
- Standalone authorization document used?
- All 9 statutory elements included?
- Consumer signature captured?
- Expiration date tracked?
- Copy provided to consumer?
- Six-year retention implemented?
- Revocation tracking before each sale?

---

## 🧾 Deliverable: Training & Awareness Playbook

Say:
“I need to confirm that staff are trained on MHMD obligations.”

Ask:

- Tiered training program implemented?
- Annual refresh schedule?
- Role-based operational training?
- Consent-specific training?
- Consumer rights workflow training?
- Geofence prohibition covered?
- Incident escalation training?
- Training completion logs retained?

---

## 🧾 Deliverable: Compliance Audit Checklist & Evidence Register

Say:
“I need to confirm you can demonstrate compliance with evidence.”

Ask:

- Annual compliance audit performed?
- Evidence artifacts stored centrally?
- Remediation tracker maintained?
- Executive sign-off documented?
- Six-year document retention?
- Litigation readiness binder assembled?
- Version control for policies?
- Change management documentation?

---

## ✅ Closing

Say:
“That gives us what we need to prepare your Washington My Health My Data Act compliance package.”