# Law Profile

## Law Name
Washington My Health My Data Act (MHMDA)

## Citation
Revised Code of Washington (RCW) 19.373

## Status
Enacted

## Effective Dates
March 31, 2024 (large businesses)  
June 30, 2024 (small businesses)

## Regulatory Scope

Applies to entities that:

- Conduct business in Washington or target Washington consumers
- Determine the purpose and means of collecting, processing, sharing, or selling consumer health data

Applies regardless of revenue thresholds.

Covers both:

- Controllers
- Processors

## Definition of Consumer Health Data

Includes personal information linked or reasonably linkable to a consumer that identifies past, present, or future physical or mental health status.

Examples:

- Medical conditions
- Diagnosis information
- Health treatments
- Reproductive or sexual health data
- Biometric identifiers used for health inference
- Location data indicating visits to healthcare facilities

Broader than HIPAA.  
Applies even to non-HIPAA covered entities.

## Core Obligations

Covered entities must:

1. Publish a standalone consumer health data privacy policy
2. Obtain opt-in consent before collecting or sharing consumer health data
3. Obtain separate authorization before selling consumer health data
4. Provide consumer rights:
   - Access
   - Deletion
   - Withdrawal of consent
5. Maintain data security safeguards
6. Execute processor contracts
7. Prohibit geofencing around healthcare facilities for certain purposes
8. Maintain compliance documentation

## Geofencing Prohibition

Prohibits implementing geofencing within 2,000 feet of healthcare facilities when used to:

- Identify consumers seeking healthcare
- Collect health data
- Send targeted ads related to health services

## Enforcement Authority

Washington Attorney General  
Private right of action under Washington Consumer Protection Act

## Penalties

Civil penalties under the Consumer Protection Act.

Private lawsuits permitted.

Each violation may constitute an unfair or deceptive act in trade.

High litigation exposure.

## Private Right of Action
Yes

## Tier Classification
Tier 1 – Consumer Health Data Protection Law

## Revenue Priority
Very High (Broad applicability + private lawsuits)

## Target Industries

- Health tech platforms
- Wellness apps
- Telehealth providers
- Fitness tracking platforms
- Retailers collecting reproductive health data
- Data brokers
- Advertising technology firms
- Location data providers

## Strategic Positioning

Position as:

Consumer Health Data Risk Containment & Litigation Prevention Program.

This law extends beyond HIPAA and applies to many non-healthcare companies.

Primary risk drivers:

- Unauthorized collection
- Lack of opt-in consent
- Sale of health data
- Geofencing violations
- Inadequate disclosures

## Internal Notes

Primary compliance focus areas:

1. Consumer Health Data Mapping
2. Standalone Privacy Policy
3. Consent & Authorization Controls
4. Consumer Rights Workflow
5. Processor Contract Addendum
6. Geofence Prohibition Assessment
7. Data Security Safeguards
8. Training & Audit Controls

High cross-sell with:

- TDPSA
- Colorado Privacy Act
- Illinois BIPA (biometric crossover)