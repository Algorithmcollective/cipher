# Washington My Health My Data Act — Data Security Practices Checklist (EXAMPLE)

**Document Title:** MHMD Data Security Practices Checklist for PulseWell Inc.  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.050 — Data Security Practices  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  

> **Purpose:** This example shows how PulseWell Inc. documents its data security posture for MHMD compliance, identifies gaps, and tracks remediation.

---

## 1. Access Restriction Controls

### 1.1 Role‑Based Access Control (RBAC)

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Consumer health data systems have role‑based access controls implemented | ✅ Implemented | DevOps | AWS IAM policies + PostgreSQL row‑level security |
| Access roles are defined and documented for each system | ✅ Implemented | DevOps | Roles documented in Confluence: Admin, Data Engineer, Product Analyst, Support (read‑only) |
| Each role's access is limited to the minimum data necessary | ✅ Implemented | DevOps | Support role cannot access raw biometric waveforms; Analysts cannot access PII |
| Access roles reviewed and updated quarterly | ✅ Implemented | CPO + DevOps | Last review: January 15, 2026; next: April 15, 2026 |

### 1.2 Personnel Access Inventory

| System / Database | Contains Consumer Health Data? | Authorized Roles | Users with Access | Last Access Review |
|-------------------|:-----------------------------:|-------------------|:-----------------:|:------------------:|
| PostgreSQL (production) | Y | Admin, Data Engineer | 8 | Jan 15, 2026 |
| Snowflake (analytics) | Y | Data Engineer, Product Analyst | 12 | Jan 15, 2026 |
| S3 raw telemetry bucket | Y | Admin, Data Engineer | 5 | Jan 15, 2026 |
| PulseWell App backend API | Y | Admin, Backend Engineers | 6 | Jan 15, 2026 |
| S3 Glacier (backups) | Y | Admin, DevOps | 3 | Jan 15, 2026 |
| Jira Service Management (rights requests) | Y (consumer identifiers only) | Privacy Ops, CPO | 4 | Jan 15, 2026 |

### 1.3 Processor and Contractor Access

| Processor / Contractor | Data Accessed | Purpose | Access Method | Addendum Executed? |
|------------------------|--------------|---------|---------------|:------------------:|
| AWS | All health data (storage) | Cloud hosting | IAM service roles | Y |
| SendGrid (Twilio) | Email + med reminder content | Email delivery | API key (scoped) | Y |
| NightOwl Security Inc. | Penetration test scope | Annual pen test | VPN + temp credentials | Y |

### 1.4 Access Provisioning & De‑Provisioning

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| New access requires written approval from CPO or Engineering Manager | ✅ Implemented | CPO / Eng Mgr | Approval via Jira ticket workflow |
| Access provisioned based on role, not individual request | ✅ Implemented | DevOps | Standard role templates in AWS IAM |
| Access revoked within 4 hours of termination | ✅ Implemented | HR + DevOps | Automated via Okta lifecycle management; manual backup process |
| Access changes logged with timestamp, approver, reason | ✅ Implemented | DevOps | CloudTrail + Okta audit logs |

---

## 2. Administrative Security Practices

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Written information security policy covering health data | ✅ Implemented | CPO | "PulseWell Information Security Policy v3.2" — last updated Dec 2025 |
| Policy reviewed and updated annually | ✅ Implemented | CPO | Next review: December 2026 |
| Designated privacy/security officer | ✅ Implemented | — | Jordan Reeves, Chief Privacy Officer |
| Security awareness training at hire + annually | ✅ Implemented | HR + CPO | KnowBe4 platform; completion tracked in HR system |
| Training includes MHMD‑specific obligations | 🔲 Planned | CPO | MHMD module to be added to KnowBe4 by April 2026 |
| Background checks for health data personnel | ✅ Implemented | HR | All engineering, data, and privacy staff screened at hire |
| Confidentiality agreements signed | ✅ Implemented | HR + Legal | Part of standard employment agreement; contractor NDAs on file |
| Incident response plan exists for health data breaches | ✅ Implemented | CPO + DevOps | "PulseWell Incident Response Plan v2.1" |
| IR plan tested annually (tabletop) | ✅ Implemented | CPO | Last exercise: November 2025; next: November 2026 |
| Vendor risk assessments before granting data access | ✅ Implemented | CPO + Legal | Vendor questionnaire + contract review; documented in Confluence |

---

## 3. Technical Security Practices

### 3.1 Encryption

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Encryption at rest: AES‑256 | ✅ Implemented | DevOps | S3 SSE‑KMS, RDS encryption enabled, Glacier vault lock |
| Encryption in transit: TLS 1.3 | ✅ Implemented | DevOps | All API endpoints, Band‑to‑app Bluetooth uses AES‑CCM |
| Key management: AWS KMS | ✅ Implemented | DevOps | Customer‑managed keys (CMK) in us‑west‑2 |
| Key rotation: annual automatic rotation | ✅ Implemented | DevOps | AWS KMS auto‑rotation enabled |

### 3.2 Network Security

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Firewalls restrict health data system access | ✅ Implemented | DevOps | AWS Security Groups + WAF on API Gateway |
| Network segmentation for health data | ✅ Implemented | DevOps | Health data in dedicated VPC subnet; no direct internet access to DB |
| IDS/IPS deployed | ✅ Implemented | DevOps | AWS GuardDuty + custom CloudWatch alarms |
| VPN/zero‑trust for remote access | ✅ Implemented | DevOps | Tailscale zero‑trust network for all engineer access |

### 3.3 Application Security

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Secure SDLC followed | ✅ Implemented | Engineering | Code reviews required; OWASP checklist in PR template |
| Input validation / output encoding | ✅ Implemented | Engineering | Parameterized queries; React auto‑escaping on frontend |
| MFA for health data access | ✅ Implemented | DevOps | Okta MFA required for all internal tools; app users have optional biometric |
| Vulnerability scanning: weekly | ✅ Implemented | DevOps | Snyk (code), AWS Inspector (infrastructure) |
| Annual penetration test | ✅ Implemented | CPO | NightOwl Security Inc.; last test: October 2025; next: October 2026 |

### 3.4 Logging and Monitoring

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Health data access logged (who, what, when) | ✅ Implemented | DevOps | CloudTrail + application‑level audit logs |
| Logs retained for 6 years | 🔲 Planned | DevOps | Currently 12 months; extending to 6 years by Q2 2026 (S3 lifecycle policy) |
| Logs reviewed weekly for anomalies | ✅ Implemented | DevOps | Automated Datadog dashboards + weekly manual review |
| Automated alerting for suspicious patterns | ✅ Implemented | DevOps | GuardDuty + custom Datadog alerts for bulk exports, unusual access hours |
| Tamper‑protected logs | ✅ Implemented | DevOps | CloudTrail log file validation enabled; S3 Object Lock on log bucket |

---

## 4. Physical Security Practices

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Physical server access restricted | ✅ Implemented | — | All infrastructure is AWS cloud — AWS SOC 2 covers physical security |
| Visitor access logged/escorted | ✅ Implemented | Office Mgr | Seattle office has badge access; visitors signed in and escorted |
| Workstation screen locks | ✅ Implemented | IT | Auto‑lock after 5 min idle; enforced via MDM policy |
| Removable media restrictions | ✅ Implemented | IT | USB storage disabled on company devices via MDM |
| Secure hardware disposal | ✅ Implemented | IT | Laptops wiped (NIST 800‑88) before recycling; certificates retained |

---

## 5. Data Retention and Disposal

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| Data retention policy specifies health data periods | ✅ Implemented | CPO + Legal | Active data: duration of account + 90 days. Sale auth records: 6 years. |
| Health data not retained beyond disclosed purpose | ✅ Implemented | Data Eng | Automated 90‑day purge after account deletion |
| Automated deletion enforces retention limits | ✅ Implemented | Data Eng | S3 lifecycle policies; PostgreSQL scheduled jobs |
| Sale authorization records retained 6 years | 🔲 Planned | Legal | Compliance vault setup in progress; target: April 2026 |
| Deletion processes verified | ✅ Implemented | CPO | Quarterly spot‑check audit of deleted accounts |

---

## 6. Incident Response — Consumer Health Data

| Control | Status | Owner | Evidence / Notes |
|---------|:------:|:-----:|-----------------|
| IR plan addresses health data breaches | ✅ Implemented | CPO | Section 4.3 of IR Plan v2.1 |
| Classification criteria include MHMD data | 🔲 Planned | CPO | Adding MHMD severity tier by March 2026 |
| Response team includes MHMD roles | ✅ Implemented | CPO | Jordan Reeves (privacy), Taylor Simmons (legal), DevOps lead (technical) |
| Notification procedures: consumers, AG, processors | 🔲 Planned | CPO + Legal | MHMD‑specific notification templates to be drafted by April 2026 |
| Post‑incident review documented | ✅ Implemented | CPO | Standard post‑mortem template in Confluence |
| Annual tabletop exercise | ✅ Implemented | CPO | Last: Nov 2025 (scenario: unauthorized health data export) |

---

## 7. Industry Standard of Care Benchmark

| Benchmark / Framework | Adopted? | Certification / Evidence | Notes |
|-----------------------|:--------:|--------------------------|-------|
| NIST Cybersecurity Framework (CSF) | Y | Self‑assessment completed Dec 2025 | Aligned to CSF 2.0 |
| SOC 2 Type II | Y | Report dated Sept 2025 (Deloitte) | Covers all trust services criteria |
| ISO 27001 | N | — | Evaluating for 2027 certification |
| HIPAA Security Rule | N | — | Not a covered entity; not required |
| CIS Controls v8 | Y | Implementation Group 2 achieved | Documented in Confluence |
| OWASP Top 10 | Y | Integrated into SDLC PR checklist | Updated for 2025 edition |

---

## 8. Remediation Tracker

| # | Gap Identified | Risk | Remediation Action | Owner | Target Date | Status |
|:-:|---------------|:----:|-------------------|:-----:|:-----------:|:------:|
| 1 | MHMD‑specific training module not yet in KnowBe4 | Medium | Create and deploy MHMD training module | CPO | April 15, 2026 | In progress |
| 2 | Log retention only 12 months (need 6 years) | Medium | Extend S3 lifecycle + Glacier archival to 6 years | DevOps | May 1, 2026 | Planned |
| 3 | Sale authorization 6‑year vault not built | Medium | Build encrypted S3 compliance vault with IAM restrictions | Legal + DevOps | April 30, 2026 | Planned |
| 4 | IR plan lacks MHMD classification tier | Low | Add MHMD severity tier and notification templates | CPO | March 31, 2026 | In progress |
| 5 | MHMD breach notification templates not drafted | Medium | Draft consumer, AG, and processor notification templates | CPO + Legal | April 15, 2026 | Planned |

---

## 9. Review and Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Completed By | Algorithm Collective LLC | _______________ | Feb 23, 2026 |
| Reviewed By | Jordan Reeves, CPO | _______________ | _______________ |
| Approved By | Taylor Simmons, GC | _______________ | _______________ |

**Next Review Date:** February 2027 (or sooner if material changes occur)

---

**End of Example**
