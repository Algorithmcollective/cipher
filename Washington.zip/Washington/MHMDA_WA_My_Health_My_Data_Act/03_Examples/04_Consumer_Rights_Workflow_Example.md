# Washington My Health My Data Act — Consumer Rights Request & Deletion Workflow (EXAMPLE)

**Document Title:** MHMD Consumer Rights Request & Deletion Workflow for PulseWell Inc.  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.040 — Consumer Rights and Requests  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  

> **Purpose:** This example shows how PulseWell Inc. operationalizes the consumer rights workflow required under MHMD, using their actual systems, teams, and tools.

---

## 1. Consumer Rights Overview

| Right | Statutory Basis | Description | Response Deadline |
|-------|----------------|-------------|:-----------------:|
| Right to Confirm & Access | RCW 19.373.040(1)(a) | Consumer can confirm data collection/sharing/sale and access their data + list of all third parties with contact info | 45 days (+45 extension) |
| Right to Withdraw Consent | RCW 19.373.040(1)(b) | Consumer can withdraw consent to collection and sharing | 45 days |
| Right to Delete | RCW 19.373.040(1)(c) | Consumer can request full deletion from all systems; PulseWell must notify all downstream recipients | 45 days (backups up to 6 months) |
| Right to Appeal | RCW 19.373.040(1)(h) | Consumer can appeal any refusal; written response within 45 days; AG referral if denied | 45 days |

---

## 2. Request Intake Channels

| Channel | Details | Responsible Team |
|---------|---------|:----------------:|
| Email | privacy@pulsewell.com | Privacy Operations Team |
| Online Portal | pulsewell.com/health-data-rights | Privacy Operations Team |
| Phone | 1‑800‑555‑PULSE (1‑800‑555‑7857) | Customer Support → Privacy Operations |
| In‑App | Settings > Privacy > My Health Data Rights | Privacy Operations Team (via API) |

PulseWell does not require consumers to create a new account. Consumers with existing accounts can submit via the app or portal. Consumers without accounts can submit via email or phone.

---

## 3. Authentication Procedure

### 3.1 Authentication Steps

| Step | Action | Owner |
|:----:|--------|:-----:|
| 1 | Receive request; log in Jira Service Management (ticket type: MHMD‑Rights); timestamp auto‑recorded | Privacy Ops |
| 2 | Send acknowledgment email within 3 business days confirming receipt and ticket number | Privacy Ops |
| 3 | Verify identity: for portal/app requests, confirm authenticated session (user was logged in). For email/phone, send email verification link to registered email address | Privacy Ops |
| 4 | If verification fails (e.g., unrecognized email), request additional info: last 4 digits of phone on file, date of account creation, or device serial number | Privacy Ops |
| 5 | If still unverifiable after two attempts, notify consumer that the request cannot be processed and explain why | Privacy Ops + Legal |

### 3.2 Authentication Methods by Channel

| Channel | Primary Authentication | Fallback Authentication |
|---------|----------------------|------------------------|
| Online Portal | Logged‑in session + email verification code | Last 4 of phone + account creation date |
| Email | Reply from registered email + email verification link | Government ID upload (redacted) via secure portal |
| Phone | Account PIN (set during registration) + registered email confirmation | Security questions (date of birth + last device synced) |
| In‑App | Biometric unlock (Face ID / fingerprint) within authenticated session | App PIN + email verification code |

---

## 4. Request Processing Workflows

### 4.1 Right to Confirm & Access — PulseWell Workflow

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Authenticate consumer (Section 3) | Privacy Ops | Day 1–3 |
| 2 | Run data export query across: PostgreSQL (production), Snowflake (analytics), S3 (raw Band data), SendGrid (email logs), Insights Portal (sale records) | Data Engineering | Day 3–15 |
| 3 | Compile data package: all health data held + third‑party/affiliate list with contact info | Privacy Ops | Day 15–25 |
| 4 | Third‑party/affiliate list for this consumer: | | |
| | — AWS (processor): aws-privacy@amazon.com | | |
| | — SendGrid/Twilio (processor): privacy@twilio.com | | |
| | — HealthMetrics Research LLC (third party, data sold): data-partnerships@healthmetrics.com | | |
| | — AdTech Partner Co. (third party, data shared): privacy@adtechpartner.com | | |
| | — PulseWell Wearables Ltd. (affiliate): privacy@pulsewellwearables.co.uk | | |
| | — Partner clinic [if used booking]: contact info of specific clinic | | |
| 5 | Jordan Reeves (CPO) reviews package for completeness | CPO | Day 25–35 |
| 6 | Deliver to consumer via encrypted email or secure portal download | Privacy Ops | By Day 45 |

### 4.2 Right to Withdraw Consent — PulseWell Workflow

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Authenticate consumer | Privacy Ops | Day 1–3 |
| 2 | Confirm which consents to withdraw: collection only, sharing only, or both | Privacy Ops | Day 3–5 |
| 3 | Update consent database (consent_records table): set status = "withdrawn," timestamp = now | Data Engineering | Day 5–10 |
| 4 | If collection consent withdrawn: disable Band sync, stop symptom/med/mood data ingestion for this user; app shows "Health tracking paused" state | Product Engineering | Day 5–10 |
| 5 | If sharing consent withdrawn: remove user from AdTech Partner segment exports; disable clinic booking data sharing; flag user in Insights Portal as "no‑share" | Product Engineering | Day 5–10 |
| 6 | Send confirmation to consumer: "Your consent has been withdrawn. The following features are now unavailable: [list]. Your previously collected data has not been deleted — if you also wish to delete your data, please submit a separate deletion request." | Privacy Ops | By Day 45 |

### 4.3 Right to Delete — PulseWell Workflow

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Authenticate consumer | Privacy Ops | Day 1–3 |
| 2 | Run deletion inventory across all systems: | Data Engineering | Day 3–10 |
| | — PostgreSQL production DB (user profile, health records, consent records) | | |
| | — Snowflake analytics warehouse (aggregated metrics, user‑level rows) | | |
| | — S3 raw data bucket (raw Band telemetry files) | | |
| | — ML training pipeline (check if user data is in any active training set) | | |
| | — Application logs (health data references in structured logs) | | |
| 3 | Execute deletion from all production systems | Data Engineering | Day 10–20 |
| 4 | Initiate backup/archive deletion: AWS S3 Glacier archives, daily DB snapshots | DevOps / IT | Day 10–20 (completion within 6 months) |
| 5 | Send downstream deletion notifications to: | Privacy Ops | Day 10–15 |
| | — AWS (processor): confirm data purge from compute/storage | | |
| | — SendGrid (processor): delete email logs containing health data | | |
| | — HealthMetrics Research LLC (third party): delete any consumer‑level data received | | |
| | — AdTech Partner Co. (third party): delete user segment data | | |
| | — PulseWell Wearables Ltd. (affiliate): delete device telemetry | | |
| | — Any partner clinic that received booking data | | |
| 6 | Track downstream confirmations in Jira ticket; follow up at Day 25 if not received | Privacy Ops | Day 15–40 |
| 7 | Send consumer confirmation: "Your consumer health data has been deleted from our production systems. Backup deletion will be completed within 6 months. All third parties and affiliates have been notified." | Privacy Ops | By Day 45 |

**Downstream Notification — PulseWell Standard Email:**

> Subject: Consumer Health Data Deletion Request — PulseWell Inc. / MHMD  
>  
> To: [Recipient Privacy Contact]  
>  
> Pursuant to the Washington My Health My Data Act (RCW 19.373.040(1)(c)), we are notifying you that a consumer has exercised their right to delete their consumer health data. You have previously received this consumer's data from PulseWell Inc.  
>  
> **Action required:** Please delete all consumer health data associated with PulseWell consumer reference number PW‑DEL‑2026‑00147 from your records, including archived and backup systems, and confirm completion to compliance@pulsewell.com within 15 business days.  
>  
> Request reference: PW‑DEL‑2026‑00147  
> Date of consumer request: February 23, 2026  
>  
> Questions? Contact compliance@pulsewell.com or call 1‑800‑555‑PULSE.

### 4.4 Right to Appeal — PulseWell Workflow

| Step | Action | Owner | Deadline |
|:----:|--------|:-----:|:--------:|
| 1 | Consumer submits appeal via appeals@pulsewell.com or pulsewell.com/health-data-rights/appeal | Consumer | — |
| 2 | Log appeal in Jira linked to original request ticket | Privacy Ops | Day 1 |
| 3 | Jordan Reeves (CPO) reviews original decision, refusal rationale, and any new consumer information | CPO | Day 1–20 |
| 4 | If complex or legal risk flagged, escalate to Taylor Simmons (GC) for review | CPO → GC | Day 10–25 |
| 5 | Make appeal decision | CPO / GC | Day 25–35 |
| 6 | Send written response to consumer explaining decision and reasons | Privacy Ops | By Day 45 |
| 7 | If appeal denied, include AG referral: "You may file a complaint with the Washington State Attorney General at www.atg.wa.gov/file-complaint, by calling (800) 551‑4636, or by writing to: Attorney General's Office, 800 Fifth Avenue, Suite 2000, Seattle, WA 98104." | Privacy Ops | Included in response |

---

## 5. Timelines & Extensions

| Event | Deadline | PulseWell Target |
|-------|:--------:|:----------------:|
| Acknowledge receipt | 3 business days | Internal SLA |
| Respond to request | 45 days from receipt | Day 40 target (5‑day buffer) |
| Extension (if needed) | +45 days (90 total) | Notify consumer by Day 40 with reason |
| Backup/archive deletion | Up to 6 months | Target 90 days (DevOps quarterly purge cycle) |
| Respond to appeal | 45 days from receipt | Day 40 target |

---

## 6. Fees & Frequency Limits

- First two requests per consumer per year: **free**.  
- If a consumer submits more than 2 requests in a calendar year, or requests are manifestly unfounded/excessive/repetitive, PulseWell may charge a reasonable fee (estimated $25–50 to cover administrative costs) or decline to act.  
- Jordan Reeves (CPO) must approve any fee or declination in writing before it is communicated to the consumer.  
- PulseWell bears the burden of demonstrating the request is unfounded/excessive/repetitive.

---

## 7. Non‑Discrimination

PulseWell will not discriminate against any consumer for exercising MHMD rights:  
- No denial of app access or Band functionality.  
- No different subscription pricing.  
- No degraded service quality.  
- No retaliation of any kind.

---

## 8. Record‑Keeping

| Record | Retention Period |
|--------|:---------------:|
| Request received (date, channel, type, consumer ID, ticket number) | 6 years |
| Authentication records | 6 years |
| Actions taken (system queries, deletions, notifications) | 6 years |
| Response sent to consumer | 6 years |
| Downstream notification confirmations | 6 years |
| Appeal records | 6 years |

All records stored in PulseWell's compliance vault (encrypted S3 bucket with IAM‑restricted access, separate from production health data).

---

## 9. Roles & Responsibilities

| Role | Name / Title | Responsibilities |
|------|-------------|-----------------|
| Intake & Acknowledgment | Privacy Operations Team (3 staff) | Receive, log, acknowledge, deliver responses |
| Authentication | Privacy Ops + Customer Support | Verify consumer identity across channels |
| Data Search & Deletion | Data Engineering Team | Locate and delete data across all systems |
| Backup Deletion | DevOps / IT | Purge archived and backup systems |
| Downstream Notification | Jordan Reeves, CPO | Send and track deletion notices to all recipients |
| Appeal Review | Jordan Reeves (CPO) + Taylor Simmons (GC) | Review and decide appeals |
| Escalation | Taylor Simmons, General Counsel | AG inquiries, litigation, sensitive‑data requests |

---

## 10. Escalation Triggers

Immediately escalate to Taylor Simmons (GC) if:

- A request references the Washington Attorney General, a law firm, or threatens legal action.  
- A request involves data sold through the Insights Portal (implicates sale authorization records and HealthMetrics Research LLC).  
- A request involves reproductive health data (menstrual cycle tracker) or any sensitive category.  
- Authentication fails and the requester is persistent or adversarial.  
- Multiple requests received from the same law firm or appearing to be coordinated (class action signal).  
- A downstream recipient (especially HealthMetrics or AdTech Partner) refuses or fails to confirm deletion within 15 business days.  
- Any media inquiry related to health data privacy.

---

**End of Example**
