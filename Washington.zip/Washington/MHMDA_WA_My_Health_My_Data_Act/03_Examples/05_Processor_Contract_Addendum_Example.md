# Washington My Health My Data Act — Processor Contract Addendum (EXAMPLE)

**Document Title:** MHMD Processor Contract Addendum — PulseWell Inc. and Amazon Web Services  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.060 — Processors  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  

> **Purpose:** This example shows how PulseWell Inc. executes the MHMD Processor Contract Addendum with Amazon Web Services (AWS), its primary cloud infrastructure processor. A similar addendum would be executed with each processor (SendGrid/Twilio, etc.).

---

## MHMD PROCESSOR CONTRACT ADDENDUM

**Addendum Effective Date:** March 1, 2026

**Between:**

**Regulated Entity ("Controller"):**  
PulseWell Inc.  
1200 Wellness Way, Suite 400, Seattle, WA 98101  
Contact: Taylor Simmons, General Counsel  
Email: legal@pulsewell.com

**Processor ("Processor"):**  
Amazon Web Services, Inc.  
410 Terry Avenue North, Seattle, WA 98109  
Contact: AWS Privacy Team  
Email: aws-privacy@amazon.com

**Underlying Agreement:** AWS Enterprise Customer Agreement dated January 15, 2024 ("Agreement")

---

### 1. Definitions

For purposes of this Addendum, capitalized terms have the meanings given to them in the Washington My Health My Data Act (RCW Chapter 19.373) unless otherwise defined herein.

- **"Consumer Health Data"** has the meaning set forth in RCW 19.373.010(8).  
- **"Consumer"** has the meaning set forth in RCW 19.373.010(7).  
- **"Process" or "Processing"** has the meaning set forth in RCW 19.373.010(20).  
- **"MHMD"** means the Washington My Health My Data Act, RCW Chapter 19.373, as amended.

---

### 2. Scope of Processing

Processor shall process Consumer Health Data only as described in this Section and in accordance with Controller's documented instructions.

**(a) Categories of Consumer Health Data processed:**  
- Vital signs and biometric data (heart rate, blood oxygen, sleep patterns, heart rate waveforms)  
- Symptom and condition logs  
- Medication names, dosages, and schedules  
- Mood and behavioral wellness entries  
- Reproductive health data (menstrual cycle tracking)  
- Inferred/derived health data (wellness risk scores, stress scores)  
- Precise location data (from "Find a Clinic" sessions — transient, not stored long‑term)  
- Consumer account and profile data linked to the above health data  

**(b) Purpose(s) of processing:**  
- Cloud infrastructure hosting: storage, computation, and transmission of Consumer Health Data within PulseWell's application environment  
- Database hosting (Amazon RDS / PostgreSQL) for PulseWell's production health data  
- Object storage (Amazon S3) for raw PulseWell Band telemetry data  
- Analytics infrastructure (Amazon Redshift / Snowflake on AWS) for PulseWell's internal analytics  
- Backup and disaster recovery (Amazon S3 Glacier)  

**(c) Duration of processing:**  
Processing shall continue for the term of the AWS Enterprise Customer Agreement unless terminated earlier pursuant to Section 10 of this Addendum.

**(d) Nature of processing operations:**  
Storage, computation, transmission, backup, encryption, and disaster recovery of Consumer Health Data within AWS's us‑west‑2 (Oregon) region. AWS does not access, analyze, or use the contents of Consumer Health Data except as necessary to provide the cloud services described above.

---

### 3. Processing Instructions and Limitations

**(a)** AWS shall process Consumer Health Data only in a manner consistent with the binding instructions in this Addendum and PulseWell's AWS service configurations.

**(b)** AWS shall **not**:  
- Process Consumer Health Data for any purpose other than providing the cloud services described in Section 2(b).  
- Sell Consumer Health Data.  
- Share Consumer Health Data with any third party, affiliate, or sub‑processor except as expressly authorized by PulseWell or as necessary to provide the contracted services (e.g., AWS sub‑services within the us‑west‑2 region).  
- Combine Consumer Health Data with data from other AWS customers.  
- Use Consumer Health Data for AWS's own business purposes, including product development, advertising, model training, or profiling.

**(c)** If AWS believes an instruction from PulseWell violates MHMD or other applicable law, AWS shall promptly notify PulseWell in writing before acting on the instruction.

> **MHMD Warning:** If AWS fails to adhere to PulseWell's instructions or processes Consumer Health Data outside the scope of this Addendum, AWS shall be considered a regulated entity with respect to such data and shall be subject to all MHMD requirements, including the private right of action (RCW 19.373.060(1)(c)).

---

### 4. Technical and Organizational Measures

AWS shall implement and maintain appropriate technical and organizational measures to:

**(a)** Assist PulseWell in fulfilling its MHMD obligations, including responding to consumer deletion requests and access requests.

**(b)** Implement data security practices including:  
- AES‑256 encryption at rest for all stored Consumer Health Data (S3, RDS, Glacier)  
- TLS 1.2+ encryption in transit for all data transmission  
- IAM‑based role access controls restricting access to authorized PulseWell configurations only  
- SOC 2 Type II and ISO 27001 certified infrastructure  
- Continuous monitoring, intrusion detection, and incident response capabilities  

**(c)** Restrict access to Consumer Health Data to only those AWS personnel for whom access is necessary to maintain infrastructure operations (AWS does not routinely access customer data content).

---

### 5. Consumer Rights Assistance — Deletion Obligations

**(a)** Upon notification from PulseWell that a consumer has exercised their right to delete Consumer Health Data, AWS shall:  
- Support PulseWell's deletion operations through standard AWS data deletion APIs and tools (S3 object deletion, RDS record deletion, Glacier vault deletion).  
- Confirm that standard AWS deletion processes render data unrecoverable in accordance with AWS's published data disposal practices.  
- For archived data in S3 Glacier, deletion may take up to **six (6) months** from PulseWell's deletion request, consistent with RCW 19.373.040(1)(c)(iii).  
- Provide written confirmation of deletion completion upon PulseWell's request within **15 business days** of completing the deletion.

**(b)** AWS shall assist PulseWell in responding to consumer access and consent withdrawal requests by providing PulseWell with timely access to its own data through standard AWS console and API tools.

---

### 6. Sub‑Processors

**(a)** PulseWell acknowledges that AWS uses affiliated entities and infrastructure partners to deliver its cloud services. AWS shall maintain a list of sub‑processors involved in processing Consumer Health Data and make it available upon request.

**(b)** AWS shall enter into agreements with sub‑processors that impose obligations no less protective than those in this Addendum.

**(c)** Current authorized sub‑processors relevant to PulseWell's workload:

| Sub‑Processor Name | Processing Activity | Location |
|--------------------|-------------------|----------|
| Amazon Data Services, Inc. | Data center operations (us‑west‑2) | Oregon, USA |
| Amazon Technologies, Inc. | Network infrastructure | Oregon, USA |

---

### 7. Confidentiality

AWS ensures that all personnel authorized to access infrastructure hosting Consumer Health Data are bound by written confidentiality obligations and undergo background checks, consistent with AWS's SOC 2 Type II controls.

---

### 8. Audits and Inspections

**(a)** AWS shall make available to PulseWell its SOC 2 Type II audit reports, ISO 27001 certificates, and other compliance documentation upon request.

**(b)** PulseWell may request additional audit information or conduct a third‑party audit upon **30 days'** written notice, subject to AWS's standard audit cooperation terms in the Enterprise Customer Agreement. Audits shall not unreasonably interfere with AWS operations and may be conducted through review of AWS compliance reports and questionnaire responses.

**(c)** AWS shall promptly remediate any non‑compliance identified during an audit that is within AWS's responsibility under the shared responsibility model.

---

### 9. Data Breach Notification

AWS shall notify PulseWell without undue delay, and in no event later than **72 hours**, after becoming aware of any:  
- Unauthorized access to, disclosure of, or loss of Consumer Health Data stored on AWS infrastructure.  
- Security incident affecting the availability or integrity of PulseWell's AWS environment.  
- Any request, inquiry, or complaint from a consumer, regulator, or the Washington Attorney General directed to AWS relating to Consumer Health Data processed on PulseWell's behalf.

AWS shall cooperate fully with PulseWell in investigating, remediating, and responding to any such incident.

---

### 10. Term and Termination

**(a)** This Addendum shall remain in effect for the duration of the AWS Enterprise Customer Agreement.

**(b)** Upon termination or expiration of the underlying Agreement, or upon PulseWell's written request, AWS shall:  
- Cease all processing of Consumer Health Data.  
- Support PulseWell's data export and deletion through standard AWS tools.  
- Upon PulseWell's confirmation that export is complete, delete all Consumer Health Data from AWS systems (including Glacier backups within 6 months).  
- Certify deletion in writing within **30 days** of completing deletion.

---

### 11. Liability and Indemnification

**(a)** If AWS's failure to comply with this Addendum or MHMD results in PulseWell being subject to enforcement action, private lawsuit, fines, penalties, damages, or costs, AWS shall indemnify and hold harmless PulseWell for all such losses to the extent caused by AWS's breach, subject to the liability terms in the underlying Agreement.

**(b)** Nothing in the underlying Agreement shall limit AWS's liability for willful or grossly negligent breaches of this Addendum.

---

### 12. Governing Law

This Addendum shall be governed by the laws of the State of Washington. The parties acknowledge that MHMD violations are enforceable under the Washington Consumer Protection Act (RCW 19.86) and through a private right of action.

---

### 13. Order of Precedence

In the event of a conflict between this Addendum and the underlying Agreement, this Addendum shall control with respect to the processing of Consumer Health Data.

---

### 14. Signatures

**Controller — PulseWell Inc.**

Signature: ___________________________________  
Name: Taylor Simmons  
Title: General Counsel  
Date: ___________________________________

**Processor — Amazon Web Services, Inc.**

Signature: ___________________________________  
Name: ___________________________________  
Title: ___________________________________  
Date: ___________________________________

---

> **PulseWell implementation note:** This same addendum structure is executed with each processor:  
> - **SendGrid (Twilio Inc.)** — scope limited to email addresses + medication reminder content for transactional email delivery.  
> - **Any future processors** — must execute this addendum before receiving any Consumer Health Data.  
>  
> Taylor Simmons (GC) maintains the master list of executed addenda in PulseWell's compliance vault.

---

**End of Example**
