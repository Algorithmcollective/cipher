# Washington My Health My Data Act — Valid Authorization to Sell Consumer Health Data (EXAMPLE)

**Document Title:** MHMD Valid Authorization to Sell — PulseWell Inc. to HealthMetrics Research LLC  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.070 — Valid Authorization to Sell  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  

> **Purpose:** This example shows how PulseWell Inc. fills out the valid authorization to sell template for its Insights Program, where aggregated wellness data is sold to HealthMetrics Research LLC.

---

## VALID AUTHORIZATION TO SELL CONSUMER HEALTH DATA

> This is a standalone legal document. It is not combined with any other agreement, consent form, or terms of service.

---

### AUTHORIZATION TO SELL CONSUMER HEALTH DATA  
Pursuant to the Washington My Health My Data Act (RCW 19.373.070)

Please read this authorization carefully before signing. This document authorizes the sale of your consumer health data as described below.

---

**(a) Specific Consumer Health Data to Be Sold**

The following categories of your consumer health data will be sold:

- **De‑identified vital sign trend data:** Weekly and monthly averages of heart rate, resting heart rate, blood oxygen saturation (SpO2), and sleep duration derived from your PulseWell Band usage.  
- **Wellness risk score distributions:** Your anonymized wellness risk scores (calculated by PulseWell's algorithm from your biometric and activity data), grouped into statistical ranges.  
- **Medication category adherence rates:** Aggregated adherence rates by medication category (e.g., "cardiovascular," "mental health") based on your medication reminder usage — specific medication names are **not** included.  
- **Activity level summaries:** Weekly step count ranges, active minutes, and workout frequency.  
- **Demographic bracket:** Age range (e.g., 30–39) and general geographic region (e.g., Pacific Northwest) — your name, exact age, exact address, and other direct identifiers are **not** included.

Your name, email address, phone number, exact location, raw biometric waveforms, symptom logs, and reproductive health data are **never** sold under this authorization.

---

**(b) Seller — Name and Contact Information**

| | |
|--|--|
| **Name:** | PulseWell Inc. |
| **Address:** | 1200 Wellness Way, Suite 400, Seattle, WA 98101 |
| **Email:** | privacy@pulsewell.com |
| **Phone:** | 1‑800‑555‑PULSE (1‑800‑555‑7857) |

---

**(c) Purchaser — Name and Contact Information**

| | |
|--|--|
| **Name:** | HealthMetrics Research LLC |
| **Address:** | 500 Pharma Park Drive, Cambridge, MA 02142 |
| **Email:** | data-partnerships@healthmetrics.com |
| **Phone:** | 1‑617‑555‑0199 |

---

**(d) Purpose of the Sale**

**Why this data is being sold:**  
PulseWell participates in the PulseWell Insights Program, which provides aggregated, de‑identified wellness trend data to research organizations studying population health patterns. Revenue from the Insights Program helps fund continued development of free and premium PulseWell features.

**How the data will be gathered by the seller:**  
PulseWell's Data Engineering team extracts data from consenting Insights Program participants on a quarterly basis. Data is aggregated across participants (minimum cohort size of 50 per data point to prevent re‑identification), de‑identified by removing all direct identifiers, and exported in CSV format via a secure SFTP transfer.

**How the data will be used by the purchaser:**  
HealthMetrics Research LLC will analyze the data internally for population health research, including:  
- Identifying wellness and fitness trends across demographic brackets  
- Informing pharmaceutical product development and clinical trial design  
- Publishing anonymized research reports (no individual‑level data is published)  
- HealthMetrics may share aggregated, anonymized findings with its pharmaceutical clients in report form  

HealthMetrics will **not** use the data for: direct marketing to individuals, re‑identification of consumers, sale to third parties, or insurance underwriting.

---

**(e) Non‑Conditioning Statement**

The provision of goods or services by PulseWell Inc. may **not** be conditioned on you signing this authorization. You are not required to sign this authorization to use PulseWell's products or services. All PulseWell App features, PulseWell Band functionality, and customer support remain fully available to you regardless of whether you participate in the Insights Program.

---

**(f) Right to Revoke**

You have the right to revoke this authorization **at any time**. To revoke:

- Email privacy@pulsewell.com with the subject line "Revoke Sale Authorization"  
- Go to **Settings > Privacy > Insights Program > Revoke Authorization** in the PulseWell App  
- Call 1‑800‑555‑PULSE (1‑800‑555‑7857) and request revocation  

Upon revocation:  
- Your data will be excluded from all future quarterly data exports to HealthMetrics Research LLC.  
- Data already included in exports delivered prior to your revocation may not be retrievable from HealthMetrics. However, because data is aggregated and de‑identified before export, your individual data cannot be isolated in previously delivered datasets.  
- Revocation does not affect the lawfulness of any sale that occurred before the revocation.  
- Your PulseWell account and all features will continue to work normally after revocation.

---

**(g) Redisclosure Warning**

**IMPORTANT:** The consumer health data sold pursuant to this authorization **may be subject to redisclosure** by HealthMetrics Research LLC and **may no longer be protected** by the Washington My Health My Data Act once sold. HealthMetrics may share aggregated, anonymized research findings derived from the data with its pharmaceutical clients.

---

**(h) Expiration Date**

This authorization expires on: **February 23, 2027**

This date is one (1) year from the date of the consumer's signature below. After this date, this authorization is no longer valid and no further data exports may include your data under this authorization. If you wish to continue participating in the Insights Program after expiration, PulseWell will present a new authorization for your review and signature.

---

**(i) Consumer Signature and Date**

By signing below, I acknowledge that I have read and understood this authorization, including my right to revoke it at any time and the redisclosure warning above.

| | |
|--|--|
| **Signature:** | _Jane M. Wellsworth_ |
| **Printed Name:** | _Jane M. Wellsworth_ |
| **Date:** | _February 23, 2026_ |

---

## Post‑Execution Actions Completed (PulseWell Internal)

| Step | Action | Owner | Completed |
|:----:|--------|:-----:|:---------:|
| 1 | Signed copy emailed to jane.wellsworth@email.com via DocuSign | Privacy Ops | ✅ Feb 23, 2026 |
| 2 | Signed copy stored in compliance vault (S3: /compliance/sale-auth/2026/PW-SALE-2026-00312.pdf) | Privacy Ops | ✅ Feb 23, 2026 |
| 3 | Copy transmitted to HealthMetrics Research LLC via secure portal | Privacy Ops | ✅ Feb 23, 2026 |
| 4 | HealthMetrics confirmed receipt and 6‑year retention acknowledgment | Privacy Ops | ✅ Feb 24, 2026 |
| 5 | Expiration reminder set: January 24, 2027 (30 days before expiration) | Privacy Ops | ✅ Feb 23, 2026 |
| 6 | Logged in authorization tracking register | Privacy Ops | ✅ Feb 23, 2026 |

## Authorization Tracking Register Entry

| Auth ID | Consumer ID | Consumer Name | Signing Date | Purchaser | Data Categories | Expiration | Revoked? | Copy to Consumer? | Copy to Purchaser? | Vault Location |
|---------|------------|--------------|:------------:|-----------|----------------|:----------:|:--------:|:-----------------:|:------------------:|---------------|
| PW‑SALE‑2026‑00312 | USR‑884721 | Jane M. Wellsworth | Feb 23, 2026 | HealthMetrics Research LLC | Vital sign trends, wellness scores, med adherence, activity summaries, demo bracket | Feb 23, 2027 | No | Yes | Yes | /compliance/sale-auth/2026/PW-SALE-2026-00312.pdf |

---

**End of Example**
