# Washington My Health My Data Act — Training & Awareness Playbook (EXAMPLE)

**Document Title:** MHMD Training & Awareness Playbook for PulseWell Inc.  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  

> **Purpose:** This example shows how PulseWell Inc. implements its MHMD training program across three tiers, with specific content, schedules, and scenarios tailored to its wellness app and wearable business.

---

## 1. Training Program Overview

### 1.1 Objectives

- Ensure all 87 PulseWell employees and 12 contractors understand MHMD obligations relevant to their roles.  
- Reduce accidental violations — especially given the private right of action risk with ~340,000 WA consumers.  
- Build a documented compliance culture as evidence of good faith.  
- Make sure every team member knows: "When in doubt, ask Jordan (CPO) before acting."

### 1.2 Training Tiers

| Tier | Audience | Content Depth | Frequency | Duration |
|:----:|----------|:-------------:|:---------:|:--------:|
| Tier 1 — Awareness | All 87 employees + 12 contractors | High‑level overview | At hire + annually (March) | 30 min |
| Tier 2 — Operational | Product (14), Engineering (22), Data (8), Support (6), Marketing (5) = 55 staff | Detailed obligations + scenarios | At hire + annually (March) + role change | 60 min |
| Tier 3 — Specialist | Privacy Ops (3), Legal (2), Security/DevOps (4) = 9 staff | Deep‑dive + tabletop | At hire + semi‑annually (March + September) | 90 min |

---

## 2. Tier 1 — Company‑Wide Awareness Training

### 2.1 Module Outline (KnowBe4 — Online Self‑Paced)

| # | Topic | Key Points | Duration |
|:-:|-------|-----------|:--------:|
| 1 | What is MHMD? | WA law protecting consumer health data beyond HIPAA; PulseWell is a regulated entity; effective since March 2024 | 4 min |
| 2 | What is "consumer health data"? | Much broader than medical records: vital signs, biometrics, medication tracking, mood logs, location near clinics, **and data our algorithms infer from activity patterns** — all in scope | 5 min |
| 3 | Who is a "consumer"? | WA residents + anyone whose data is collected in WA; our ~340K WA users; does not include PulseWell employees acting in their job | 3 min |
| 4 | Why should you care? | Any consumer can sue PulseWell — treble damages up to $25K per person; AG fines up to $7,500 per violation; class actions are expected; one mistake can cost millions | 5 min |
| 5 | Basic dos and don'ts | Do: follow the consent flows built into the app; honor every deletion request immediately; escalate questions to Jordan Reeves (CPO). Don't: access health data without a business need; share data outside approved channels; ignore or delay a consumer request | 5 min |
| 6 | Who to contact | Questions → Jordan Reeves, CPO (jordan@pulsewell.com). Legal issues → Taylor Simmons, GC (taylor@pulsewell.com). Incidents → #incident-response Slack channel | 3 min |
| 7 | Quiz + acknowledgment | 8‑question multiple‑choice quiz (80% to pass) + electronic acknowledgment | 5 min |

---

## 3. Tier 2 — Operational Training

### 3.1 Module Outline (Live Virtual Workshop — Zoom)

| # | Topic | Key Points | Duration |
|:-:|-------|-----------|:--------:|
| 1 | Consent deep‑dive | Three layers: collection consent (onboarding screen), sharing consent (separate screen), sale authorization (Insights Program DocuSign). No dark patterns. Cannot bundle. Must be before data collection. | 8 min |
| 2 | Consumer rights workflow | Walk‑through of Jira‑based workflow: intake → authenticate → search → action → respond. 45‑day clock. Extension rules. Free 2x/year. | 10 min |
| 3 | Deletion procedures | Production deletion (PostgreSQL, Snowflake, S3) → backup deletion (Glacier, up to 6 months) → downstream notifications (AWS, SendGrid, HealthMetrics, AdTech Partner, clinics) → confirmation tracking | 8 min |
| 4 | Privacy policy compliance | Walk through PulseWell's published health data privacy policy; emphasize: cannot collect or share anything not listed without updating policy + getting new consent | 5 min |
| 5 | Sharing and sale rules | Sharing consent ≠ collection consent; sale authorization needs all 9 elements, consumer signature, 1‑year expiry, 6‑year retention by both parties | 7 min |
| 6 | Geofence prohibition | No geofences within 2,000 ft of health facilities; "Workout Zone" exclusion zone check; AdTech SDK audit status; applies to everyone in the chain | 5 min |
| 7 | Data security responsibilities | Only access what your role allows; no exports to personal devices; report suspicious access via #incident-response; follow RBAC | 5 min |
| 8 | Scenario exercises | 7 scenarios (see below) — breakout room discussions | 10 min |
| 9 | Quiz + acknowledgment | 10 scenario‑based questions (80% to pass) + electronic acknowledgment | 5 min |

### 3.2 Scenario Exercises

| # | Scenario | Answer |
|:-:|----------|--------|
| 1 | A consumer emails support@pulsewell.com: "I want to know what health data you have about me and who you've shared it with." | This is a Right to Confirm & Access request. Log in Jira (MHMD‑Rights ticket). Acknowledge within 3 business days. Authenticate. Compile data + full third‑party list with contact info. Respond within 45 days. |
| 2 | A consumer calls and says: "I want you to delete all my health data right now." | Right to Delete request. Don't ask why. Log in Jira. Authenticate. Initiate full deletion workflow: production → backups → downstream notifications to AWS, SendGrid, HealthMetrics (if Insights participant), AdTech, affiliate, and any partner clinic. Respond within 45 days. |
| 3 | The product team wants to add a blood pressure tracker to the PulseWell App. | New category of consumer health data (vital signs — blood pressure). Must update the health data privacy policy to include it, then obtain new affirmative consent from each user before collecting. Cannot go live until both steps are complete. |
| 4 | Marketing wants to create a "users who track medications" audience segment and share it with a new ad partner. | Sharing consumer health data with a new third party. Need: (1) update privacy policy to list new partner, (2) obtain separate sharing consent from affected users, (3) execute MHMD processor/third‑party addendum with the new partner. |
| 5 | A data engineer needs to pull 10,000 users' heart rate data to debug an algorithm issue. | Access minimum data needed. Use anonymized/pseudonymized data if possible. Log the access. Do not copy to personal devices. Delete the export when debugging is complete. If full PII is needed, get CPO approval first. |
| 6 | A user creates a "Workout Zone" geofence 1,500 feet from Swedish Medical Center in Seattle. | Within 2,000 ft of a health care facility. The system should block zone creation and display the compliance message. If the block wasn't triggered (gap), escalate to Product Engineering and CPO immediately. |
| 7 | A new research company contacts PulseWell wanting to buy anonymized sleep data. | Cannot sell without a new valid authorization signed by each consumer whose data would be included. The authorization must name this specific purchaser, describe the specific data, and include all 9 RCW 19.373.070 elements. Cannot reuse the HealthMetrics authorization. |

---

## 4. Tier 3 — Specialist Training

### 4.1 Module Outline (In‑Person Workshop — PulseWell Seattle Office)

| # | Topic | Key Points | Duration |
|:-:|-------|-----------|:--------:|
| 1 | MHMD statutory walk‑through | RCW 19.373.010–.100 section by section; definitions, obligations, exemptions, enforcement | 15 min |
| 2 | Enforcement landscape | Private right of action mechanics; treble damages math (340K users × $25K = catastrophic); BIPA litigation parallels ($650M Clearview AI, $228M TikTok settlements); first MHMD lawsuits filed against retailers for SDK location tracking | 15 min |
| 3 | Exemptions analysis | How to document HIPAA/GLBA/FCRA exemptions; security incident exception (burden is on us); what's NOT exempt (most of PulseWell's data) | 10 min |
| 4 | Consent & authorization drafting | Common errors: vague data descriptions, missing elements, compound documents, consent‑by‑scrolling; review PulseWell's current consent flows for weaknesses | 10 min |
| 5 | Processor contract review | Walk through PulseWell's AWS addendum; processor‑becomes‑regulated‑entity trigger; sub‑processor chain risk | 10 min |
| 6 | Incident response leadership | Roles during a health data breach; consumer notification decisions; AG notification timing; litigation hold procedures; PR coordination with comms team | 10 min |
| 7 | Emerging trends | Other states copying MHMD (Nevada SB 370, Connecticut health data proposals); federal health privacy developments; potential MHMD amendments | 10 min |
| 8 | Tabletop exercise | Scenario: PulseWell receives a class action demand letter from a Seattle plaintiff's firm alleging the AdTech Partner SDK geofenced near 47 pharmacies, collecting precise location data from 180,000 consumers. Walk through: litigation hold, SDK kill switch, scope assessment, consumer notification, AG communication, board briefing, insurance claim. | 20 min |

---

## 5. Training Schedule — 2026

| Training | Audience | Date | Facilitator |
|----------|---------|:----:|:-----------:|
| Tier 1 — Annual Awareness | All employees + contractors | March 15, 2026 | KnowBe4 (self‑paced, due by March 31) |
| Tier 2 — Annual Operational | 55 operational staff | March 20, 2026 (Zoom, 2 sessions: 10am + 2pm PT) | Jordan Reeves (CPO) |
| Tier 3 — Semi‑Annual Specialist (Spring) | 9 specialist staff | March 25, 2026 (in‑person, Seattle office) | Jordan Reeves (CPO) + Taylor Simmons (GC) |
| Tier 3 — Semi‑Annual Specialist (Fall) | 9 specialist staff | September 15, 2026 | Jordan Reeves + Taylor Simmons |

### New Hire Onboarding

- Tier 1: within 7 days of start date (KnowBe4 auto‑assigned by HR)  
- Tier 2: within 14 days of start date (next scheduled session or 1:1 with CPO)  
- Tier 3: within 21 days of start date (1:1 deep‑dive with CPO + GC)

---

## 6. Assessment and Acknowledgment

| Tier | Assessment | Passing Score | Remediation |
|:----:|-----------|:-------------:|-------------|
| Tier 1 | 8‑question multiple‑choice (KnowBe4) | 80% (6/8) | Retake module + quiz within 7 days; manager notified |
| Tier 2 | 10 scenario‑based questions (Google Form) | 80% (8/10) | Retake + 1:1 review with Jordan Reeves within 14 days |
| Tier 3 | Tabletop participation + written reflection (1 page) | Participation required | Follow‑up session with Taylor Simmons |

All participants sign electronic acknowledgment (DocuSign) confirming completion, understanding of obligations, knowledge of escalation contacts, and understanding that violations may result in disciplinary action up to and including termination.

---

## 7. Record‑Keeping

| Record | Retention | Storage |
|--------|:---------:|---------|
| Completion records (name, date, tier, score) | 6 years | HR system (BambooHR) + compliance vault |
| Signed acknowledgments | 6 years | DocuSign vault + S3 compliance bucket |
| Training materials (modules, slides, quizzes) | 6 years | Confluence + Google Drive (compliance folder) |
| Remediation records | 6 years | HR system |

---

## 8. Roles & Responsibilities

| Role | Name | Responsibilities |
|------|------|-----------------|
| Training Program Owner | Jordan Reeves, CPO | Develops content, schedules sessions, tracks completion, leads Tier 2 |
| Legal Content Reviewer | Taylor Simmons, GC | Reviews for legal accuracy, leads Tier 3, updates for legal changes |
| HR Integration | Maria Chen, HR Director | Integrates into onboarding, tracks completion in BambooHR, escalates non‑completion to managers |
| People Managers | All managers | Ensure team members complete training by deadlines |

---

## 9. Program Review

This playbook is reviewed and updated:  
- **Annually** (February, before March training cycle)  
- When MHMD is amended  
- When PulseWell launches new health data features  
- After any enforcement action, litigation, or significant incident  
- If assessment results show knowledge gaps (>20% failure rate on any tier)

**Next scheduled review:** February 2027

---

**End of Example**
