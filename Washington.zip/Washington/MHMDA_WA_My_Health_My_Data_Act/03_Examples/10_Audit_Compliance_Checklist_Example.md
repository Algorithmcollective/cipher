# Washington My Health My Data Act — Compliance Audit Checklist & Evidence Register (EXAMPLE)

**Document Title:** MHMD Compliance Audit Checklist & Evidence Register for PulseWell Inc.  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  
**Audit Period:** January 1, 2026 to February 23, 2026 (initial baseline audit)  

> **Purpose:** This example shows how PulseWell Inc. completes the master audit checklist, linking every statutory requirement to specific deliverables and evidence artifacts.

---

## 1. Scope & Applicability

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 1.1 | Determined regulated entity status | ✅ | WA_01 Scope Memo v1.0; PulseWell meets both prongs (WA business + collects health data) | Headquarters in Seattle; ~340K WA consumers |
| 1.2 | Identified all categories of consumer health data | ✅ | WA_01 Section 4 (13‑category table); 9 of 13 categories apply to PulseWell | Includes inferred/derived wellness scores |
| 1.3 | Identified all consumers affected | ✅ | WA_01 Section 3; ~340,000 WA‑based PulseWell App users | Count as of Jan 2026 from analytics dashboard |
| 1.4 | Assessed exemptions | ✅ | WA_01 Section 5; no HIPAA, GLBA, or other exemptions apply | PulseWell is not a HIPAA covered entity or BA |
| 1.5 | Mapped all data flows | ✅ | WA_01 Section 6 data flow diagram; 6 collection points, 6 sharing recipients, 1 sale relationship | Includes processors (AWS, SendGrid), third parties (HealthMetrics, AdTech), affiliate (Wearables Ltd.) |

---

## 2. Consumer Health Data Privacy Policy

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 2.1 | Separate privacy policy published | ✅ | WA_02 deployed at pulsewell.com/health-data-privacy | Separate from general privacy policy at /privacy |
| 2.2 | Prominent homepage link | ✅ | Screenshot: header + footer links labeled "Health Data Privacy" | Captured Feb 23, 2026 |
| 2.3 | App store + in‑app link | ✅ | App Store listing includes link; Settings > Privacy > Health Data Privacy Policy | Screenshots in evidence folder |
| 2.4 | Categories + purpose + use disclosed | ✅ | WA_02 Section 1 table: 9 categories with purpose and use for each | Matches WA_01 data inventory |
| 2.5 | Sources disclosed | ✅ | WA_02 Section 2: 4 sources (direct input, Band, app algorithms, clinic partners) | |
| 2.6 | Shared categories disclosed | ✅ | WA_02 Section 3 table: 4 sharing categories | |
| 2.7 | Third parties + specific affiliates by name | ✅ | WA_02 Section 4 table: AWS, SendGrid, HealthMetrics, AdTech Partner, PulseWell Wearables Ltd., partner clinics | Affiliate named specifically per MHMD requirement |
| 2.8 | Consumer rights exercise info | ✅ | WA_02 Section 5: email, portal URL, phone, 45‑day timeline, appeal process, AG referral | |
| 2.9 | No collection/sharing beyond disclosed | ✅ | No new data categories or sharing added since policy v1.0 published | Will re‑verify at next audit |
| 2.10 | Processor contracts consistent with policy | ✅ | WA_05 addenda executed with AWS and SendGrid; terms aligned with WA_02 disclosures | AdTech Partner addendum pending (see remediation) |

---

## 3. Consent Framework

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 3.1 | Collection consent before collection | ✅ | WA_03 Part A deployed in app onboarding; appears before Band sync | Screenshots + user flow recording |
| 3.2 | Consent for specified purpose | ✅ | Consent screen lists 4 specific purposes | |
| 3.3 | Sharing consent before sharing | ✅ | WA_03 Part B deployed as separate screen after collection consent | |
| 3.4 | Sharing consent separate from collection | ✅ | Separate checkbox, separate screen, independent affirmative action | UX team confirmed; screenshot evidence |
| 3.5 | Clear affirmative act (opt‑in) | ✅ | Checkboxes unchecked by default; requires tap to agree | |
| 3.6 | Freely given, specific, informed, voluntary | ✅ | Consent screens list specific data categories, purposes, and recipients | |
| 3.7 | Not in general ToS | ✅ | Health data consent is standalone flow; ToS acceptance is separate step | |
| 3.8 | No dark patterns | ✅ | "I agree" and "I do not agree" buttons are equal size, same color weight, no pre‑selection | UX audit report dated Feb 2026 |
| 3.9 | No consent by scrolling/hovering/muting | ✅ | Requires explicit checkbox tap; dismissing screen defaults to no consent | |
| 3.10 | No discrimination for declining | ✅ | Non‑consenting users retain access to non‑health features (account, firmware, support) | Tested Feb 2026 |
| 3.11 | Consent records maintained | ✅ | consent_records table in PostgreSQL: user_id, timestamp, version, categories, purposes, IP, device | 340K+ records; sample audit of 50 records verified |

---

## 4. Consumer Rights

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 4.1 | Confirm & access (data + third‑party list with contact info) | ✅ | WA_04 workflow in Jira; 3 access requests processed to date; all included full third‑party list | Sample response reviewed |
| 4.2 | Withdraw consent | ✅ | WA_04 Section 4.2; Settings > Privacy > Consent available; 7 withdrawals processed | |
| 4.3 | Delete from all systems + backups (6 months) | ✅ | WA_04 Section 4.3; 5 deletion requests processed; production + Snowflake + S3 confirmed deleted | Glacier deletions in progress (within 6‑month window) |
| 4.4 | Downstream deletion notifications | ✅ | Standard notification email template used; 5 sent to AWS, SendGrid for each deletion; HealthMetrics notified for 1 Insights participant | Confirmation receipts on file |
| 4.5 | Request methods match consumer interaction patterns | ✅ | Email, portal, phone, in‑app — mirrors how users normally interact with PulseWell | |
| 4.6 | No new account required | ✅ | Email and phone channels available for non‑account holders | |
| 4.7 | Commercially reasonable authentication | ✅ | WA_04 Section 3; multi‑method per channel; documented | |
| 4.8 | 45‑day response time | ✅ | All 15 requests to date responded within 28–39 days | Tracked in Jira |
| 4.9 | Free 2x/year | ✅ | No fees charged; no consumer has exceeded 2 requests | |
| 4.10 | Appeal process with AG referral | ⚠️ Partial | WA_04 Section 4.4 documented; appeal email/portal set up; no appeals received yet; AG referral language drafted but not tested end‑to‑end | Test with simulated appeal by March 2026 |

---

## 5. Data Security

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 5.1 | Access restricted to necessary personnel | ✅ | WA_06 Sections 1.1–1.4; IAM + PostgreSQL RLS; 34 total users across 6 systems | Quarterly access review current |
| 5.2 | Reasonable industry standard practices | ✅ | WA_06 Sections 2–4; SOC 2 Type II (Sept 2025), NIST CSF aligned, CIS Controls IG2 | |
| 5.3 | RBAC documented | ✅ | WA_06 Section 1.1; Confluence documentation | |
| 5.4 | Encryption at rest + in transit | ✅ | AES‑256 (KMS) at rest; TLS 1.3 in transit | WA_06 Section 3.1 |
| 5.5 | IR plan covers health data | ⚠️ Partial | IR Plan v2.1 exists; MHMD severity tier and notification templates in progress | Target: April 2026 |
| 5.6 | Industry framework adopted | ✅ | SOC 2 Type II + NIST CSF 2.0 + CIS Controls v8 IG2 + OWASP Top 10 | |

---

## 6. Processor Contracts

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 6.1 | Binding contract with every processor | ⚠️ Partial | AWS addendum executed (WA_05); SendGrid addendum executed; AdTech Partner addendum **not yet executed** | AdTech addendum target: March 15, 2026 |
| 6.2 | Clear processing instructions | ✅ | AWS addendum Section 2 specifies categories, purposes, operations | |
| 6.3 | Processor actions limited | ✅ | AWS addendum Section 3 prohibits all non‑authorized uses | |
| 6.4 | Processor aware of regulated entity trigger | ✅ | AWS addendum Section 3 includes MHMD warning clause | |
| 6.5 | Processor assists with deletion | ✅ | AWS addendum Section 5; deletion confirmation within 15 business days | |
| 6.6 | Sub‑processor controls | ✅ | AWS addendum Section 6; written consent required; 2 sub‑processors listed | |

---

## 7. Sale of Consumer Health Data

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 7.1 | Valid authorization before sale | ✅ | WA_08 deployed via DocuSign for Insights Program; 1,247 authorizations signed | |
| 7.2 | All 9 elements present | ✅ | WA_08 template verified against RCW 19.373.070(2)(a)–(i); sample of 20 signed auths reviewed | All 9 elements confirmed present |
| 7.3 | Standalone document | ✅ | DocuSign envelope contains only the sale authorization; no bundled documents | |
| 7.4 | Not conditioned on goods/services | ✅ | WA_08 Section (e) non‑conditioning statement; all app features available without signing | |
| 7.5 | Expiration ≤ 1 year | ✅ | All authorizations set to expire exactly 1 year from signature date | Renewal outreach starts 30 days before expiration |
| 7.6 | Copy provided to consumer | ✅ | DocuSign auto‑sends signed copy to consumer email | |
| 7.7 | Seller retains 6 years | ⚠️ Partial | Compliance vault exists but 6‑year lifecycle policy not yet configured | Target: April 2026 |
| 7.8 | Purchaser retains 6 years | ✅ | HealthMetrics confirmed 6‑year retention in writing (email on file) | |
| 7.9 | Revocation mechanism functional | ✅ | Email, app settings, and phone options tested; 23 revocations processed | |
| 7.10 | No sale under invalid authorization | ✅ | Pre‑export script checks authorization status (valid, not expired, not revoked) before including user in quarterly export | |

---

## 8. Geofence Prohibition

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 8.1 | No geofence for tracking near health facilities | ✅ | WA_07 assessment: no PulseWell‑deployed geofences target health facilities | |
| 8.2 | No geofence for data collection near health facilities | ✅ | "Find a Clinic" uses GPS search, not geofence; Band GPS is passive tracking with no virtual boundary | |
| 8.3 | No geofence for health‑related notifications near facilities | ⚠️ Partial | "Workout Zone" can be set near health facilities — exclusion zone check not yet implemented | Target: April 30, 2026 |
| 8.4 | Third‑party SDKs audited | ❌ | AdTech Partner Co. SDK audit not yet completed | HIGH PRIORITY — Target: April 1, 2026 |
| 8.5 | Pre‑deployment review process | ⚠️ Partial | Process documented in WA_07 Section 4.2 but not yet integrated into Jira product launch workflow | Target: March 15, 2026 |

---

## 9. Training & Awareness

| # | Requirement | Status | Evidence | Notes |
|:-:|-------------|:------:|----------|-------|
| 9.1 | Company‑wide awareness training | ⚠️ Partial | WA_09 Tier 1 module drafted; deployment via KnowBe4 scheduled March 15, 2026 | Not yet delivered to staff |
| 9.2 | Operational training | ⚠️ Partial | WA_09 Tier 2 content + scenarios ready; live workshop scheduled March 20, 2026 | |
| 9.3 | Specialist training | ⚠️ Partial | WA_09 Tier 3 content + tabletop ready; in‑person session scheduled March 25, 2026 | |
| 9.4 | Acknowledgments signed and retained | 🔲 Pending | DocuSign acknowledgment template created; will be executed at training sessions | |
| 9.5 | Program reviewed within 12 months | ✅ | Initial program created Feb 2026; next review scheduled Feb 2027 | |

---

## 10. Enforcement Readiness

| # | Readiness Item | Status | Evidence | Notes |
|:-:|---------------|:------:|----------|-------|
| 10.1 | AG inquiry response plan | ⚠️ Partial | GC has informal playbook; formal written plan to be documented by April 2026 | |
| 10.2 | Litigation hold procedures | ✅ | IT litigation hold SOP v1.3 covers health data preservation | |
| 10.3 | Insurance coverage reviewed | ✅ | Cyber policy reviewed Jan 2026; confirmed MHMD claims within coverage scope | Hartford policy #CY‑2026‑PW |
| 10.4 | Outside counsel identified | ✅ | Perkins Coie LLP (Seattle) — privacy litigation team | Engagement letter on file |
| 10.5 | 6‑year document retention | ⚠️ Partial | Policy drafted; S3 lifecycle rules for compliance vault in progress | Target: April 2026 |

---

## 11. Remediation Tracker — Consolidated

| # | Item | Gap | Risk | Action | Owner | Target | Status |
|:-:|:----:|-----|:----:|--------|:-----:|:------:|:------:|
| 1 | 6.1 | AdTech Partner processor addendum not executed | High | Execute MHMD addendum with AdTech Partner Co. | GC | Mar 15, 2026 | In progress |
| 2 | 8.4 | AdTech SDK not audited for geofence behavior | **Critical** | Complete SDK audit; obtain written geofence certification or remove SDK | CPO + Eng | Apr 1, 2026 | In progress |
| 3 | 8.3 | "Workout Zone" can be set near health facilities | Medium | Implement health facility exclusion zone check | Product Eng | Apr 30, 2026 | Planned |
| 4 | 8.5 | Pre‑deployment geofence review not in Jira workflow | Medium | Add mandatory geofence review step to product launch template | CPO | Mar 15, 2026 | Planned |
| 5 | 9.1–9.4 | Training not yet delivered | Medium | Complete all 3 tiers by March 31, 2026 | CPO + HR | Mar 31, 2026 | Scheduled |
| 6 | 5.5 | IR plan lacks MHMD severity tier + notification templates | Medium | Update IR Plan to v3.0 with MHMD tier | CPO + DevOps | Apr 15, 2026 | In progress |
| 7 | 7.7 / 10.5 | 6‑year retention lifecycle not configured in compliance vault | Medium | Configure S3 lifecycle + Glacier rules for 6‑year retention | DevOps + Legal | Apr 30, 2026 | Planned |
| 8 | 4.10 | Appeal process not tested end‑to‑end | Low | Run simulated appeal to verify full workflow | Privacy Ops | Mar 31, 2026 | Planned |
| 9 | 10.1 | AG inquiry response plan not formally documented | Medium | Draft and approve formal AG response playbook | GC | Apr 15, 2026 | Planned |

---

## 12. Audit Sign‑Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Audit Conducted By | Algorithm Collective LLC | _______________ | Feb 23, 2026 |
| Reviewed By | Jordan Reeves, Chief Privacy Officer | _______________ | _______________ |
| Approved By | Taylor Simmons, General Counsel | _______________ | _______________ |

**Next Scheduled Audit:** August 2026 (semi‑annual) then annually

---

## Appendix — Deliverable Cross‑Reference

| # | Title | Statutory Section(s) | Status |
|:-:|-------|:-------------------:|:------:|
| WA_01 | Scope & Applicability Memo | 19.373.010, .005 | ✅ Complete |
| WA_02 | Consumer Health Data Privacy Policy | 19.373.020 | ✅ Complete |
| WA_03 | Consent & Authorization Framework | 19.373.030, .070 | ✅ Complete |
| WA_04 | Consumer Rights Request & Deletion Workflow | 19.373.040 | ✅ Complete |
| WA_05 | Processor Contract Addendum | 19.373.060 | ⚠️ AdTech pending |
| WA_06 | Data Security Practices Checklist | 19.373.050 | ⚠️ 5 gaps in remediation |
| WA_07 | Geofence Compliance Assessment & Policy | 19.373.080 | ⚠️ SDK audit + exclusion zone pending |
| WA_08 | Valid Authorization to Sell | 19.373.070 | ⚠️ Vault lifecycle pending |
| WA_09 | Training & Awareness Playbook | Best practice | ⚠️ Delivery pending March 2026 |
| WA_10 | Compliance Audit Checklist & Evidence Register | All sections | ✅ This document |

**Overall Compliance Score: 42 of 51 items ✅ Compliant (82%) | 8 ⚠️ Partial | 1 ❌ Non‑Compliant**

**Critical priority:** AdTech SDK geofence audit (Item #2) — must complete before April 1, 2026 or remove SDK.

---

**End of Example**
