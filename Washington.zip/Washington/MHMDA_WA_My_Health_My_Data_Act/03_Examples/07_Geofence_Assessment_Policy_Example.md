# Washington My Health My Data Act — Geofence Compliance Assessment & Policy (EXAMPLE)

**Document Title:** MHMD Geofence Compliance Assessment & Policy for PulseWell Inc.  
**Law:** Washington My Health My Data Act (RCW Chapter 19.373)  
**Primary Section:** RCW 19.373.080 — Geofence Restrictions  
**Organization:** PulseWell Inc.  
**Prepared By:** Algorithm Collective LLC  
**Date:** February 23, 2026  
**Version:** 1.0  

> **Purpose:** This example shows how PulseWell Inc. assesses its location‑based features against the MHMD geofence prohibition and establishes a policy to prevent violations.

---

## Part 1 — Geofence Technology Inventory

### 1.1 Location Technology Inventory

| # | Technology / Feature | Type | Product | Purpose | Creates Virtual Boundary? | Radius / Range |
|:-:|---------------------|------|---------|---------|:-------------------------:|:--------------:|
| 1 | "Find a Clinic" GPS feature | GPS | PulseWell App | Displays nearby health care providers on a map at user's request | No — user‑initiated search, no persistent boundary | User‑selected radius (default 5 miles) |
| 2 | PulseWell Band GPS tracking | GPS | PulseWell Band | Records GPS coordinates during outdoor workouts for route mapping | No — passive recording, no virtual boundary | N/A (continuous track) |
| 3 | "Workout Zone" reminder | GPS + Geofence | PulseWell App | Sends a reminder notification when user enters a pre‑set location (e.g., their gym) | **Yes** — user creates a virtual boundary around a location of their choice | User‑configurable: 500 ft to 1 mile |
| 4 | Push notification for medication reminders | Time‑based only | PulseWell App | Sends medication reminder at scheduled time | No — time‑based, not location‑based | N/A |

### 1.2 Third‑Party / Partner Location Technologies

| # | Partner / Vendor | Technology Used | In PulseWell Products? | Purpose | Creates Virtual Boundary? |
|:-:|-----------------|----------------|:----------------------:|---------|:-------------------------:|
| 1 | AdTech Partner Co. | SDK with location‑based ad targeting | Yes (embedded in PulseWell App) | Serves location‑relevant wellness ads | **Unknown — requires SDK audit** |
| 2 | Google Maps Platform | Maps API | Yes (powers "Find a Clinic" map) | Renders map tiles and clinic locations | No — display only, no geofencing |

---

## Part 2 — Health Care Facility Proximity Analysis

### 2.1 Proximity Assessment

| # | Technology / Feature | Geofence Location(s) | Within 2,000 ft of Health Care Facility? | Facility Type | Risk Level |
|:-:|---------------------|---------------------|:----------------------------------------:|---------------|:----------:|
| 1 | "Find a Clinic" GPS | No fixed geofence — user‑initiated search | N/A (no geofence deployed) | N/A | Low |
| 2 | Band GPS tracking | No geofence — passive track recording | N/A (no geofence deployed) | N/A | Low |
| 3 | "Workout Zone" reminder | User‑defined locations | **Possible** — a user could set a workout zone within 2,000 ft of a clinic, hospital, or pharmacy | Hospital, clinic, pharmacy, therapy office | **Medium** |
| 4 | AdTech Partner Co. SDK | Unknown | **Unknown** — SDK behavior not yet audited | Unknown | **High** |

### 2.2 Assessment Methodology

- Proximity determination: For the "Workout Zone" feature, PulseWell does not currently check user‑defined zone coordinates against health care facility locations. This is a gap.  
- Data source for health care facilities: Not yet integrated. Recommended: Washington State DOH facility registry + CMS National Provider database.  
- Re‑assessment frequency: To be established (recommended quarterly).

---

## Part 3 — Prohibited Use Assessment

### 3.1 "Workout Zone" Reminder Feature

| Prohibited Purpose | Used for This? | Evidence / Explanation |
|-------------------|:--------------:|----------------------|
| Identify or track consumers seeking health care services | No (by design) | Feature is designed for gym/park reminders. However, a user *could* set a zone around a health facility. PulseWell does not verify zone locations. |
| Collect consumer health data from consumers | No (by design) | The zone trigger only fires a local push notification. No health data is collected when entering the zone. However, the zone entry event is logged (timestamp + location), which could constitute precise location data near a health facility. |
| Send notifications related to health data or health care services | **Possible risk** | The notification content is a generic "You're near your workout spot! Ready to exercise?" message — not health‑care‑specific. But if a user sets a zone around a clinic and the notification fires, it could be argued the notification is related to health care services. |

**Assessment:** The "Workout Zone" feature is **not intentionally** used for prohibited purposes, but its design creates a compliance gap because PulseWell does not prevent users from setting zones near health care facilities and does not filter out health‑care‑proximate zone triggers.

### 3.2 AdTech Partner Co. SDK

| Prohibited Purpose | Used for This? | Evidence / Explanation |
|-------------------|:--------------:|----------------------|
| Identify or track consumers seeking health care services | **Unknown** | SDK audit not yet completed. Location‑based ad SDKs commonly use geofencing for targeting. |
| Collect consumer health data from consumers | **Unknown** | SDK may collect precise location data and transmit to AdTech Partner Co. servers. |
| Send notifications related to health data or health care services | **Unknown** | SDK may trigger location‑based ad notifications. If near a health facility, this could violate RCW 19.373.080(3). |

**Assessment:** The AdTech Partner Co. SDK is **high risk** and requires an immediate audit.

### 3.3 Overall Geofence Compliance Determination

| Feature | Within 2,000 ft? | Prohibited Purpose? | Compliant? | Required Action |
|---------|:-----------------:|:-------------------:|:----------:|----------------|
| "Find a Clinic" GPS | N/A (no geofence) | No | ✅ Yes | None — document as compliant |
| Band GPS tracking | N/A (no geofence) | No | ✅ Yes | None — document as compliant |
| "Workout Zone" reminder | Possible (user‑defined) | Possible (indirect) | ⚠️ Conditional | Implement health facility exclusion zone (see remediation) |
| AdTech Partner Co. SDK | Unknown | Unknown | ❌ Unknown | Immediate SDK audit required |

---

## Part 4 — Geofence Compliance Policy

### 4.1 Policy Statement

PulseWell Inc. prohibits the use of geofencing technology within 2,000 feet of any entity that provides in‑person health care services for the purpose of:  
- Identifying or tracking consumers seeking health care services;  
- Collecting consumer health data from consumers; or  
- Sending notifications, messages, or advertisements to consumers related to their consumer health data or health care services.

This prohibition applies to PulseWell, its employees, processors, contractors, advertising partners (including embedded SDKs), and any other person acting on PulseWell's behalf.

### 4.2 Pre‑Deployment Review Requirement

Before deploying any new geofence or location‑based feature, PulseWell must:

| Step | Action | Owner |
|:----:|--------|:-----:|
| 1 | Document geofence parameters (coordinates, radius, technology, purpose) | Product Engineering |
| 2 | Run proximity check against WA DOH + CMS health care facility database | Jordan Reeves (CPO) |
| 3 | Confirm feature is not used for any of the three prohibited purposes | Jordan Reeves (CPO) |
| 4 | If concern exists, escalate to Taylor Simmons (GC) before deployment | Taylor Simmons (GC) |
| 5 | Log approval/denial in geofence compliance log (Confluence) | Jordan Reeves (CPO) |

### 4.3 Third‑Party and SDK Controls

- **AdTech Partner Co.:** Must provide written certification that its SDK does not implement geofences within 2,000 feet of health care facilities for prohibited purposes. Certification due by **April 1, 2026**.  
- **All future SDK/ad partners:** Must include MHMD geofence compliance clause in their contract before SDK integration is approved.  
- **Google Maps Platform:** Low risk (display only, no geofencing). No additional action required.

### 4.4 Ongoing Monitoring

| Activity | Frequency | Owner |
|----------|:---------:|:-----:|
| Re‑run proximity analysis for "Workout Zone" locations | Quarterly | CPO + Data Engineering |
| Audit AdTech Partner Co. SDK geofence behavior | Semi‑annually | CPO + Product Engineering |
| Review new health care facility openings near common user zone locations | Quarterly | CPO |
| Update health care facility database | Quarterly | Data Engineering |
| Spot‑check SDK network traffic for geofence‑related API calls | Semi‑annually | DevOps + CPO |

### 4.5 Violation Response

If a geofence is discovered to be in violation:

| Step | Action | Owner | Timeline |
|:----:|--------|:-----:|:--------:|
| 1 | Immediately disable the geofence or feature | Product Engineering | Within 24 hours |
| 2 | Notify Taylor Simmons (GC) | Jordan Reeves (CPO) | Within 24 hours |
| 3 | Assess scope: duration active, consumers affected, data collected/sent | CPO + Data Engineering | Within 72 hours |
| 4 | Document in geofence compliance log | CPO | Within 1 week |
| 5 | If health data was collected, assess consumer notification/deletion needs | GC | Within 1 week |
| 6 | Implement preventive controls | Product Engineering + CPO | Within 30 days |

---

## Part 5 — Enforcement Risk

| Risk Factor | PulseWell Assessment |
|-------------|---------------------|
| AG civil penalties ($7,500/violation) | Medium — "Workout Zone" is not intentionally targeting health facilities, but gap exists |
| Private right of action (treble damages up to $25,000) | Medium‑High — if SDK is geofencing near pharmacies/clinics, class could be large |
| Class action risk | High for SDK issue — SDK runs on all ~340,000 WA users' devices |
| Reputational risk | High — "wellness app geofencing near clinics" is a damaging headline |

---

## Part 6 — Remediation Plan

| # | Issue | Risk | Remediation | Owner | Target Date | Status |
|:-:|-------|:----:|-------------|:-----:|:-----------:|:------:|
| 1 | "Workout Zone" allows zones near health facilities | Medium | Implement server‑side check: when user creates a zone, cross‑reference coordinates against health facility database. If within 2,000 ft, block zone creation and display message: "This location is near a health care facility and cannot be used as a Workout Zone under Washington privacy law." | Product Eng | April 30, 2026 | Planned |
| 2 | AdTech Partner Co. SDK not audited for geofence behavior | High | Conduct full SDK audit (network traffic analysis + code review). Request written MHMD geofence certification from AdTech Partner Co. If certification not received by April 1, 2026, remove SDK. | CPO + Product Eng | April 1, 2026 | In progress |
| 3 | No health care facility database integrated | Medium | Integrate WA DOH facility registry + CMS National Provider database into internal compliance tools for proximity checks | Data Eng | April 15, 2026 | Planned |
| 4 | No pre‑deployment geofence review process | Medium | Implement mandatory review checklist (Section 4.2) in product launch workflow (Jira template) | CPO | March 15, 2026 | Planned |

---

## Part 7 — Record‑Keeping

| Record | Retention Period |
|--------|:---------------:|
| Geofence technology inventory | 6 years |
| Proximity analysis results | 6 years |
| Prohibited use assessments | 6 years |
| Pre‑deployment review logs | 6 years |
| Third‑party geofence certifications | 6 years |
| Violation incident reports | 6 years |
| SDK audit reports | 6 years |

All records stored in PulseWell compliance vault (Confluence + encrypted S3 backup).

---

**End of Example**
